"""Compare: graded companies side by side, the best in each row marked.

Everything comes from what Tarsier already has (SEC filings, your projections) plus the market price
fetched by prices.py. Nothing here goes to the SEC.
"""
from . import mobile, pipeline, prices  # noqa: F401  (mobile imports compare lazily)

MAX = 5

# (section, key, label, kind, better, help) — better: "high", "low" or None (not ranked)
ROWS = [
    ("Grade", "grade", "Grade", "grade", "high", "The latest quarter's grade and score out of 100."),
    ("Grade", "business", "Business grade", "text", None, "From page 3: shown once all five pillars are filled."),
    ("Growth and margins · latest quarter vs the same quarter a year ago", "revenue", "Revenue (quarter)", "money", None,
     "Revenue of the latest quarter."),
    ("Growth and margins · latest quarter vs the same quarter a year ago", "rev_yoy", "Revenue growth YoY", "pct+", "high",
     "Latest quarter vs the same quarter a year earlier."),
    ("Growth and margins · latest quarter vs the same quarter a year ago", "gross", "Gross margin", "pct", "high", ""),
    ("Growth and margins · latest quarter vs the same quarter a year ago", "operating", "Operating margin", "pct", "high", ""),
    ("Growth and margins · latest quarter vs the same quarter a year ago", "net", "Net margin", "pct", "high", ""),
    ("Growth and margins · latest quarter vs the same quarter a year ago", "fcf_margin", "FCF margin (12 months)", "pct",
     "high", "Free cash flow over the last 12 months, as % of revenue."),
    ("Growth and margins · latest quarter vs the same quarter a year ago", "eps", "EPS GAAP (quarter)", "eps", None,
     "Diluted earnings per share, as reported."),
    ("Growth and margins · latest quarter vs the same quarter a year ago", "eps_yoy", "EPS growth YoY", "pct+", "high",
     "Only when both quarters were profitable."),
    ("Balance", "net_cash", "Net cash (debt)", "money", "high", "Cash and investments minus debt. Negative = net debt."),
    ("Balance", "dilution", "Share count YoY", "pct+", "low", "Change in basic shares vs a year ago: lower is better."),
    ("Valuation · at the market price", "price", "Share price", "usd", None, "Today's price, fetched when you compare."),
    ("Valuation · at the market price", "market_cap", "Market cap", "money", None, ""),
    ("Valuation · at the market price", "pe", "P/E (12 months)", "x", "low", "Price ÷ GAAP EPS of the last 4 quarters."),
    ("Valuation · at the market price", "fpe", "Forward P/E", "x", "low",
     "Price ÷ EPS of the next full fiscal year in your base case (page 2), not analysts' consensus."),
    ("Valuation · at the market price", "peg", "PEG", "x2", "low",
     "Forward P/E ÷ yearly EPS growth over the two years after (base case). Below 1 is cheap for the growth."),
    ("Valuation · at the market price", "ev_sales", "EV / Sales", "x", "low", "Enterprise value ÷ revenue of the last 12 months."),
    ("Valuation · at the market price", "ev_ebitda", "EV / EBITDA", "x", "low", "Enterprise value ÷ EBITDA of the last 12 months."),
    ("Valuation · at the market price", "fcf_yield", "FCF yield", "pct", "high", "Free cash flow of the last 12 months ÷ market cap."),
    ("Valuation · at the market price", "fair_value", "Fair value", "usd", None, "Page 2, after the margin of safety."),
    ("Valuation · at the market price", "upside", "Upside to fair value", "pct+", "high", ""),
]


def tickers():
    return mobile.companies()


def sector_of(t):
    return mobile._sector(t)


def cached_price(t):
    """The last price fetched for t, marked stale when older than 15 minutes (no network)."""
    import time
    c = prices._load().get(t.upper())
    if not c:
        return None
    return dict(c, stale=time.time() - c.get("fetched", 0) > prices.FRESH_SECONDS)


def metrics(t, market=None, fetch=False, progress=None):
    """One column of the table: {key: value} plus the labels shown at the top.
    fetch=True: a ticker never graded is fetched from the SEC and graded now, marked as a quick look."""
    t = t.upper()
    try:
        out = pipeline.run(t, mobile._watch_row(t), offline=True)
    except Exception as e:
        if not fetch or "no cached data" not in str(e):
            raise
        if progress:
            progress(f"{t}: not graded yet, getting it from the SEC…")
        out = pipeline.run(t, {}, offline=False)
        pipeline.mark_quick(t, "compare")
    return from_out(out, market)


def from_out(out, market=None, v=None, biz=None):
    """The same column from a grading already done (the phone export passes its own valuation)."""
    t = out["ticker"].upper()
    rs = sorted(out["results"], key=lambda r: r["end"])
    if not rs:
        raise RuntimeError(f"{t}: no graded quarter yet")
    r, co = rs[-1], out.get("company")
    n = mobile._numbers(co, r["end"]) or {}
    cur, prior = n.get("cur") or {}, n.get("prior") or {}
    v = v if v is not None else (mobile._valuation(out, co, market) or {})
    m = v.get("multiples") or {}
    biz = biz if biz is not None else (mobile._business(out) or {})
    dil = next((p["value"] for p in r.get("parts", {}).get("balance", [])
                if p["id"] == "dilution" and isinstance(p.get("value"), (int, float))), None)
    eps_yoy = None
    if cur.get("eps") and prior.get("eps") and cur["eps"] > 0 and prior["eps"] > 0:
        eps_yoy = (cur["eps"] / prior["eps"] - 1) * 100
    h = (out.get("projection") or {}).get("hist") or {}
    sec = mobile._sector(t)
    return {
        "ticker": t, "name": out["name"], "label": r["label"], "sector": sec["sector"], "industry": sec["industry"],
        "grade": (r["grade"], r["score"]), "provisional": r.get("provisional"), "preliminary": r.get("preliminary"),
        "business": biz.get("grade") or "—",
        "revenue": cur.get("revenue"), "rev_yoy": cur.get("revenue_yoy"), "gross": cur.get("gross"),
        "operating": cur.get("operating"), "net": cur.get("net"), "fcf_margin": (r.get("fcf") or {}).get("margin_ttm"),
        "eps": cur.get("eps"), "eps_yoy": eps_yoy,
        "net_cash": h.get("net_cash"), "dilution": dil,
        "price": m.get("price") or v.get("price"), "price_source": v.get("price_source"),
        "market_cap": m.get("market_cap"), "pe": m.get("pe"), "fpe": m.get("fpe"), "fwd_year": m.get("fwd_year"),
        "peg": m.get("peg"), "ev_sales": m.get("ev_sales"), "ev_ebitda": m.get("ev_ebitda"),
        "fcf_yield": m.get("fcf_yield"), "fair_value": v.get("fair_value"), "upside": v.get("upside"),
        "base": m.get("base"), "quick": pipeline.quick(t),
    }


def _rank_value(key, kind, val):
    if val is None:
        return None
    if kind == "grade":
        return val[1]
    if not isinstance(val, (int, float)):
        return None
    if key in ("pe", "fpe", "peg", "ev_sales", "ev_ebitda") and val <= 0:
        return None                      # a negative multiple is not "cheap"
    return val


def best(cols, key, kind, better):
    """Index of the best column for this row, or None (fewer than two comparable values, or a tie)."""
    if not better:
        return None
    vals = [(i, _rank_value(key, kind, c.get(key))) for i, c in enumerate(cols)]
    vals = [(i, x) for i, x in vals if x is not None]
    if len(vals) < 2:
        return None
    pick = max(vals, key=lambda p: p[1]) if better == "high" else min(vals, key=lambda p: p[1])
    if sum(1 for _i, x in vals if x == pick[1]) > 1:
        return None
    return pick[0]


def fmt(kind, val):
    if val is None:
        return "—"
    if kind == "grade":
        g, s = val
        return f"{g or '—'}  {s:.1f}" if s is not None else (g or "—")
    if kind == "text":
        return str(val)
    if kind == "money":                  # $ millions in, plain words out
        a = abs(val)
        t = f"${a / 1e3:,.1f}B" if a >= 1e3 else f"${a:,.0f}M"
        return ("−" if val < 0 else "") + t
    if kind == "usd":
        return f"${val:,.2f}"
    if kind == "eps":
        return ("−" if val < 0 else "") + f"${abs(val):.2f}"
    if kind == "pct":
        return f"{val:.1f}%"
    if kind == "pct+":
        return f"{val:+.1f}%".replace("-", "−")
    if kind == "x":
        return f"{val:.1f}×"
    if kind == "x2":
        return f"{val:.2f}"
    return str(val)
