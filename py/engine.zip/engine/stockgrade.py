"""The stock's grade, from its fundamentals: five axes (Value, Future, Past, Health, Dividend), a grade from
A+ to F, a one-line summary, and the rewards and risks behind it.

Each measure scores 0–100. Half comes from the peers (equal to their median = 50, twice as good = 100),
half from fixed bands that depend on the business model (a bank is not valued like software).
Value is mostly growth-adjusted: a bank at 20× earnings growing 30% a year is cheap, not expensive.
Only this page uses it: the Earnings results grade is about the quarter.
"""
import math
from datetime import date

WEIGHTS = {"Value": 30, "Future": 25, "Past": 20, "Health": 25}
DIVIDEND_WEIGHT = 10          # added (and everything rescaled) only when the company pays a dividend
AXES = ["Value", "Future", "Past", "Health", "Dividend"]

# bands: (value, score) points, straight lines between them; the ends hold
BANDS = {
    "pe": [(8, 100), (12, 85), (18, 65), (25, 45), (35, 25), (50, 10), (70, 0)],
    "pe_bank": [(6, 100), (9, 85), (12, 65), (15, 45), (20, 25), (28, 0)],
    "pb_bank": [(0.7, 100), (1.0, 80), (1.5, 55), (2.2, 30), (3.5, 0)],
    "ev_sales": [(2, 100), (4, 80), (7, 60), (11, 40), (16, 20), (25, 0)],
    "ev_ebitda": [(5, 100), (8, 80), (12, 60), (16, 40), (22, 20), (32, 0)],
    "peg": [(0.5, 100), (1.0, 80), (1.5, 62), (2.0, 48), (3.0, 25), (4.5, 0)],
    "upside": [(-0.4, 0), (-0.15, 25), (0, 45), (0.15, 68), (0.3, 85), (0.5, 100)],
    "eps_fwd": [(-0.05, 0), (0, 20), (0.08, 50), (0.15, 72), (0.25, 90), (0.35, 100)],
    "rev_fwd": [(-0.05, 0), (0, 20), (0.06, 45), (0.12, 68), (0.2, 85), (0.3, 100)],
    "growth_past": [(-0.1, 0), (0, 25), (0.08, 50), (0.15, 70), (0.25, 88), (0.4, 100)],
    "eps_yoy": [(-0.3, 0), (0, 30), (0.1, 55), (0.25, 75), (0.5, 92), (1.0, 100)],
    "op_margin": [(-0.1, 0), (0, 20), (0.1, 50), (0.2, 72), (0.3, 88), (0.4, 100)],
    "roic": [(0, 10), (0.08, 45), (0.15, 72), (0.25, 92), (0.35, 100)],
    "roe_bank": [(0.04, 10), (0.08, 40), (0.12, 65), (0.16, 85), (0.2, 100)],
    "net_debt_ebitda": [(-0.5, 100), (0, 92), (1, 80), (2, 62), (3, 40), (4.5, 15), (6, 0)],
    "current": [(0.6, 0), (0.9, 25), (1.2, 50), (1.6, 72), (2.2, 90), (3, 100)],
    "debt_eq": [(0, 100), (0.3, 88), (0.7, 68), (1.2, 45), (2, 22), (3, 0)],
    "fcf_margin": [(-0.1, 0), (0, 30), (0.05, 55), (0.12, 78), (0.2, 95), (0.3, 100)],
    "dilution": [(-0.02, 100), (0, 92), (0.02, 70), (0.05, 38), (0.1, 0)],
    "roa_bank": [(0.002, 10), (0.006, 40), (0.01, 65), (0.014, 85), (0.018, 100)],
    "yield": [(0.005, 15), (0.01, 30), (0.02, 55), (0.03, 75), (0.045, 90), (0.06, 100)],
    "payout": [(0.3, 100), (0.5, 90), (0.7, 70), (0.85, 45), (1.0, 20), (1.2, 0)],
    "div_growth": [(-0.05, 0), (0, 25), (0.03, 50), (0.07, 75), (0.12, 100)],
}


def band(v, name):
    pts = BANDS[name]
    if v is None:
        return None
    if v <= pts[0][0]:
        return float(pts[0][1])
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        if v <= x1:
            return y0 + (y1 - y0) * (v - x0) / (x1 - x0)
    return float(pts[-1][1])


def vs_peers(v, med, better, kind="ratio"):
    """50 at the peers' median. Multiples: by ratio (twice as cheap = 100). Percentages: by points (+15 pts = 100)."""
    if v is None or not med:
        return None
    m = med[0]
    if kind == "ratio":
        if v <= 0 or m <= 0:
            return None
        r = (m / v) if better == "low" else (v / m)
        return max(0.0, min(100.0, 50 + 50 * math.log2(r)))
    d = (v - m) if better == "high" else (m - v)
    return max(0.0, min(100.0, 50 + d / 0.15 * 50))


def mix(*parts):
    """Weighted average of (score, weight) pairs, skipping the missing ones."""
    got = [(s, w) for s, w in parts if s is not None]
    if not got:
        return None
    return sum(s * w for s, w in got) / sum(w for _s, w in got)


def both(abs_score, peer_score):
    return mix((abs_score, 1), (peer_score, 1))


def _value(v, med, model):
    """40% growth-adjusted, 30% your fair value, 30% the model's own multiple against the peers and its bands."""
    peg = band(v.get("peg"), "peg")
    peg_ttm = vs_peers(v.get("peg_ttm"), med.get("peg_ttm"), "low")
    growth_adj = mix((peg, 0.7), (peg_ttm, 0.3))
    fv = band(v.get("fv_upside"), "upside")
    if model in ("bank", "insurer"):
        mult = mix((both(band(v.get("pe"), "pe_bank"), vs_peers(v.get("pe"), med.get("pe"), "low")), 0.5),
                   (both(band(v.get("pb"), "pb_bank"), vs_peers(v.get("pb"), med.get("pb"), "low")), 0.5))
        used = "P/E and P/B"
    elif model in ("software", "unprofitable_growth", "pre_revenue"):
        mult = both(band(v.get("ev_sales"), "ev_sales"), vs_peers(v.get("ev_sales"), med.get("ev_sales"), "low"))
        used = "EV/Sales"
    elif model in ("energy", "capital_heavy", "reit"):
        mult = both(band(v.get("ev_ebitda"), "ev_ebitda"), vs_peers(v.get("ev_ebitda"), med.get("ev_ebitda"), "low"))
        used = "EV/EBITDA"
    else:
        mult = both(band(v.get("pe"), "pe"), vs_peers(v.get("pe"), med.get("pe"), "low"))
        used = "P/E"
    parts = [("Growth-adjusted (PEG)", growth_adj, 40), ("Against your fair value", fv, 30),
             (f"{used} vs peers and its usual range", mult, 30)]
    return mix(*[(s, w) for _n, s, w in parts]), parts


def _future(v, _med, _model):
    if v.get("estimates_sourced") is False:      # no guidance, no consensus: a guess is not graded
        return None, [("No guidance or analyst consensus yet (page 2): not graded", None, 0)]
    parts = [("EPS growth expected (5 years)", band(v.get("eps_next_5y"), "eps_fwd"), 60),
             ("Revenue growth expected (5 years)", band(v.get("rev_next_5y"), "rev_fwd"), 40)]
    return mix(*[(s, w) for _n, s, w in parts]), parts


def _past(v, med, model):
    growth = mix((band(v.get("sales_past_3y"), "growth_past"), 1), (band(v.get("eps_past_3y"), "growth_past"), 1),
                 (both(band(v.get("eps_yoy_ttm"), "eps_yoy"), vs_peers(v.get("eps_yoy_ttm"), med.get("eps_yoy_ttm"),
                                                                        "high", "pts")), 1))
    if model in ("bank", "insurer"):
        quality = both(band(v.get("roe"), "roe_bank"), vs_peers(v.get("roe"), med.get("roe"), "high", "pts"))
        qname = "Return on equity vs peers"
    else:
        quality = mix((both(band(v.get("op_margin"), "op_margin"), vs_peers(v.get("op_margin"), med.get("op_margin"),
                                                                            "high", "pts")), 1),
                      (both(band(v.get("roic"), "roic"), vs_peers(v.get("roic"), med.get("roic"), "high", "pts")), 1))
        qname = "Margins and ROIC vs peers"
    parts = [("Growth: sales and EPS, 3 years and last 12 months", growth, 50), (qname, quality, 50)]
    return mix(*[(s, w) for _n, s, w in parts]), parts


def _health(v, med, model):
    dil = band(v.get("dilution"), "dilution")
    if model in ("bank", "insurer"):          # a lender's debt is its raw material: judge returns and dilution
        parts = [("Return on assets", band(v.get("roa"), "roa_bank"), 60), ("Share count", dil, 40)]
    else:
        nd = v.get("net_debt_ebitda")
        if nd is None and v.get("debt") is not None and v.get("cash") is not None and v["cash"] >= v["debt"]:
            nd = -0.5                         # net cash, even with no EBITDA
        parts = [("Net debt ÷ EBITDA", band(nd, "net_debt_ebitda"), 35),
                 ("Current ratio", band(v.get("current_ratio"), "current"), 20),
                 ("Debt / equity vs peers", both(band(v.get("debt_eq") or 0.0 if v.get("equity", 0) and v["equity"] > 0
                                                     else None, "debt_eq"),
                                                vs_peers(v.get("debt_eq"), med.get("debt_eq"), "low", "pts")), 20),
                 ("Free cash flow margin", band(v.get("fcf_margin"), "fcf_margin"), 15),
                 ("Share count", dil, 10)]
    return mix(*[(s, w) for _n, s, w in parts]), parts


def _dividend(v, _med, _model):
    if not v.get("div_ttm"):
        return None, []
    parts = [("Yield", band(v.get("div_yield"), "yield"), 40), ("Payout", band(v.get("payout"), "payout"), 35),
             ("Dividend growth, 3 years", band(v.get("div_g3"), "div_growth"), 25)]
    return mix(*[(s, w) for _n, s, w in parts]), parts


def _pct(x, d=0):
    return f"{x * 100:.{d}f}%"


def _money(x):
    return f"{x / 1e9:,.1f}B" if x >= 1e9 else f"{x / 1e6:,.1f}M" if x >= 1e6 else f"{x / 1e3:,.0f}K"


def _rewards_risks(v, med, axes):
    rw, rk = [], []                      # (strength, text)
    fu = v.get("fv_upside")
    if fu is not None and fu >= 0.15:
        rw.append((fu, f"Trading {_pct(fu)} below your fair value (${v['fair_value']:,.2f})"))
    if fu is not None and fu <= -0.15:
        rk.append((-fu, f"Trading {_pct(-fu)} above your fair value (${v['fair_value']:,.2f})"))
    g = v.get("eps_next_5y")
    if g is not None and g >= 0.15:
        rw.append((g, f"EPS expected to grow {_pct(g, 1)} a year (your projection)"))
    if v.get("peg") is not None and v["peg"] < 1:
        rw.append((1 - v["peg"], f"PEG {v['peg']:.2f}: cheap for its expected growth"))
    y = v.get("eps_yoy_ttm")
    if y is not None and y >= 0.25:
        rw.append((min(y, 2) / 2, f"Earnings grew {_pct(y, 1)} over the last year"))
    if y is not None and y <= -0.15:
        rk.append((min(-y, 1), f"Earnings fell {_pct(-y, 1)} over the last year"))
    r, rm = v.get("roic"), (med.get("roic") or (None,))[0]
    if r is not None and r >= 0.15 and (rm is None or r > rm):
        rw.append((r, f"ROIC {_pct(r)}" + (f", above the peers' {_pct(rm)}" if rm is not None else "")))
    nd = v.get("net_debt_ebitda")
    if v.get("cash") is not None and v.get("debt") is not None and v["cash"] > v["debt"] and v.get("model") not in ("bank", "insurer"):
        rw.append((0.3, f"Net cash: ${(v['cash'] - v['debt']) / 1e9:,.1f}B more cash than debt"))
    elif nd is not None and nd >= 3 and v.get("model") not in ("bank", "insurer"):
        rk.append((nd / 6, f"Debt is {nd:.1f}× EBITDA"))
    om, omm = v.get("op_margin"), (med.get("op_margin") or (None,))[0]
    if om is not None and omm is not None and om - omm >= 0.08:
        rw.append((om - omm, f"Operating margin {_pct(om)}, above the peers' {_pct(omm)}"))
    if v.get("fcf") is not None and v["fcf"] < 0:
        rk.append((0.6, f"Negative free cash flow: −${-v['fcf'] / 1e9:,.2f}B in 12 months"))
    d = v.get("dilution")
    if d is not None and d >= 0.03:
        rk.append((d * 5, f"Share count up {_pct(d, 1)} in a year (dilution)"))
    ins = v.get("_ins") or {}
    if ins.get("buys_12m") and (ins.get("buyers_12m", 0) >= 2 or ins.get("top_bought")):
        who = f"{ins['buyers_12m']} insider" + ("s" if ins["buyers_12m"] > 1 else "")
        if ins.get("top_bought"):
            who += ", incl. " + ins["top_bought"][0].split(" (")[1].rstrip(")")
        rw.append((0.5 + min(ins["buys_12m"] / 1e7, 0.5), f"Insiders bought ${_money(ins['buys_12m'])} on the open "
                                                           f"market in 12 months ({who})"))
    disc = (ins.get("sells_12m") or 0) - (ins.get("sells_plan_12m") or 0)
    if disc > 0 and v.get("mcap") and disc / v["mcap"] >= 0.002 and not ins.get("buys_12m"):
        rk.append((min(disc / v["mcap"] * 100, 1), f"Insiders sold ${_money(disc)} outside 10b5-1 plans in 12 "
                                                    f"months, and bought none"))
    io = v.get("insider_own")
    if io is not None and io >= 0.10:
        rw.append((min(io, 0.5), f"Insiders own {_pct(io)}: their money is in it with yours"))
    ic = v.get("inst_change")
    if ic is not None and ic >= 0.03:
        rw.append((min(ic * 5, 0.8), f"Institutions added {_pct(ic, 1)} to their holdings last quarter (13F)"))
    if ic is not None and ic <= -0.03:
        rk.append((min(-ic * 5, 0.8), f"Institutions cut their holdings by {_pct(-ic, 1)} last quarter (13F)"))
    b = v.get("beta")
    vm = v.get("vol_month")
    if (b is not None and b >= 1.8) or (vm is not None and vm >= 0.06):
        rk.append((0.5, "Volatile: " + ", ".join(x for x in (f"beta {b:.1f}" if b is not None else "",
                                                             f"swings {_pct(vm, 1)} a day" if vm is not None else "") if x)))
    s200 = v.get("sma200")
    if s200 is not None and s200 <= -0.15:
        rk.append((-s200, f"{_pct(-s200)} below its 200-day average: the long trend is down"))
    pe, pem = v.get("pe"), (med.get("pe") or (None,))[0]
    if pe and pem and pe > 1.5 * pem and not (v.get("peg") is not None and v["peg"] < 1.5):
        rk.append((pe / pem / 4, f"P/E {pe:.0f}× against the peers' {pem:.0f}×, without the growth to match"))
    p = v.get("payout")
    if v.get("div_ttm") and p is not None and p > 0.9:
        rk.append((p - 0.9, f"Dividend payout {_pct(p)}: more than the profit can comfortably cover"))
    ne = v.get("next_earnings")
    if ne:
        days = (date.fromisoformat(ne) - date.today()).days
        if 0 <= days <= 10:
            rk.append((0.2, f"Earnings in about {days} days (estimated): expect a big move"))
    said = " ".join(t.lower() for _s, t in rk)
    for h in v.get("holder_risks") or []:
        head = h.get("head", "")
        if h.get("level") not in ("high", "hi", "red") or not head:
            continue
        if ("dilution" in head.lower() or "share count" in head.lower()) and "dilution" in said:
            continue                          # already listed, with its number
        rk.append((0.4, head))
    rw.sort(key=lambda x: -x[0])
    rk.sort(key=lambda x: -x[0])
    return [t for _s, t in rw[:5]], [t for _s, t in rk[:5]]


def _summary(ax):
    """'Undervalued, with fast growth, a strong balance sheet and a solid track record'."""
    v, f, p, h = (ax.get(k) for k in ("Value", "Future", "Past", "Health"))
    val = None if v is None else "Undervalued" if v >= 65 else "Expensive" if v <= 35 else "Fairly valued"
    bits = [None if f is None else "fast growth" if f >= 65 else "slow growth" if f <= 35 else "steady growth",
            None if h is None else "a strong balance sheet" if h >= 70 else "a stretched balance sheet" if h <= 35 else None,
            None if p is None else "a solid track record" if p >= 65 else "a weak track record" if p <= 35 else None]
    bits = [b for b in bits if b]
    tail = ", ".join(bits[:-1]) + (" and " if len(bits) > 1 else "") + bits[-1] if bits else ""
    if val and tail:
        return f"{val}, with {tail}"
    return val or (tail[0].upper() + tail[1:] if tail else "")


def grade(data):
    """{'score', 'grade', 'axes': {name: score or None}, 'parts': {name: [(label, score, weight)]},
    'summary', 'rewards', 'risks'} from fundamentals.build()."""
    from .scorecard import grade_for
    v, med = data["values"], data["peers"]
    model = v.get("model") or "standard"
    axes, parts = {}, {}
    for name, fn in (("Value", _value), ("Future", _future), ("Past", _past), ("Health", _health),
                     ("Dividend", _dividend)):
        s, p = fn(v, med, model)
        axes[name], parts[name] = s, p
    w = dict(WEIGHTS)
    if axes["Dividend"] is not None:
        w["Dividend"] = DIVIDEND_WEIGHT
    score = mix(*[(axes[k], wt) for k, wt in w.items()])
    rewards, risks = _rewards_risks(v, med, axes)
    return {"score": score, "grade": grade_for(round(score)) if score is not None else None, "axes": axes,
            "parts": parts, "weights": w, "summary": _summary(axes), "rewards": rewards, "risks": risks,
            "model": v.get("model_label")}
