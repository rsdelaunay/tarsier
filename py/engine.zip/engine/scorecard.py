"""The scorecard decides: metrics -> block scores -> weighted score -> grade."""
from . import rules as R


def band(value, table):
    """Higher is better: first threshold the value reaches."""
    for thr, pts in table:
        if value >= thr:
            return pts
    return table[-1][1]


def band_low(value, table):
    """Lower is better: first ceiling the value stays under."""
    for ceiling, pts in table:
        if value <= ceiling:
            return pts
    return table[-1][1]


def grade_for(score):
    for thr, g in R.GRADES:
        if score >= thr:
            return g
    return "F"


def _block(parts, mix):
    used = [p for p in parts if p["points"] is not None]
    w = sum(mix[p["id"]] for p in used)
    score = sum(p["points"] * mix[p["id"]] for p in used) / w if w else None
    for p in parts:
        p["weight"] = mix[p["id"]]
    return {"score": score, "parts": parts, "inputs_used": len(used),
            "inputs_total": len([p for p in parts if p["applies"]])}


def _p(pid, label, value, points, circle=None, note=None, applies=True):
    """applies=False: this input is not used for this kind of company (not a data gap)."""
    return {"id": pid, "label": label, "value": value, "points": points if applies else None,
            "circle": circle, "note": note, "applies": applies}


def growth_block(m):
    r = m["revenue"]
    g = r["scored_growth_pct"]
    pts = None if g is None else band(g, R.REVENUE_GROWTH)
    note = "organic" if r["organic_yoy_pct"] is not None else "total"
    if pts is not None and r["accel_pp"] is not None:
        if r["accel_pp"] >= R.ACCELERATION_PP:
            pts, note = min(100, pts + R.ACCELERATION_POINTS), note + ", accelerating"
        elif r["accel_pp"] <= -R.ACCELERATION_PP:
            pts, note = max(0, pts - R.ACCELERATION_POINTS), note + ", decelerating"
    if r["acquisitions_last_4q"] and r["organic_yoy_pct"] is None:
        note += " (FLAG: acquisitions, organic not broken out)"
    parts = [_p("revenue_growth", "Revenue growth YoY", g, pts, "revenue", note)]
    b = _block(parts, {"revenue_growth": 100})
    return b


def _eps_points(e):
    cls = e["classification"]
    if cls is None:
        return None
    if cls in R.EPS_CHANGE_POINTS:
        return R.EPS_CHANGE_POINTS[cls]
    return None if e["yoy_pct"] is None else band(e["yoy_pct"], R.EPS_GROWTH)


def profitability_block(m, is_software):
    mg, a = m["margins"], m["assets"]

    def chg(pp):
        return None if pp is None else band(pp, R.MARGIN_CHANGE)
    parts = [
        _p("gross", "Gross margin change (pp)", mg["gross"]["pp"], chg(mg["gross"]["pp"]), "gross_profit"),
        _p("operating", "Operating margin change (pp)", mg["operating"]["pp"], chg(mg["operating"]["pp"]),
           "operating_income"),
        _p("net", "Net margin change (pp)", mg["net"]["pp"], chg(mg["net"]["pp"]), "net_income"),
        _p("eps", "GAAP EPS vs last year", m["eps"]["classification"], _eps_points(m["eps"]), "net_income",
           None if m["eps"]["yoy_pct"] is None or (m["eps"]["gaap_prior"] or 0) <= 0
           else f"{m['eps']['yoy_pct']:+.0f}%"),
    ]
    lev = m["operating_leverage"]["share_slower"]
    parts.append(_p("leverage", "Opex lines growing slower than revenue (%)", None if lev is None else lev * 100,
                    None if lev is None else round(lev * 100), None, "operating leverage"))
    r40 = m["rule_of_40"]
    use_r40 = is_software and not a["asset_heavy"]
    parts.append(_p("rule_of_40", "Rule of 40 (software only)", r40 if use_r40 else None,
                    None if r40 is None else band(r40, R.RULE_OF_40), "fcf",
                    f"scored growth + FCF margin ({m['cash']['level_basis']})" if use_r40
                    else "not used outside asset-light software", applies=use_r40))
    parts.append(_p("ebitda", "EBITDA margin change (pp)", a["ebitda_margin_pp"], chg(a["ebitda_margin_pp"]),
                    None, "asset-heavy: profit before depreciation" if a["asset_heavy"]
                    else "used only for asset-heavy companies", applies=a["asset_heavy"]))
    return _block(parts, R.PROFITABILITY_MIX)


def cash_block(m):
    c, s = m["cash"], m["sbc"]
    if s["pp_yoy"] is None:
        trend = None
    elif s["pp_yoy"] <= -R.SBC_TREND_PP:
        trend = "falling"
    elif s["pp_yoy"] >= R.SBC_TREND_PP:
        trend = "rising"
    else:
        trend = "stable"
    basis = c["level_basis"]
    heavy = m["assets"]["asset_heavy"]
    parts = [
        _p("fcf_margin", "FCF margin (%)", c["fcf_margin_scored"],
           None if c["fcf_margin_scored"] is None else band(c["fcf_margin_scored"], R.FCF_MARGIN), "fcf", basis),
        _p("fcf_margin_change", "FCF margin change (pp)", c["fcf_margin_pp"],
           None if c["fcf_margin_pp"] is None else band(c["fcf_margin_pp"], R.FCF_MARGIN_CHANGE), "fcf",
           "this quarter vs same quarter last year"),
        _p("fcf_after_sbc", "FCF after SBC margin (%)", c["fcf_after_sbc_margin_scored"],
           None if c["fcf_after_sbc_margin_scored"] is None
           else band(c["fcf_after_sbc_margin_scored"], R.FCF_AFTER_SBC_MARGIN), "sbc", basis),
        _p("sbc_trend", "SBC % of revenue vs last year (pp)", s["pp_yoy"],
           None if trend is None else R.SBC_TREND_POINTS[trend], "sbc", trend),
        _p("cfo_margin", "Cash from operations margin (%)", c["cfo_margin_ttm"],
           None if c["cfo_margin_ttm"] is None else band(c["cfo_margin_ttm"], R.CFO_MARGIN), None,
           "asset-heavy: cash before growth capex" if heavy else "used only for asset-heavy companies",
           applies=heavy),
    ]
    return _block(parts, R.CASH_MIX)


def balance_block(m, industry_group, peer_median_dilution):
    d, dil_m = m["debt"], m["dilution"]
    nc, has_debt = d["net_cash"], bool(d["total"])
    if nc is None:
        pts, note = None, None
    elif nc >= 0:
        pts, note = R.NET_CASH_POINTS, "net cash"
    elif d["net_debt_to_ebitda"] is None:
        pts, note = R.NET_DEBT_NO_EBITDA_POINTS, "net debt, EBITDA not positive"
    else:
        pts = band_low(d["net_debt_to_ebitda"], R.NET_DEBT_TO_EBITDA)
        note = f"net debt {d['net_debt_to_ebitda']:.1f}x EBITDA"
    parts = [_p("net_debt", "Net cash (debt)", nc, pts, "net_cash", note)]

    cover = d["interest_cover"]
    if not has_debt:
        cp, cnote = 100, "no debt"
    elif nc is not None and nc >= 0:
        cp, cnote = 100, "net cash: the debt could be repaid from cash on hand"
    elif cover is not None:
        cp, cnote = band(cover, R.INTEREST_COVER), f"EBITDA / interest, {d['interest_cover_basis']}"
    elif d["interest_q"] is not None and d["interest_q"] <= 0:
        cp, cnote = 100, "no net interest expense"
    else:
        cp, cnote = None, None
    parts.append(_p("interest_cover", "Interest cover (x)", cover, cp, "debt", cnote))

    near = d["near_term_cover"]
    if not has_debt or (d["near_term"] is not None and d["near_term"] <= 0):
        mp, mnote = 100, "nothing due soon" if has_debt else "no debt"
    elif near is not None:
        mp = band(near, R.NEAR_TERM_COVER)
        mnote = f"cash / debt due within ~{d['near_term_months']} months"
    else:
        mp, mnote = None, "maturity schedule not found"
    parts.append(_p("maturity", "Cash cover of debt due soon (x)", near, mp, "debt", mnote))

    pace = d["revenue_minus_debt_growth_pp"]
    parts.append(_p("debt_pace", "Revenue growth minus debt growth (pp)", pace,
                    None if pace is None else band(pace, R.DEBT_PACE_PP), "debt",
                    "debt is material" if d["material"] else
                    f"not scored: debt below {R.DEBT_MATERIAL_PCT_OF_REVENUE}% of yearly revenue",
                    applies=d["material"]))

    dil = dil_m["yoy_pct"]
    if dil is None:
        dp, dnote = None, None
    elif peer_median_dilution is not None:
        dp = band_low(dil - peer_median_dilution, R.DILUTION_VS_PEER_MEDIAN)
        dnote = f"vs peer median {peer_median_dilution:.1f}%"
    else:
        table = R.DILUTION_DEFAULT.get(industry_group, R.DILUTION_DEFAULT["other"])
        dp = band_low(dil, table)
        dnote = "default band (peer median not entered yet)"
    parts.append(_p("dilution", "Basic shares YoY (%)", dil, dp, "shares", dnote))
    return _block(parts, R.BALANCE_MIX)


def execution_block(m, inputs):
    rev = m["revenue"]["cur"]
    cons = inputs.get("consensus") or {}
    gd = inputs.get("guidance_for_this_quarter") or {}

    def beat(actual, bar):
        return None if actual is None or not bar else (actual - bar) / abs(bar) * 100

    rev_m = rev / 1e6 if rev is not None else None
    b_cons = beat(rev_m, cons.get("revenue_musd"))
    mid = gd.get("revenue_mid_musd")
    if mid is None and gd.get("revenue_low_musd") and gd.get("revenue_high_musd"):
        mid = (gd["revenue_low_musd"] + gd["revenue_high_musd"]) / 2
    b_guide = beat(rev_m, mid)

    hist = [x for x in (inputs.get("past_beats_vs_guidance_pct") or []) if x is not None]
    habit = sum(hist) / len(hist) if hist else None
    vs_habit = None if habit is None or b_guide is None else b_guide - habit

    eps_bar, eps_act = cons.get("eps_nongaap"), (inputs.get("eps_nongaap") or {}).get("cur")
    if eps_bar is None:
        eps_bar, eps_act = cons.get("eps_gaap"), m["eps"]["gaap_cur"]
    b_eps = beat(eps_act, eps_bar)

    gch = (inputs.get("full_year_guidance") or {}).get("change")
    parts = [
        _p("guidance", "Full-year guidance", gch, R.GUIDANCE_POINTS.get(gch), None,
           (inputs.get("full_year_guidance") or {}).get("detail")),
        _p("rev_vs_consensus", "Revenue vs consensus (%)", b_cons,
           None if b_cons is None else band(b_cons, R.BEAT_PCT), "revenue",
           None if b_cons is None else f"${rev_m - cons['revenue_musd']:+,.1f}M"),
        _p("rev_vs_guidance", "Revenue vs guidance midpoint (%)", b_guide,
           None if b_guide is None else band(b_guide, R.BEAT_PCT), "revenue",
           None if b_guide is None else f"${rev_m - mid:+,.1f}M"),
        _p("beat_vs_habit", "Beat vs the company's usual beat (pp)", vs_habit,
           None if vs_habit is None else band(vs_habit, R.BEAT_VS_HABIT_PP), None,
           None if habit is None else f"usual beat {habit:.1f}%"),
        _p("eps_vs_consensus", "EPS vs consensus (%)", b_eps,
           None if b_eps is None else band(b_eps, R.EPS_BEAT_PCT), None),
    ]
    blk = _block(parts, R.EXECUTION_MIX)
    if gch == "lowered" and blk["score"] is not None:
        blk["score"] = min(blk["score"], R.GUIDANCE_CUT_EXECUTION_CAP)
        blk["rule"] = "Guidance cut: Execution capped at 40"
    return blk


def grade(m, inputs, sic=None):
    inputs = inputs or {}
    group = inputs.get("industry_group") or default_group(sic)
    is_software = group == "Software"
    ctype = inputs.get("company_type") or "auto"
    if ctype == "auto":
        g = m["revenue"]["scored_growth_pct"]
        ctype = "growth" if g is not None and g >= R.GROWTH_COMPANY_MIN_YOY else "mature"
    weights = R.WEIGHTS[ctype]

    blocks = {
        "growth": growth_block(m),
        "profitability": profitability_block(m, is_software),
        "cash": cash_block(m),
        "balance": balance_block(m, group, inputs.get("peer_median_dilution_pct")),
        "execution": execution_block(m, inputs),
    }
    used = {k: b for k, b in blocks.items() if b["score"] is not None}
    wsum = sum(weights[k] for k in used)
    score = sum(b["score"] * weights[k] for k, b in used.items()) / wsum if wsum else None
    rules_applied = [b["rule"] for b in blocks.values() if b.get("rule")]

    floor = R.SOFTWARE_RULE_OF_40_FLOOR
    if (floor["enabled"] and is_software and not m["assets"]["asset_heavy"] and score is not None
            and m["rule_of_40"] is not None
            and m["rule_of_40"] > floor["rule_of_40_above"] and score < floor["min_score"]):
        rules_applied.append(f"Software with Rule of 40 above 40: at least a B "
                             f"(the scorecard alone gave {score:.1f} = {grade_for(round(score))})")
        score = floor["min_score"]

    warnings = []
    for k, b in blocks.items():
        if b["inputs_used"] < b["inputs_total"]:
            missing_parts = [p["label"] for p in b["parts"] if p["applies"] and p["points"] is None]
            warnings.append(f"{k.capitalize()}: {b['inputs_used']} of {b['inputs_total']} inputs available "
                            f"(missing: {'; '.join(missing_parts)}).")
    missing = [k for k in blocks if k not in used]
    if missing:
        warnings.append("No score for: " + ", ".join(missing) + " (weights re-spread over the rest).")

    circles = sorted({p["circle"] for b in blocks.values() for p in b["parts"]
                      if p["circle"] and p["points"] is not None and (p["points"] >= 90 or p["points"] <= 40)})
    ex = blocks["execution"]
    provisional = ex["inputs_used"] < R.MIN_EXECUTION_INPUTS
    if provisional:
        warnings.insert(0, f"PROVISIONAL grade: only {ex['inputs_used']} of {ex['inputs_total']} Execution "
                           "inputs entered (consensus, guidance).")
    unsupported = group == "Financials"
    if unsupported:
        warnings.insert(0, "NOT COMPARABLE: financial company (bank, lender, insurer). Revenue, margins, debt and "
                           "cash flow mean something else there; this scorecard does not fit yet.")
    return {"score": score, "grade": None if score is None else grade_for(round(score)),
            "provisional": provisional, "unsupported": unsupported, "asset_heavy": m["assets"]["asset_heavy"], "sic": sic,
            "company_type": ctype, "industry_group": group, "weights": weights,
            "blocks": blocks, "house_rules_applied": rules_applied, "warnings": warnings,
            "circled": circles, "method_version": R.METHOD_VERSION}


def default_group(sic):
    try:
        sic = int(sic)
    except (TypeError, ValueError):
        return "Unknown"
    if 7370 <= sic <= 7379:
        return "Software"
    if sic == 3674:
        return "Semiconductors"
    if 6000 <= sic <= 6799:
        return "Financials"
    return f"SIC {sic}"
