"""Stock fundamentals: the numbers a stock screener shows, worked out from the SEC filings (statements) and
Yahoo Finance (price, volume, dividends), with the peers' median for each one.

Nothing here needs a key. Market data is kept 30 minutes in _cache/fundamentals_market.json.
Values that have no free, reliable source (insider and institutional ownership, short interest, float,
index membership, options) are left out on purpose.
"""
import json
import math
import os
import statistics
import time
import urllib.parse
from datetime import date, datetime, timedelta, timezone

from . import paths, xbrl

FRESH = 30 * 60
CACHE = os.path.join(paths.CACHE, "fundamentals_market.json")


# ---------- market data (Yahoo Finance chart API) ------------------------------------------------------------
def _chart(symbol, query):
    from . import prices
    q = urllib.parse.quote(symbol.replace(".", "-"))
    last = None
    for host in ("query1", "query2"):
        try:
            d = prices._get_json(f"https://{host}.finance.yahoo.com/v8/finance/chart/{q}?{query}", timeout=15)
            r = ((d or {}).get("chart") or {}).get("result") or []
            if r:
                return r[0]
        except Exception as e:                       # network, blocked: try the other host
            last = e
    if last:
        raise last
    return None


def _rows(r):
    """[(date, open, high, low, close, volume)] from a chart result, skipping empty days."""
    ts = r.get("timestamp") or []
    q = ((r.get("indicators") or {}).get("quote") or [{}])[0]
    out = []
    for i, t in enumerate(ts):
        vals = [(q.get(k) or [None] * len(ts))[i] for k in ("open", "high", "low", "close", "volume")]
        if vals[3] is None:
            continue
        d = datetime.fromtimestamp(t, tz=timezone.utc).date().isoformat()
        out.append((d, *vals))
    return out


def _divs(r):
    ev = ((r.get("events") or {}).get("dividends") or {}).values()
    return sorted((datetime.fromtimestamp(x["date"], tz=timezone.utc).date().isoformat(), float(x["amount"]))
                  for x in ev if x.get("amount"))


def cached(ticker):
    """(the price history kept on disk however old, or None; whether it is still fresh). No network."""
    c = _load_cache().get(ticker.upper())
    return (c, bool(c) and time.time() - c.get("fetched", 0) < FRESH)


def _load_cache():
    try:
        with open(CACHE, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def market(ticker, refresh=False):
    """{daily, monthly, spy_monthly, divs, meta, fetched} for a ticker; cached 30 minutes."""
    t = ticker.upper()
    cache = _load_cache()
    c = cache.get(t)
    if c and not refresh and time.time() - c.get("fetched", 0) < FRESH:
        return c
    day = _chart(t, "range=1y&interval=1d&events=div")
    mon = _chart(t, "range=10y&interval=1mo&events=div")
    spy = cache.get("^SPY")
    if not spy or time.time() - spy.get("fetched", 0) > 12 * 3600:
        s = _chart("SPY", "range=5y&interval=1mo")
        spy = {"monthly": _rows(s) if s else [], "fetched": time.time()}
        cache["^SPY"] = spy
    meta = (day or {}).get("meta") or {}
    rec = {"daily": _rows(day) if day else [], "monthly": _rows(mon) if mon else [],
           "spy_monthly": spy["monthly"], "divs": _divs(mon) if mon else [],
           "meta": {k: meta.get(k) for k in ("regularMarketPrice", "fiftyTwoWeekHigh", "fiftyTwoWeekLow",
                                            "firstTradeDate", "regularMarketVolume", "currency",
                                            "regularMarketTime")},
           "fetched": time.time()}
    cache[t] = rec
    try:
        os.makedirs(paths.CACHE, exist_ok=True)
        tmp = CACHE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(cache, f)
        os.replace(tmp, CACHE)
    except OSError:
        pass
    return rec


# ---------- small helpers ---------------------------------------------------------------------------------------
def _div(a, b):
    return None if a is None or b is None or b == 0 else a / b


def _pos_div(a, b):
    """A multiple only means something when both sides are positive."""
    return None if a is None or b is None or a <= 0 or b <= 0 else a / b


def _growth(a, b):
    return None if a is None or b is None or b <= 0 else a / b - 1


def _cagr(a, b, years):
    return None if a is None or b is None or a <= 0 or b <= 0 else (a / b) ** (1 / years) - 1


def _sma(closes, n):
    return sum(closes[-n:]) / n if len(closes) >= n else None


def _rsi(closes, n=14):
    if len(closes) <= n:
        return None
    gains, losses = [], []
    for a, b in zip(closes[:-1], closes[1:]):
        d = b - a
        gains.append(max(d, 0))
        losses.append(max(-d, 0))
    g, l = sum(gains[:n]) / n, sum(losses[:n]) / n
    for x, y in zip(gains[n:], losses[n:]):                 # Wilder's smoothing
        g, l = (g * (n - 1) + x) / n, (l * (n - 1) + y) / n
    return 100.0 if l == 0 else 100 - 100 / (1 + g / l)


def _atr(rows, n=14):
    if len(rows) <= n:
        return None
    trs = []
    for (_d0, _o0, _h0, _l0, c0, _v0), (_d, _o, h, l, _c, _v) in zip(rows[:-1], rows[1:]):
        if h is None or l is None:
            continue
        trs.append(max(h - l, abs(h - c0), abs(l - c0)))
    if len(trs) < n:
        return None
    a = sum(trs[:n]) / n
    for x in trs[n:]:
        a = (a * (n - 1) + x) / n
    return a


def _beta(mon, spy):
    a = {d[:7]: c for d, _o, _h, _l, c, _v in mon[-61:]}             # 5 years of monthly returns
    b = {d[:7]: c for d, _o, _h, _l, c, _v in spy}
    ks = sorted(set(a) & set(b))
    ra, rb = [], []
    for k0, k1 in zip(ks[:-1], ks[1:]):
        if a[k0] and b[k0]:
            ra.append(a[k1] / a[k0] - 1)
            rb.append(b[k1] / b[k0] - 1)
    if len(ra) < 24:
        return None
    ma, mb = statistics.fmean(ra), statistics.fmean(rb)
    cov = sum((x - ma) * (y - mb) for x, y in zip(ra, rb))
    var = sum((y - mb) ** 2 for y in rb)
    return cov / var if var else None


def _iv(facts, concepts, end, unit="USD"):
    got = xbrl.instants(facts, concepts, unit)
    if end in got:
        return got[end]["val"]
    near = [e for e in got if abs((date.fromisoformat(e) - date.fromisoformat(end)).days) <= 10]
    return got[near[0]]["val"] if near else None


def _latest_instant(facts, concepts, unit):
    got = xbrl.instants(facts, concepts, unit)
    if not got:
        return None, None
    end = max(got)
    return got[end]["val"], end


# ---------- from the SEC filings ----------------------------------------------------------------------------------
def from_filings(co):
    """Statement numbers and the ratios that need no price, for the latest quarter."""
    ends = co.quarter_ends()
    if not ends:
        return None
    end = ends[-1]
    p4 = co.previous(end, 4)
    snap, old = co.snapshot(end), co.snapshot(p4) if p4 else None
    ttm = lambda f, e=end: co.ttm(f, e) if e else None
    rev, rev_p = ttm("revenue"), ttm("revenue", p4)
    ni, ni_p = ttm("net_income"), ttm("net_income", p4)
    op, gp, fcf, ebitda = ttm("operating_income"), ttm("gross_profit"), ttm("fcf"), ttm("ebitda")
    eps, eps_p = ttm("eps_diluted"), ttm("eps_diluted", p4)
    tax, pre = ttm("tax"), ttm("pretax")
    rate = min(max(tax / pre, 0.0), 0.35) if tax is not None and pre and pre > 0 else 0.21
    f = co.facts
    equity, equity_p = co.iv("equity", end), co.iv("equity", p4) if p4 else None
    assets, assets_p = co.iv("total_assets", end), co.iv("total_assets", p4) if p4 else None
    cash = (snap.get("cash") or 0) + (snap.get("st_investments") or 0) if snap.get("cash") is not None else None
    debt = snap.get("debt")
    cur_a = _iv(f, ["AssetsCurrent"], end)
    cur_l = _iv(f, ["LiabilitiesCurrent"], end)
    inv = _iv(f, ["InventoryNet", "InventoryGross"], end) or 0.0
    lt_debt = co.iv("debt_noncurrent", end)
    if lt_debt is None and debt is not None:
        lt_debt = debt - (co.iv("debt_current", end) or 0) - (snap.get("st_borrowings") or 0)
    out_sh, out_end = _latest_instant(f, ["EntityCommonStockSharesOutstanding"], "shares")
    shares = out_sh or snap.get("shares_basic") or snap.get("shares_diluted")
    avg = lambda a, b: (a + b) / 2 if a is not None and b is not None else a
    inv_cap = None if equity is None else equity + (debt or 0) - (cash or 0)
    p12, p20 = co.previous(end, 12), co.previous(end, 20)
    q1y = co.snapshot(p4) if p4 else None
    divs = co.cf_ttm("dividends", end) if hasattr(co, "cf_ttm") else None
    return {
        "end": end, "label": co.label(end), "filed": co.period(end)[2],
        "revenue": rev, "net_income": ni, "op_income": op, "fcf": fcf, "ebitda": ebitda, "eps": eps,
        "equity": equity, "cash": cash, "debt": debt, "shares": shares, "shares_end": out_end,
        "book_ps": _div(equity, shares), "cash_ps": _div(cash, shares),
        "gross_margin": _div(gp, rev), "op_margin": _div(op, rev), "net_margin": _div(ni, rev),
        "roe": _div(ni, avg(equity, equity_p)) if equity and equity > 0 else None,
        "roa": _div(ni, avg(assets, assets_p)),
        "roic": _div(op * (1 - rate), inv_cap) if op is not None and inv_cap and inv_cap > 0 else None,
        "current_ratio": _div(cur_a, cur_l), "quick_ratio": _div(None if cur_a is None else cur_a - inv, cur_l),
        "debt_eq": _div(debt, equity) if equity and equity > 0 else None,
        "lt_debt_eq": _div(lt_debt, equity) if equity and equity > 0 else None,
        "eps_yoy_ttm": _growth(eps, eps_p) if eps_p and eps_p > 0 else None,
        "sales_yoy_ttm": _growth(rev, rev_p),
        "eps_qoq": _growth(snap.get("eps_diluted"), (q1y or {}).get("eps_diluted"))
        if (q1y or {}).get("eps_diluted") and q1y["eps_diluted"] > 0 else None,
        "sales_qoq": _growth(snap.get("revenue"), (q1y or {}).get("revenue")),
        "eps_past_3y": _cagr(eps, ttm("eps_diluted", p12), 3), "eps_past_5y": _cagr(eps, ttm("eps_diluted", p20), 5),
        "sales_past_3y": _cagr(rev, ttm("revenue", p12), 3), "sales_past_5y": _cagr(rev, ttm("revenue", p20), 5),
        "dividends_paid": divs,
        "dilution": _growth(snap.get("shares_basic"), (old or {}).get("shares_basic")),
        "net_debt_ebitda": None if ebitda is None or ebitda <= 0 or debt is None and cash is None
        else ((debt or 0) - (cash or 0)) / ebitda,
        "fcf_margin": _div(fcf, rev), "payout": _div(divs, ni) if divs and ni and ni > 0 else (0.0 if not divs else None),
    }


# ---------- from the price chart -----------------------------------------------------------------------------------
def from_market(mk):
    rows, meta = mk.get("daily") or [], mk.get("meta") or {}
    closes = [r[4] for r in rows]
    price = meta.get("regularMarketPrice") or (closes[-1] if closes else None)
    out = {"price": price, "currency": meta.get("currency") or "USD"}
    if not closes:
        return out
    hi = max([r[2] for r in rows if r[2] is not None] or closes)
    lo = min([r[3] for r in rows if r[3] is not None] or closes)
    out.update(hi52=hi, lo52=lo, from_hi=price / hi - 1, from_lo=price / lo - 1)
    for n in (20, 50, 200):
        s = _sma(closes, n)
        out[f"sma{n}"] = None if s is None else price / s - 1
    out["rsi"] = _rsi(closes)
    out["atr"] = _atr(rows)
    rng = [(r[2] - r[3]) / r[4] for r in rows if r[2] is not None and r[3] is not None and r[4]]
    out["vol_week"] = statistics.fmean(rng[-5:]) if len(rng) >= 5 else None
    out["vol_month"] = statistics.fmean(rng[-21:]) if len(rng) >= 21 else None
    vols = [r[5] for r in rows if r[5] is not None]
    out["volume"] = meta.get("regularMarketVolume") or (vols[-1] if vols else None)
    out["avg_volume"] = statistics.fmean(vols[-63:]) if len(vols) >= 20 else None
    out["rel_volume"] = _div(out["volume"], out["avg_volume"])
    out["beta"] = _beta(mk.get("monthly") or [], mk.get("spy_monthly") or [])
    ftd = meta.get("firstTradeDate")
    out["ipo"] = datetime.fromtimestamp(ftd, tz=timezone.utc).date().isoformat() if ftd else None
    # dividends: the last year, the yearly rate now, and growth over 3 and 5 years
    dv = mk.get("divs") or []
    if dv:
        last_day = rows[-1][0]
        y1 = (date.fromisoformat(last_day) - timedelta(days=365)).isoformat()
        year = [a for d, a in dv if d > y1]
        out["div_ttm"] = sum(year) if year else 0.0
        out["div_est"] = dv[-1][1] * len(year) if year else 0.0
        out["ex_date"] = dv[-1][0]

        def window(k):
            a = (date.fromisoformat(last_day) - timedelta(days=365 * (k + 1))).isoformat()
            b = (date.fromisoformat(last_day) - timedelta(days=365 * k)).isoformat()
            return sum(x for d, x in dv if a < d <= b)
        out["div_g3"] = _cagr(out["div_ttm"], window(3), 3)
        out["div_g5"] = _cagr(out["div_ttm"], window(5), 5)
    else:
        out.update(div_ttm=0.0, div_est=0.0, ex_date=None, div_g3=None, div_g5=None)
    out["div_yield"] = _div(out["div_ttm"], price)
    out["div_est_yield"] = _div(out["div_est"], price)
    return out


# ---------- the earnings dates ---------------------------------------------------------------------------------------
def earnings_dates(subs, filed=None):
    """(last earnings release date, the next one estimated) from the SEC filing list (8-K item 2.02)."""
    rec = ((subs or {}).get("filings") or {}).get("recent") or {}
    last = None
    for form, items, d in zip(rec.get("form", []), rec.get("items", []), rec.get("filingDate", [])):
        if form in ("8-K", "8-K/A") and "2.02" in (items or ""):
            last = d if last is None or d > last else last
    last = last or filed
    if not last:
        return None, None
    nxt = date.fromisoformat(last) + timedelta(days=91)
    while nxt < date.today():
        nxt += timedelta(days=91)
    return last, nxt.isoformat()


# ---------- everything together, with the peers -----------------------------------------------------------------
def valuation(fin, price):
    if not fin or not price:
        return {}
    mcap = price * fin["shares"] if fin.get("shares") else None
    ev = None if mcap is None else mcap + (fin.get("debt") or 0) - (fin.get("cash") or 0)
    return {"mcap": mcap, "ev": ev, "pe": _pos_div(price, fin.get("eps")), "ps": _pos_div(mcap, fin.get("revenue")),
            "pb": _pos_div(mcap, fin.get("equity")), "pc": _pos_div(mcap, fin.get("cash")),
            "pfcf": _pos_div(mcap, fin.get("fcf")), "ev_ebitda": _pos_div(ev, fin.get("ebitda")),
            "ev_sales": _pos_div(ev, fin.get("revenue"))}


def forward(res, price):
    """EPS this year, next year and 5-year growth from Tarsier's projection (base case, or your consensus)."""
    if not res:
        return {}
    try:
        o = res["scen"]["base"]["out"]
        ng = any(x is not None for x in res.get("cons_eps") or [])
        eps = o["adj_eps"] if ng and all(x is not None for x in o["adj_eps"]) else o["eps"]   # non-GAAP with a consensus
        A = res["actual"]
        a = A["eps"]
        if eps is o["adj_eps"] and a is not None and A.get("shares"):      # last year on the same (adjusted) basis
            a += (((A.get("sbc") or 0) + (res["settings"].get("amort_musd") or 0))
                  * (1 - (A.get("tax_rate") or 0)) / A["shares"])
        fys = res["fys"]
    except (KeyError, TypeError):
        return {}
    try:
        rv, ra = res["scen"]["base"]["out"]["revenue"], res["actual"]["revenue"]
        rev5 = _cagr(rv[-1], ra, len(rv)) if rv else None
    except (KeyError, TypeError):
        rev5 = None
    fv = res.get("fair_value")
    e0 = eps[0] if eps else None
    e1 = eps[1] if len(eps) > 1 else None
    g5 = _cagr(eps[-1], a, len(eps)) if eps else None
    pe_f = _pos_div(price, e1)
    return {"eps_this_y": _growth(e0, a) if a and a > 0 else None, "eps_next_y": _growth(e1, e0) if e0 and e0 > 0 else None,
            "eps_next_y_val": e1, "eps_next_5y": g5, "fwd_pe": pe_f, "fy_next": fys[1] if len(fys) > 1 else None,
            "fy_this": fys[0] if fys else None, "rev_next_5y": rev5, "fair_value": fv,
            "fv_upside": _growth(fv, price) if fv and price else None,
            "model": (res.get("model") or {}).get("code"), "model_label": (res.get("model") or {}).get("label"),
            "holder_risks": res.get("holder_risks") or [],
            "estimates_sourced": any(x for lst in (res.get("cons_src") or {}).values() for x in lst)}


def surprises(co, inputs):
    """EPS and sales surprise of the latest quarter, from what you typed (consensus) and the filing."""
    ends = co.quarter_ends()
    if not ends or not inputs:
        return {}
    end = ends[-1]
    row = inputs.get(end) or {}
    eps, ceps = row.get("eps_nongaap"), row.get("consensus_eps_nongaap")
    rev, crev = (co.snapshot(end) or {}).get("revenue"), row.get("consensus_revenue_musd")
    return {"eps_surprise": _growth(eps, ceps) if ceps and ceps > 0 else None,
            "sales_surprise": _growth(rev / 1e6, crev) if rev and crev else None}


def peer_values(peer_stats, peer_prices):
    """{ticker: {metric: value}} for the peers: the ratios they have, and multiples at today's price."""
    out = {}
    for t, s in (peer_stats or {}).items():
        if not s:
            continue
        v = {k: s.get(k) for k in ("gross_margin", "op_margin", "net_margin", "roe", "roa", "roic", "current_ratio",
                                     "quick_ratio", "debt_eq", "lt_debt_eq", "payout", "fcf_margin")}
        v["sales_yoy_ttm"], v["eps_yoy_ttm"] = s.get("rev_growth"), s.get("eps_growth")
        px = (peer_prices.get(t) or {}).get("price")
        if px and s.get("shares"):
            mcap = px * s["shares"]
            ev = mcap + (s.get("debt") or 0) - (s.get("cash") or 0)
            pe_ = _pos_div(px, s.get("eps"))
            g = s.get("eps_growth")
            v.update(mcap=mcap, pe=pe_, peg_ttm=pe_ / (g * 100) if pe_ and g and g > 0 else None, ps=_pos_div(mcap, s.get("revenue")),
                     pb=_pos_div(mcap, s.get("equity")), pfcf=_pos_div(mcap, s.get("fcf")),
                     pc=_pos_div(mcap, s.get("cash")), ev_ebitda=_pos_div(ev, s.get("ebitda")),
                     ev_sales=_pos_div(ev, s.get("revenue")))
        out[t] = v
    return out


def medians(pv):
    keys = {k for v in pv.values() for k in v}
    med = {}
    for k in keys:
        vals = [v[k] for v in pv.values() if v.get(k) is not None and not (isinstance(v[k], float) and math.isnan(v[k]))]
        if vals:
            med[k] = (statistics.median(vals), len(vals))
    return med


def build(co, subs, mk, res=None, inputs=None, peer_stats=None, peer_prices=None, ticker=None):
    """All the numbers the page shows: {values: {key: number or text}, peers: {key: (median, n)}, asof}."""
    fin = from_filings(co) or {}
    m = from_market(mk or {})
    val = valuation(fin, m.get("price"))
    fw = forward(res, m.get("price"))
    pe, g5 = val.get("pe"), fw.get("eps_next_5y")
    # PEG as screeners show it (Finviz): forward P/E ÷ expected EPS growth a year over 5 years (in %)
    pe_peg = fw.get("fwd_pe") or pe
    fw["peg"] = pe_peg / (g5 * 100) if pe_peg and g5 and g5 > 0 else None
    g1 = fin.get("eps_yoy_ttm")
    fw["peg_ttm"] = pe / (g1 * 100) if pe and g1 and g1 > 0 else None
    last, nxt = earnings_dates(subs, fin.get("filed"))
    v = {**fin, **m, **val, **fw, **surprises(co, inputs), "last_earnings": last, "next_earnings": nxt}
    if not fin.get("dividends_paid") and m.get("div_ttm") and fin.get("shares") and fin.get("net_income", 0) > 0:
        v["payout"] = m["div_ttm"] * fin["shares"] / fin["net_income"]      # not tagged in the filings: from the price data
    t = ticker
    if t:                                          # insiders (SEC Form 4) and institutions (13F), as kept
        try:
            from . import ownership
            v.update(ownership.values(t, fin.get("shares")))
        except Exception:
            pass
    med = medians(peer_values(peer_stats, peer_prices or {}))
    return {"values": v, "peers": med, "asof": time.strftime("%Y-%m-%d %H:%M"),
            "n_peers": len(peer_stats or {})}
