"""Cost of capital by industry, US companies. Source: Aswath Damodaran (NYU Stern),
"Cost of Equity and Capital (US)", data as of January 2026:
https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/wacc.html
These are industry averages (Damodaran does not publish a firm-level median). Update every January.
"""
SOURCE = "Damodaran, January 2026"
WACC = {
    "Advertising": 7.81, "Aerospace/Defense": 7.60, "Air Transport": 6.72, "Apparel": 7.13, "Auto & Truck": 9.38,
    "Auto Parts": 8.18, "Bank (Money Center)": 4.98, "Banks (Regional)": 4.98, "Beverage (Alcoholic)": 6.48,
    "Beverage (Soft)": 6.33, "Broadcasting": 5.09, "Brokerage & Investment Banking": 6.08,
    "Building Materials": 7.85, "Business & Consumer Services": 7.23, "Cable TV": 5.20, "Chemical (Basic)": 6.22,
    "Chemical (Diversified)": 5.23, "Chemical (Specialty)": 7.25, "Coal & Related Energy": 8.41,
    "Computer Services": 7.83, "Computers/Peripherals": 9.71, "Construction Supplies": 8.29, "Diversified": 7.30,
    "Drugs (Biotechnology)": 8.49, "Drugs (Pharmaceutical)": 7.85, "Education": 6.75, "Electrical Equipment": 8.99,
    "Electronics (Consumer & Office)": 7.63, "Electronics (General)": 7.85, "Engineering/Construction": 8.69,
    "Entertainment": 7.13, "Environmental & Waste Services": 7.43, "Farming/Agriculture": 7.27,
    "Financial Svcs. (Non-bank & Insurance)": 5.00, "Food Processing": 5.79, "Food Wholesalers": 6.53,
    "Furn/Home Furnishings": 6.53, "Green & Renewable Energy": 6.04, "Healthcare Products": 7.54,
    "Healthcare Support Services": 6.83, "Heathcare Information and Technology": 8.22, "Homebuilding": 7.27,
    "Hospitals/Healthcare Facilities": 6.19, "Hotel/Gaming": 7.36, "Household Products": 7.03,
    "Information Services": 7.00, "Insurance (General)": 6.34, "Insurance (Life)": 5.60,
    "Insurance (Prop/Cas.)": 5.78, "Investments & Asset Management": 6.13, "Machinery": 7.70,
    "Metals & Mining": 8.20, "Office Equipment & Services": 7.92, "Oil/Gas (Integrated)": 5.07,
    "Oil/Gas (Production and Exploration)": 6.25, "Oil/Gas Distribution": 5.78, "Oilfield Svcs/Equip.": 7.04,
    "Packaging & Container": 6.75, "Paper/Forest Products": 6.93, "Power": 5.01, "Precious Metals": 7.47,
    "Publishing & Newspapers": 5.95, "R.E.I.T.": 5.32, "Real Estate (Development)": 5.82,
    "Real Estate (General/Diversified)": 6.25, "Real Estate (Operations & Services)": 7.41, "Recreation": 6.76,
    "Reinsurance": 5.64, "Restaurant/Dining": 7.16, "Retail (Automotive)": 6.78, "Retail (Building Supply)": 9.51,
    "Retail (Distributors)": 7.22, "Retail (General)": 7.27, "Retail (Grocery and Food)": 7.24,
    "Retail (REITs)": 5.57, "Retail (Special Lines)": 8.01, "Rubber& Tires": 4.48, "Semiconductor": 10.55,
    "Semiconductor Equip": 9.89, "Shipbuilding & Marine": 6.69, "Shoe": 8.01, "Software (Entertainment)": 8.44,
    "Software (Internet)": 10.66, "Software (System & Application)": 9.34, "Steel": 7.76,
    "Telecom (Wireless)": 5.48, "Telecom. Equipment": 7.72, "Telecom. Services": 5.39, "Tobacco": 6.94,
    "Transportation": 6.72, "Transportation (Railroads)": 7.27, "Trucking": 7.52, "Utility (General)": 4.36,
    "Utility (Water)": 4.93, "Total Market": 6.96, "Total Market (without financials)": 7.72,
}
DEFAULT = "Total Market (without financials)"
# Tarsier scorecard group -> Damodaran industry
BY_GROUP = {
    "Software": "Software (System & Application)", "Semiconductors": "Semiconductor",
    "Hardware and equipment": "Computers/Peripherals", "Interactive media": "Software (Internet)",
    "Telecom and media": "Telecom. Services", "Retail and e-commerce": "Retail (General)",
    "Automobiles": "Auto & Truck", "Travel restaurants leisure": "Hotel/Gaming",
    "Food beverage household": "Food Processing", "Pharma and biotech": "Drugs (Pharmaceutical)",
    "Medical devices": "Healthcare Products", "Managed care and services": "Healthcare Support Services",
    "Banks and fintech lenders": "Banks (Regional)", "Financials": "Financial Svcs. (Non-bank & Insurance)",
    "Insurance": "Insurance (General)",
    "Payments exchanges asset managers": "Financial Svcs. (Non-bank & Insurance)",
    "Aerospace defence machinery": "Aerospace/Defense", "Transport and logistics": "Transportation",
    "Oil and gas": "Oil/Gas (Production and Exploration)", "Regulated utilities": "Utility (General)",
    "Power producers and energy equipment": "Power", "REITs": "R.E.I.T.",
    "Chemicals metals mining": "Chemical (Specialty)",
}
# SEC SIC code ranges -> Damodaran industry, for companies with no scorecard group yet
BY_SIC = [
    (1000, 1499, "Metals & Mining"), (1300, 1389, "Oil/Gas (Production and Exploration)"),
    (2000, 2099, "Food Processing"), (2833, 2836, "Drugs (Pharmaceutical)"), (2800, 2899, "Chemical (Specialty)"),
    (3559, 3559, "Semiconductor Equip"), (3570, 3579, "Computers/Peripherals"),
    (3600, 3629, "Electrical Equipment"), (3661, 3669, "Telecom. Equipment"), (3674, 3674, "Semiconductor"),
    (3711, 3711, "Auto & Truck"), (3714, 3714, "Auto Parts"), (3720, 3769, "Aerospace/Defense"),
    (3812, 3812, "Aerospace/Defense"), (3840, 3851, "Healthcare Products"), (4500, 4599, "Air Transport"),
    (4800, 4899, "Telecom. Services"), (4900, 4999, "Utility (General)"), (5200, 5999, "Retail (General)"),
    (6000, 6199, "Banks (Regional)"), (6200, 6299, "Brokerage & Investment Banking"),
    (6300, 6499, "Insurance (General)"), (6798, 6798, "R.E.I.T."), (7370, 7379, "Software (System & Application)"),
    (8000, 8099, "Hospitals/Healthcare Facilities"),
]


def for_company(group, sic=None):
    """(WACC as a fraction, 'Industry · source')."""
    name = BY_GROUP.get(group)
    if name is None:
        try:
            code = int(sic) if sic is not None else int(str(group).replace("SIC", "").strip())
        except (TypeError, ValueError):
            code = None
        if code is not None:
            # the narrowest range wins
            best = sorted(((hi - lo, n) for lo, hi, n in BY_SIC if lo <= code <= hi))
            name = best[0][1] if best else None
    name = name or DEFAULT
    return round(WACC[name] / 100, 4), f"{name} · {SOURCE}"
