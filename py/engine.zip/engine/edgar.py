"""SEC EDGAR: check for new filings, download, cache (standard library only).

SEC asks every caller to identify itself with a User-Agent that includes
a contact email: set it once in config.json.
"""
import gzip
import json
import os
import time
import urllib.error
import urllib.request

from . import paths

TICKERS_URL = "https://www.sec.gov/files/company_tickers.json"
FACTS_URL = "https://data.sec.gov/api/xbrl/companyfacts/CIK{cik:010d}.json"
SUBS_URL = "https://data.sec.gov/submissions/CIK{cik:010d}.json"
PERIODIC = ("10-Q", "10-K", "10-Q/A", "10-K/A")


class SecError(RuntimeError):
    pass


def load_config():
    if not os.path.exists(paths.CONFIG):
        with open(paths.CONFIG, "w", encoding="utf-8") as f:
            json.dump({"sec_user_agent": "Tarsier Research YOUR_EMAIL@example.com"}, f, indent=2)
    with open(paths.CONFIG, encoding="utf-8") as f:
        cfg = json.load(f)
    ua = cfg.get("sec_user_agent", "")
    if "@" not in ua or "YOUR_EMAIL" in ua:
        raise SecError("config.json: put your name and email in sec_user_agent (SEC requires it).")
    return cfg


def _get(url, ua):
    req = urllib.request.Request(url, headers={"User-Agent": ua, "Accept-Encoding": "gzip"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            data = r.read()
            if r.headers.get("Content-Encoding") == "gzip":
                data = gzip.decompress(data)
    except urllib.error.HTTPError as e:
        raise SecError(f"SEC returned HTTP {e.code} for {url}") from None
    except (urllib.error.URLError, OSError) as e:
        raise SecError(f"cannot reach SEC ({e})") from None
    time.sleep(0.25)  # far below SEC's 10 requests/second limit
    return json.loads(data.decode("utf-8"))


def get_text(url, ua):
    """A file from the EDGAR archive, as text (press releases)."""
    req = urllib.request.Request(url, headers={"User-Agent": ua, "Accept-Encoding": "gzip"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            data = r.read()
            if r.headers.get("Content-Encoding") == "gzip":
                data = gzip.decompress(data)
    except urllib.error.HTTPError as e:
        raise SecError(f"SEC returned HTTP {e.code} for {url}") from None
    except (urllib.error.URLError, OSError) as e:
        raise SecError(f"cannot reach SEC ({e})") from None
    time.sleep(0.25)
    return data.decode("utf-8", errors="replace")


def _path(name):
    os.makedirs(paths.CACHE, exist_ok=True)
    return os.path.join(paths.CACHE, name)


def _read(name):
    p = _path(name)
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def _write(obj, name):
    with open(_path(name), "w", encoding="utf-8") as f:
        json.dump(obj, f)


def ticker_to_cik(ticker, ua):
    p = _path("company_tickers.json")
    if not os.path.exists(p) or time.time() - os.path.getmtime(p) > 7 * 86400:
        _write(_get(TICKERS_URL, ua), "company_tickers.json")
    want = ticker.replace(".", "-")                      # the SEC writes BRK-B, not BRK.B
    for row in _read("company_tickers.json").values():
        if row["ticker"].upper() in (ticker, want):
            return int(row["cik_str"])
    raise SecError(f"{ticker}: not in the SEC ticker list (foreign filers may be missing).")


def latest_periodic(subs):
    """[form, accession, filed, period] of the latest 10-Q/10-K, or None."""
    r = (subs or {}).get("filings", {}).get("recent", {})
    for form, acc, filed, period in zip(r.get("form", []), r.get("accessionNumber", []),
                                        r.get("filingDate", []), r.get("reportDate", [])):
        if form in PERIODIC:
            return [form, acc, filed, period]
    return None


def update(ticker, offline=False):
    """Bring the cache up to date. Returns (facts, subs, status text)."""
    t = ticker.upper()
    fname, sname = f"{t}_companyfacts.json", f"{t}_submissions.json"
    old_subs = _read(sname)
    if offline:
        facts = _read(fname)
        if facts is None:
            raise SecError(f"{t}: no cached data and running offline.")
        return facts, old_subs or {}, "offline: cached data"

    ua = load_config()["sec_user_agent"]
    cik = ticker_to_cik(t, ua)
    subs = _get(SUBS_URL.format(cik=cik), ua)
    new, old = latest_periodic(subs), latest_periodic(old_subs)
    facts = _read(fname)
    if facts is None or new != old:
        facts = _get(FACTS_URL.format(cik=cik), ua)
        _write(facts, fname)
        status = f"NEW FILING: {new[0]} filed {new[2]} (period {new[3]})" if new else "downloaded"
    else:
        status = f"no new filing (last {new[0]} filed {new[2]})" if new else "no 10-Q/10-K found"
    _write(subs, sname)
    return facts, subs, status
