"""The scorecard's numbers, all in one place. Edit here to calibrate.

Bands are read top to bottom: the first line whose threshold the value
reaches gives the points. Version these changes: every report card states
the method version.
"""
METHOD_VERSION = "v0.2 (draft, calibrating)"
INF = float("inf")

# Block weights by company type (sum to 100)
WEIGHTS = {
    "growth": {"growth": 30, "profitability": 20, "cash": 15, "balance": 10, "execution": 25},
    "mature": {"growth": 15, "profitability": 25, "cash": 30, "balance": 20, "execution": 10},
}
GROWTH_COMPANY_MIN_YOY = 15.0   # company_type "auto": revenue YoY >= 15% -> growth company

GRADES = [(95, "A+"), (90, "A"), (85, "A−"), (80, "B+"), (75, "B"), (70, "B−"),
          (65, "C+"), (60, "C"), (50, "C−"), (40, "D"), (-INF, "F")]

# --- Growth block ----------------------------------------------------------
REVENUE_GROWTH = [(40, 100), (25, 80), (15, 60), (5, 40), (0, 20), (-INF, 0)]   # % YoY (organic when given)
ACCELERATION_PP = 3.0          # growth vs last quarter's growth, in pp
ACCELERATION_POINTS = 10       # + when accelerating by >= 3pp, - when decelerating by >= 3pp

# --- Profitability block ---------------------------------------------------
MARGIN_CHANGE = [(3, 100), (1, 85), (-0.5, 70), (-1.5, 50), (-3, 35), (-INF, 15)]   # pp YoY
RULE_OF_40 = [(50, 100), (40, 85), (30, 65), (20, 45), (-INF, 25)]                   # software only
# GAAP EPS vs the same quarter last year (Step 2: GAAP EPS is the scored number)
EPS_CHANGE_POINTS = {"turned profitable": 100, "loss narrowed": 65, "loss widened": 15, "turned to a loss": 5}
EPS_GROWTH = [(25, 100), (10, 85), (0, 70), (-10, 50), (-30, 35), (-INF, 20)]        # % YoY, profit to profit
# "ebitda" counts only for asset-heavy companies, where depreciation hides the trend in operating profit
PROFITABILITY_MIX = {"gross": 20, "operating": 25, "net": 10, "eps": 15, "leverage": 15, "rule_of_40": 15,
                     "ebitda": 20}

# --- Cash block ------------------------------------------------------------
FCF_MARGIN = [(25, 100), (15, 85), (8, 70), (0, 50), (-10, 25), (-INF, 10)]          # % of revenue
FCF_MARGIN_CHANGE = [(3, 100), (0.5, 80), (-0.5, 65), (-3, 40), (-INF, 20)]          # pp YoY
FCF_AFTER_SBC_MARGIN = [(15, 100), (5, 80), (0, 60), (-10, 35), (-INF, 15)]
SBC_TREND_PP = 0.5             # SBC % of revenue vs same quarter last year
SBC_TREND_POINTS = {"falling": 100, "stable": 70, "rising": 30}   # house rule: rising is negative
CFO_MARGIN = [(40, 100), (25, 85), (10, 65), (0, 40), (-INF, 15)]                    # % of revenue, last 12 months
# "cfo_margin" counts only for asset-heavy companies, whose FCF is pulled down by growth capex
CASH_MIX = {"fcf_margin": 35, "fcf_margin_change": 20, "fcf_after_sbc": 25, "sbc_trend": 20, "cfo_margin": 30}

# --- Balance sheet block ---------------------------------------------------
# Leverage: net cash scores 100; otherwise net debt / EBITDA of the last 12 months
NET_CASH_POINTS = 100
NET_DEBT_TO_EBITDA = [(1, 80), (2, 65), (3, 45), (4.5, 30), (INF, 15)]   # lower is better: first ceiling reached
NET_DEBT_NO_EBITDA_POINTS = 10
# Cost: EBITDA / interest expense, last 12 months (no interest expense scores 100)
INTEREST_COVER = [(10, 100), (6, 85), (4, 70), (2.5, 50), (1.5, 30), (-INF, 10)]
# Maturity: cash and short-term investments / debt due by the end of next fiscal year
NEAR_TERM_COVER = [(3, 100), (1.5, 80), (1, 60), (0.5, 35), (-INF, 15)]
# Pace: revenue growth minus debt growth, in pp. Scored only when debt is material.
DEBT_PACE_PP = [(10, 100), (0, 80), (-15, 55), (-40, 35), (-INF, 15)]
DEBT_MATERIAL_PCT_OF_REVENUE = 25       # total debt >= 25% of the last 12 months' revenue
# Dilution = basic weighted shares YoY (diluted counts jump when a company turns profitable).
DILUTION_VS_PEER_MEDIAN = [(-1, 100), (0, 85), (2, 60), (5, 35), (INF, 15)]          # pp above peer median
DILUTION_DEFAULT = {   # used until the peer median is entered
    "Software": [(2, 100), (4, 80), (7, 55), (10, 35), (INF, 15)],
    "other": [(0, 100), (1, 85), (3, 60), (6, 35), (INF, 15)],
}
BALANCE_MIX = {"net_debt": 25, "interest_cover": 15, "maturity": 15, "debt_pace": 10, "dilution": 35}

# --- Capital profile ---------------------------------------------------------
# Asset-heavy = net property and equipment >= 50% of a year's revenue, or capex >= 20% of revenue (12 months)
ASSET_HEAVY_PPE_PCT_OF_REVENUE = 50
ASSET_HEAVY_CAPEX_PCT_OF_REVENUE = 20
# Flags for Step 6 (explained, not scored)
IMPLIED_RATE_TOO_LOW_PCT = 2.0          # interest / debt below this: probably net of interest income
INTEREST_HEAVY_PCT_OF_REVENUE = 5.0     # interest above this share of revenue is flagged

# --- Execution block -------------------------------------------------------
BEAT_PCT = [(3, 100), (1.5, 80), (0.5, 60), (0, 45), (-1, 25), (-INF, 5)]           # revenue vs bar, %
EPS_BEAT_PCT = [(10, 100), (5, 80), (2, 60), (0, 45), (-5, 25), (-INF, 5)]
BEAT_VS_HABIT_PP = [(0, 100), (-1, 70), (-2, 45), (-INF, 20)]   # this beat minus average past beat
GUIDANCE_POINTS = {"raised": 100, "held": 60, "lowered": 15}
GUIDANCE_CUT_EXECUTION_CAP = 40   # house rule: guidance cut -> Execution cannot score above 40
EXECUTION_MIX = {"guidance": 30, "rev_vs_consensus": 25, "rev_vs_guidance": 15,
                 "beat_vs_habit": 15, "eps_vs_consensus": 15}

MIN_EXECUTION_INPUTS = 3   # fewer than 3 of the 5 Execution inputs: the grade is marked provisional

# --- House rules on the final grade ----------------------------------------
# Proposed by Rodrigo; not yet in the public methodology doc.
SOFTWARE_RULE_OF_40_FLOOR = {"enabled": True, "rule_of_40_above": 40, "min_score": 75}  # at least a B

# --- Projections ---------------------------------------------------------------
# Starting multiples by industry group. These are Tarsier's editable starting points, not market
# data: they will be replaced by the peer median once the Comparisons tab exists.
PROJ_BASE_MULTIPLES = {
    "Software": {"pe": 30, "ps": 6, "ev_ebitda": 22},
    "Semiconductors": {"pe": 25, "ps": 5, "ev_ebitda": 18},
    "Interactive media": {"pe": 22, "ps": 4, "ev_ebitda": 14},
    "default": {"pe": 20, "ps": 2.5, "ev_ebitda": 12},
}
# Suggested multiple = (base + per_point × forward revenue growth in %) / 2 × quality factor.
# For P/E, 1.5 per point is a PEG of 1.5: 30% growth alone would justify 45x.
PROJ_GROWTH_PER_POINT = {"pe": 1.5, "ps": 0.2, "ev_ebitda": 0.5}
PROJ_MULTIPLE_LIMITS = {"pe": (8, 80), "ps": (0.5, 30), "ev_ebitda": (4, 40)}
PROJ_PE_MIN_NET_MARGIN = 0.05   # P/E only once net margin is at least 5%: a tiny profit × P/E means nothing
# Quality factor from the latest quarter grade
PROJ_QUALITY = {"A+": 1.15, "A": 1.10, "A−": 1.05, "B+": 1.0, "B": 1.0, "B−": 0.95,
                "C+": 0.9, "C": 0.9, "C−": 0.85, "D": 0.8, "F": 0.7}
# Default path when you have not typed anything
PROJ_LONG_RUN_GROWTH = 0.05     # growth converges to this ...
PROJ_GROWTH_DECAY = 0.65        # ... closing 35% of the gap each year: 30% -> 21% -> 16% -> 13% -> 10%
PROJ_DEFAULT_GROWTH_CAP = 0.40  # an estimate for a future year is never above this (a 300% quarter does not repeat)
PROJ_SHARE_FADE = 0.8           # share-count growth (dilution) × 0.8 each year
PROJ_MARGIN_STEP = 0.015        # growth companies: operating margin +1.5pp a year ...
PROJ_MARGIN_CAP = {"Software": 0.35, "Semiconductors": 0.40, "default": 0.25}   # ... up to this
PROJ_MARGIN_CONVERGE_LOSS = 0.20   # while the margin is negative it closes 20% of the gap to the cap a year
PROJ_SBC_STEP = -0.005          # SBC % of revenue falls 0.5pp a year
PROJ_TAX_DEFAULT = 0.21         # used when the last 12 months' tax rate is not meaningful
PROJ_TAX_FLOOR = 0.15           # from next year on, tax rate at least this (one-off benefits do not repeat)
# Interest & other, net: next year on, gains and interest income are not projected (costs are)
PROJ_SCENARIO_OFFSETS = {       # bear and bull = base + these (g0 = current fiscal year, partly reported)
    "bear": {"g0": -0.02, "g": -0.05, "om": -0.02, "sg": 0.01},
    "bull": {"g0": 0.02, "g": 0.05, "om": 0.02, "sg": -0.005},
}
PROJ_WEIGHTS = {"bear": 0.25, "base": 0.50, "bull": 0.25}
PROJ_DISCOUNT_RATE = 0.10       # to bring a future price back to today

# --- Projections: margin of safety and the FCF valuation ---------------------------------------
PROJ_MARGIN_OF_SAFETY = 0.10    # every fair value is shown after this haircut
PROJ_TERMINAL_GROWTH = 0.025    # growth of free cash flow after the last projected year
# WACC by sector: engine/wacc_data.py (Damodaran, updated every January)
PROJ_TERMINAL_METHOD = "multiple"   # value after year 5: "multiple" (exit multiple on FCF) or "growth" (perpetual)
PROJ_FCF_CONVERSION_LIMITS = (0.4, 1.3)   # FCF ÷ net income of the last 12 months, kept within these bounds

# --- Portfolio: growth, value or dividend ------------------------------------------------------
# Checked in this order; the first rule that applies decides. Last 12 months, from SEC data.
PORT_DIV_YIELD_MIN = 0.025      # dividend yield of 2.5% or more → Dividend (needs the price from page 2)
PORT_GROWTH_MIN = 0.15          # revenue growth of 15% or more → Growth
PORT_DIV_PAYOUT_MIN = 0.40      # dividends of 40%+ of earnings (the larger of net income and FCF) → Dividend
#                                 everything else → Value (slower growth, little or no dividend)
PORT_MAX_SLICES = 8             # pie charts: up to 7 named slices; from 8 on, the smallest fold into "Other"
