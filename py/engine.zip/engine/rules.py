"""The scorecard's numbers, all in one place. Edit here to calibrate.

Bands are read top to bottom: the first line whose threshold the value
reaches gives the points. Version these changes: every report card states
the method version.
"""
METHOD_VERSION = "v0.2 (draft, calibrating)"
INF = float("inf")

# Block weights by company type (sum to 100)
WEIGHTS = {
    "growth": {"growth": 30, "profitability": 20, "cash": 15, "balance": 10, "execution": 25},
    "mature": {"growth": 15, "profitability": 25, "cash": 30, "balance": 20, "execution": 10},
}
GROWTH_COMPANY_MIN_YOY = 15.0   # company_type "auto": revenue YoY >= 15% -> growth company

GRADES = [(95, "A+"), (90, "A"), (85, "A−"), (80, "B+"), (75, "B"), (70, "B−"),
          (65, "C+"), (60, "C"), (50, "C−"), (40, "D"), (-INF, "F")]

# --- Growth block ----------------------------------------------------------
REVENUE_GROWTH = [(40, 100), (25, 80), (15, 60), (5, 40), (0, 20), (-INF, 0)]   # % YoY (organic when given)
ACCELERATION_PP = 3.0          # growth vs last quarter's growth, in pp
ACCELERATION_POINTS = 10       # + when accelerating by >= 3pp, - when decelerating by >= 3pp

# --- Profitability block ---------------------------------------------------
MARGIN_CHANGE = [(3, 100), (1, 85), (-0.5, 70), (-1.5, 50), (-3, 35), (-INF, 15)]   # pp YoY
RULE_OF_40 = [(50, 100), (40, 85), (30, 65), (20, 45), (-INF, 25)]                   # software only
# GAAP EPS vs the same quarter last year (Step 2: GAAP EPS is the scored number)
EPS_CHANGE_POINTS = {"turned profitable": 100, "loss narrowed": 65, "loss widened": 15, "turned to a loss": 5}
EPS_GROWTH = [(25, 100), (10, 85), (0, 70), (-10, 50), (-30, 35), (-INF, 20)]        # % YoY, profit to profit
# "ebitda" counts only for asset-heavy companies, where depreciation hides the trend in operating profit
PROFITABILITY_MIX = {"gross": 20, "operating": 25, "net": 10, "eps": 15, "leverage": 15, "rule_of_40": 15,
                     "ebitda": 20}

# --- Cash block ------------------------------------------------------------
FCF_MARGIN = [(25, 100), (15, 85), (8, 70), (0, 50), (-10, 25), (-INF, 10)]          # % of revenue
FCF_MARGIN_CHANGE = [(3, 100), (0.5, 80), (-0.5, 65), (-3, 40), (-INF, 20)]          # pp YoY
FCF_AFTER_SBC_MARGIN = [(15, 100), (5, 80), (0, 60), (-10, 35), (-INF, 15)]
SBC_TREND_PP = 0.5             # SBC % of revenue vs same quarter last year
SBC_TREND_POINTS = {"falling": 100, "stable": 70, "rising": 30}   # house rule: rising is negative
CFO_MARGIN = [(40, 100), (25, 85), (10, 65), (0, 40), (-INF, 15)]                    # % of revenue, last 12 months
# "cfo_margin" counts only for asset-heavy companies, whose FCF is pulled down by growth capex
CASH_MIX = {"fcf_margin": 35, "fcf_margin_change": 20, "fcf_after_sbc": 25, "sbc_trend": 20, "cfo_margin": 30}

# --- Balance sheet block ---------------------------------------------------
# Leverage: net cash scores 100; otherwise net debt / EBITDA of the last 12 months
NET_CASH_POINTS = 100
NET_DEBT_TO_EBITDA = [(1, 80), (2, 65), (3, 45), (4.5, 30), (INF, 15)]   # lower is better: first ceiling reached
NET_DEBT_NO_EBITDA_POINTS = 10
# Cost: EBITDA / interest expense, last 12 months (no interest expense scores 100)
INTEREST_COVER = [(10, 100), (6, 85), (4, 70), (2.5, 50), (1.5, 30), (-INF, 10)]
# Maturity: cash and short-term investments / debt due by the end of next fiscal year
NEAR_TERM_COVER = [(3, 100), (1.5, 80), (1, 60), (0.5, 35), (-INF, 15)]
# Pace: revenue growth minus debt growth, in pp. Scored only when debt is material.
DEBT_PACE_PP = [(10, 100), (0, 80), (-15, 55), (-40, 35), (-INF, 15)]
DEBT_MATERIAL_PCT_OF_REVENUE = 25       # total debt >= 25% of the last 12 months' revenue
# Dilution = basic weighted shares YoY (diluted counts jump when a company turns profitable).
DILUTION_VS_PEER_MEDIAN = [(-1, 100), (0, 85), (2, 60), (5, 35), (INF, 15)]          # pp above peer median
DILUTION_DEFAULT = {   # used until the peer median is entered
    "Software": [(2, 100), (4, 80), (7, 55), (10, 35), (INF, 15)],
    "other": [(0, 100), (1, 85), (3, 60), (6, 35), (INF, 15)],
}
BALANCE_MIX = {"net_debt": 25, "interest_cover": 15, "maturity": 15, "debt_pace": 10, "dilution": 35}

# --- Capital profile ---------------------------------------------------------
# Asset-heavy = net property and equipment >= 50% of a year's revenue, or capex >= 20% of revenue (12 months)
ASSET_HEAVY_PPE_PCT_OF_REVENUE = 50
ASSET_HEAVY_CAPEX_PCT_OF_REVENUE = 20
# Flags for Step 6 (explained, not scored)
IMPLIED_RATE_TOO_LOW_PCT = 2.0          # interest / debt below this: probably net of interest income
INTEREST_HEAVY_PCT_OF_REVENUE = 5.0     # interest above this share of revenue is flagged

# --- Execution block -------------------------------------------------------
BEAT_PCT = [(3, 100), (1.5, 80), (0.5, 60), (0, 45), (-1, 25), (-INF, 5)]           # revenue vs bar, %
EPS_BEAT_PCT = [(10, 100), (5, 80), (2, 60), (0, 45), (-5, 25), (-INF, 5)]
BEAT_VS_HABIT_PP = [(0, 100), (-1, 70), (-2, 45), (-INF, 20)]   # this beat minus average past beat
GUIDANCE_POINTS = {"raised": 100, "held": 60, "lowered": 15}
GUIDANCE_CUT_EXECUTION_CAP = 40   # house rule: guidance cut -> Execution cannot score above 40
EXECUTION_MIX = {"guidance": 30, "rev_vs_consensus": 25, "rev_vs_guidance": 15,
                 "beat_vs_habit": 15, "eps_vs_consensus": 15}

MIN_EXECUTION_INPUTS = 3   # fewer than 3 of the 5 Execution inputs: the grade is marked provisional

# --- House rules on the final grade ----------------------------------------
# Proposed by Rodrigo; not yet in the public methodology doc.
SOFTWARE_RULE_OF_40_FLOOR = {"enabled": True, "rule_of_40_above": 40, "min_score": 75}  # at least a B

# --- Projections ---------------------------------------------------------------
# Starting multiples by industry group. These are Tarsier's editable starting points, not market
# data: they will be replaced by the peer median once the Comparisons tab exists.
PROJ_BASE_MULTIPLES = {
    "Software": {"pe": 30, "ps": 6, "ev_ebitda": 22, "ev_sales": 8, "p_ffo": 16},
    "Semiconductors": {"pe": 25, "ps": 5, "ev_ebitda": 18, "ev_sales": 8, "p_ffo": 16},
    "Interactive media": {"pe": 22, "ps": 4, "ev_ebitda": 14, "ev_sales": 7, "p_ffo": 16},
    "default": {"pe": 20, "ps": 2.5, "ev_ebitda": 12, "ev_sales": 6, "p_ffo": 16},
}
# Suggested multiple = (base + per_point × forward revenue growth in %) / 2 × quality factor.
# For P/E, 1.5 per point is a PEG of 1.5: 30% growth alone would justify 45x.
PROJ_GROWTH_PER_POINT = {"pe": 1.5, "ps": 0.2, "ev_ebitda": 0.5, "ev_sales": 0.2, "p_ffo": 0.5}
PROJ_MULTIPLE_LIMITS = {"pe": (8, 80), "ps": (0.5, 30), "ev_ebitda": (4, 40), "ev_sales": (0.5, 25),
                        "p_ffo": (8, 30), "p_d": (8, 45), "p_tbv": (0.5, 3.5), "p_b": (0.5, 4.0)}
PROJ_PE_MIN_NET_MARGIN = 0.05   # P/E only once net margin is at least 5%: a tiny profit × P/E means nothing
# Quality factor from the latest quarter grade
PROJ_QUALITY = {"A+": 1.15, "A": 1.10, "A−": 1.05, "B+": 1.0, "B": 1.0, "B−": 0.95,
                "C+": 0.9, "C": 0.9, "C−": 0.85, "D": 0.8, "F": 0.7}
# Default path when you have not typed anything
PROJ_LONG_RUN_GROWTH = 0.03     # growth converges to this ...
PROJ_GROWTH_DECAY = 0.65        # ... keeping 65% of the gap each year: 30% -> 20% -> 14% -> 10% -> 8%
PROJ_DECAY_BY_SIZE = [(200_000, 0.50), (50_000, 0.55)]   # revenue of $50B / $200B and more ($M): fades faster
PROJ_DEFAULT_GROWTH_CAP = 0.40  # an estimate for a future year is never above this (a 300% quarter does not repeat)
PROJ_SHARE_FADE = 0.8           # share-count growth (dilution) × 0.8 each year
PROJ_MARGIN_STEP = 0.015        # growth companies: operating margin +1.5pp a year ...
PROJ_MARGIN_CAP = {"Software": 0.35, "Semiconductors": 0.40, "default": 0.25}   # ... up to this
PROJ_MARGIN_CONVERGE_LOSS = 0.20   # while the margin is negative it closes 20% of the gap to the cap a year
PROJ_SBC_STEP = -0.005          # SBC % of revenue falls 0.5pp a year
PROJ_TAX_DEFAULT = 0.21         # used when the last 12 months' tax rate is not meaningful
PROJ_TAX_FLOOR = 0.15           # from next year on, tax rate at least this (one-off benefits do not repeat)
# Interest & other, net: next year on, gains and interest income are not projected (costs are)
PROJ_SCENARIO_OFFSETS = {       # bear and bull = base + these (g0 = current fiscal year, partly reported)
    "bear": {"g0": -0.02, "g": -0.05, "om": -0.02, "sg": 0.01, "roe": -0.02},
    "bull": {"g0": 0.02, "g": 0.05, "om": 0.02, "sg": -0.005, "roe": 0.02},
}
PROJ_WEIGHTS = {"bear": 0.25, "base": 0.50, "bull": 0.25}
PROJ_DISCOUNT_RATE = 0.10       # to bring a future price back to today

# --- Projections: margin of safety and the FCF valuation ---------------------------------------
PROJ_MARGIN_OF_SAFETY = 0.10    # every fair value is shown after this haircut
PROJ_TERMINAL_GROWTH = 0.025    # growth of free cash flow after the last projected year
# WACC by sector: engine/wacc_data.py (Damodaran, updated every January)
PROJ_TERMINAL_METHOD = "multiple"   # value after year 5: "multiple" (exit multiple on FCF) or "growth" (perpetual)
PROJ_FCF_CONVERSION_LIMITS = (0.4, 1.3)   # FCF ÷ net income of the last 12 months, kept within these bounds

# --- Portfolio: growth, value or dividend ------------------------------------------------------
# Checked in this order; the first rule that applies decides. Last 12 months, from SEC data.
PORT_DIV_YIELD_MIN = 0.025      # dividend yield of 2.5% or more → Dividend (needs the price from page 2)
PORT_GROWTH_MIN = 0.15          # revenue growth of 15% or more → Growth
PORT_DIV_PAYOUT_MIN = 0.40      # dividends of 40%+ of earnings (the larger of net income and FCF) → Dividend
#                                 everything else → Value (slower growth, little or no dividend)
PORT_MAX_SLICES = 8             # pie charts: up to 7 named slices; from 8 on, the smallest fold into "Other"

# --- Portfolio: your rules (the Warnings box) ----------------------------------------------------
# Largest share of the whole portfolio (cash included) for one position, by how sure you are of it.
CONVICTION_CAPS = {"High conviction": 0.30, "Conviction": 0.10, "Gamble": 0.03}
CONVICTION_DEFAULT = "Conviction"       # a stock with no conviction set is held to this cap
CASH_MIN, CASH_MAX = 0.10, 0.25          # cash: 25% with the market at its highs, 10% after a correction
CASH_DD_HIGHS = 0.03                     # QQQ and the S&P 500 within 3% of their all-time highs → at the highs
CASH_DD_CORRECTION = 0.20                # 20% or more below → full correction: cash down to 10%
CASH_TOLERANCE = 0.05                    # flag cash more than 5 points from the target
SECTOR_MAX = 0.40                        # one sector above 40% of the money invested (funds and cash aside)
DEFENSIVE_MIN = 0.10                     # Value + Dividend below 10% of the money invested
GAMBLES_MAX = 0.10                       # all gambles together above 10% of the portfolio
WEAK_GRADES = ("D+", "D", "D-", "D−", "F")   # holdings graded this low last quarter

# --- Macroeconomy: the grade of the US economy (Macroeconomy page) -------------------------------------
ECON_WEIGHTS = {"Growth": 20, "Jobs": 40, "Inflation": 40}   # the Fed watches jobs and prices most
ECON_GDP_TREND = 2.0                     # long-run US real growth, % a year: above it is "above trend"
ECON_GDP = [(3.0, 100), (2.0, 80), (1.0, 55), (0.0, 30), (-INF, 0)]            # real GDP %, quarter (annualized) and year
ECON_UNEMPLOYMENT = [(4.0, 100), (4.5, 80), (5.0, 60), (6.0, 35), (INF, 10)]   # rate %, at or under
ECON_UNEMPLOYMENT_RISE = [(0.5, -40), (0.3, -20), (0.15, -10)]                # pts in 6 months (0.5 ≈ recession signal)
ECON_UNEMPLOYMENT_FALL = 10                                                   # falling 0.15 pts or more in 6 months
ECON_CLAIMS = [(300_000, -15), (250_000, -5)]                                  # initial claims, 4-week average
ECON_CORE_INFLATION = [(2.25, 100), (2.5, 85), (2.75, 65), (3.0, 45), (3.25, 35), (3.5, 25), (4.0, 10),
                       (INF, 0)]                                             # core PCE % year on year: hot costs fast
ECON_HIKING = -5                    # the Fed is raising rates (its last move in 12 months was a hike): off the total
ECON_HOT_CAP = 70                   # inflation block under 40: the total stays under 70 (B− at best)
ECON_HOT_BLOCK = 40
ECON_INFLATION_RISING = -15         # 2+ of CPI, core CPI, PCE, core PCE up 0.15 pts or more in 6 months
ECON_INFLATION_FALLING = 10         # 2+ of them down as much

# --- Valuation by business model (methodology, section 10) --------------------------------------------
# Each company is valued the way the market values its kind of business. The model comes from the
# Peer Groups workbook ("Business model" column), else from the SIC code and the numbers; the method
# can be changed per company in the Projections window.
BUSINESS_MODELS = {   # code: (label, valuation method)
    "software": ("Subscription software", "ev_sales_r40"),
    "cyclical": ("Cyclical semiconductors and hardware", "pe_midcycle"),
    "dividend": ("Dividend payer", "ddm"),
    "reit": ("REIT", "p_ffo"),
    "bank": ("Bank or lender", "p_tbv"),
    "insurer": ("Insurer", "p_b"),
    "energy": ("Energy and commodities", "ev_ebitda"),
    "capital_heavy": ("Capital heavy", "ev_ebitda"),
    "unprofitable_growth": ("Unprofitable high growth", "ev_sales"),
    "pre_revenue": ("Pre-revenue", "none"),
    "standard": ("Standard", "auto"),
}
RULE_OF_40_PIVOT = 40            # EV/Sales = starting EV/Sales × (Rule of 40 ÷ 40) × quality
NOT_SUBSCRIPTION_SIC = (7370, 7374, 7375)   # data processing, internet platforms: graded as software, valued on earnings
CYCLICAL_SIC = (3674, 3672, 3572, 3576, 3577, 3661, 3663, 3679)   # semis, boards, storage, networking
ENERGY_SIC = [(1000, 1499), (2900, 2999)]                          # mining, oil and gas, refining
CAPITAL_HEAVY_SIC = [(3711, 3716), (3530, 3537), (4800, 4899), (4900, 4991), (4000, 4799)]   # autos, machinery,
                                                                   # telecom, utilities, transport
MODEL_DECAY = {"cyclical": 0.50, "energy": 0.40}                  # growth fades faster in cycles
ENERGY_GROWTH_CAP = 0.05         # no growth projected from a commodity price spike
MIDCYCLE_PULL = 0.35             # cyclicals: margin closes 35% of the gap to the mid-cycle margin a year
CYCLE_FACTOR_LIMITS = (0.70, 1.0)   # P/E × mid-cycle ÷ current margin when margins sit above mid-cycle
CYCLE_PEAK_SHARE = 0.90          # "at a peak": the last 12 months' margin is 90% or more of the best year
COST_OF_EQUITY = {"dividend": 0.08, "reit": 0.08, "bank": 0.10, "insurer": 0.09, "default": 0.09}
DDM_MAX_GROWTH = 0.06            # dividend growth used for ever, at most
DDM_MIN_SPREAD = 0.02            # cost of equity − dividend growth, at least
DIVIDEND_MIN_PAYOUT = 0.40       # a dividend payer pays out 40% of earnings or more ...
DIVIDEND_MAX_GROWTH = 0.08       # ... and grows revenue under 8%
PRE_REVENUE_MAX_MUSD = 50        # under $50M of revenue in 12 months and a loss: not valued
UNPROFITABLE_GROWTH_MIN = 0.20   # a loss and revenue growing 20%+: valued on EV/Sales

# --- Portfolio: where the monthly contribution goes (methodology, section 11) ----------------------------
DISCOUNT_FROM_HIGH = 0.20        # last close 20% or more under its 52-week high: "discounted", first in line
CONTRIBUTION_WEIGHTS = {"High conviction": 3, "Conviction": 2, "Gamble": 1, None: 2}   # share of the month
DEFENSIVE_STYLES = ("Value", "Dividend")
DEFENSIVE_MONTH_SHARE = 1 / 3   # while value + dividend is under DEFENSIVE_MIN: up to a third of the stock money
                                # goes there (held value/dividend names first, gambles excluded; else new positions)


# ---------- shareholder risks: what can take value away from today's shareholder ------------------
# (level "watch" from the first number, "high" from the second; shown as warnings, they do not move the grade)
HOLDER_DILUTION_PCT = (2.0, 5.0)          # share count growth on the year, %
HOLDER_SBC_REVENUE_PCT = (10.0, 20.0)     # stock-based pay as % of revenue (latest quarter)
HOLDER_SBC_FCF = (0.40, 0.80)             # stock-based pay as a share of free cash flow, 12 months
HOLDER_OVERHANG_PCT = 3.0                 # diluted vs basic shares: options and RSUs waiting to vest
HOLDER_ACQUISITIONS_FCF = 1.0             # acquisitions above this share of 12-month FCF
HOLDER_EQUITY_RAISE_REV = 0.05            # new shares sold above this share of 12-month revenue
HOLDER_ADJUSTED_GAP = 0.50                # adjusted EPS this much above GAAP EPS (gap / adjusted)
HOLDER_SOFT_ASSETS_PCT = 50.0             # goodwill + acquired intangibles as % of total assets
HOLDER_TAX_WITHHELD_FCF = 0.10            # cash paid for employees' stock taxes, share of FCF
HOLDER_SALES_METHODS = ("ev_sales_r40", "ev_sales", "ps")   # valuations that never see stock-based pay
