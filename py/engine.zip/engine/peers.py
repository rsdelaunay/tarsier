"""Peers: who they are (the Peer Groups workbook) and their last-twelve-month numbers (SEC data).

Peer numbers are computed once and kept in _cache/peer_stats.json; a peer is refreshed when its
stats are older than MAX_AGE_DAYS. Foreign filers (marked * in the workbook) have no 10-Q and are skipped.
"""
import glob
import json
import os
import statistics
from datetime import date

from openpyxl import load_workbook

from . import edgar, metrics, paths

MAX_AGE_DAYS = 7
STATS = os.path.join(paths.CACHE, "peer_stats.json")
# key, label
FIELDS = [("rev_growth", "revenue growth"), ("op_margin", "operating margin"), ("net_margin", "net margin"),
          ("eps_growth", "EPS growth"), ("fcf_margin", "FCF margin"), ("fcf_growth", "FCF growth"),
          ("sbc_pct", "SBC % of revenue"), ("dilution", "share count growth"),
          ("gross_margin", "gross margin"), ("rnd_pct", "R&D % of revenue")]


def _workbook():
    hits = sorted(glob.glob(os.path.join(paths.BASE, "*Peer Groups*.xlsx")))
    return hits[0] if hits else None


def _tickers(cell):
    out = []
    for t in str(cell or "").replace(";", ",").split(","):
        t = t.strip().upper()
        if t:
            out.append(t)
    return out


def groups_for(ticker):
    """[(group name, [peers without the company itself], scorecard)] from the Peer Groups workbook."""
    path = _workbook()
    if not path:
        return []
    t = ticker.upper()
    out = []
    wb = load_workbook(path, read_only=True, data_only=True)
    for ws in wb.worksheets:
        head = None
        for row in ws.iter_rows(values_only=True):
            cells = [str(c).strip() if c is not None else "" for c in row]
            if head is None:
                if "Peers" in cells:
                    head = {name: i for i, name in enumerate(cells) if name}
                continue
            name = cells[0]
            members = _tickers(cells[head["Peers"]])
            if "Also followed" in head and head["Also followed"] < len(cells):
                members += _tickers(cells[head["Also followed"]])
            if not name or t not in [x.rstrip("*") for x in members]:
                continue
            score = cells[head["Scorecard"]] if "Scorecard" in head and head["Scorecard"] < len(cells) else ""
            out.append((name, [x for x in members if x.rstrip("*") != t], score))
    wb.close()
    return out


def model_for(ticker):
    """The 'Business model' column of the company's peer group in the Peer Groups workbook (or None).
    Codes or labels from rules.BUSINESS_MODELS: software, cyclical, dividend, reit, bank, insurer, energy,
    capital_heavy, unprofitable_growth, pre_revenue, standard."""
    from . import rules
    path = _workbook()
    if not path:
        return None
    t = ticker.upper()
    by_label = {lab.lower(): code for code, (lab, _m) in rules.BUSINESS_MODELS.items()}
    found = None
    try:
        wb = load_workbook(path, read_only=True, data_only=True)
    except Exception:
        return None
    for ws in wb.worksheets:
        head = None
        for row in ws.iter_rows(values_only=True):
            cells = [str(c).strip() if c is not None else "" for c in row]
            if head is None:
                if "Peers" in cells:
                    head = {name: i for i, name in enumerate(cells) if name}
                continue
            col = head.get("Business model")
            if col is None or col >= len(cells) or not cells[col]:
                continue
            members = _tickers(cells[head["Peers"]])
            if "Also followed" in head and head["Also followed"] < len(cells):
                members += _tickers(cells[head["Also followed"]])
            if t in [x.rstrip("*") for x in members]:
                v = cells[col].strip().lower().replace(" ", "_")
                found = v if v in rules.BUSINESS_MODELS else by_label.get(cells[col].strip().lower())
                if found:
                    break
        if found:
            break
    wb.close()
    return found


def stats_from(co):
    """Last-twelve-month numbers of one company, as fractions. None where the data is missing."""
    ends = co.quarter_ends()
    if not ends:
        return None
    end = ends[-1]
    prior = co.previous(end, 4)

    def ttm(field, e=end):
        return co.ttm(field, e) if e else None

    def ratio(a, b):
        return None if a is None or not b else a / b

    def growth(a, b):
        return None if a is None or b is None or b <= 0 else a / b - 1
    rev, rev_p = ttm("revenue"), ttm("revenue", prior)
    ni, ni_p = ttm("net_income"), ttm("net_income", prior)
    fcf, fcf_p = ttm("fcf"), ttm("fcf", prior)
    cur, old = co.snapshot(end), co.snapshot(prior) if prior else None
    sh, sh_p = cur.get("shares_diluted"), (old or {}).get("shares_diluted")
    eps, eps_p = ratio(ni, sh), ratio(ni_p, sh_p)
    b, b_p = cur.get("shares_basic"), (old or {}).get("shares_basic")
    return {
        "period_end": end,
        "rev_growth": growth(rev, rev_p), "op_margin": ratio(ttm("operating_income"), rev),
        "net_margin": ratio(ni, rev),
        "eps_growth": growth(eps, eps_p) if eps is not None and eps > 0 else None,
        "fcf_margin": ratio(fcf, rev), "fcf_growth": growth(fcf, fcf_p) if fcf is not None and fcf > 0 else None,
        "sbc_pct": ratio(ttm("sbc"), rev), "dilution": growth(b, b_p),
        "gross_margin": ratio(ttm("gross_profit"), rev), "rnd_pct": ratio(ttm("rnd"), rev),
        **_fund(co),
    }


def _fund(co):
    """The numbers Stock fundamentals compares with: ratios, and what multiples need (at today's price)."""
    from . import fundamentals
    try:
        f = fundamentals.from_filings(co) or {}
    except Exception:                    # the phone's engine has no fundamentals module: just skip them
        return {}
    return {k: f.get(k) for k in ("revenue", "net_income", "fcf", "ebitda", "eps", "equity", "cash", "debt", "shares",
                                  "roe", "roa", "roic", "current_ratio", "quick_ratio", "debt_eq", "lt_debt_eq",
                                  "payout")}


def _load():
    try:
        with open(STATS, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _save(data):
    os.makedirs(paths.CACHE, exist_ok=True)
    with open(STATS, "w", encoding="utf-8") as f:
        json.dump(data, f)


def _fresh(entry):
    try:
        return (date.today() - date.fromisoformat(entry["asof"])).days <= MAX_AGE_DAYS
    except (KeyError, TypeError, ValueError):
        return False


def load(ticker, offline=False, progress=None):
    """Peer numbers for a company. Downloads what is missing from the SEC (unless offline)."""
    groups = groups_for(ticker)
    names = []
    for _name, members, _score in groups:
        for x in members:
            if x not in names:
                names.append(x)
    cache = _load()
    got, missing, foreign = {}, [], []
    todo = [x for x in names if not x.endswith("*")]
    foreign = [x.rstrip("*") for x in names if x.endswith("*")]
    for i, t in enumerate(todo, 1):
        entry = cache.get(t)
        if entry and (_fresh(entry) or offline) and "roic" in entry["stats"]:
            got[t] = entry["stats"]
            continue
        if progress:
            progress(f"peers of {ticker}: {t} ({i} of {len(todo)})")
        try:
            # older stats without the fundamentals: work them out again from the filings already on this PC
            facts, _subs, _status = edgar.update(t, offline or bool(entry and _fresh(entry)))
            st = stats_from(metrics.Company(facts))
        except (edgar.SecError, RuntimeError, KeyError, ValueError):
            st = None
        if st:
            cache[t] = {"asof": date.today().isoformat(), "stats": st}
            got[t] = st
            _save(cache)
        elif entry:
            got[t] = entry["stats"]          # stale is better than nothing
        else:
            missing.append(t)
    return summarise(ticker, groups, got, missing, foreign)


def summarise(ticker, groups, got, missing=(), foreign=()):
    med, mean, n = {}, {}, {}
    for k, _label in FIELDS:
        vals = [s[k] for s in got.values() if s.get(k) is not None]
        n[k] = len(vals)
        med[k] = statistics.median(vals) if vals else None
        mean[k] = statistics.fmean(vals) if vals else None
    return {"ticker": ticker.upper(), "groups": [g for g, _m, _s in groups], "peers": got,
            "median": med, "mean": mean, "n": n, "missing": list(missing), "foreign": list(foreign)}


def text(p, key, signed=False):
    """'peers: median 23.4% · mean 25.1% (8)' or '' when there is nothing to show."""
    if not p or not p["n"].get(key):
        return ""
    fmt = "{:+.1f}%" if signed else "{:.1f}%"
    return (f"peers: median {fmt.format(p['median'][key] * 100)} · mean {fmt.format(p['mean'][key] * 100)} "
            f"({p['n'][key]})")
