"""Results day: grade a quarter from the earnings press release until the 10-Q / 10-K reaches the SEC.

On results day the company files an 8-K (Item 2.02) with the press release as Exhibit 99. Its tables are not
machine-tagged like a 10-Q, so they are read by press.py, checked by you in the window, and saved in
TICKER_prelim.json. The quarter is then graded as PRELIMINARY. When the 10-Q / 10-K arrives, its numbers
replace yours and the differences are reported once.
"""
import json
import os
import re
from datetime import date, timedelta

from . import edgar, metrics, paths, press, xbrl

QUARTER_KEYS = ["revenue", "cost_of_revenue", "gross_profit", "rnd", "sales_marketing", "ga", "sga",
                "operating_income", "interest_expense", "pretax", "tax", "net_income"]
PER_SHARE_KEYS = ["eps_diluted", "shares_diluted", "shares_basic"]
FLOW_KEYS = ["cfo", "capex_ppe", "capex_software", "sbc", "da_cf", "acquisitions"]   # kept quarter by quarter
# not in a press release, and slow to change: taken from the last 10-Q / 10-K until the filing arrives
CARRY = ["mat_rem", "mat_y1", "mat_y2", "mat_y3", "mat_y4", "mat_y5", "mat_after", "debt_principal", "secured_debt"]
USE_KEYS = {**{k: k for k in ("buybacks", "dividends", "tax_withheld", "stock_issued", "debt_issued",
                              "debt_repaid")}, "acquisitions": "acquisitions_ytd"}   # where the cash went: year to date
BS_KEYS = ["cash", "st_investments", "total_assets", "goodwill", "ppe_net", "debt_current", "debt_noncurrent"]
REQUIRED = ("revenue", "net_income")
SAME_QUARTER_DAYS = 10
ARCHIVE = "https://www.sec.gov/Archives/edgar/data/{cik}/{acc_nd}/{acc}.txt"


def _d(s):
    return date.fromisoformat(s)


def path(ticker):
    return os.path.join(paths.COMPANIES, ticker.upper(), f"{ticker.upper()}_prelim.json")


def load(ticker):
    try:
        with open(path(ticker), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def save(ticker, data):
    p = path(ticker)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=1)


# ---------- the calendar ---------------------------------------------------------------------------
def _fy_ends(co):
    return sorted(e for e, (d, _v) in co.ytd_days.get("cfo", {}).items() if d >= 350)


def fy_end_before(co, end):
    prior = [e for e in _fy_ends(co) if e < end]
    if prior:
        return prior[-1]
    ends = co.quarter_ends()            # no cash flow history: assume quarters run in fours from the first
    return None if not ends else ends[0]


def next_quarter(co):
    """(expected end, year-ago end, label) of the quarter after the last one at the SEC."""
    ends = co.quarter_ends()
    last = ends[-1]
    ya = xbrl.find_end(ends, last, 274, 15)          # three quarters before the last = a year before the next
    if ya is None:
        return None
    exp = press.expected_end(ya, last)
    return exp, ya, next_label(co, ya)


def next_label(co, ya_end):
    lab = co.label(ya_end)
    m = re.match(r"FY(\d{4}) (Q\d)", lab or "")
    return f"FY{int(m.group(1)) + 1} {m.group(2)}" if m else None


# ---------- what we already know about last year -----------------------------------------------------
def refs(co, end):
    """{key: [(value, basis)]}: the year-ago numbers a press release must show next to this quarter."""
    ends = [e for e in co.quarter_ends() if e < end]
    ya = xbrl.find_end(ends, end, 364, 12)
    out = {}
    if ya is None:
        return out
    s = co.snapshot(ya) or {}
    for k in QUARTER_KEYS + PER_SHARE_KEYS + FLOW_KEYS:
        if s.get(k) is not None:
            out.setdefault(k, []).append((s[k], "q"))
    ya_fy = fy_end_before(co, ya)
    if ya_fy:
        in_year = [e for e in ends if ya_fy < e <= ya]
        for k in FLOW_KEYS:
            vals = [co.v(k, e) for e in in_year]
            if vals and all(v is not None for v in vals) and len(vals) > 1:
                out.setdefault(k, []).append((sum(vals), "ytd"))
        cfo_ytd = co.ytd_days.get("cfo", {}).get(ya)
        if cfo_ytd and cfo_ytd[0] > 100:
            out.setdefault("cfo", []).append((cfo_ytd[1], "ytd"))
        prev = xbrl.find_end(ends, ya, 91, 15)
        for k, use in USE_KEYS.items():
            y = co.ytd_days.get(use, {}).get(ya)
            if y:
                out.setdefault(k, []).append((y[1], "ytd"))
                p = co.ytd_days[use].get(prev) if prev and prev > ya_fy else None
                q = y[1] - (p[1] if p else 0)
                if q:
                    out[k].append((q, "q"))
    fy = fy_end_before(co, end)
    for k in BS_KEYS:
        for e in dict.fromkeys([fy, ya]):
            if e and co.iv(k, e) is not None:
                out.setdefault(k, []).append((co.iv(k, e), "bs"))
    if "debt_noncurrent" not in out:                 # some companies tag only total long-term debt
        for e in dict.fromkeys([fy, ya]):
            tot, cur = (co.iv("debt_total", e), co.iv("debt_current", e)) if e else (None, None)
            if tot is not None:
                out.setdefault("debt_noncurrent", []).append((tot - (cur or 0), "bs"))
    return out


def refs_for(ticker, end):
    """Year-ago numbers for any quarter end, from the cached SEC data (the review screen asks for these when
    the pasted release turns out to be for another quarter than expected)."""
    facts, _subs, _st = edgar.update(ticker.upper(), True)
    co = metrics.Company(facts)
    ends = [e for e in co.quarter_ends() if e < end]
    ya = xbrl.find_end(ends, end, 364, 12)
    return {"refs": refs(co, end), "year_ago": year_ago_view(co, end), "label": next_label(co, ya) if ya else None}


def year_ago_view(co, end):
    """The year-ago number for each line, as the review screen shows it next to yours."""
    out = {}
    for k, lst in refs(co, end).items():
        q = [v for v, b in lst if b in ("q", "bs")]
        out[k] = q[0] if q else None
    return out


# ---------- the 8-K ------------------------------------------------------------------------------------
def latest_release(subs):
    """The newest 8-K with Item 2.02 (results) filed after the latest 10-Q / 10-K, or None."""
    r = (subs or {}).get("filings", {}).get("recent", {})
    per = edgar.latest_periodic(subs)
    after = per[2] if per else "0000"
    for form, acc, filed, items, doc in zip(r.get("form", []), r.get("accessionNumber", []),
                                            r.get("filingDate", []), r.get("items", []),
                                            r.get("primaryDocument", [])):
        if filed <= after:
            return None                               # newest first: everything below is older
        if form == "8-K" and "2.02" in (items or ""):
            return {"accession": acc, "filed": filed, "doc": doc}
    return None


def _exhibits(full_text):
    """HTML of the EX-99.x documents inside a full EDGAR submission (.txt)."""
    out = []
    for block in re.findall(r"<DOCUMENT>(.*?)</DOCUMENT>", full_text, flags=re.S | re.I):
        typ = re.search(r"<TYPE>([^\n<]+)", block)
        if typ and typ.group(1).strip().upper().startswith("EX-99"):
            body = re.search(r"<TEXT>(.*)</TEXT>", block, flags=re.S | re.I)
            out.append((typ.group(1).strip(), body.group(1) if body else block))
    out.sort(key=lambda x: x[0])
    return "\n".join(h for _t, h in out)


def fetch_release(ticker, subs, rel):
    """The press release HTML (cached in _cache)."""
    cache = os.path.join(paths.CACHE, f"{ticker.upper()}_8k_{rel['accession']}.html")
    if os.path.exists(cache):
        with open(cache, encoding="utf-8") as f:
            return f.read()
    ua = edgar.load_config()["sec_user_agent"]
    cik = int(subs.get("cik") or edgar.ticker_to_cik(ticker.upper(), ua))
    url = ARCHIVE.format(cik=cik, acc_nd=rel["accession"].replace("-", ""), acc=rel["accession"])
    html = _exhibits(edgar.get_text(url, ua))
    if not html.strip():
        raise edgar.SecError("the 8-K has no press release exhibit (EX-99)")
    os.makedirs(paths.CACHE, exist_ok=True)
    with open(cache, "w", encoding="utf-8") as f:
        f.write(html)
    return html


def read_release(co, tables, text, source):
    """A draft for the review screen: the quarter, what was found and the year-ago numbers."""
    nq = next_quarter(co)
    if not nq:
        return None
    exp, _ya, label = nq
    named = press.period_end_in(text)
    end = named if named and named > co.quarter_ends()[-1] else press.quarter_end(text, exp)
    found = press.extract(tables, refs(co, end))
    unit, how = press.unit_of(found, tables)
    return {"period_end": end, "label": label, "source": source, "found": found, "unit": unit, "unit_how": how,
            "adjusted_eps": press.adjusted_eps(tables), "year_ago": year_ago_view(co, end),
            "refs": refs(co, end)}


# ---------- putting a preliminary quarter into the company ------------------------------------------
def overlay(co, p):
    """Add the press-release quarter to the company's data, as if the SEC had it."""
    end = p["period_end"]
    v = p["values"]
    ends = co.quarter_ends()
    prev = xbrl.find_end(ends, end, 91, 15)
    start = (_d(prev) + timedelta(days=1)).isoformat() if prev else (_d(end) - timedelta(days=90)).isoformat()
    fy = fy_end_before(co, end)
    in_year = [e for e in ends if fy and fy < e < end]
    bases = p.get("basis", {})

    def put(key, val):
        co.q.setdefault(key, {})[end] = {"val": val, "start": start, "derived": False, "concept": "press release"}

    for k in QUARTER_KEYS + PER_SHARE_KEYS:
        if v.get(k) is not None:
            put(k, float(v[k]))
    last_q = ends[-1] if ends and ends[-1] < end else prev
    if last_q and v.get("shares_diluted") is None and v.get("shares_basic") is None:
        for k in ("shares_diluted", "shares_basic"):          # no share count in the release: last quarter's
            rec = co.q.get(k, {}).get(last_q)
            val = rec["val"] if rec else co.year_shares[k].get(last_q)
            if val:
                co.q[k][end] = {"val": val, "start": start, "derived": True, "concept": "carried from the last filing"}
    for k in FLOW_KEYS:
        if v.get(k) is None:
            continue
        x = float(v[k])
        if bases.get(k, "q") == "ytd":
            earlier = [co.v(k, e) for e in in_year]
            if any(e is None for e in earlier):
                continue                              # cannot split the year to date into quarters
            x -= sum(earlier)
        put(k, x)
    days = (_d(end) - _d(fy)).days if fy else 91
    for k, use in [("cfo", "cfo")] + list(USE_KEYS.items()):
        if v.get(k) is None:
            continue
        x = float(v[k])
        if bases.get(k, "q") == "q":
            p_ = co.ytd_days.get(use, {}).get(prev) if prev and fy and prev > fy else None
            x += p_[1] if p_ else 0
        co.ytd_days.setdefault(use, {})[end] = (days, x)
    for k in BS_KEYS:
        if v.get(k) is not None:
            co.i.setdefault(k, {})[end] = {"val": float(v[k]), "concept": "press release"}
    last = ends[-1] if ends and ends[-1] < end else prev
    for k in CARRY:
        rec = co.i.get(k, {}).get(last) if last else None
        if rec and end not in co.i[k]:
            co.i[k][end] = {**rec, "concept": "carried from the last filing"}
    if last and last in co.disclosed_rate and end not in co.disclosed_rate:
        co.disclosed_rate[end] = co.disclosed_rate[last]
    co.labels[end] = (p.get("label") or end, "8-K" if p.get("accession") else "press release",
                      p.get("filed") or p.get("confirmed"))
    co._snap = {}


def compare(co, p, sec_end):
    """Press release vs the 10-Q: lines that moved by more than 0.5%."""
    s = co.snapshot(sec_end) or {}
    out = []
    for k in ("revenue", "cost_of_revenue", "operating_income", "net_income", "eps_diluted", "shares_diluted",
              "cfo", "capex_ppe", "cash"):
        a, b = p["values"].get(k), s.get(k)
        if p.get("basis", {}).get(k) == "ytd":
            continue
        if a is None or b is None:
            continue
        gap = (b - a) / abs(a) * 100 if a else None
        if gap is not None and abs(gap) > 0.5:
            out.append(f"{press.LABEL[k].lower()} {gap:+.1f}%")
    return out


def state(ticker, co, subs, offline):
    """Decide what results day means for this company now, and apply a saved preliminary quarter.

    Returns {'mode': 'none'|'found'|'preliminary'|'superseded', ...} for the window."""
    t = ticker.upper()
    sec_ends = co.quarter_ends()
    per = edgar.latest_periodic(subs)
    st = {"mode": "none", "last_filing": f"{per[0]} filed {per[2]}" if per else None,
          "last_sec_end": sec_ends[-1] if sec_ends else None,
          "sec_quarters": [[e, co.label(e)] for e in sec_ends[-8:]]}
    if len(sec_ends) < 5:                 # not enough history (foreign filer, recent IPO): nothing to anchor on
        return st
    nq = next_quarter(co)
    if nq:
        st["next"] = {"period_end": nq[0], "label": nq[2], "refs": refs(co, nq[0]),
                      "year_ago": year_ago_view(co, nq[0])}
    p = load(t)
    if p and p.get("values") and not p.get("removed"):
        same = [e for e in sec_ends if abs((_d(e) - _d(p["period_end"])).days) <= SAME_QUARTER_DAYS]
        if same:
            if not p.get("superseded"):
                p["superseded"] = {"date": date.today().isoformat(), "sec_end": same[0],
                                   "diffs": compare(co, p, same[0]), "grade_was": p.get("grade"),
                                   "grade_now": None, "filing": st["last_filing"],
                                   "check": p.get("grade") is None}       # pasted after the filing: a check
                save(t, p)
            st.update(mode="superseded", prelim=p)
        else:
            overlay(co, p)
            st.update(mode="preliminary", prelim=p)
    if offline:
        return st
    try:
        rel = latest_release(subs)
        if not rel or (p and p.get("accession") == rel["accession"]) or rel["accession"] in (p or {}).get(
                "dismissed", []):
            return st
        html = fetch_release(t, subs, rel)
        tables, text = press.parse_html(html)
        draft = read_release(co, tables, text, f"8-K filed {rel['filed']}")
        if draft and draft["period_end"] > sec_ends[-1] and (
                st["mode"] != "preliminary" or draft["period_end"] != p["period_end"]):
            draft.update(accession=rel["accession"], filed=rel["filed"])
            st["draft"] = draft
            if st["mode"] != "preliminary":
                st["mode"] = "found"
    except (edgar.SecError, OSError, ValueError) as e:
        st["error"] = f"press release: {e}"
    return st


def to_values(found):
    """The review screen works with what press.extract found; the file keeps plain numbers."""
    return {k: f["val"] for k, f in found.items()}


def bases(found):
    return {k: f["basis"] for k, f in found.items() if press.FIELDS[k][1] == "cf"}


def plausibility(values, year_ago):
    """Warnings the review screen shows before you grade."""
    w = []
    stable = ("revenue", "cost_of_revenue", "gross_profit", "rnd", "sga", "sales_marketing", "ga", "total_assets",
              "shares_diluted", "shares_basic", "goodwill")
    for k, v in values.items():
        y = year_ago.get(k)
        if v is None or not y or k not in stable:             # the others can really move 20-fold
            continue
        r = abs(v / y)
        if r > 20 or r < 0.05:
            w.append(f"{press.LABEL[k]} is {r:.0f}× last year: check the unit (thousands or millions)." if r > 1
                     else f"{press.LABEL[k]} is 1/{1 / r:.0f} of last year: check the unit.")
    ni, sh, eps = values.get("net_income"), values.get("shares_diluted"), values.get("eps_diluted")
    if ni and sh and eps and abs(ni / sh - eps) > max(0.02, 0.06 * abs(eps)):
        w.append(f"Net income ÷ diluted shares = {ni / sh:.2f}, but EPS says {eps:.2f}: check one of them.")
    if values.get("revenue") and not (values.get("shares_diluted") or values.get("shares_basic")):
        w.append("No share count: last quarter's is used, so new dilution is missed and the grade may come out "
                 "higher than with the 10-Q. Look for 'shares used in per share' in the release.")
    if values.get("revenue") and values.get("cfo") is None:
        w.append("No cash from operations: the Cash block waits for the 10-Q.")
    rev, gp, cor = values.get("revenue"), values.get("gross_profit"), values.get("cost_of_revenue")
    if rev and gp is not None and cor is not None and abs(rev - gp - cor) > 0.01 * rev:
        w.append("Revenue − cost of revenue ≠ gross profit: the cost line may leave out amortisation.")
    return w

