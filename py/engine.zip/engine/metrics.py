"""Steps 1-6 of 'How We Grade Earnings': every number the scorecard needs.

Everything here is arithmetic on the filings. No judgement, no grading.
"""
from . import xbrl

# --- XBRL tags, in order of preference -------------------------------------
DURATION = {
    "revenue": ["RevenueFromContractWithCustomerExcludingAssessedTax", "Revenues",
                "RevenueFromContractWithCustomerIncludingAssessedTax", "SalesRevenueNet"],
    "cost_of_revenue": ["CostOfRevenue", "CostOfGoodsAndServicesSold", "CostOfServices",
                        "CostOfGoodsSold"],
    "gross_profit": ["GrossProfit"],
    "sales_marketing": ["SellingAndMarketingExpense", "SellingExpense"],
    "rnd": ["ResearchAndDevelopmentExpense",
            "ResearchAndDevelopmentExpenseExcludingAcquiredInProcessCost"],
    "ga": ["GeneralAndAdministrativeExpense"],
    "sga": ["SellingGeneralAndAdministrativeExpense"],
    "da_is": ["DepreciationAndAmortization", "DepreciationDepletionAndAmortization",
              "AmortizationOfIntangibleAssets"],
    "restructuring": ["RestructuringCharges"],
    "acq_costs": ["BusinessCombinationAcquisitionRelatedCosts"],
    "operating_income": ["OperatingIncomeLoss"],
    "interest_expense": ["InterestExpense", "InterestExpenseNonoperating", "InterestExpenseDebt",
                         "InterestAndDebtExpense"],
    "interest_capitalized": ["InterestCostsCapitalized", "InterestPaidCapitalized"],
    "depreciation": ["Depreciation", "DepreciationNonproduction"],
    "amort_intangibles": ["AmortizationOfIntangibleAssets"],
    "other_nonop": ["NonoperatingIncomeExpense", "OtherNonoperatingIncomeExpense"],
    "pretax": ["IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest",
               "IncomeLossFromContinuingOperationsBeforeIncomeTaxesMinorityInterestAndIncomeLossFromEquityMethodInvestments"],
    "tax": ["IncomeTaxExpenseBenefit"],
    "net_income": ["NetIncomeLoss", "ProfitLoss", "NetIncomeLossAvailableToCommonStockholdersBasic"],
    "cfo": ["NetCashProvidedByUsedInOperatingActivities",
            "NetCashProvidedByUsedInOperatingActivitiesContinuingOperations"],
    "capex_ppe": ["PaymentsToAcquirePropertyPlantAndEquipment", "PaymentsToAcquireProductiveAssets"],
    "capex_software": ["PaymentsToDevelopSoftware", "PaymentsForSoftware"],
    "sbc": ["ShareBasedCompensation", "AllocatedShareBasedCompensationExpense"],
    "da_cf": ["DepreciationDepletionAndAmortization", "DepreciationAmortizationAndAccretionNet",
              "DepreciationAndAmortization"],
    "acquisitions": ["PaymentsToAcquireBusinessesNetOfCashAcquired"],
}
PER_SHARE = {  # never derived by subtraction
    "eps_diluted": (["EarningsPerShareDiluted", "EarningsPerShareBasicAndDiluted"], "USD/shares"),
    "shares_basic": (["WeightedAverageNumberOfSharesOutstandingBasic"], "shares"),
    "shares_diluted": (["WeightedAverageNumberOfDilutedSharesOutstanding"], "shares"),
}
INSTANT = {
    "cash": ["CashAndCashEquivalentsAtCarryingValue",
             "CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents"],
    "st_investments": ["ShortTermInvestments", "MarketableSecuritiesCurrent", "DebtSecuritiesCurrent",
                       "AvailableForSaleSecuritiesDebtSecuritiesCurrent", "AvailableForSaleSecuritiesCurrent",
                       "DebtSecuritiesAvailableForSaleExcludingAccruedInterestCurrent"],
    "debt_total": ["LongTermDebt", "DebtLongtermAndShorttermCombinedAmount"],
    "debt_noncurrent": ["LongTermDebtNoncurrent", "ConvertibleNotesPayable",
                        "ConvertibleLongTermNotesPayable", "LongTermNotesPayable"],
    "debt_current": ["LongTermDebtCurrent", "ConvertibleNotesPayableCurrent", "DebtCurrent"],
    "credit_line": ["LongTermLineOfCredit", "LineOfCredit"],
    "st_borrowings": ["ShortTermBorrowings", "OtherShortTermBorrowings", "CommercialPaper"],
    "finance_lease": ["FinanceLeaseLiability"],
    "finance_lease_cur": ["FinanceLeaseLiabilityCurrent"],
    "finance_lease_noncur": ["FinanceLeaseLiabilityNoncurrent"],
    "debt_principal": ["DebtInstrumentCarryingAmount", "LongTermDebtGross", "DebtInstrumentFaceAmount"],
    "secured_debt": ["SecuredDebt", "SecuredLongTermDebt"],
    "ppe_net": ["PropertyPlantAndEquipmentNet",
                "PropertyPlantAndEquipmentAndFinanceLeaseRightOfUseAssetAfterAccumulatedDepreciationAndAmortization"],
    "ppe_gross": ["PropertyPlantAndEquipmentGross"],
    "cap_software": ["CapitalizedComputerSoftwareNet"],
    "goodwill": ["Goodwill"],
    "intangibles": ["IntangibleAssetsNetExcludingGoodwill", "FiniteLivedIntangibleAssetsNet"],
    "total_assets": ["Assets"],
    "mat_rem": ["LongTermDebtMaturitiesRepaymentsOfPrincipalRemainderOfFiscalYear"],
    "mat_y1": ["LongTermDebtMaturitiesRepaymentsOfPrincipalInNextTwelveMonths",
               "LongTermDebtMaturitiesRepaymentsOfPrincipalInNextRollingTwelveMonths"],
    "mat_y2": ["LongTermDebtMaturitiesRepaymentsOfPrincipalInYearTwo",
               "LongTermDebtMaturitiesRepaymentsOfPrincipalInRollingYearTwo"],
    "mat_y3": ["LongTermDebtMaturitiesRepaymentsOfPrincipalInYearThree",
               "LongTermDebtMaturitiesRepaymentsOfPrincipalInRollingYearThree"],
    "mat_y4": ["LongTermDebtMaturitiesRepaymentsOfPrincipalInYearFour",
               "LongTermDebtMaturitiesRepaymentsOfPrincipalInRollingYearFour"],
    "mat_y5": ["LongTermDebtMaturitiesRepaymentsOfPrincipalInYearFive",
               "LongTermDebtMaturitiesRepaymentsOfPrincipalInRollingYearFive"],
    "mat_after": ["LongTermDebtMaturitiesRepaymentsOfPrincipalAfterYearFive",
                  "LongTermDebtMaturitiesRepaymentsOfPrincipalInRollingAfterYearFive"],
}
# Year-to-date cash flow items (shown as reported, not split into quarters)
YTD = {
    "debt_issued": ["ProceedsFromIssuanceOfDebt", "ProceedsFromIssuanceOfLongTermDebt",
                    "ProceedsFromDebtNetOfIssuanceCosts", "ProceedsFromIssuanceOfSeniorLongTermDebt"],
    "credit_drawn": ["ProceedsFromLongTermLinesOfCredit", "ProceedsFromLinesOfCredit"],
    "convert_issued": ["ProceedsFromConvertibleNotesPayable"],
    "debt_repaid": ["RepaymentsOfLongTermDebt", "RepaymentsOfDebt", "RepaymentsOfSeniorDebt"],
    "credit_repaid": ["RepaymentsOfLongTermLinesOfCredit", "RepaymentsOfLinesOfCredit"],
    "interest_paid": ["InterestPaidNet", "InterestPaid"],
}
# What the company does with its cash (year-to-date items, turned into last-twelve-month totals)
CASH_USES = {
    "buybacks": ["PaymentsForRepurchaseOfCommonStock", "PaymentsForRepurchaseOfEquity"],
    "dividends": ["PaymentsOfDividends", "PaymentsOfDividendsCommonStock", "PaymentsOfOrdinaryDividends"],
    "tax_withheld": ["PaymentsRelatedToTaxWithholdingForShareBasedCompensation"],
    "acquisitions_ytd": ["PaymentsToAcquireBusinessesNetOfCashAcquired"],
    "stock_issued": ["ProceedsFromIssuanceOfCommonStock", "ProceedsFromStockOptionsExercised",
                     "ProceedsFromIssuanceOrSaleOfEquity"],
}
DISCLOSED_RATE = ["LongTermDebtWeightedAverageInterestRate", "DebtWeightedAverageInterestRate",
                  "LongtermDebtWeightedAverageInterestRate", "DebtInstrumentInterestRateEffectivePercentage",
                  "LineOfCreditFacilityInterestRateAtPeriodEnd", "DebtInstrumentInterestRateStatedPercentage"]
# Operating-expense lines shown in the waterfall, most specific first.
OPEX_LINES = [
    ("Sales and marketing", "sales_marketing"),
    ("Research and development", "rnd"),
    ("General and administrative", "ga"),
    ("Selling, general and administrative", "sga"),
    ("Depreciation and amortisation", "da_is"),
    ("Restructuring", "restructuring"),
    ("Acquisition-related costs", "acq_costs"),
]
M = 1e6


def pct(cur, prior):
    """% change; None when the base is zero/missing or the sign flips."""
    if cur is None or prior in (None, 0):
        return None
    if (cur < 0) != (prior < 0) and cur != 0:
        return None
    return (cur - prior) / abs(prior) * 100


def share(x, rev):
    return None if x is None or not rev else x / rev * 100


def diff(a, b):
    return None if a is None or b is None else a - b


class Company:
    def __init__(self, facts):
        self.facts = facts
        self.q = {k: xbrl.quarterly(facts, v) for k, v in DURATION.items()}
        # stock splits: older filings are never re-filed, so their shares and EPS are restated here
        self.splits = xbrl.splits(facts, PER_SHARE["shares_diluted"][0] + PER_SHARE["shares_basic"][0])
        for k, (concepts, unit) in PER_SHARE.items():
            self.q[k] = xbrl.quarterly(facts, concepts, unit, derive=False, splits_=self.splits)
        self.i = {k: xbrl.instants(facts, v) for k, v in INSTANT.items()}
        # Q4 share counts are only reported for the full year: used as an approximation
        self.year_shares = {k: xbrl.longest(facts, PER_SHARE[k][0], "shares", self.splits)
                            for k in ("shares_basic", "shares_diluted")}
        self.ytd = {k: xbrl.longest(facts, v, "USD") for k, v in YTD.items()}
        self.ytd_days = {k: xbrl.longest_with_days(facts, v) for k, v in {**YTD, **CASH_USES}.items()}
        self.ytd_days["cfo"] = xbrl.longest_with_days(facts, DURATION["cfo"])
        self.disclosed_rate = xbrl.instants(facts, DISCLOSED_RATE, "pure")
        self.labels = {}          # quarters added from a press release: end -> (label, form, filed)
        self._snap = {}

    def period(self, end):
        """(fiscal label, form, filed) of a quarter."""
        if end in self.labels:
            return self.labels[end]
        return xbrl.period_label(self.facts, DURATION["revenue"], end)

    def label(self, end):
        return self.period(end)[0]

    def v(self, key, end):
        rec = self.q[key].get(end)
        return rec["val"] if rec else None

    def derived(self, key, end):
        rec = self.q[key].get(end)
        return bool(rec and rec.get("derived"))

    def iv(self, key, end):
        rec = self.i[key].get(end)
        return rec["val"] if rec else None

    def quarter_ends(self):
        return sorted(self.q["revenue"].keys())

    def previous(self, end, quarters=1):
        """Period end `quarters` quarters before `end` (None when the chain breaks)."""
        ends = self.quarter_ends()
        for _ in range(quarters):
            end = xbrl.find_end(ends, end, 91, 15) if end else None
        return end

    def cf_ttm(self, key, end):
        """Last twelve months of a year-to-date cash flow item = this YTD + last full year - last year's YTD.
        Items the company never reports give None; a period with no entry counts as zero."""
        m = self.ytd_days.get(key) or {}
        ref = self.ytd_days["cfo"]
        if not m or end not in ref:
            return None
        if end in self.labels and end not in m:       # a press-release quarter that did not show this line
            return None
        if ref[end][0] >= 350:                       # the period end is a fiscal year end
            return float(m.get(end, (0, 0))[1])
        fy_ends = sorted(e for e, (d, _v) in ref.items() if d >= 350 and e < end)
        py_end = xbrl.find_end(list(ref), end, 364, 12)
        if not fy_ends or py_end is None:
            return None
        return float(m.get(end, (0, 0))[1] + m.get(fy_ends[-1], (0, 0))[1] - m.get(py_end, (0, 0))[1])

    def ttm(self, field, end):
        """Trailing twelve months of a snapshot field; None unless all 4 quarters exist."""
        total = 0.0
        for i in range(4):
            snap = self.snapshot(self.previous(end, i))
            if not snap or snap.get(field) is None:
                return None
            total += snap[field]
        return total

    # -- one quarter, all lines ------------------------------------------------
    def snapshot(self, end):
        if end is None:
            return None
        if end not in self._snap:
            self._snap[end] = self._snapshot(end)
        return dict(self._snap[end])

    def _snapshot(self, end):
        s = {"end": end}
        rev = s["revenue"] = self.v("revenue", end)
        cor, gp = self.v("cost_of_revenue", end), self.v("gross_profit", end)
        if gp is None and rev is not None and cor is not None:
            gp = rev - cor
        if cor is None and rev is not None and gp is not None:
            cor = rev - gp
        s["cost_of_revenue"], s["gross_profit"] = cor, gp
        oi = self.v("operating_income", end)
        s["oi_estimated"] = False
        if oi is None and gp is not None:
            # some companies stop tagging operating income: gross profit less the operating lines they do tag
            sga = self.v("sga", end)
            if sga is None and self.v("sales_marketing", end) is not None and self.v("ga", end) is not None:
                sga = self.v("sales_marketing", end) + self.v("ga", end)
            if sga is not None:
                oi = gp - sga - (self.v("rnd", end) or 0) - (self.v("restructuring", end) or 0)
                s["oi_estimated"] = True
        s["operating_income"] = oi
        ni = s["net_income"] = self.v("net_income", end)
        tax = s["tax"] = self.v("tax", end)
        pre = self.v("pretax", end)
        if pre is None and ni is not None and tax is not None:
            pre = ni + tax
        s["pretax"] = pre
        s["below_operating"] = diff(pre, oi)
        s["interest_expense"] = self.v("interest_expense", end)
        s["other_nonop"] = self.v("other_nonop", end)
        for _, key in OPEX_LINES:
            s[key] = self.v(key, end)

        s["eps_diluted"] = self.v("eps_diluted", end)
        s["eps_approx"] = False
        sd = self.v("shares_diluted", end) or self.year_shares["shares_diluted"].get(end)
        if s["eps_diluted"] is None and ni is not None and sd:
            s["eps_diluted"], s["eps_approx"] = ni / sd, True
        s["shares_diluted"] = sd
        s["shares_basic"] = self.v("shares_basic", end) or self.year_shares["shares_basic"].get(end)

        cfo = s["cfo"] = self.v("cfo", end)
        cp, cs = self.v("capex_ppe", end), self.v("capex_software", end)
        s["capex_ppe"], s["capex_software"] = cp, cs
        s["fcf"] = None if cfo is None else cfo - (cp or 0) - (cs or 0)
        s["capex_missing"] = cp is None and cs is None
        s["sbc"] = self.v("sbc", end)
        s["da_cf"] = self.v("da_cf", end)
        s["acquisitions"] = self.v("acquisitions", end)
        s["derived_lines"] = [k for k in ("revenue", "operating_income", "net_income", "cfo", "sbc")
                              if self.derived(k, end)]

        s["cash"] = self.iv("cash", end)
        s["st_investments"] = self.iv("st_investments", end)
        debt = self.iv("debt_total", end)
        if debt is None:
            parts = [self.iv(k, end) for k in ("debt_noncurrent", "debt_current", "credit_line")]
            debt = sum(p for p in parts if p is not None) if any(p is not None for p in parts) else None
        s["debt_long"] = debt
        s["st_borrowings"] = self.iv("st_borrowings", end)
        fl = self.iv("finance_lease", end)
        if fl is None:
            fparts = [self.iv(k, end) for k in ("finance_lease_cur", "finance_lease_noncur")]
            fl = sum(p for p in fparts if p is not None) if any(p is not None for p in fparts) else None
        s["finance_leases"] = fl
        extra = [x for x in (s["st_borrowings"], fl) if x is not None]
        if debt is not None or extra:   # total debt = borrowings + finance leases
            debt = (debt or 0) + sum(extra)
        s["debt"] = debt
        s["da"] = s["da_cf"] if s["da_cf"] is not None else s.get("da_is")
        s["ebitda"] = None if oi is None else oi + (s["da"] or 0)
        s["capex"] = None if s["capex_missing"] else (cp or 0) + (cs or 0)
        s["fcf_after_sbc"] = None if s["fcf"] is None or s["sbc"] is None else s["fcf"] - s["sbc"]
        s["depreciation"] = self.v("depreciation", end)
        if s["depreciation"] is None and s["da"] is not None and self.v("amort_intangibles", end) is not None:
            s["depreciation"] = s["da"] - self.v("amort_intangibles", end)
        s["interest_capitalized"] = self.v("interest_capitalized", end)
        for k in ("ppe_net", "ppe_gross", "cap_software", "goodwill", "intangibles", "total_assets",
                  "debt_current", "debt_principal", "secured_debt"):
            s[k] = self.iv(k, end)
        liquid = None if s["cash"] is None else s["cash"] + (s["st_investments"] or 0)
        s["net_cash"] = None if liquid is None else liquid - (debt or 0)
        s["debt_missing"] = debt is None
        return s


def _opex_lines(cur, prior):
    """Pick the opex lines that are separate lines (not already inside another one)."""
    chosen = []
    for name, key in OPEX_LINES:
        if cur.get(key) is None:
            continue
        trial = chosen + [(name, key)]
        ok = True
        for s in (cur, prior):
            if s is None or s.get("gross_profit") is None or s.get("operating_income") is None:
                continue
            total = sum((s.get(k) or 0) for _, k in trial)
            other = s["gross_profit"] - s["operating_income"] - total
            if other < -0.01 * abs(s["revenue"] or 1):
                ok = False  # would double count: this line is embedded elsewhere
        if ok:
            chosen = trial
    return chosen


def _line(name, key, cur, prior, kind):
    c, p = cur.get(key), (prior or {}).get(key)
    rc, rp = cur.get("revenue"), (prior or {}).get("revenue")
    sc, sp = share(c, rc), share(p, rp)
    pp = diff(sc, sp)
    if pp is None or kind == "revenue":
        good = None if kind != "revenue" or pct(c, p) is None else pct(c, p) > 0
    elif kind == "cost":
        good = pp < 0
    else:  # profit or income-type line: higher share of revenue is better
        good = pp > 0
    flip = c is not None and p is not None and (c < 0) != (p < 0) and c != 0 and p != 0
    return {"name": name, "key": key, "kind": kind, "cur": c, "prior": p,
            "yoy_pct": pct(c, p), "sign_flip": flip,
            "pct_rev_cur": sc, "pct_rev_prior": sp, "pp": pp, "good": good}


def build(company, end, inputs=None):
    inputs = inputs or {}
    ends = company.quarter_ends()
    if end is None:
        end = ends[-1]
    py_end = xbrl.find_end(ends, end, 364, 12)
    pq_end = xbrl.find_end(ends, end, 91, 15)
    pq_py_end = xbrl.find_end(ends, pq_end, 364, 12) if pq_end else None

    cur, prior = company.snapshot(end), company.snapshot(py_end)
    pq, pq_py = company.snapshot(pq_end), company.snapshot(pq_py_end)
    label, form, filed = company.period(end)
    m = {"period": {"end": end, "label": label, "form": form, "filed": filed,
                    "prior_year_end": py_end, "prior_quarter_end": pq_end},
         "cur": cur, "prior": prior}
    if prior is None:
        m["error"] = "No same-quarter-last-year data: cannot grade."
        return m
    rev, rev_p = cur["revenue"], prior["revenue"]

    # Step 1 - revenue
    yoy = pct(rev, rev_p)
    yoy_pq = pct(pq["revenue"], pq_py["revenue"]) if pq and pq_py else None
    organic = inputs.get("organic_revenue_yoy_pct")
    organic_pq = inputs.get("organic_revenue_yoy_pct_prev_quarter")
    recent = [e for e in ends if e <= end][-4:]
    acq_recent = any((company.snapshot(e) or {}).get("acquisitions") for e in recent)
    # acceleration compares like with like: organic vs organic, or total vs total
    accel = diff(organic, organic_pq) if organic is not None else diff(yoy, yoy_pq)
    m["revenue"] = {"cur": rev, "prior": rev_p, "yoy_pct": yoy, "yoy_pct_prev_quarter": yoy_pq,
                    "accel_pp": accel, "organic_yoy_pct": organic,
                    "ttm": company.ttm("revenue", end),
                    "scored_growth_pct": organic if organic is not None else yoy,
                    "acquisitions_last_4q": acq_recent}

    # Step 3 - the statement as a waterfall (Step 2 EPS below)
    lines = [_line("Revenue", "revenue", cur, prior, "revenue"),
             _line("Cost of revenue", "cost_of_revenue", cur, prior, "cost"),
             _line("Gross profit", "gross_profit", cur, prior, "profit")]
    opex = _opex_lines(cur, prior)
    for name, key in opex:
        lines.append(_line(name, key, cur, prior, "cost"))
    for s in (cur, prior):
        if s.get("gross_profit") is not None and s.get("operating_income") is not None:
            s["other_opex"] = s["gross_profit"] - s["operating_income"] - sum((s.get(k) or 0) for _, k in opex)
    if any(abs(s.get("other_opex") or 0) > 0.005 * abs(s["revenue"] or 1) for s in (cur, prior)):
        lines.append(_line("Other operating expenses", "other_opex", cur, prior, "cost"))
    lines += [_line("Operating income", "operating_income", cur, prior, "profit"),
              _line("Interest and other, net", "below_operating", cur, prior, "income"),
              _line("Pre-tax income", "pretax", cur, prior, "profit"),
              _line("Income tax", "tax", cur, prior, "cost"),
              _line("Net income", "net_income", cur, prior, "profit")]
    m["statement"] = [ln for ln in lines if ln["key"] in ("revenue", "operating_income", "net_income")
                      or (ln["cur"] or 0) != 0 or (ln["prior"] or 0) != 0]

    def margin(key):
        c, p = share(cur.get(key), rev), share(prior.get(key), rev_p)
        return {"cur": c, "prior": p, "pp": diff(c, p)}
    m["margins"] = {"gross": margin("gross_profit"), "operating": margin("operating_income"),
                    "net": margin("net_income")}
    m["cost_of_revenue_yoy_pct"] = pct(cur["cost_of_revenue"], prior["cost_of_revenue"])
    lev = [{"name": n, "yoy_pct": pct(cur[k], prior.get(k)),
            "slower_than_revenue": (pct(cur[k], prior.get(k)) is not None and yoy is not None
                                    and pct(cur[k], prior.get(k)) < yoy)} for n, k in opex]
    scored = [x for x in lev if x["yoy_pct"] is not None]
    m["operating_leverage"] = {"lines": lev, "share_slower": (sum(x["slower_than_revenue"] for x in scored)
                                                              / len(scored)) if scored else None}

    # Step 2 - EPS
    e_c, e_p = cur["eps_diluted"], prior["eps_diluted"]
    if e_c is None or e_p is None:
        cls = None
    elif e_p < 0 <= e_c:
        cls = "turned profitable"
    elif e_p < 0 and e_c < 0:
        cls = "loss narrowed" if e_c > e_p else "loss widened"
    elif e_c < 0 <= e_p:
        cls = "turned to a loss"
    else:
        cls = "profit grew" if e_c >= e_p else "profit fell"
    ng = inputs.get("eps_nongaap") or {}
    sbc_ps = cur["sbc"] / cur["shares_diluted"] if cur["sbc"] is not None and cur["shares_diluted"] else None
    gap = diff(ng.get("cur"), e_c)
    m["eps"] = {"gaap_cur": e_c, "gaap_prior": e_p, "yoy_pct": pct(e_c, e_p), "classification": cls,
                "approx": cur["eps_approx"] or prior["eps_approx"],
                "nongaap_cur": ng.get("cur"), "nongaap_prior": ng.get("prior"), "gap": gap,
                "sbc_per_share": sbc_ps,
                "sbc_share_of_gap_pct": (sbc_ps / gap * 100) if sbc_ps is not None and gap else None}

    # SBC trend
    m["sbc"] = {"cur": cur["sbc"], "prior": prior["sbc"],
                "pct_rev_cur": share(cur["sbc"], rev), "pct_rev_prior": share(prior["sbc"], rev_p),
                "pct_rev_prev_quarter": share(pq["sbc"], pq["revenue"]) if pq else None}
    m["sbc"]["pp_yoy"] = diff(m["sbc"]["pct_rev_cur"], m["sbc"]["pct_rev_prior"])
    m["sbc"]["pp_qoq"] = diff(m["sbc"]["pct_rev_cur"], m["sbc"]["pct_rev_prev_quarter"])

    # Step 4 - cash
    f_c, f_p = cur["fcf"], prior["fcf"]
    fm_c, fm_p = share(f_c, rev), share(f_p, rev_p)
    after = None if f_c is None or cur["sbc"] is None else f_c - cur["sbc"]
    m["cash"] = {"fcf_cur": f_c, "fcf_prior": f_p, "fcf_yoy_pct": pct(f_c, f_p),
                 "fcf_margin_cur": fm_c, "fcf_margin_prior": fm_p, "fcf_margin_pp": diff(fm_c, fm_p),
                 "fcf_after_sbc": after, "fcf_after_sbc_margin": share(after, rev),
                 "cfo": cur["cfo"], "capex_ppe": cur["capex_ppe"], "capex_software": cur["capex_software"],
                 "capex_missing": cur["capex_missing"]}
    rev_ttm = m["revenue"]["ttm"]
    c = m["cash"]
    c["fcf_ttm"] = company.ttm("fcf", end)
    c["fcf_margin_ttm"] = share(c["fcf_ttm"], rev_ttm)
    c["fcf_after_sbc_ttm"] = company.ttm("fcf_after_sbc", end)
    c["fcf_after_sbc_margin_ttm"] = share(c["fcf_after_sbc_ttm"], rev_ttm)
    c["cfo_margin_ttm"] = share(company.ttm("cfo", end), rev_ttm)
    # levels are scored on the last twelve months when available (one quarter swings with working capital)
    c["fcf_margin_scored"] = c["fcf_margin_ttm"] if c["fcf_margin_ttm"] is not None else fm_c
    c["fcf_after_sbc_margin_scored"] = (c["fcf_after_sbc_margin_ttm"] if c["fcf_after_sbc_margin_ttm"] is not None
                                        else c["fcf_after_sbc_margin"])
    c["level_basis"] = "last 12 months" if c["fcf_margin_ttm"] is not None else "this quarter"
    g_scored = m["revenue"]["scored_growth_pct"]
    m["rule_of_40"] = (None if g_scored is None or c["fcf_margin_scored"] is None
                       else g_scored + c["fcf_margin_scored"])

    # Step 5 - balance sheet and dilution
    da = cur["da_cf"] if cur["da_cf"] is not None else cur.get("da_is")
    ebitda = None if cur["operating_income"] is None else cur["operating_income"] + (da or 0)
    nc, nc_pq = cur["net_cash"], (pq or {}).get("net_cash")
    m["balance"] = {"cash": cur["cash"], "st_investments": cur["st_investments"], "debt": cur["debt"],
                    "debt_missing": cur["debt_missing"], "net_cash": nc,
                    "net_cash_prev_quarter": nc_pq, "net_cash_change": diff(nc, nc_pq),
                    "debt_prev_quarter": (pq or {}).get("debt"),
                    "ebitda_q": ebitda,
                    "net_debt_to_ebitda": (-nc / (ebitda * 4)) if nc is not None and nc < 0 and ebitda and ebitda > 0 else None}
    sb_c, sb_p = cur["shares_basic"], prior["shares_basic"]
    m["dilution"] = {"basic_shares_cur": sb_c, "basic_shares_prior": sb_p, "yoy_pct": pct(sb_c, sb_p),
                     "diluted_shares_cur": cur["shares_diluted"], "diluted_shares_prior": prior["shares_diluted"]}

    recent = [(f, k) for f, k in company.splits if py_end and f > py_end]
    if recent:
        f, k = recent[-1]
        ratio = f"{k:g}-for-1" if k >= 1 else f"1-for-{1 / k:g} reverse"
        m["split_note"] = (f"Stock split ({ratio}, first filing on the new basis {f}): earlier share counts and "
                           "EPS were restated to today's basis.")
    m["fcf"] = fcf_block(company, end, m)
    from . import debt as debt_mod
    m["debt"], m["assets"] = debt_mod.build(company, end, py_end, pq_end, m)
    m["balance"]["net_debt_to_ebitda"] = m["debt"]["net_debt_to_ebitda"]
    m["questions"] = questions(m) + debt_mod.questions(m)
    return m


def fcf_block(co, end, m):
    """Free cash flow over the last twelve months, whether it grows, and where the cash went."""
    prior = co.previous(end, 4)
    rev, rev_p = m["revenue"]["ttm"], co.ttm("revenue", prior) if prior else None
    f, f_p = co.ttm("fcf", end), co.ttm("fcf", prior) if prior else None
    after, after_p = co.ttm("fcf_after_sbc", end), co.ttm("fcf_after_sbc", prior) if prior else None
    sbc = co.ttm("sbc", end)
    out = {
        "ttm": f, "ttm_prior": f_p, "growth_pct": pct(f, f_p) if f and f_p and f_p > 0 else None,
        "margin_ttm": share(f, rev), "margin_ttm_prior": share(f_p, rev_p),
        "after_sbc_ttm": after, "after_sbc_margin_ttm": share(after, rev),
        "after_sbc_ttm_prior": after_p,
        "cfo_ttm": co.ttm("cfo", end), "capex_ttm": co.ttm("capex", end), "sbc_ttm": sbc, "revenue_ttm": rev,
    }
    out["margin_pp"] = diff(out["margin_ttm"], out["margin_ttm_prior"])
    uses = {k: co.cf_ttm(k, end) for k in ("buybacks", "dividends", "tax_withheld", "acquisitions_ytd",
                                             "stock_issued")}
    borrowed = [co.cf_ttm(k, end) for k in ("debt_issued", "credit_drawn", "convert_issued")]
    repaid = [co.cf_ttm(k, end) for k in ("debt_repaid", "credit_repaid")]
    uses["net_borrowing"] = (None if all(x is None for x in borrowed + repaid)
                             else sum(x or 0 for x in borrowed) - sum(x or 0 for x in repaid))
    uses["acquisitions"] = uses.pop("acquisitions_ytd")
    out["uses"] = uses
    out["verdict"] = _cash_verdict(out, m)
    return out


def _fmt_big(x):
    if x is None:
        return "n/a"
    a = abs(x) / M
    txt = f"${a / 1000:,.1f}B" if a >= 1000 else f"${a:,.0f}M" if a >= 100 else f"${a:,.1f}M"
    return txt if x >= 0 else "−" + txt


def _cash_verdict(fc, m):
    """One plain sentence: what the company did with its free cash flow in the last twelve months."""
    f, u = fc["ttm"], fc["uses"]
    if f is None:
        return "Free cash flow for the last twelve months is not available."
    if f <= 0:
        txt = f"Free cash flow is negative ({_fmt_big(f)} in twelve months): the company is consuming cash"
        if (u.get("net_borrowing") or 0) > 0:
            txt += f", funded by {_fmt_big(u['net_borrowing'])} of net borrowing"
        if (u.get("stock_issued") or 0) > 0:
            txt += f" and {_fmt_big(u['stock_issued'])} of new shares"
        return txt + "."
    parts = []
    returned = (u.get("buybacks") or 0) + (u.get("dividends") or 0)
    for key, label in (("buybacks", "buybacks"), ("dividends", "dividends"), ("acquisitions", "acquisitions"),
                       ("tax_withheld", "taxes on employee stock")):
        v = u.get(key) or 0
        if v > 0.03 * f:
            parts.append(f"{label} {_fmt_big(v)} ({v / f * 100:.0f}% of FCF)")
    nb = u.get("net_borrowing")
    if nb is not None and abs(nb) > 0.05 * f:
        parts.append(f"net {'borrowing' if nb > 0 else 'debt repaid'} {_fmt_big(abs(nb))}")
    txt = ("Where the cash went: " + "; ".join(parts) + ".") if parts else \
        "No buybacks, dividends or acquisitions of note: the cash is piling up on the balance sheet."
    dil, sbc = m["dilution"]["yoy_pct"], fc["sbc_ttm"]
    bb = u.get("buybacks") or 0
    if bb > 0 and sbc:
        txt += (f" Buybacks are {bb / sbc:.1f}x stock-based pay and the share count moved "
                f"{dil:+.1f}%: " if dil is not None else f" Buybacks are {bb / sbc:.1f}x stock-based pay: ")
        txt += ("they shrink the share count." if dil is not None and dil < -0.5 else
                "they mostly offset dilution, not shrink the count.")
    elif dil is not None and dil > 2:
        txt += f" No buybacks, and the share count grew {dil:+.1f}%."
    if returned > f:
        txt += " Returned more than it generated."
    return txt


def _fmt_m(x):
    return "n/a" if x is None else ("−" if x < 0 else "") + f"${abs(x) / M:,.1f}M"


def questions(m):
    """Step 6: every number a careful reader would stop at."""
    q = []
    cur, prior = m["cur"], m["prior"]
    e = m["eps"]["gaap_cur"]
    if e is not None and cur["net_income"] is not None and e != 0 and cur["net_income"] != 0 \
            and (e > 0) != (cur["net_income"] > 0):
        q.append("Net income and EPS have different signs: preferred dividends can explain it; otherwise the "
                 "data is wrong. Check the filing.")
    for ln in m["statement"]:
        if ln["sign_flip"]:
            q.append(f"{ln['name']} changed sign: {_fmt_m(ln['prior'])} -> {_fmt_m(ln['cur'])}. "
                     "No % shown; explain what changed.")
        elif ln["kind"] in ("cost", "income") and ln["pp"] is not None and abs(ln["pp"]) >= 2:
            q.append(f"{ln['name']} moved {ln['pp']:+.1f}pp of revenue "
                     f"({ln['pct_rev_prior']:.1f}% -> {ln['pct_rev_cur']:.1f}%). Explain.")
    for s, tag in ((cur, "this quarter"), (prior, "same quarter last year")):
        b = s.get("below_operating")
        if b is not None and s["revenue"] and abs(b) / s["revenue"] >= 0.02:
            q.append(f"Gap between operating and pre-tax income {tag}: {_fmt_m(b)} "
                     f"({b / s['revenue'] * 100:+.1f}% of revenue). Name the items (interest, FX, fair value, other).")
    def etr(s):
        return s["tax"] / s["pretax"] * 100 if s.get("tax") is not None and s.get("pretax") and s["pretax"] > 0 else None
    t_c, t_p = etr(cur), etr(prior)
    if (cur.get("tax") or 0) < 0 and cur["revenue"] and abs(cur["tax"]) >= 0.01 * cur["revenue"]:
        q.append(f"Income tax benefit of {_fmt_m(-cur['tax'])} this quarter. Explain (valuation allowance, "
                 "stock-comp deductions, one-off).")
    elif t_c is not None and t_p is not None and (prior.get("tax") or 0) >= 0 and abs(t_c - t_p) >= 10:
        q.append(f"Effective tax rate moved {t_p:.0f}% -> {t_c:.0f}%. Explain.")
    if cur.get("tax") and cur.get("pretax") is not None and cur["pretax"] <= 0 < cur["tax"]:
        q.append("Tax expense despite a pre-tax loss. Explain (foreign taxes, valuation allowance).")
    if m["eps"]["nongaap_cur"] is not None:
        q.append(f"Non-GAAP EPS {m['eps']['nongaap_cur']:.2f} vs GAAP {'n/a' if e is None else format(e, '.2f')}: "
                 "name every item in the gap (from the press release reconciliation).")
    dil = m["dilution"]["yoy_pct"]
    if dil is not None and dil >= 5:
        q.append(f"Basic shares {dil:+.1f}% YoY. Explain the source: shares issued for acquisitions, "
                 "SBC vesting, offerings, net of buybacks.")
    if m["revenue"]["acquisitions_last_4q"] and m["revenue"]["organic_yoy_pct"] is None:
        q.append("Acquisitions in the last 4 quarters and no organic growth entered: total growth scored and flagged.")
    if cur.get("oi_estimated"):
        q.append("Operating income is not tagged in the filing: estimated as gross profit − SG&A − R&D − "
                 "restructuring. Check it against the income statement.")
    if m.get("split_note"):
        q.append(m["split_note"])
    if m["eps"]["approx"]:
        q.append("EPS not reported for the quarter itself (Q4 comes from the 10-K): estimated as net income / "
                 "full-year diluted shares. Check the press release.")
    if m["cash"]["capex_missing"]:
        q.append("No capex tag found: FCF equals operating cash flow. Check the cash flow statement.")
    if m["balance"]["debt_missing"]:
        q.append("No debt tag found: treated as zero debt. Check the balance sheet.")
    return q
