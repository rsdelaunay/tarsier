"""TICKER_model.xlsx: the projection as live Excel formulas.

Sheets
  Model        the three scenarios, year by year, down to price targets, returns and fair value
  Assumptions  Default | Yours | Used for every setting and every input. Type in the yellow
               "Yours" cells; leave them empty to use the default. Only those cells are kept
               when the engine rewrites the file.
  History      the fiscal years, last 12 months and the GAAP vs adjusted bridge (values only)

The arithmetic mirrors projection.py exactly, so the window and the workbook agree.
"""
import os
from datetime import date, datetime

from openpyxl import Workbook, load_workbook
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter as L
from openpyxl.worksheet.datavalidation import DataValidation

from . import excel, projection as P, rules as R

FONT = "Arial"
NAVY, GOLD, INK, MUTED, LINE = "1B2A41", "C9962E", "1F2933", "6B7785", "D9DEE5"
YOURS_BG, BLUE, GREY = "FFF6D6", "0000FF", "8A94A3"
FMT = {"pct": "0.0%", "musd": '#,##0.0;(#,##0.0)', "x": '0.0"x"', "usd": '$#,##0.00', "mshares": "#,##0.0",
       "date": "yyyy-mm-dd", "text": "@", "eps": '0.00;(0.00)'}
THIN = Side(style="thin", color=LINE)


def f(size=10, bold=False, color=INK, italic=False):
    return Font(name=FONT, size=size, bold=bold, color=color, italic=italic)


def _fill(c):
    return PatternFill("solid", fgColor=c)


def _put(ws, ref, value, font=None, fmt=None, bg=None, align=None, border=False):
    c = ws[ref]
    c.value = value
    c.font = font or f()
    if fmt:
        c.number_format = fmt
    if bg:
        c.fill = _fill(bg)
    if align:
        c.alignment = align
    if border:
        c.border = Border(bottom=THIN)
    return c


def _section(ws, row, text, last_col):
    _put(ws, f"A{row}", text, f(11, True, NAVY))
    for col in range(1, last_col + 1):
        ws.cell(row=row, column=col).border = Border(bottom=Side(style="medium", color=GOLD))


def _n(x):
    """A number for a formula, or 0."""
    return 0 if x is None else round(float(x), 10)


# ---------- reading back what you typed ---------------------------------------------------------
def _fy_from_label(v):
    try:
        return int(str(v).strip().replace("FY", "").rstrip("EA"))
    except ValueError:
        return None


def _val(v):
    if v is None or (isinstance(v, str) and not v.strip()):
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, str) and v.strip().startswith("="):
        return None                  # a formula typed in a "Yours" cell: not kept (type numbers)
    return v.strip() if isinstance(v, str) else v


def read_user(path):
    if not os.path.exists(path):
        return {}
    ws = load_workbook(path)["Assumptions"]
    out = {"settings": {}, "consensus": {"revenue": {}, "eps": {}}, "scen": {}}
    header = {}
    for row in ws.iter_rows(min_row=1, max_row=ws.max_row):
        tag = row[0].value
        cells = {c.column: c.value for c in row}
        if tag == "#yours":                       # header row of a year table: map columns to fiscal years
            header = {col: _fy_from_label(v) for col, v in cells.items() if _fy_from_label(v)}
            continue
        key = cells.get(2)
        if not isinstance(key, str) or not key.startswith(("set:", "cons:", "scen:")):
            continue
        kind, rest = key.split(":", 1)
        if kind == "set":
            v = _val(cells.get(5))
            if v is not None:
                out["settings"][rest] = v
        else:
            target = (out["consensus"][rest] if kind == "cons"
                      else out["scen"].setdefault(rest.split("|")[0], {}).setdefault(rest.split("|")[1], {}))
            for col, fy in header.items():
                v = _val(cells.get(col))
                if isinstance(v, (int, float)):
                    target[fy] = float(v)
    out["scen"] = {s: {k: v for k, v in d.items() if v} for s, d in out["scen"].items()}
    out["scen"] = {s: d for s, d in out["scen"].items() if d}
    return out


# ---------- writing ----------------------------------------------------------------------------
def write(path, h, user, ticker, name):
    res = P.compute(h, user)
    wb = Workbook()
    wb.calculation.fullCalcOnLoad = True
    ws = wb.active
    ws.title = "Model"
    wa = wb.create_sheet("Assumptions")
    wh = wb.create_sheet("History")
    c = res["constants"]
    fys, labels = res["fys"], res["labels"]
    YC = [L(3 + y) for y in range(P.YEARS)]           # model columns C..G
    A = h["fya_rec"]

    # ---- Assumptions: settings ------------------------------------------------------------------
    wa.sheet_view.showGridLines = False
    for col, w in zip("ABCDEFGHIJKLMN", (3, 26, 44, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 40)):
        wa.column_dimensions[col].width = w
    wa.column_dimensions["A"].hidden = False
    _put(wa, "B1", f"{ticker} · assumptions", f(14, True, NAVY))
    _put(wa, "B2", "Type your numbers in the yellow “Yours” cells (percentages as 30%). Leave a cell empty to "
                   "use the default. Only the yellow cells are kept when Tarsier rewrites this file.",
         f(9, color=MUTED))
    r0 = 4
    for col, t in zip("BCDEF", ("key", "Setting", "Default", "Yours", "Used")):
        _put(wa, f"{col}{r0}", t, f(9, True, "FFFFFF"), bg=NAVY)
    SET, SETROW = {}, {}
    sd = res["settings_default"]
    us = (user or {}).get("settings", {})
    for i, (k, label, unit) in enumerate(P.SETTINGS):
        r = r0 + 1 + i
        fmt = FMT.get(unit, "General")
        _put(wa, f"B{r}", f"set:{k}", f(8, color=GREY))
        suffix = {"musd": "  ($M)", "mshares": "  (M shares)", "usd": "  ($)"}.get(unit, "")
        _put(wa, f"C{r}", label + suffix, f(10))
        d = sd[k]
        SETROW[k] = r
        if k == "price_date":
            d = "=TODAY()"
        elif isinstance(d, float):
            d = round(d, 10)
        _put(wa, f"D{r}", d, f(10, color=GREY), fmt)
        _put(wa, f"E{r}", us.get(k), f(10, True, BLUE), fmt, bg=YOURS_BG)
        _put(wa, f"F{r}", f'=IF(E{r}<>"",E{r},IF(D{r}<>"",D{r},""))', f(10, True), fmt)
        SET[k] = f"Assumptions!$F${r}"
    r_method = r0 + 1 + [k for k, *_ in P.SETTINGS].index("method")
    dv = DataValidation(type="list", formula1='"auto,ps,ev_ebitda"', allow_blank=True)
    wa.add_data_validation(dv)
    dv.add(f"E{r_method}")
    _put(wa, f"G{r_method}", f"auto = P/E (P/S while net margin < {R.PROJ_PE_MIN_NET_MARGIN * 100:.0f}%) · ps = P/S · "
                             "ev_ebitda = EV/EBITDA", f(8, color=MUTED))

    # ---- Assumptions: consensus -------------------------------------------------------------------
    rc = r0 + len(P.SETTINGS) + 3
    _put(wa, f"A{rc}", "#yours", f(7, color="FFFFFF"))
    _put(wa, f"B{rc}", "key", f(9, True, "FFFFFF"), bg=NAVY)
    _put(wa, f"C{rc}", "What analysts expect (consensus)", f(9, True, "FFFFFF"), bg=NAVY)
    for y in range(P.YEARS):
        _put(wa, f"{L(4 + y)}{rc}", labels[y], f(9, True, "FFFFFF"), bg=NAVY, align=Alignment(horizontal="center"))
    CONS = {}
    uc = (user or {}).get("consensus", {})
    for i, (k, label, fmt) in enumerate((("revenue", "Revenue ($M)", FMT["musd"]), ("eps", "EPS, GAAP if available ($)", FMT["eps"]))):
        r = rc + 1 + i
        _put(wa, f"B{r}", f"cons:{k}", f(8, color=GREY))
        _put(wa, f"C{r}", label, f(10))
        CONS[k] = []
        for y in range(P.YEARS):
            ref = f"{L(4 + y)}{r}"
            _put(wa, ref, uc.get(k, {}).get(fys[y]), f(10, True, BLUE), fmt, bg=YOURS_BG)
            CONS[k].append(f"Assumptions!${L(4 + y)}${r}")
    _put(wa, f"C{rc + 3}", "Where: Yahoo Finance › Analysis (revenue and earnings estimates), Seeking Alpha › "
                           "Earnings › estimates. Enter the years you find: the base case follows them.",
         f(8, color=MUTED))

    # ---- Model layout (rows decided first, formulas need them) -----------------------------------
    model_rows = {}
    row = 17
    order = ("base", "bear", "bull")
    out_rows = [("revenue", "Revenue ($M)", "musd"), ("op_income", "Operating income ($M)", "musd"),
                ("pretax", "Pre-tax income implied by the operating margin ($M)", "musd"),
                ("tax", "Income tax implied ($M)", "musd"),
                ("net_income", "Net income = revenue × net margin ($M)", "musd"),
                ("shares", "Diluted shares (M)", "mshares"), ("eps", "EPS, GAAP ($)", "eps"),
                ("adj_eps", "Adjusted EPS: + SBC and acquired amortisation, after tax ($)", "eps"),
                ("eps_vs_consensus", "GAAP EPS vs consensus", "pct"), ("ebitda", "EBITDA ($M)", "musd"),
                ("basis", "Valuation basis", "text"), ("suggested", "Suggested multiple", "x"),
                ("target", "Price target at fiscal year end ($)", "usd"),
                ("years", "Years from the price date", "x2"), ("ret", "Return a year from today's price", "pct"),
                ("pv", "Value today, discounted ($)", "usd"),
                ("fcf", "Free cash flow ($M)", "musd"), ("fcf_after_sbc", "Free cash flow after SBC ($M)", "musd"),
                ("ahead", "Part of the fiscal year still ahead", "x2"), ("df", "Discount factor at the WACC", "x3"),
                ("dcf_pv", "Value of the projected free cash flows ($M)", "musd"),
                ("dcf_tv", "Value of the business at the end of year 5, discounted ($M)", "musd"),
                ("dcf_value", "FCF value per share today ($)", "usd"),
                ("dcf_sbc_value", "FCF value per share today, on FCF after SBC ($)", "usd")]
    for s in order:
        rows = {"_head": row}
        row += 1
        rows["_inputs"] = row
        for k, *_rest in P.INPUTS:
            rows[k] = row
            row += 1
        row += 1
        for k, *_rest in out_rows:
            rows[k] = row
            row += 1
        row += 1
        model_rows[s] = rows
    r_sum = row + 1

    def M(s, k, y):
        return f"Model!${YC[y]}${model_rows[s][k]}"

    lo_, hi_ = R.PROJ_MULTIPLE_LIMITS["pe"]
    wa[f"D{SETROW['exit_multiple']}"] = (
        f"=MIN({hi_},MAX({lo_},({SET['base_pe']}+{R.PROJ_GROWTH_PER_POINT['pe']}"
        f"*Model!${YC[P.YEARS - 1]}${model_rows['base']['rev_growth']}*100)/2*{SET['quality']}))")
    dvt = DataValidation(type="list", formula1='"multiple,growth"', allow_blank=True)
    wa.add_data_validation(dvt)
    dvt.add(f"E{SETROW['terminal_method']}")

    def rowB(s, k):                                    # the FY actual column
        return f"Model!$B${model_rows[s][k]}"

    def m(s, k, y):                                    # same sheet
        return f"{YC[y]}{model_rows[s][k]}"

    # ---- Assumptions: scenario inputs ------------------------------------------------------------
    rs = rc + 6
    _put(wa, f"A{rs}", "#yours", f(7, color="FFFFFF"))
    _put(wa, f"B{rs}", "key", f(9, True, "FFFFFF"), bg=NAVY)
    _put(wa, f"C{rs}", "Scenario · input", f(9, True, "FFFFFF"), bg=NAVY)
    for y in range(P.YEARS):
        _put(wa, f"{L(4 + y)}{rs}", f"Default {labels[y]}", f(9, True, "FFFFFF"), bg=NAVY,
             align=Alignment(horizontal="center"))
        _put(wa, f"{L(9 + y)}{rs}", labels[y], f(9, True, "FFFFFF"), bg=GOLD, align=Alignment(horizontal="center"))
    _put(wa, f"{L(9)}{rs - 1}", "Yours", f(9, True, GOLD))
    AD, AY = {}, {}
    LT, DEC, SF = R.PROJ_LONG_RUN_GROWTH, R.PROJ_GROWTH_DECAY, R.PROJ_SHARE_FADE
    uscen = (user or {}).get("scen", {})
    r = rs + 1
    for s in order:
        off = R.PROJ_SCENARIO_OFFSETS.get(s)
        for k, label, unit, y0, y1, _win in P.INPUTS:
            _put(wa, f"B{r}", f"scen:{s}|{k}", f(8, color=GREY))
            _put(wa, f"C{r}", f"{P.SCEN_LABEL[s]} · {label}" + (" ($M)" if unit == "musd" else ""), f(10))
            fmt = FMT[unit]
            for y in range(P.YEARS):
                dref, yref = f"{L(4 + y)}{r}", f"{L(9 + y)}{r}"
                AD[(s, k, y)], AY[(s, k, y)] = f"Assumptions!${L(4 + y)}${r}", f"Assumptions!${L(9 + y)}${r}"
                if not (y0 <= y <= y1):
                    wa[dref].fill = _fill("F1F3F6")
                    wa[yref].fill = _fill("F1F3F6")
                    continue
                _put(wa, dref, _default_formula(s, k, y, c, CONS, SET, M, off, LT, DEC, SF, A, AD, rowB),
                     f(10, color=GREY), fmt)
                _put(wa, yref, uscen.get(s, {}).get(k, {}).get(fys[y]), f(10, True, BLUE), fmt, bg=YOURS_BG)
            r += 1
        r += 1

    # ---- Model sheet -----------------------------------------------------------------------------
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 52
    for col in "BCDEFG":
        ws.column_dimensions[col].width = 14
    ws.column_dimensions["H"].width = 60
    _put(ws, "A1", "TARSIER RESEARCH  ·  PROJECTIONS", f(9, True, GOLD))
    _put(ws, "A2", f"{ticker}  ·  {name}", f(16, True, NAVY))
    _put(ws, "A3", f"Last full year FY{h['fya']}  ·  last quarter "
                   f"{h['latest_label']}  ·  grade {h['grade']}{' (provisional)' if h['provisional'] else ''}  ·  "
                   f"{h['group']}  ·  GAAP EPS is the valued number", f(9, color=MUTED))
    _put(ws, "A4", "Blue = your number (Assumptions sheet) · grey = Tarsier default · every other cell is a formula.",
         f(8, italic=True, color=MUTED))
    today_rows = [("Share price today ($)", "price", "usd"), ("Price date", "price_date", "date"),
                  ("Diluted shares now (M)", "shares_now", "mshares"), ("Net cash (debt) ($M)", "net_cash_musd", "musd"),
                  ("Valuation method", "method", "text"), ("Discount rate", "discount_rate", "pct")]
    _section(ws, 5, "TODAY", 8)
    for i, (label, k, unit) in enumerate(today_rows):
        rr = 6 + i
        _put(ws, f"A{rr}", label, f(10, True), border=True)
        _put(ws, f"B{rr}", f"={SET[k]}", f(10, True), FMT[unit], align=Alignment(horizontal="right"), border=True)
    _put(ws, "D6", "Market cap ($M)", f(10, True))
    _put(ws, "F6", f'=IF(B6="","",B6*B8)', f(10, True), FMT["musd"])
    _put(ws, "D7", "Quality factor (grade)", f(10, True))
    _put(ws, "F7", f"={SET['quality']}", f(10, True), FMT["x"])
    _put(ws, "D8", "Weights bear / base / bull", f(10, True))
    _put(ws, "F8", f'=TEXT({SET["w_bear"]},"0%")&" / "&TEXT({SET["w_base"]},"0%")&" / "&TEXT({SET["w_bull"]},"0%")',
         f(10, True))
    for rr_, (label, k, unit) in zip((9, 10, 11), (("Margin of safety", "margin_of_safety", "pct"),
                                                    ("WACC (sector)", "wacc", "pct2"),
                                                    ("Exit multiple on year-5 FCF", "exit_multiple", "x"))):
        _put(ws, f"D{rr_}", label, f(10, True))
        _put(ws, f"F{rr_}", f"={SET[k]}", f(10, True), "0.00%" if unit == "pct2" else FMT[unit])
    _put(ws, "G10", res["wacc_source"], f(8, color=MUTED))

    hdr = 15
    _put(ws, f"A{hdr}", "Fiscal year", f(9, True, "FFFFFF"), bg=NAVY)
    _put(ws, f"B{hdr}", f"FY{h['fya']}A", f(9, True, "FFFFFF"), bg=NAVY, align=Alignment(horizontal="center"))
    for y in range(P.YEARS):
        _put(ws, f"{YC[y]}{hdr}", labels[y], f(9, True, "FFFFFF"), bg=NAVY, align=Alignment(horizontal="center"))
    _put(ws, f"H{hdr}", "Notes", f(9, True, "FFFFFF"), bg=NAVY)
    _put(ws, "A13", "Fiscal year ends", f(9, color=MUTED))
    for y in range(P.YEARS):
        _put(ws, f"{YC[y]}13", res["fy_ends"][y], f(9, color=MUTED), FMT["date"], align=Alignment(horizontal="center"))
    _put(ws, "A14", "Consensus revenue ($M) · EPS ($)", f(9, color=MUTED))
    for y in range(P.YEARS):
        _put(ws, f"{YC[y]}14", f'=IF({CONS["revenue"][y]}="","",TEXT({CONS["revenue"][y]},"#,##0")&" · "&'
                                f'IF({CONS["eps"][y]}="","–",TEXT({CONS["eps"][y]},"0.00")))', f(8, color=MUTED),
             align=Alignment(horizontal="center"))
    FYEND = {y: f"${YC[y]}$13" for y in range(P.YEARS)}

    actual = {"revenue": A["revenue"], "op_income": A["operating_income"], "pretax": A["pretax"], "tax": A["tax"],
              "net_income": A["net_income"], "shares": A["shares"], "eps": A["eps"], "ebitda": A["ebitda"],
              "fcf": A.get("fcf")}
    actual_inputs = {"rev_growth": None, "op_margin": A["op_margin"], "other_musd": A["other"],
                     "net_margin": (A["net_income"] / A["revenue"]) if A["revenue"] and A["net_income"] is not None else None,
                     "fcf_margin": (A["fcf"] / A["revenue"]) if A["revenue"] and A.get("fcf") is not None else None,
                     "tax_rate": A["tax_rate"], "sbc_pct": (A["sbc"] or 0) / A["revenue"] if A["revenue"] else None,
                     "da_pct": (A["da"] or 0) / A["revenue"] if A["revenue"] else None}
    prev_fy = [r_ for r_ in h["fy_actual"] if r_["fy"] == h["fya"] - 1]
    if prev_fy and prev_fy[0]["revenue"]:
        actual_inputs["rev_growth"] = A["revenue"] / prev_fy[0]["revenue"] - 1

    for s in order:
        rows = model_rows[s]
        title = {"base": "BASE CASE", "bear": "BEAR CASE", "bull": "BULL CASE"}[s]
        _section(ws, rows["_head"], f"{title}  ·  weight {res['weights'][s] * 100:.0f}% by default", 8)
        for k, label, unit, y0, y1, _win in P.INPUTS:
            rr = rows[k]
            _put(ws, f"A{rr}", label + (" ($M)" if unit == "musd" else ""), f(10), border=True)
            if k in actual_inputs and actual_inputs[k] is not None:
                _put(ws, f"B{rr}", actual_inputs[k], f(10, color=MUTED), FMT[unit],
                     align=Alignment(horizontal="right"), border=True)
            for y in range(P.YEARS):
                ref = f"{YC[y]}{rr}"
                if not (y0 <= y <= y1):
                    _put(ws, ref, None, border=True)
                    continue
                ay, ad = AY[(s, k, y)], AD[(s, k, y)]
                _put(ws, ref, f'=IF({ay}="",{ad},{ay})', f(10, color=GREY), FMT[unit],
                     align=Alignment(horizontal="right"), border=True)
                ws.conditional_formatting.add(ref, FormulaRule(formula=[f'{ay}<>""'],
                                                               font=Font(name=FONT, bold=True, color=BLUE)))
        for k, label, unit in out_rows:
            rr = rows[k]
            bold = k in ("revenue", "eps", "target")
            _put(ws, f"A{rr}", label, f(10, bold), border=True)
            if k in actual and actual[k] is not None:
                _put(ws, f"B{rr}", actual[k], f(10, bold, MUTED), FMT.get(unit, "General"),
                     align=Alignment(horizontal="right"), border=True)
            for y in range(P.YEARS):
                fml = _model_formula(s, k, y, m, YC, rows, SET, CONS, FYEND)
                fmt = {"x2": "0.00", "x3": "0.000"}.get(unit) or FMT.get(unit, "General")
                _put(ws, f"{YC[y]}{rr}", fml, f(10, bold), fmt, align=Alignment(horizontal="right"), border=True)
        ws[f"H{rows['target']}"] = "Priced on the NEXT year's numbers: the market pays for the year ahead."
        ws[f"H{rows['target']}"].font = f(8, color=MUTED)
        ws[f"H{rows['multiple']}"] = "Empty in Assumptions = the suggested multiple below."
        ws[f"H{rows['multiple']}"].font = f(8, color=MUTED)
        ws[f"H{rows['adj_eps']}"] = "Shown, not valued: see History for what the adjustments are."
        ws[f"H{rows['adj_eps']}"].font = f(8, color=MUTED)
        for key, note in (("net_margin", "Empty = what the operating margin leaves after interest and tax."),
                          ("eps_growth", "Empty = net income ÷ projected shares. Ignored when last year's EPS ≤ 0."),
                          ("fcf_margin", "Empty = net margin × the share of net income that arrived as cash in the last 12 months."),
                          ("dcf_value", "(5 years of FCF + value at the end of year 5, discounted at the WACC, + net cash) ÷ shares now."),
                          ("other_musd", "Behind the net margin default."), ("share_growth", "Behind the EPS default.")):
            ws[f"H{rows[key]}"] = note
            ws[f"H{rows[key]}"].font = f(8, color=MUTED)

    # ---- summary ----------------------------------------------------------------------------------
    _section(ws, r_sum, "WEIGHTED  ·  price targets, return a year, fair value today", 8)
    wsum = f'({SET["w_bear"]}+{SET["w_base"]}+{SET["w_bull"]})'
    W = {s: f'{SET["w_" + s]}/{wsum}' for s in P.SCENARIOS}
    srow = {"target": r_sum + 1, "ret": r_sum + 2, "pv": r_sum + 3}
    _put(ws, f"A{srow['target']}", "Weighted price target at fiscal year end ($)", f(10, True), border=True)
    _put(ws, f"A{srow['ret']}", "Weighted return a year from today's price", f(10, True), border=True)
    _put(ws, f"A{srow['pv']}", "Weighted value today ($)", f(10, True), border=True)
    for T in P.TARGETS:
        col = YC[T]
        tg = "+".join(f"{W[s]}*{col}{model_rows[s]['target']}" for s in P.SCENARIOS)
        pv = "+".join(f"{W[s]}*{col}{model_rows[s]['pv']}" for s in P.SCENARIOS)
        yrs = f"{col}{model_rows['base']['years']}"
        t_ = f"{col}{srow['target']}"
        _put(ws, f"{col}{srow['target']}", f"={tg}", f(10, True), FMT["usd"], border=True)
        _put(ws, f"{col}{srow['ret']}", _ret_formula(t_, SET["price"], yrs), f(10, True), FMT["pct"], border=True)
        _put(ws, f"{col}{srow['pv']}", f"={pv}", f(10, True), FMT["usd"], border=True)
    last = YC[P.TARGETS[-1]]
    r_dcf = srow["pv"] + 1
    _put(ws, f"A{r_dcf}", "Weighted FCF value per share today ($)", f(10, True), border=True)
    _put(ws, f"A{r_dcf + 1}", "Weighted FCF value per share today, on FCF after SBC ($)", f(10, True), border=True)
    for off_, key in ((0, "dcf_value"), (1, "dcf_sbc_value")):
        cells = [f"{YC[0]}{model_rows[s_][key]}" for s_ in P.SCENARIOS]
        fml = "+".join(f"{W[s_]}*{c_}" for s_, c_ in zip(P.SCENARIOS, cells))
        _put(ws, f"{YC[0]}{r_dcf + off_}", f'=IF(COUNT({",".join(cells)})<3,"",{fml})', f(10, True), FMT["usd"],
             border=True)
    mos = f"(1-{SET['margin_of_safety']})"
    pvw, dcfw, dcfs = f"{last}{srow['pv']}", f"{YC[0]}{r_dcf}", f"{YC[0]}{r_dcf + 1}"
    price = SET["price"]
    rr = r_dcf + 3
    big = [("FAIR VALUE BY MULTIPLE, after the margin of safety ($)", f"={pvw}*{mos}", FMT["usd"]),
           ("   before the margin of safety ($)", f"={pvw}", FMT["usd"]),
           ("   vs today's price", f'=IF({price}="","",{pvw}*{mos}/{price}-1)', FMT["pct"]),
           ("FAIR VALUE BY FREE CASH FLOW, after the margin of safety ($)", f'=IF({dcfw}="","",{dcfw}*{mos})',
            FMT["usd"]),
           ("   before the margin of safety ($)", f"={dcfw}", FMT["usd"]),
           ("   vs today's price", f'=IF(OR({price}="",{dcfw}=""),"",{dcfw}*{mos}/{price}-1)', FMT["pct"]),
           ("   on FCF after SBC, after the margin of safety ($)", f'=IF({dcfs}="","",{dcfs}*{mos})', FMT["usd"]),
           (f"Expected return a year to the end of {labels[P.TARGETS[-1]]}", f"={last}{srow['ret']}", FMT["pct"])]
    for label, fml, fmt in big:
        head = not label.startswith("   ")
        _put(ws, f"A{rr}", label, f(12 if head else 10, head, NAVY if head else INK))
        _put(ws, f"B{rr}", fml, f(12 if head else 10, head, NAVY if head else INK), fmt, bg="F1F3F6")
        rr += 1
    for note in res["warnings"]:
        _put(ws, f"A{rr}", "! " + note, f(9, color="B3261E"))
        rr += 1
    _put(ws, f"A{rr + 1}", "Educational model of published results and your assumptions. Not a recommendation.",
         f(8, italic=True, color=MUTED))
    ws.freeze_panes = "B16"
    for sheet in (ws, wa, wh):
        sheet.page_setup.orientation = "landscape"
        sheet.sheet_properties.pageSetUpPr.fitToPage = True
        sheet.page_setup.fitToWidth, sheet.page_setup.fitToHeight = 1, 0

    _history_sheet(wh, h)
    for sheet in (wa, wh):
        sheet.sheet_properties.tabColor = "BFC5CE"
    excel._save(wb, path)
    return res


def _ret_formula(target, price, years):
    return (f'=IF(OR({price}="",{target}="",{years}<=0),"",IF({target}<=0,"",'
            f'IF({years}>0.25,({target}/{price})^(1/{years})-1,{target}/{price}-1)))')


def _shares_path(M, s, y, SET):
    return SET["shares_now"] if y == 0 else f"{M(s, 'shares', y - 1)}*(1+{M(s, 'share_growth', y)})"


def _default_formula(s, k, y, c, CONS, SET, M, off, LT, DEC, SF, A, AD, rowB):
    """Excel version of projection._scenario defaults. rowB(scenario, key) = the FY actual cell."""
    if k == "multiple":
        return f"={M(s, 'suggested', y)}"
    if k == "net_margin":
        own = f"({M(s, 'pretax', y)}-{M(s, 'tax', y)})/{M(s, 'revenue', y)}"
        return f"={own}" if s == "base" else f"={own}+({M('base', k, y)}-{AD[('base', k, y)]})"
    if k == "eps_growth":
        prev = rowB(s, "eps") if y == 0 else M(s, "eps", y - 1)
        own = f"{M(s, 'net_income', y)}/({_shares_path(M, s, y, SET)})/{prev}-1"
        if s != "base":
            mb, adb = M("base", k, y), AD[("base", k, y)]
            own += f"+IF(AND(ISNUMBER({mb}),ISNUMBER({adb})),{mb}-{adb},0)"
        return f'=IF(ISNUMBER({prev}),IF({prev}>0,{own},""),"")'
    if k == "fcf_margin" and c["conv"] is not None:
        own = f"{M(s, 'net_margin', y)}*{_n(c['conv'])}"
        return f"={own}" if s == "base" else f"={own}+({M('base', k, y)}-{AD[('base', k, y)]})"
    if k == "fcf_margin":
        if s != "base":
            return (f"={M('base', k, y)}+({M(s, 'op_margin', y)}-{M('base', 'op_margin', y)})"
                    f"*(1-{M(s, 'tax_rate', y)})")
        if y == 0:
            return _n(c["fcf0"])
        return (f"={M('base', k, y - 1)}+({M('base', 'op_margin', y)}-{M('base', 'op_margin', y - 1)})"
                f"*(1-{M('base', 'tax_rate', y)})")
    if s != "base":
        if k == "rev_growth":
            return f"={M('base', k, y)}+{off['g0'] if y == 0 else off['g']}"
        if k == "op_margin":
            return f"={M('base', k, y)}+{off['om']}"
        if k == "share_growth":
            return f"={M('base', k, y)}+{off['sg']}"
        return f"={M('base', k, y)}"
    prev_rev = _n(A["revenue"]) if y == 0 else M("base", "revenue", y - 1)
    if k == "rev_growth":
        cons = CONS["revenue"][y]
        if y == 0:
            fallback = _n(c["g0"])
        elif y == 1:
            org = SET["organic"]
            fallback = f'MIN({R.PROJ_DEFAULT_GROWTH_CAP},{LT}+(IF({org}<>"",{org},{M("base", k, 0)})-{LT})*{DEC})'
        else:
            fallback = f"MIN({R.PROJ_DEFAULT_GROWTH_CAP},{LT}+({M('base', k, y - 1)}-{LT})*{DEC})"
        return f'=IF({cons}<>"",{cons}/{prev_rev}-1,{fallback})'
    if k == "op_margin":
        if y == 0:
            if 0 < c["ytd_n"] < 4 and c["ytd_rev"] is not None and c["ytd_oi"] is not None:
                rev0 = M("base", "revenue", 0)
                return f"=({_n(c['ytd_oi'])}+({rev0}-{_n(c['ytd_rev'])})*{_n(c['lastq_m'])})/{rev0}"
            return _n(c["om0_ttm"])
        prev = f"MAX({M('base', k, 0)},{_n(c['lastq_m'])})" if y == 1 else M("base", k, y - 1)
        cap, st = _n(c['cap']), _n(c['step'])
        step = f"IF({prev}<0,MAX({st},({cap}-{prev})*{R.PROJ_MARGIN_CONVERGE_LOSS}),{st})"
        return f"=IF({prev}>={cap},{prev},MIN({cap},{prev}+{step}))"
    if k == "other_musd":
        grow = f"*(1+{M('base', 'rev_growth', y)})" if c["other_scales"] else ""
        return _n(c["other0"]) if y == 0 else (f"={_n(c['other_run'])}{grow}" if y == 1
                                                else f"={M('base', k, y - 1)}{grow}")
    if k == "tax_rate":
        return _n(c["tax0"]) if y == 0 else f"=MAX({R.PROJ_TAX_FLOOR},{M('base', k, y - 1)})"
    if k == "da_pct":
        return _n(c["da0"]) if y == 0 else f"={M('base', k, y - 1)}"
    if k == "sbc_pct":
        return _n(c["sbc0"]) if y == 0 else f"=MAX(0,{M('base', k, y - 1)}+{R.PROJ_SBC_STEP})"
    if k == "share_growth":
        return _n(c["sg1"]) if y == 1 else f"={M('base', k, y - 1)}*{SF}"
    raise KeyError(k)


def _model_formula(s, k, y, m, YC, rows, SET, CONS, FYEND):
    def cell(key, yy):
        return f"{YC[yy]}{rows[key]}" if yy >= 0 else f"$B{rows[key]}"

    def span(key):
        return f"{YC[0]}{rows[key]}:{YC[P.YEARS - 1]}{rows[key]}"
    rev, prev = cell("revenue", y), cell(k, y - 1)
    wacc, gt = SET["wacc"], SET["terminal_growth"]
    lastc = P.YEARS - 1
    if k in ("dcf_pv", "dcf_tv", "dcf_value", "dcf_sbc_value"):
        if y != 0:
            return None
        meth, exitm = SET["terminal_method"], SET["exit_multiple"]
        ok = f'OR({meth}<>"growth",{wacc}-{gt}>=0.005)'

        def tv(key):
            last_ = cell(key, lastc)
            return f'IF({meth}="growth",{last_}*(1+{gt})/({wacc}-{gt}),{last_}*{exitm})*{cell("df", lastc)}'

        def total(key):
            return f"SUMPRODUCT({span(key)},{span('ahead')},{span('df')})+{tv(key)}"
        if k == "dcf_pv":
            return f"=SUMPRODUCT({span('fcf')},{span('ahead')},{span('df')})"
        if k == "dcf_tv":
            return f'=IF({ok},{tv("fcf")},"")'
        key = "fcf" if k == "dcf_value" else "fcf_after_sbc"
        return f'=IF({ok},({total(key)}+{SET["net_cash_musd"]})/{SET["shares_now"]},"")'
    if k == "revenue":
        return f"={cell('revenue', y - 1)}*(1+{cell('rev_growth', y)})"
    if k == "op_income":
        return f"={rev}*{cell('op_margin', y)}"
    if k == "pretax":
        return f"={cell('op_income', y)}+{cell('other_musd', y)}"
    if k == "tax":
        return f"=MAX(0,{cell('pretax', y)})*{cell('tax_rate', y)}"
    if k == "net_income":
        return f"={rev}*{cell('net_margin', y)}"
    path = SET["shares_now"] if y == 0 else f"{cell('shares', y - 1)}*(1+{cell('share_growth', y)})"
    if k == "eps":
        p_, eg, ni = cell("eps", y - 1), cell("eps_growth", y), cell("net_income", y)
        derived = f"{ni}/({path})"
        return f"=IF(AND(ISNUMBER({p_}),ISNUMBER({eg})),IF({p_}>0,{p_}*(1+{eg}),{derived}),{derived})"
    if k == "shares":
        e, ni = cell("eps", y), cell("net_income", y)
        return f"=IF(ISNUMBER({e}),IF(AND({e}>0,{ni}>0),{ni}/{e},{path}),{path})"
    if k == "adj_eps":
        tr = cell("tax_rate", y)
        return (f'=IFERROR(({cell("net_income", y)}+({cell("sbc_pct", y)}*{rev}+{SET["amort_musd"]})*(1-{tr}))'
                f'/{cell("shares", y)},"")')
    if k == "eps_vs_consensus":
        cons = CONS["eps"][y]
        return f'=IF({cons}="","",IFERROR({cell("eps", y)}/{cons}-1,""))'
    if k == "ebitda":
        return f"={cell('op_income', y)}+{cell('da_pct', y)}*{rev}"
    if k == "fcf":
        return f"={rev}*{cell('fcf_margin', y)}"
    if k == "fcf_after_sbc":
        return f"={rev}*({cell('fcf_margin', y)}-{cell('sbc_pct', y)})"
    if k == "years":
        return f"=({FYEND[y]}-{SET['price_date']})/365.25"
    if k == "ahead":
        return f"=MIN(1,MAX(0,{cell('years', y)}))"
    if k == "df":
        return f"=1/(1+{wacc})^MAX({cell('years', y)},0)"
    if y not in P.TARGETS:
        return None
    fwd = y + 1
    eps_f, rev_f, sh_f, eb_f = cell("eps", fwd), cell("revenue", fwd), cell("shares", fwd), cell("ebitda", fwd)
    basis, mult = cell("basis", y), cell("multiple", y)
    meth = SET["method"]
    if k == "basis":
        return (f'=IF({meth}="ps","P/S",IF({meth}="ev_ebitda",IF({eb_f}>0,"EV/EBITDA","P/S"),'
                f'IF(AND(ISNUMBER({eps_f}),{eps_f}>0,{cell("net_income", fwd)}/{rev_f}>={R.PROJ_PE_MIN_NET_MARGIN}),'
                f'"P/E","P/S")))')
    if k == "suggested":
        g = f"AVERAGE({YC[fwd]}{rows['rev_growth']}:{YC[P.YEARS - 1]}{rows['rev_growth']})"

        def one(key):
            lo, hi = R.PROJ_MULTIPLE_LIMITS[key]
            return f"MIN({hi},MAX({lo},({SET['base_' + key]}+{R.PROJ_GROWTH_PER_POINT[key]}*{g}*100)/2*{SET['quality']}))"
        return f'=IF({basis}="P/E",{one("pe")},IF({basis}="P/S",{one("ps")},{one("ev_ebitda")}))'
    if k == "target":
        return (f'=IF({basis}="P/E",{eps_f}*{mult},IF({basis}="P/S",{rev_f}*{mult}/{sh_f},'
                f'({eb_f}*{mult}+{SET["net_cash_musd"]})/{sh_f}))')
    if k == "ret":
        return _ret_formula(cell("target", y), SET["price"], cell("years", y))
    if k == "pv":
        return f"={cell('target', y)}/(1+{SET['discount_rate']})^MAX({cell('years', y)},0)"
    raise KeyError(k)


def _history_sheet(ws, h):
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 44
    for col in "BCDEFG":
        ws.column_dimensions[col].width = 14
    _put(ws, "A1", "History the projection starts from ($M)", f(14, True, NAVY))
    cols = [(f"FY{r['fy']}", r) for r in h["fy_actual"]]
    t = h["ttm"]
    _put(ws, "A3", "Line", f(9, True, "FFFFFF"), bg=NAVY)
    for i, (lab, _r) in enumerate(cols):
        _put(ws, f"{L(2 + i)}3", lab, f(9, True, "FFFFFF"), bg=NAVY, align=Alignment(horizontal="center"))
    _put(ws, f"{L(2 + len(cols))}3", "Last 12 months", f(9, True, "FFFFFF"), bg=NAVY, align=Alignment(horizontal="center"))
    lines = [("Revenue", "revenue", "revenue"), ("Operating income", "operating_income", "op_income"),
             ("Interest & other, net", "other", "other"), ("Pre-tax income", "pretax", "pretax"),
             ("Income tax", "tax", "tax"), ("Net income", "net_income", "net_income"),
             ("Stock-based compensation", "sbc", "sbc"), ("Amortisation of acquired intangibles", "amort", "amort"),
             ("Acquisition-related costs", "acq_costs", "acq_costs"), ("Restructuring", "restructuring", "restructuring"),
             ("D&A", "da", "da"), ("Diluted shares (M, average)", "shares", None), ("EPS, GAAP ($)", "eps", None),
             ("Operating margin", "op_margin", None)]
    for j, (label, fk, tk) in enumerate(lines, 4):
        _put(ws, f"A{j}", label, f(10), border=True)
        for i, (_lab, rec) in enumerate(cols):
            fmt = FMT["pct"] if fk == "op_margin" else (FMT["eps"] if fk == "eps" else FMT["musd"])
            _put(ws, f"{L(2 + i)}{j}", rec.get(fk), f(10), fmt, border=True)
        if tk:
            _put(ws, f"{L(2 + len(cols))}{j}", t.get(tk), f(10), FMT["musd"], border=True)
    b = h["bridge"]
    r = 4 + len(lines) + 2
    _put(ws, f"A{r}", f"GAAP vs adjusted EPS · {b['label']}", f(11, True, NAVY))
    r += 1
    for col, t_ in zip("ABCDE", ("Item (pre-tax)", "This quarter $M", "Per share $", "Last 12 months $M", "Last FY $M")):
        _put(ws, f"{col}{r}", t_, f(9, True, "FFFFFF"), bg=NAVY)
    for row_ in b["rows"]:
        r += 1
        _put(ws, f"A{r}", row_["label"], f(10), border=True)
        _put(ws, f"B{r}", row_["quarter"], f(10), FMT["musd"], border=True)
        _put(ws, f"C{r}", row_["per_share_q"], f(10), FMT["eps"], border=True)
        _put(ws, f"D{r}", row_["ttm"], f(10), FMT["musd"], border=True)
        _put(ws, f"E{r}", row_["last_fy"], f(10), FMT["musd"], border=True)
    r += 2
    ws.merge_cells(f"A{r}:G{r + 3}")
    _put(ws, f"A{r}", b["text"], f(9), align=Alignment(wrap_text=True, vertical="top"))
