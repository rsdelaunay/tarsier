"""Page 1 · Stock fundamentals: what each number is, how it is shown and coloured. No tkinter, so the phone
export (mobile.py) shows the same rows, words and colours as the PC."""
from datetime import date

ESTIMATES = ("fwd_pe", "peg", "eps_next_y_val", "eps_this_y", "eps_next_y", "eps_next_5y")

# key: (label, format, better, what it is)   better: "high", "low" or None (no colour)
D = {
    "price": ("Price", "usd", None, ["Last close (or the latest trade), Yahoo Finance"]),
    "mcap": ("Market cap", "big", None, ["Price × shares outstanding: what the market pays for the whole company"]),
    "ev": ("Enterprise value", "big", None, ["Market cap + debt − cash: the price of the business itself, "
                                             "whoever funds it"]),
    "pe": ("P/E", "x", "low", ["Price ÷ earnings per share of the last 12 months (GAAP)",
                               "How many years of today's profit the price pays for", "Empty when earnings are negative"]),
    "fwd_pe": ("Forward P/E", "x", "low", ["Price ÷ next year's EPS from your projection (page 2)",
                                            "Non-GAAP (adjusted) EPS when there is a guidance or analyst consensus, "
                                            "as the market quotes it"]),
    "peg": ("PEG", "x2", "low", ["Forward P/E ÷ expected EPS growth a year over the next 5 years (in %), as "
                                 "Finviz shows it",
                                 "Around 1: the price matches the growth; under 1: cheap for its growth"]),
    "ps": ("P/S", "x", "low", ["Market cap ÷ revenue of the last 12 months",
                               "Useful when profits are small or negative"]),
    "pb": ("P/B", "x", "low", ["Market cap ÷ shareholders' equity (book value)"]),
    "pc": ("P/C", "x", "low", ["Market cap ÷ cash and short-term investments"]),
    "pfcf": ("P/FCF", "x", "low", ["Market cap ÷ free cash flow of the last 12 months",
                                   "The cash the business really produces after investment"]),
    "ev_ebitda": ("EV/EBITDA", "x", "low", ["Enterprise value ÷ operating profit before depreciation and "
                                            "amortization (12 months)", "Compares companies with different debt"]),
    "ev_sales": ("EV/Sales", "x", "low", ["Enterprise value ÷ revenue of the last 12 months"]),
    "revenue": ("Sales (12 months)", "big", None, ["Revenue of the last four quarters"]),
    "net_income": ("Income (12 months)", "big", None, ["Net income of the last four quarters (GAAP)"]),
    "eps": ("EPS (12 months)", "usd", None, ["Diluted earnings per share of the last four quarters (GAAP)"]),
    "eps_next_y_val": ("EPS next year", "usd", None, ["Tarsier's projection for next fiscal year (base case)"]),
    "book_ps": ("Book / share", "usd", None, ["Shareholders' equity ÷ shares outstanding"]),
    "cash_ps": ("Cash / share", "usd", None, ["Cash and short-term investments ÷ shares outstanding"]),
    "shares": ("Shares outstanding", "count", None, ["From the cover of the latest 10-Q / 10-K"]),
    "eps_this_y": ("EPS this year", "pct", "high", ["Growth of this fiscal year's EPS in Tarsier's projection, "
                                                    "against the last full year"]),
    "eps_next_y": ("EPS next year", "pct", "high", ["Growth of next fiscal year's EPS in the projection"]),
    "eps_next_5y": ("EPS next 5 years", "pct", "high", ["Yearly EPS growth over the projection's 5 years"]),
    "eps_past_3y": ("EPS past 3 years", "pct", "high", ["Yearly growth of 12-month EPS over the last 3 years"]),
    "eps_past_5y": ("EPS past 5 years", "pct", "high", ["Yearly growth of 12-month EPS over the last 5 years"]),
    "sales_past_3y": ("Sales past 3 years", "pct", "high", ["Yearly growth of 12-month revenue over 3 years"]),
    "sales_past_5y": ("Sales past 5 years", "pct", "high", ["Yearly growth of 12-month revenue over 5 years"]),
    "eps_yoy_ttm": ("EPS Y/Y (12 months)", "pct", "high", ["The last 12 months' EPS against the 12 months before"]),
    "sales_yoy_ttm": ("Sales Y/Y (12 months)", "pct", "high", ["The last 12 months' revenue against the 12 before"]),
    "eps_qoq": ("EPS Q/Q", "pct", "high", ["The last quarter's EPS against the same quarter a year earlier"]),
    "sales_qoq": ("Sales Q/Q", "pct", "high", ["The last quarter's revenue against the same quarter a year earlier"]),
    "gross_margin": ("Gross margin", "pct", "high", ["Revenue minus the cost of what was sold, ÷ revenue (12 months)",
                                                     "Pricing power: what is left to pay for everything else"]),
    "op_margin": ("Operating margin", "pct", "high", ["Operating profit ÷ revenue (12 months)",
                                                      "What the business earns before interest and tax"]),
    "net_margin": ("Profit margin", "pct", "high", ["Net income ÷ revenue (12 months)"]),
    "roa": ("ROA", "pct", "high", ["Return on assets: net income ÷ average total assets"]),
    "roe": ("ROE", "pct", "high", ["Return on equity: net income ÷ average shareholders' equity",
                                   "High with little debt is the good kind"]),
    "roic": ("ROIC", "pct", "high", ["Return on invested capital: operating profit after tax ÷ (equity + debt − cash)",
                                     "Above ~10% a year usually means the business creates value"]),
    "current_ratio": ("Current ratio", "r", "high", ["Current assets ÷ current liabilities",
                                                     "Above 1: what comes due within a year is covered"]),
    "quick_ratio": ("Quick ratio", "r", "high", ["Like the current ratio, without inventory"]),
    "debt_eq": ("Debt / equity", "r", "low", ["Total debt (with finance leases) ÷ shareholders' equity"]),
    "lt_debt_eq": ("LT debt / equity", "r", "low", ["Debt due after a year ÷ shareholders' equity"]),
    "div_ttm": ("Dividend (12 months)", "div", None, ["Dividends per share paid in the last 12 months, and the "
                                                      "yield at today's price"]),
    "div_est": ("Dividend, yearly rate", "div_est", None, ["The latest dividend × how many were paid in a year: the "
                                                           "yearly rate now, and its yield"]),
    "ex_date": ("Last ex-dividend", "date", None, ["The last day the stock traded without its dividend"]),
    "div_g3": ("Dividend growth 3 years", "pct", "high", ["Yearly growth of the dividend over 3 years"]),
    "div_g5": ("Dividend growth 5 years", "pct", "high", ["Yearly growth of the dividend over 5 years"]),
    "payout": ("Payout", "pct", None, ["Dividends ÷ net income: the share of profit paid out"]),
    "last_earnings": ("Last earnings", "date", None, ["Date of the last results press release (SEC 8-K)"]),
    "next_earnings": ("Next earnings (estimate)", "date", None, ["About 13 weeks after the last one; the company "
                                                                 "confirms the date a few weeks before"]),
    "eps_surprise": ("EPS surprise", "pct", "high", ["Adjusted EPS against the consensus you typed in Earnings "
                                                     "results"]),
    "sales_surprise": ("Sales surprise", "pct", "high", ["Revenue against the consensus you typed in Earnings "
                                                         "results"]),
    "hi52": ("52-week high", "hilo", None, ["Highest price of the last 12 months, and how far below it the price is"]),
    "lo52": ("52-week low", "hilo", None, ["Lowest price of the last 12 months, and how far above it the price is"]),
    "sma20": ("vs 20-day average", "pct", "high", ["Price against its average of the last 20 trading days"]),
    "sma50": ("vs 50-day average", "pct", "high", ["Price against its average of the last 50 trading days"]),
    "sma200": ("vs 200-day average", "pct", "high", ["Price against its average of the last 200 trading days",
                                                     "Above it: the long trend is up"]),
    "rsi": ("RSI (14)", "n1", None, ["Relative strength of the last 14 days, 0 to 100",
                                     "Over 70: bought a lot lately (overbought); under 30: oversold"]),
    "atr": ("ATR (14)", "usd", None, ["Average true range: how many dollars the price moves on a normal day"]),
    "vol_week": ("Volatility (week)", "pct", None, ["Average daily high-to-low swing, last 5 days"]),
    "vol_month": ("Volatility (month)", "pct", None, ["Average daily high-to-low swing, last 21 days"]),
    "beta": ("Beta", "r", None, ["How much the stock moves with the S&P 500 (5 years, monthly)",
                                 "1: like the market; 2: twice as much; under 1: calmer"]),
    "volume": ("Volume", "count", None, ["Shares traded in the last session"]),
    "avg_volume": ("Average volume", "count", None, ["Shares traded a day, average of the last 3 months"]),
    "rel_volume": ("Relative volume", "r", None, ["Last session's volume ÷ the average: above 1, busier than usual"]),
    "ipo": ("First trade", "date", None, ["The first day Yahoo Finance has a price for the stock"]),
}
GROUPS = [
    ("Valuation", ["mcap", "ev", "pe", "fwd_pe", "peg", "ps", "pb", "pc", "pfcf", "ev_ebitda", "ev_sales"]),
    ("Size and per share", ["revenue", "net_income", "eps", "eps_next_y_val", "book_ps", "cash_ps", "shares"]),
    ("Growth", ["eps_this_y", "eps_next_y", "eps_next_5y", "eps_past_3y", "sales_past_3y",
                "eps_yoy_ttm", "sales_yoy_ttm", "eps_qoq", "sales_qoq"]),
    ("Profitability", ["gross_margin", "op_margin", "net_margin", "roa", "roe", "roic"]),
    ("Balance sheet", ["current_ratio", "quick_ratio", "debt_eq", "lt_debt_eq"]),
    ("Dividends", ["div_ttm", "div_est", "ex_date", "div_g3", "div_g5", "payout"]),
    ("Earnings", ["last_earnings", "next_earnings", "eps_surprise", "sales_surprise"]),
    ("Price and trading", ["price", "hi52", "lo52", "sma20", "sma50", "sma200", "rsi", "atr", "vol_week",
                           "vol_month", "beta", "volume", "avg_volume", "rel_volume", "ipo"]),
]
COLUMNS = [["Valuation", "Size and per share"], ["Growth", "Earnings"], ["Profitability", "Balance sheet", "Dividends"],
           ["Price and trading"]]


def _big(x):
    a = abs(x)
    return (f"{x / 1e12:.2f}T" if a >= 1e12 else f"{x / 1e9:.2f}B" if a >= 1e9 else f"{x / 1e6:.1f}M" if a >= 1e6
            else f"{x:,.0f}")


def _count(x):
    return f"{x / 1e9:.2f}B" if x >= 1e9 else f"{x / 1e6:.2f}M" if x >= 1e6 else f"{x / 1e3:.0f}K" if x >= 1e3 else f"{x:.0f}"


def _date(d):
    if not d:
        return "—"
    x = date.fromisoformat(d)
    return f"{x.day} {x:%b %Y}"


def fmt(key, kind, v, vals):
    if v is None:
        return "—"
    if kind == "usd":
        return f"${v:,.2f}"
    if kind == "big":
        return "$" + _big(v)
    if kind == "x":
        return f"{v:.1f}×"
    if kind == "x2":
        return f"{v:.2f}"
    if kind == "pct":
        return f"{v * 100:+.1f}%" if D[key][2] == "high" and key not in ("gross_margin", "op_margin", "net_margin",
                                                                          "roa", "roe", "roic") else f"{v * 100:.1f}%"
    if kind == "r":
        return f"{v:.2f}"
    if kind == "n1":
        return f"{v:.1f}"
    if kind == "count":
        return _count(v)
    if kind == "date":
        return _date(v)
    if kind == "div":
        return "none" if not v else f"${v:.2f} · {vals.get('div_yield', 0) * 100:.2f}%"
    if kind == "div_est":
        return "none" if not v else f"${v:.2f} · {vals.get('div_est_yield', 0) * 100:.2f}%"
    if kind == "hilo":
        rel = vals.get("from_hi" if key == "hi52" else "from_lo")
        return f"${v:,.2f} · {rel * 100:+.1f}%" if rel is not None else f"${v:,.2f}"
    return str(v)


def tone(key, v, med):
    """'good' / 'bad' / None: better or worse than the peers' median, else the sign where the sign means something."""
    better = D[key][2]
    if v is None or better is None:
        return None
    if med is not None:
        m = med[0]
        if abs(m) > 1e-12 and abs(v / m - 1) < 0.03:     # within 3% of the median: no colour
            return None
        return "good" if (v > m) == (better == "high") else "bad"
    if D[key][1] == "pct" and key.startswith(("eps", "sales", "sma", "div_g")):
        return "good" if v > 0 else "bad" if v < 0 else None
    return None
