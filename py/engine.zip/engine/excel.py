"""Excel files: the watchlist and inputs you edit, the grades the engine writes."""
import os
from datetime import date, datetime

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.table import Table, TableStyleInfo

NAVY = "1B2A41"
HEAD = Font(bold=True, color="FFFFFF")
FILL = PatternFill("solid", fgColor=NAVY)
EDIT_FILL = PatternFill("solid", fgColor="FFF6E0")


class FileOpenError(RuntimeError):
    pass


def _save(wb, path):
    try:
        wb.save(path)
    except PermissionError:
        raise FileOpenError(f"{os.path.basename(path)} is open in Excel: close it and run again.") from None


def _clean(v):
    if isinstance(v, datetime):
        return v.date().isoformat()
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, str):
        v = v.strip()
        return v or None
    return v


def _num(v):
    if v is None or v == "":
        return None
    if isinstance(v, (int, float)):
        return float(v)
    try:
        return float(str(v).replace(",", ".").replace("%", "").strip())
    except ValueError:
        return None


def _header(ws, cols, widths=None):
    for i, c in enumerate(cols, 1):
        cell = ws.cell(row=1, column=i, value=c)
        cell.font, cell.fill = HEAD, FILL
        cell.alignment = Alignment(vertical="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(i)].width = (widths or {}).get(c, max(12, len(c) + 2))
    ws.freeze_panes = "B2"


def _table(ws, name, ncols, nrows):
    if nrows < 1:
        return
    ref = f"A1:{get_column_letter(ncols)}{nrows + 1}"
    t = Table(displayName=name, ref=ref)
    t.tableStyleInfo = TableStyleInfo(name="TableStyleLight9", showRowStripes=True)
    ws.add_table(t)


def _read_rows(path, sheet):
    wb = load_workbook(path, data_only=True)
    ws = wb[sheet]
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return []
    head = [str(h).strip() if h else "" for h in rows[0]]
    return [{h: _clean(v) for h, v in zip(head, r) if h} for r in rows[1:] if any(x is not None for x in r)]


# --- Watchlist ----------------------------------------------------------------
WATCH_COLS = ["ticker", "industry_group", "company_type", "active", "notes"]
INDUSTRY_HELP = ("Software, Semiconductors, Hardware and equipment, Interactive media, Telecom and media, "
                 "Retail and e-commerce, Automobiles, Travel restaurants leisure, Food beverage household, "
                 "Pharma and biotech, Medical devices, Managed care and services, Banks and fintech lenders, "
                 "Insurance, Payments exchanges asset managers, Aerospace defence machinery, "
                 "Transport and logistics, Oil and gas, Regulated utilities, Power producers and energy equipment, "
                 "REITs, Chemicals metals mining")


def read_watchlist(path, add=()):
    if not os.path.exists(path):
        write_watchlist(path, [{"ticker": "ZETA", "industry_group": "Software", "company_type": "auto",
                                "active": "yes", "notes": ""}])
    rows = _read_rows(path, "Watchlist")
    have = {str(r.get("ticker") or "").upper() for r in rows}
    missing = [t for t in add if t not in have]
    if missing:
        rows += [{"ticker": t, "industry_group": None, "company_type": "auto", "active": "yes",
                  "notes": "added automatically"} for t in missing]
        write_watchlist(path, rows)
    for r in rows:
        r["ticker"] = str(r.get("ticker") or "").upper()
    return [r for r in rows if r["ticker"]]


def write_watchlist(path, rows):
    wb = Workbook()
    ws = wb.active
    ws.title = "Watchlist"
    _header(ws, WATCH_COLS, {"industry_group": 28, "notes": 40})
    for r in rows:
        ws.append([r.get(c) for c in WATCH_COLS])
    dv = DataValidation(type="list", formula1='"auto,growth,mature"', allow_blank=True)
    dv2 = DataValidation(type="list", formula1='"yes,no"', allow_blank=True)
    ws.add_data_validation(dv)
    ws.add_data_validation(dv2)
    dv.add("C2:C500")
    dv2.add("D2:D500")
    _table(ws, "Watchlist", len(WATCH_COLS), len(rows))
    h = wb.create_sheet("Help")
    for line in ["ticker: as on the exchange (ZETA).",
                 "industry_group: the scorecard it is graded against. Empty = guessed from SEC SIC code.",
                 "   " + INDUSTRY_HELP,
                 "company_type: auto (revenue growth >= 15% = growth), growth or mature (sets the weights).",
                 "active: no = skipped when running all companies."]:
        h.append([line])
    h.column_dimensions["A"].width = 120
    _save(wb, path)


# --- Inputs (per company, you fill) ---------------------------------------------
INPUT_COLS = ["period_end", "quarter", "organic_revenue_yoy_pct",
              "consensus_revenue_musd", "consensus_eps_gaap", "consensus_eps_nongaap",
              "guidance_low_musd", "guidance_high_musd", "guidance_mid_musd",
              "fy_guidance_change", "fy_guidance_detail",
              "eps_nongaap", "eps_nongaap_prior_year", "peer_median_dilution_pct", "notes"]
INPUT_HELP = [
    "One row per quarter. The engine adds a row when a new quarter appears; you fill the yellow columns.",
    "Leave empty what you don't have: it is skipped and listed under data gaps.",
    "organic_revenue_yoy_pct: only when the company breaks out acquired revenue (e.g. 30 for 30%).",
    "consensus_*: analyst consensus before the report. Money in USD millions, EPS in USD.",
    "guidance_*: the company's own guidance for THIS quarter, given last quarter. Low/high, or the midpoint.",
    "fy_guidance_change: raised / held / lowered (full-year guidance given with this report).",
    "eps_nongaap: adjusted EPS from the press release, this quarter and the same quarter last year.",
    "peer_median_dilution_pct: until peers are automatic.",
    "The company's usual beat is computed from the guidance you entered in earlier rows.",
]


def read_inputs(path):
    if not os.path.exists(path):
        return {}
    out = {}
    for r in _read_rows(path, "Inputs"):
        pe = r.get("period_end")
        if not pe:
            continue
        for k in INPUT_COLS:
            if k.endswith(("_pct", "_musd")) or k.startswith(("consensus_eps", "eps_")):
                r[k] = _num(r.get(k))
        out[str(pe)[:10]] = r
    return out


def ensure_inputs(path, periods, seed=None):
    """Make sure every period has a row; never touches values you typed."""
    rows = read_inputs(path)
    for pe, label in periods:
        if pe not in rows:
            rows[pe] = {"period_end": pe, "quarter": label, **((seed or {}).get(pe, {}))}
        rows[pe]["quarter"] = label
    if os.path.exists(path) and all(pe in read_inputs(path) for pe, _ in periods):
        return rows
    wb = Workbook()
    ws = wb.active
    ws.title = "Inputs"
    _header(ws, INPUT_COLS, {"quarter": 12, "fy_guidance_detail": 36, "notes": 40})
    ordered = sorted(rows.values(), key=lambda r: r["period_end"], reverse=True)
    for r in ordered:
        ws.append([r.get(c) for c in INPUT_COLS])
    for row in ws.iter_rows(min_row=2, min_col=3, max_col=len(INPUT_COLS)):
        for cell in row:
            cell.fill = EDIT_FILL
    dv = DataValidation(type="list", formula1='"raised,held,lowered"', allow_blank=True)
    ws.add_data_validation(dv)
    dv.add("J2:J500")
    h = wb.create_sheet("Help")
    for line in INPUT_HELP:
        h.append([line])
    h.column_dimensions["A"].width = 120
    _save(wb, path)
    return rows


def update_inputs(path, period_end, values):
    """Write the values you typed in the window into the inputs workbook (keeps formatting)."""
    wb = load_workbook(path)
    ws = wb["Inputs"]
    head = [c.value for c in ws[1]]
    for row in ws.iter_rows(min_row=2):
        if str(_clean(row[0].value) or "")[:10] == period_end:
            for k, v in values.items():
                if k in head:
                    row[head.index(k)].value = v
            break
    else:
        raise RuntimeError(f"{period_end} not found in {os.path.basename(path)}")
    _save(wb, path)


def drop_empty_periods(path, ends):
    """Remove rows of quarters that no longer exist (a press-release quarter you removed), if you typed nothing."""
    if not os.path.exists(path) or not ends:
        return
    wb = load_workbook(path)
    ws = wb["Inputs"]
    gone = [r for r in ws.iter_rows(min_row=2) if str(_clean(r[0].value) or "")[:10] in ends
            and all(c.value in (None, "") for c in r[2:])]
    for r in sorted(gone, key=lambda r: -r[0].row):
        ws.delete_rows(r[0].row)
    if gone:
        _save(wb, path)


def rename_period(path, old, new):
    """A preliminary quarter's date was estimated; the 10-Q has the exact one. Keeps what you typed."""
    if not os.path.exists(path) or old == new:
        return
    wb = load_workbook(path)
    ws = wb["Inputs"]
    rows = {str(_clean(r[0].value) or "")[:10]: r for r in ws.iter_rows(min_row=2)}
    if old not in rows:
        return
    if new in rows:                                   # both exist: fill the gaps of the new row, drop the old
        for a, b in zip(rows[old][2:], rows[new][2:]):
            if b.value in (None, "") and a.value not in (None, ""):
                b.value = a.value
        ws.delete_rows(rows[old][0].row)
    else:
        rows[old][0].value = new
    _save(wb, path)


# --- Grades (per company, engine writes) ----------------------------------------
def write_grades(path, ticker, grades, statement, scorecard, questions):
    wb = Workbook()
    sheets = [("Grades", grades), ("Statement", statement), ("Scorecard", scorecard), ("ToExplain", questions)]
    first = True
    for title, rows in sheets:
        ws = wb.active if first else wb.create_sheet(title)
        ws.title, first = title, False
        cols = list(rows[0].keys()) if rows else ["period_end"]
        _header(ws, cols, {"question": 110, "line": 32, "item": 40, "note": 40,
                           "house_rules": 40, "data_gaps": 60})
        for r in rows:
            ws.append([r.get(c) for c in cols])
        _table(ws, f"{ticker}_{title}".replace("-", "_").replace(".", "_"), len(cols), len(rows))
    _save(wb, path)
