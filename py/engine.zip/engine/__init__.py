"""Tarsier Research grading engine, v0.

Rule of the house: code calculates, the scorecard decides, the LLM only explains.
"""
VERSION = "1.2"
