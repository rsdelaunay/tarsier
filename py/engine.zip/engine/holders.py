"""Shareholder risks: dilution and other things that move value from today's shareholders to someone else.

They inform, they do not grade: the grade stays the scorecard's. Each risk is {level, head, text}.
"""
from . import rules as R

M = 1e6


def _big(x):
    a = abs(x) / M
    t = f"${a / 1000:,.1f}B" if a >= 1000 else f"${a:,.0f}M"
    return t if x >= 0 else "−" + t


def _lvl(v, pair):
    return "high" if v >= pair[1] else "watch" if v >= pair[0] else None


def risks(m):
    out = []

    def add(level, head, text):
        if level:
            out.append({"level": level, "head": head, "text": text})

    dil = m["dilution"]["yoy_pct"]
    fc = m["fcf"]
    f, u, sbc = fc["ttm"], fc["uses"], fc["sbc_ttm"]
    bb = u.get("buybacks") or 0

    # 1. the share count
    if dil is not None:
        add(_lvl(dil, R.HOLDER_DILUTION_PCT), "Dilution",
            f"share count {dil:+.1f}% in a year: each share owns {dil / (100 + dil) * 100:.1f}% less of the company")
    d = m["dilution"]
    if d["basic_shares_cur"] and d["diluted_shares_cur"]:
        ov = (d["diluted_shares_cur"] / d["basic_shares_cur"] - 1) * 100
        if ov >= R.HOLDER_OVERHANG_PCT:
            add("watch", "Shares waiting",
                f"diluted count is {ov:.1f}% above basic: options and stock awards still to become shares")

    # 2. stock-based pay
    sr = m["sbc"]["pct_rev_cur"]
    if sr is not None:
        add(_lvl(sr, R.HOLDER_SBC_REVENUE_PCT), "Stock-based pay",
            f"{sr:.1f}% of revenue, paid in new shares: a real cost that the adjusted figures leave out")
    if sbc and f and f > 0:
        add(_lvl(sbc / f, R.HOLDER_SBC_FCF), "FCF flattered by stock pay",
            f"stock pay is {sbc / f * 100:.0f}% of free cash flow; after it, FCF is {_big(f - sbc)}")
    if sbc and sbc > 0 and dil is not None and dil > 0.5 and bb < sbc:
        add("watch", "Buybacks short of stock pay",
            f"buybacks {_big(bb)} vs stock pay {_big(sbc)}: the share count still grows")
    tw = u.get("tax_withheld") or 0
    if f and f > 0 and tw > R.HOLDER_TAX_WITHHELD_FCF * f:
        add("watch", "Cash spent on employee stock",
            f"{_big(tw)} ({tw / f * 100:.0f}% of FCF) paid for employees' stock taxes: stock pay costing cash too")

    # 3. new paper
    rev = m["revenue"].get("ttm")
    si = u.get("stock_issued") or 0
    if rev and si > R.HOLDER_EQUITY_RAISE_REV * rev:
        add("high", "New shares sold", f"{_big(si)} raised by selling shares in 12 months")
    conv = u.get("convert_issued") or 0
    if conv > 0:
        add("watch", "Convertible debt", f"{_big(conv)} of convertible notes in 12 months: they can turn into shares")

    # 4. how the cash is used
    acq = u.get("acquisitions") or 0
    if f and f > 0 and acq > R.HOLDER_ACQUISITIONS_FCF * f:
        add("watch", "Big acquisitions", f"{_big(acq)} ({acq / f * 100:.0f}% of FCF): value depends on the price paid "
                                         "and on the deals paying off")
    nb = u.get("net_borrowing")
    returned = bb + (u.get("dividends") or 0)
    if f is not None and returned > max(f, 0) and (nb or 0) > 0:
        add("high", "Paying out with debt", f"returned {_big(returned)} against FCF {_big(f)}, with {_big(nb)} of net "
                                             "borrowing")
    elif f is not None and f <= 0 and (nb or 0) > 0:
        add("watch", "Borrowing to run", f"FCF {_big(f)}; net borrowing {_big(nb)}")

    # 5. what the company shows vs what is there
    e = m["eps"]
    g, a = e.get("gaap_cur"), e.get("nongaap_cur")
    if a and a > 0 and g is not None and (a - g) / a >= R.HOLDER_ADJUSTED_GAP:
        add("watch", "Adjusted EPS far above GAAP",
            f"adjusted ${a:.2f} vs GAAP ${g:.2f}: more than half of the 'profit' is costs left out")
    sa = (m.get("assets") or {}).get("goodwill_intangibles_pct_assets")
    if sa is not None and sa >= R.HOLDER_SOFT_ASSETS_PCT:
        add("watch", "Paid-for assets", f"{sa:.0f}% of assets are goodwill and acquired intangibles: write-down risk")

    out.sort(key=lambda r: r["level"] != "high")
    return out


def method_note(method, sbc_pct_rev):
    """A valuation on sales never sees stock pay: say so when the pay is material."""
    if method in R.HOLDER_SALES_METHODS and sbc_pct_rev and sbc_pct_rev >= R.HOLDER_SBC_REVENUE_PCT[0]:
        return (f"it values sales, so stock pay ({sbc_pct_rev:.0f}% of revenue) never enters the target: "
                "check the FCF value after SBC and the dilution")
    return None
