"""Write the report card: Markdown for reading, JSON for the website."""
import os
from datetime import date

M = 1e6


def money(x):
    if x is None:
        return "n/a"
    sign = "−" if x < 0 else ""
    return f"{sign}${abs(x) / M:,.1f}M"


def usd(x):
    return "n/a" if x is None else ("−" if x < 0 else "") + f"${abs(x):.2f}"


def pc(x, signed=False):
    if x is None:
        return "n/a"
    return f"{x:+.1f}%" if signed else f"{x:.1f}%"


def arrow(x):
    if x is None:
        return ""
    return "▲" if x > 0 else ("▼" if x < 0 else "■")


def mark(good):
    return "" if good is None else ("🟢" if good else "🔴")


def markdown(ticker, name, m, g):
    p = m["period"]
    out = []
    head = f"# {ticker} · {p['label']} (quarter ended {p['end']})"
    out.append(head)
    out.append(f"**{name}** · graded against: **{g['industry_group']}** · {g['company_type']} company · "
               f"method {g['method_version']} · source: {p['form']} filed {p['filed']}\n")
    out.append(f"## Quarter grade: **{g['grade']}**  ({g['score']:.1f} / 100)"
               + ("  · PROVISIONAL (Execution inputs missing)" if g["provisional"] else "") + "\n"
               if g["score"] is not None else "## Quarter grade: n/a\n")

    r, e, c, mg = m["revenue"], m["eps"], m["cash"], m["margins"]
    out.append("### Past the headline")
    rev_line = f"- Revenue {money(r['cur'])}, {pc(r['yoy_pct'], True)} YoY"
    if r["organic_yoy_pct"] is not None:
        rev_line += f" (organic {pc(r['organic_yoy_pct'], True)})"
    if r["yoy_pct_prev_quarter"] is not None:
        rev_line += f"; last quarter {pc(r['yoy_pct_prev_quarter'], True)}"
    out.append(rev_line)
    if e["gaap_cur"] is not None:
        eps_txt = f"- GAAP EPS {usd(e['gaap_cur'])} vs {usd(e['gaap_prior'])}" if e["gaap_prior"] is not None \
            else f"- GAAP EPS {usd(e['gaap_cur'])}"
        eps_txt += f": {e['classification']}" if e["classification"] else ""
        if e["yoy_pct"] is not None and e["gaap_prior"] is not None and e["gaap_prior"] > 0:
            eps_txt += f" ({pc(e['yoy_pct'], True)})"
        if e["nongaap_cur"] is not None:
            eps_txt += f". Non-GAAP {usd(e['nongaap_cur'])}, gap {usd(e['gap'])}/share"
            if e["sbc_per_share"] is not None:
                eps_txt += f", of which SBC ≈ ${e['sbc_per_share']:.2f}"
        out.append(eps_txt)
    out.append("- Margins (same quarter last year → this quarter): "
               + ", ".join(f"{k} {pc(v['prior'])} → {pc(v['cur'])} {arrow(v['pp'])}"
                           for k, v in mg.items()))
    out.append(f"- Revenue {pc(r['yoy_pct'], True)} vs cost of revenue {pc(m['cost_of_revenue_yoy_pct'], True)}")
    out.append(f"- FCF {money(c['fcf_cur'])} ({pc(c['fcf_margin_cur'])} margin, {pc(c['fcf_yoy_pct'], True)} YoY); "
               f"after SBC {money(c['fcf_after_sbc'])} ({pc(c['fcf_after_sbc_margin'])})")
    if m["rule_of_40"] is not None and g["industry_group"] == "Software" and not g["asset_heavy"]:
        out.append(f"- Rule of 40: {m['rule_of_40']:.0f}")
    out.append("")

    out.append("### The annotated statement")
    out.append("Columns read left to right: **Same quarter last year → This quarter**. "
               "🟢/🔴 = good/bad for the business, ◯ = moved the grade.\n")
    out.append("| Line | Same quarter last year | This quarter | YoY | % of revenue | Change | |")
    out.append("|---|---:|---:|---:|---:|---:|:-:|")
    circled = set(g["circled"])
    for ln in m["statement"]:
        if ln["cur"] is None and ln["prior"] is None:
            continue
        if ln["sign_flip"]:
            yoy = "sign flip"
        elif ln["prior"] is not None and ln["prior"] < 0 and ln["cur"] is not None:
            d_ = ln["cur"] - ln["prior"]  # % of a negative base misleads: show dollars
            yoy = f"{arrow(d_)} {'+' if d_ >= 0 else ''}{money(d_)}"
        else:
            yoy = f"{arrow(ln['yoy_pct'])} {pc(ln['yoy_pct'], True)}" if ln["yoy_pct"] is not None else "n/a"
        share = (f"{pc(ln['pct_rev_prior'])} → {pc(ln['pct_rev_cur'])}" if ln["kind"] != "revenue" else "100%")
        chg = f"{arrow(ln['pp'])} {ln['pp']:+.1f}pp" if ln["pp"] is not None and ln["kind"] != "revenue" else ""
        name = f"◯ **{ln['name']}**" if ln["key"] in circled else ln["name"]
        out.append(f"| {name} | {money(ln['prior'])} | {money(ln['cur'])} | {yoy} | {share} | {chg} | {mark(ln['good'])} |")
    out.append("")

    out.append("### Scorecard")
    out.append("| Block | Score | Weight | Contribution |")
    out.append("|---|---:|---:|---:|")
    wsum = sum(g["weights"][k] for k, b in g["blocks"].items() if b["score"] is not None)
    for k, b in g["blocks"].items():
        if b["score"] is None:
            out.append(f"| {k.capitalize()} | n/a | {g['weights'][k]}% | — |")
        else:
            contrib = b["score"] * g["weights"][k] / wsum
            out.append(f"| {k.capitalize()} | {b['score']:.0f} | {g['weights'][k]}% | {contrib:.1f} |")
    out.append("")
    for k, b in g["blocks"].items():
        out.append(f"**{k.capitalize()}**")
        for p_ in b["parts"]:
            val = p_["value"]
            if p_["id"] == "net_debt":
                val = money(val)
            elif isinstance(val, float):
                val = f"{val:.1f}"
            elif val is None:
                val = "n/a"
            pts = "—" if p_["points"] is None else f"{p_['points']:.0f} pts"
            note = f" · {p_['note']}" if p_["note"] else ""
            out.append(f"- {p_['label']}: {val} → {pts} (weight {p_['weight']}){note}")
        if b.get("rule"):
            out.append(f"- House rule: {b['rule']}")
        out.append("")

    if g["house_rules_applied"]:
        out.append("### House rules applied")
        out += [f"- {x}" for x in g["house_rules_applied"]]
        out.append("")
    if g["warnings"]:
        out.append("### Data gaps")
        out += [f"- {x}" for x in g["warnings"]]
        out.append("")

    dbt, ast = m["debt"], m["assets"]
    out.append("### Debt and assets")
    out.append(f"- {ast['profile']}")
    if dbt["total"]:
        line = f"- Total debt {money(dbt['total'])}"
        if dbt["yoy_pct"] is not None:
            line += f" ({pc(dbt['yoy_pct'], True)} YoY vs revenue {pc(r['yoy_pct'], True)})"
        if dbt["pct_revenue_ttm"] is not None:
            line += f", {dbt['pct_revenue_ttm']:.0f}% of a year's revenue"
        if dbt["net_debt_to_ebitda"] is not None:
            line += f"; net debt {dbt['net_debt_to_ebitda']:.1f}x EBITDA"
        out.append(line)
        cost = f"- Interest expense {money(dbt['interest_q'])}"
        if dbt["avg_rate_pct"] is not None:
            cost += f" = about {dbt['avg_rate_pct']:.2f}% a year on average debt"
        if dbt["interest_pct_revenue"] is not None:
            cost += f", {dbt['interest_pct_revenue']:.2f}% of revenue"
        if dbt["interest_cover"] is not None:
            cost += f"; EBITDA covers interest {dbt['interest_cover']:.1f}x ({dbt['interest_cover_basis']})"
        out.append(cost)
        if dbt["near_term"] is not None:
            due = f"- Due within ~{dbt['near_term_months']} months: {money(dbt['near_term'])}"
            if dbt["near_term_cover"] is not None:
                due += f", covered {dbt['near_term_cover']:.1f}x by cash"
            if dbt["avg_maturity_years"] is not None:
                due += f"; average maturity about {dbt['avg_maturity_years']:.1f} years"
            out.append(due)
        if dbt["schedule"]:
            out.append("- Repayment ladder: " + " · ".join(f"{lab} {money(amt)}" for lab, amt in dbt["schedule"]))
    if ast["ebitda_margin"] is not None:
        out.append(f"- EBITDA margin {pc(ast['ebitda_margin_prior'])} → {pc(ast['ebitda_margin'])}; "
                   f"D&A {pc(ast['da_pct_revenue'])} of revenue; capex {pc(ast['capex_pct_revenue'])} of revenue")
    out.append("")

    b = m["balance"]
    d = m["dilution"]
    out.append("### Balance sheet and dilution")
    out.append(f"- Cash {money(b['cash'])} + short-term investments {money(b['st_investments'])} − debt "
               f"{money(b['debt'])} = net cash {money(b['net_cash'])} "
               f"(change since last report {money(b['net_cash_change'])})")
    if d["yoy_pct"] is not None:
        out.append(f"- Basic shares {d['basic_shares_prior'] / M:,.1f}M → {d['basic_shares_cur'] / M:,.1f}M "
                   f"({pc(d['yoy_pct'], True)})")
    out.append("")

    out.append("### Numbers that need an explanation (Step 6)")
    out += [f"- [ ] {q}" for q in m["questions"]] or ["- none"]
    out.append("")
    derived = m["cur"]["derived_lines"]
    if derived:
        out.append(f"_Derived by subtraction (YTD or full year minus earlier periods): {', '.join(derived)}._\n")
    out.append("---")
    out.append(f"_Educational analysis of published results, not a recommendation. "
               f"Generated {date.today().isoformat()} · Tarsier Research · method {g['method_version']}. "
               f"Thesis grade: assigned by the author after the call._")
    return "\n".join(out)


def write_quarter(ticker, name, m, g, folder):
    """reports/FY2026-Q3.md; rewritten only when its content changed."""
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, m["period"]["label"].replace(" ", "-") + ".md")
    text = markdown(ticker, name, m, g)
    strip = lambda t: "\n".join(x for x in t.splitlines() if "Generated" not in x)
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            if strip(f.read()) == strip(text):
                return path
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    return path
