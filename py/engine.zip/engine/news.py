"""Market headlines from the publishers' own free RSS feeds (no key, no cost): Bloomberg, WSJ, MarketWatch,
CNBC, Reuters (through Google News: Reuters has had no RSS since 2020), FT, NYT, The Economist, Yahoo Finance,
Investing.com, Seeking Alpha.

Only the headline, the source, the time and the link are kept and shown: the article stays on the publisher's site.
The same story from several sites is shown once ("also in"). Each headline is matched to the US-listed companies
it names (Nasdaq's free screener: name and market cap of every stock), so the page can leave out the small ones
and mark yours (watchlist and portfolio)."""
import email.utils
import html
import json
import math
import os
import re
import threading
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone

from . import paths

CACHE = os.path.join(paths.CACHE, "news.json")
UNIVERSE = os.path.join(paths.CACHE, "universe.json")
FRESH = 10 * 60                  # headlines: fetched again after 10 minutes
UNIVERSE_FRESH = 7 * 24 * 3600   # names and market caps: once a week
KEEP_HOURS = 72                  # older headlines are dropped
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36"


def _gnews(q):
    return ("https://news.google.com/rss/search?q=" + urllib.parse.quote(q, safe=":/")
            + "&ceid=US:en&hl=en-US&gl=US")


# source, section, address. A feed that stops answering is skipped and named on the page (ⓘ next to the count).
FEEDS = [
    ("Bloomberg", "Markets", "https://feeds.bloomberg.com/markets/news.rss"),
    ("Bloomberg", "Economics", "https://feeds.bloomberg.com/economics/news.rss"),
    ("Bloomberg", "Technology", "https://feeds.bloomberg.com/technology/news.rss"),
    ("Bloomberg", "Industries", "https://feeds.bloomberg.com/industries/news.rss"),
    ("WSJ", "Markets", "https://feeds.content.dowjones.io/public/rss/RSSMarketsMain"),
    ("WSJ", "Economy", "https://feeds.content.dowjones.io/public/rss/socialeconomyfeed"),
    ("WSJ", "Business", "https://feeds.content.dowjones.io/public/rss/WSJcomUSBusiness"),
    ("WSJ", "Technology", "https://feeds.content.dowjones.io/public/rss/RSSWSJD"),
    ("MarketWatch", "Top stories", "https://feeds.marketwatch.com/marketwatch/topstories"),
    ("MarketWatch", "Bulletins", "https://feeds.marketwatch.com/marketwatch/bulletins"),
    ("CNBC", "Top news", "https://www.cnbc.com/id/100003114/device/rss/rss.html"),
    ("CNBC", "Market Insider",
     "https://search.cnbc.com/rs/search/combinedcms/view.xml?partnerId=wrss01&id=20409666"),
    ("CNBC", "Investing", "https://www.cnbc.com/id/15839069/device/rss/rss.html"),
    ("CNBC", "Economy", "https://www.cnbc.com/id/20910258/device/rss/rss.html"),
    ("CNBC", "Finance", "https://www.cnbc.com/id/10000664/device/rss/rss.html"),
    ("CNBC", "Earnings", "https://www.cnbc.com/id/15839135/device/rss/rss.html"),
    ("CNBC", "Technology", "https://www.cnbc.com/id/19854910/device/rss/rss.html"),
    ("CNBC", "Business", "https://www.cnbc.com/id/10001147/device/rss/rss.html"),
    ("CNBC", "Energy", "https://www.cnbc.com/id/19836768/device/rss/rss.html"),
    ("Reuters", "Markets", _gnews("when:2d site:reuters.com/markets")),
    ("Reuters", "Business", _gnews("when:2d site:reuters.com/business")),
    ("Reuters", "Technology", _gnews("when:2d site:reuters.com/technology")),
    ("Barron's", "Markets", _gnews("when:2d site:barrons.com")),
    ("FT", "Markets", "https://www.ft.com/markets?format=rss"),
    ("NYT", "Business", "https://rss.nytimes.com/services/xml/rss/nyt/Business.xml"),
    ("The Economist", "Finance", "https://www.economist.com/finance-and-economics/rss.xml"),
    ("Yahoo Finance", "News", "https://finance.yahoo.com/news/rssindex"),
    ("Investing.com", "Stock market", "https://www.investing.com/rss/news_25.rss"),
    ("Investing.com", "Economy", "https://www.investing.com/rss/news_14.rss"),
    ("Seeking Alpha", "Market currents", "https://seekingalpha.com/market_currents.xml"),
]
SOURCES = list(dict.fromkeys(s for s, _sec, _u in FEEDS))


def feed_id(source, section):
    """"bloomberg-markets": the name the phone's relay knows a feed by (relay/worker.js, NEWS)."""
    return re.sub(r"[^a-z0-9]+", "-", f"{source} {section}".lower()).strip("-")


# ---------- fetching and reading a feed ------------------------------------------------------------------------
def _get(url, timeout=12):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/rss+xml, application/xml, "
                                               "text/xml, application/json, */*", "Accept-Language": "en-US,en"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def _when(text):
    """A feed's date (RFC 822 or ISO 8601) as UTC seconds, or None."""
    if not text:
        return None
    text = text.strip()
    try:
        d = email.utils.parsedate_to_datetime(text)
    except (TypeError, ValueError, IndexError):
        d = None
    if d is None:
        try:
            d = datetime.fromisoformat(text.replace("Z", "+00:00"))
        except ValueError:
            return None
    if d.tzinfo is None:
        d = d.replace(tzinfo=timezone.utc)
    return d.timestamp()


def _clean(t):
    t = html.unescape(re.sub(r"<[^>]+>", "", t or ""))
    return re.sub(r"\s+", " ", t).strip()


def _local(tag):
    return tag.rsplit("}", 1)[-1].lower()


def parse_feed(raw, source, section):
    """[{title, link, time, source, section}] from RSS 2.0 or Atom; tolerant of slightly broken XML."""
    out = []
    text = raw.decode("utf-8", "replace") if isinstance(raw, bytes) else raw
    items = []
    try:
        root = ET.fromstring(text.encode("utf-8"))
        for el in root.iter():
            if _local(el.tag) in ("item", "entry"):
                f = {}
                for c in el:
                    k = _local(c.tag)
                    if k == "link" and c.get("href") and (c.get("rel") in (None, "alternate")):
                        f.setdefault("link", c.get("href"))
                    elif k in ("title", "link", "pubdate", "published", "updated", "date", "guid"):
                        f.setdefault(k, (c.text or "").strip())
                items.append(f)
    except ET.ParseError:                      # broken XML: read the items one by one
        for m in re.finditer(r"<(item|entry)\b.*?</\1>", text, re.S | re.I):
            block, f = m.group(0), {}
            for k in ("title", "link", "pubDate", "published", "updated", "dc:date", "guid"):
                g = re.search(rf"<{k}\b[^>]*>(.*?)</{k}>", block, re.S | re.I)
                if g:
                    v = re.sub(r"^<!\[CDATA\[(.*)\]\]>$", r"\1", g.group(1).strip(), flags=re.S)
                    f[k.lower().replace("dc:", "")] = v
            if "link" not in f:
                g = re.search(r"<link\b[^>]*href=\"([^\"]+)\"", block, re.I)
                if g:
                    f["link"] = g.group(1)
            items.append(f)
    for f in items:
        title = _clean(f.get("title"))
        link = (f.get("link") or f.get("guid") or "").strip()
        when = _when(f.get("pubdate") or f.get("published") or f.get("updated") or f.get("date"))
        if not title or not link.startswith("http"):
            continue
        if "news.google.com" in link or source in ("Reuters", "Barron's"):
            title = re.sub(r"\s+[-–—]\s+[^-–—]{2,40}$", "", title)       # Google News adds " - Reuters"
        out.append({"title": title, "link": link, "time": when, "source": source, "section": section})
    return out


def _fetch_one(feed):
    src, sec, url = feed
    try:
        items = parse_feed(_get(url), src, sec)
        return url, items, None
    except Exception as e:                      # one feed down never stops the others
        return url, [], f"{type(e).__name__}: {str(e)[:80]}"


# ---------- the companies a headline names --------------------------------------------------------------------
_SKIP_ROWS = re.compile(r"\b(warrants?|units?|rights?|preferred|notes due|depositary shares? representing|"
                        r"debentures?|% |subordinated|fixed[- ]to[- ]floating)\b", re.I)
_SUFFIX = re.compile(r"\b(common stock|common shares|ordinary shares?|class [a-c]\b( common stock| ordinary shares| "
                     r"shares)?|american depositary (shares?|receipts?)|ads|sponsored|new|inc\.?|incorporated|"
                     r"corporation|corp\.?|company|co\.?|holdings?|group|ltd\.?|limited|plc|n\.?v\.?|s\.?a\.?|ag|"
                     r"se|l\.?p\.?|llc|\(the\)|each representing.*)$", re.I)
# words that are also everyday words, places or generic company words: never a company on their own
GENERIC = set("""
american america united general first national international global new north south east west pacific atlantic
southern northern eastern western central digital energy health healthcare financial capital royal advanced applied
super universal best target block gap snap delta visa square shell chase match progressive equity citizens discover
ally dominion public sun star bright open real core prime alpha beta gamma omega one two three bank banks trust
group holdings technologies technology systems solutions services industries international partners resources
china chinese taiwan japan japanese india indian brazil mexico canada canadian texas california florida york london
europe european asia asian africa african korea korean germany german france french british britain us usa
energy power oil gas water air airlines motors motor auto mobile data cloud ai robotics bio pharma therapeutics
medical life care home house market markets stock stocks fund funds income value growth trade trading
global next future smart green blue red black white gold silver iron steel copper silicon micro mega meta
amazon apple oracle arm unity fox news sky jack wolf eagle tiger lion bear bull rocket galaxy planet
trump biden musk powell warsh fed federal state states republic union liberty freedom patriot victory summit
pinnacle apex main street wall lucky israel saudi russia ukraine iran turkey italy spain ireland australia
singapore hong kong swiss dutch nordic latin bitcoin ethereum white house treasury dollar euro yen opec
""".split())
CURATED = {   # names the headlines use that the listing names don't give
    "Google": "GOOGL", "Alphabet": "GOOGL", "Facebook": "META", "Meta": "META", "Instagram": "META",
    "Amazon": "AMZN", "Apple": "AAPL", "Microsoft": "MSFT", "Nvidia": "NVDA", "Tesla": "TSLA",
    "Broadcom": "AVGO", "Oracle": "ORCL", "Netflix": "NFLX", "Palantir": "PLTR", "Micron": "MU",
    "JPMorgan": "JPM", "JP Morgan": "JPM", "Goldman": "GS", "Goldman Sachs": "GS", "Morgan Stanley": "MS",
    "Citi": "C", "Citigroup": "C", "Wells Fargo": "WFC", "Bank of America": "BAC", "BofA": "BAC",
    "Berkshire": "BRK-B", "Berkshire Hathaway": "BRK-B", "Exxon": "XOM", "ExxonMobil": "XOM", "Chevron": "CVX",
    "Lilly": "LLY", "Eli Lilly": "LLY", "J&J": "JNJ", "Johnson & Johnson": "JNJ", "P&G": "PG",
    "Procter & Gamble": "PG", "Coca-Cola": "KO", "PepsiCo": "PEP", "Pepsi": "PEP", "McDonald's": "MCD",
    "Walmart": "WMT", "Costco": "COST", "Home Depot": "HD", "Disney": "DIS", "Boeing": "BA", "Intel": "INTC",
    "AMD": "AMD", "Qualcomm": "QCOM", "IBM": "IBM", "Salesforce": "CRM", "Adobe": "ADBE", "ServiceNow": "NOW",
    "Snowflake": "SNOW", "UnitedHealth": "UNH", "Pfizer": "PFE", "Merck": "MRK", "AbbVie": "ABBV",
    "Novo Nordisk": "NVO", "Mastercard": "MA", "Visa Inc": "V", "PayPal": "PYPL", "Shopify": "SHOP",
    "Spotify": "SPOT", "Super Micro": "SMCI", "Supermicro": "SMCI", "CoreWeave": "CRWV", "Nebius": "NBIS",
    "Uber": "UBER", "Airbnb": "ABNB", "Starbucks": "SBUX", "Nike": "NKE", "Caterpillar": "CAT",
    "Robinhood": "HOOD", "Coinbase": "COIN", "MicroStrategy": "MSTR", "Alibaba": "BABA", "TSMC": "TSM",
    "Taiwan Semiconductor": "TSM", "ASML": "ASML", "SoFi": "SOFI", "Rocket Lab": "RKLB", "GE Vernova": "GEV",
    "GE Aerospace": "GE", "Arm Holdings": "ARM", "Dell": "DELL", "Cisco": "CSCO", "AT&T": "T", "Verizon": "VZ",
    "Comcast": "CMCSA", "Ford": "F", "GM": "GM", "General Motors": "GM", "Lockheed": "LMT", "Raytheon": "RTX",
    "Target Corp": "TGT", "Block Inc": "XYZ", "Snap Inc": "SNAP", "Delta Air": "DAL", "Shopify Inc": "SHOP",
}
ACRONYMS = set("""CEO CFO COO CTO IPO IPOS ETF ETFS GDP CPI PPI PCE FED SEC FDA FTC DOJ EPS USA USD EUR GBP JPY CNY OPEC
NATO NYSE AMEX CNBC WSJ FOMC ECB BOJ BOE IMF LNG API SPAC SPACS AI EV EVS US UK EU UN TV PC IT HR M&A Q1 Q2 Q3 Q4
ESG REIT REITS ADR ADRS OTC NFL NBA FIFA CDC WHO NASA DOGE IRS EIA CBO GOP DNC RNC ICE ATM ROI""".split())


def _norm_sym(s):
    return str(s or "").strip().upper().replace("/", "-").replace(".", "-").replace("^", "-")


def _mcap(v):
    try:
        x = float(str(v).replace(",", "").replace("$", ""))
        return x if x > 0 else None
    except (TypeError, ValueError):
        return None


def clean_name(name):
    n = re.sub(r"\s+", " ", str(name or "")).strip().rstrip(",.")
    n = re.sub(r"^the\s+|\s*\(the\)", "", n, flags=re.I).strip()
    for _ in range(6):                          # suffixes can stack: "… Holdings, Inc. Class A Common Stock"
        m = _SUFFIX.search(n)
        if not m:
            break
        n = n[:m.start()].strip().rstrip(",.-&").strip()
    return n


def parse_universe(data):
    """[[symbol, clean name, market cap $]] from Nasdaq's screener JSON."""
    rows = ((data or {}).get("data") or {}).get("rows") or ((data or {}).get("data") or {}).get("table", {}).get(
        "rows") or []
    out = []
    for r in rows:
        name = str(r.get("name") or "")
        if not r.get("symbol") or _SKIP_ROWS.search(name):
            continue
        out.append([_norm_sym(r["symbol"]), clean_name(name), _mcap(r.get("marketCap"))])
    return out


def universe(refresh=False):
    """Every US-listed stock with its market cap (Nasdaq's free screener), kept a week. [] if never fetched."""
    try:
        with open(UNIVERSE, encoding="utf-8") as f:
            u = json.load(f)
    except (OSError, ValueError):
        u = {}
    if u.get("rows") and not refresh and time.time() - u.get("fetched", 0) < UNIVERSE_FRESH:
        return u["rows"]
    try:
        raw = _get("https://api.nasdaq.com/api/screener/stocks?tableonly=true&limit=25000&offset=0&download=true",
                   timeout=30)
        rows = parse_universe(json.loads(raw.decode("utf-8", "replace")))
        if len(rows) > 1000:
            u = {"fetched": time.time(), "rows": rows}
            os.makedirs(paths.CACHE, exist_ok=True)
            with open(UNIVERSE + ".tmp", "w", encoding="utf-8") as f:
                json.dump(u, f)
            os.replace(UNIVERSE + ".tmp", UNIVERSE)
    except Exception:
        pass                                     # no names this time: keep the last ones (or none)
    return u.get("rows") or []


_WORD = re.compile(r"[A-Za-z0-9][A-Za-z0-9&.\-]*(?:['’][A-Za-z]+)?")
_AFTER = {"inc", "corp", "co", "shares", "stock", "stocks", "holdings", "group", "earnings", "ceo", "plc", "ltd",
          "beats", "misses", "tops", "posts", "reports", "raises", "lifts", "cuts", "slashes", "sales", "results",
          "quarter", "profit", "profits", "revenue", "guidance", "outlook", "forecast", "jumps", "soars", "surges",
          "falls", "slides", "sinks", "plunges", "tumbles", "rallies", "rises", "drops", "gains"}
# tickers that are everyday words in capitals ("Why NOW is the time"): only as (NOW) or $NOW
COMMON_CAPS = set("""NOW ALL ARE CAN FOR ONE BIG BUY KEY LOW NEW TOP WELL GOOD BEST FUN CAR EAT LOVE PLAY OPEN RUN SAVE
SEE TRUE WORK YOU HAS HE SHE WHO WHY HOW WAS AND THE NOT OUT GO GET HOT COLD FAST FREE FIVE NINE TEN SIX MORE MOST
REAL LIFE HOME CASH GOLD BOX EYE LAND SHIP JOB JOBS PAY TAX DEAL RISK RATE AIR SKY SUN WIN WINS DOW IPO""".split())


def _words(text):
    """[(word as written, key)]: the key is lowercased, without 's and the trailing dot."""
    out = []
    for m in _WORD.finditer(text.replace("’", "'")):
        w = m.group(0)
        k = re.sub(r"'s$", "", w.lower()).rstrip(".-")
        if k:
            out.append((w, k))
    return out


class Matcher:
    """Finds the companies a headline names: by ticker ((NVDA), $NVDA, NASDAQ: NVDA, NVDA) and by name.
    Names are looked up as word sequences (up to 6 words), so thousands of names cost little."""
    MAXW = 6

    def __init__(self, rows, mine_names=None):
        self.cap = {}
        names, context, first = {}, {}, {}
        for sym, name, cap in rows:
            self.cap[sym] = cap
            ws = [k for _w, k in _words(name or "")]
            if not ws:
                continue
            key = " ".join(ws)
            if len(ws) >= 2:
                names.setdefault(key, sym)
                first.setdefault(ws[0], []).append((sym, cap))
            elif len(key) >= 3:
                if key in GENERIC or (name.isupper() and len(name) <= 3):
                    context.setdefault(key, sym)
                else:
                    names.setdefault(key, sym)
        for w, lst in first.items():             # "Goldman", "Micron": a first word only one company has
            if len(lst) == 1 and w not in GENERIC and len(w) >= 4 and w not in names:
                sym, cap = lst[0]
                if cap and cap >= 2e9:
                    names[w] = sym
                else:                            # a small one: only with "stock", "shares", "beats"… after it
                    context.setdefault(w, sym)
        for alias, sym in CURATED.items():
            names[" ".join(k for _w, k in _words(alias))] = _norm_sym(sym)
            self.cap.setdefault(_norm_sym(sym), None)
        for alias, sym in (mine_names or {}).items():
            key = " ".join(k for _w, k in _words(alias or ""))
            if len(key) >= 3 and key not in GENERIC:
                names.setdefault(key, sym)
        self.syms, self.names, self.context = set(self.cap), names, context

    def find(self, title):
        """{symbol: market cap or None}"""
        out = {}
        for m in re.finditer(r"\(([A-Z]{1,5}(?:[.-][A-Z])?)\)|\$([A-Z]{1,5})\b|"
                             r"(?:NYSE|NASDAQ|Nasdaq|NYSE American)\s*:\s*([A-Z]{1,5}(?:[.-][A-Z])?)", title):
            s = _norm_sym(next(g for g in m.groups() if g))
            if s in self.syms and s not in ACRONYMS:
                out[s] = self.cap.get(s)
        if not title.isupper():
            for m in re.finditer(r"\b([A-Z]{3,5})\b", title):      # NVDA, PLTR written plainly
                s = m.group(1)
                if s in self.syms and s not in ACRONYMS and s not in COMMON_CAPS:
                    out[s] = self.cap.get(s)
        ws = _words(title)
        i = 0
        while i < len(ws):
            hit = None
            for n in range(min(self.MAXW, len(ws) - i), 0, -1):
                key = " ".join(k for _w, k in ws[i:i + n])
                s = self.names.get(key)
                if s and (ws[i][0][0].isupper() or ws[i][0][0].isdigit()):
                    hit = (s, n)
                    break
                s = self.context.get(key) if n == 1 else None
                if s and ws[i][0][0].isupper() and i + 1 < len(ws) and ws[i + 1][1] in _AFTER:
                    hit = (s, 1)
                    break
            if hit:
                out[hit[0]] = self.cap.get(hit[0])
                i += hit[1]
            else:
                i += 1
        return out


# ---------- what a headline is about ---------------------------------------------------------------------------
MACRO = re.compile(r"\b(fed|fomc|powell|warsh|rate cuts?|rate hikes?|interest rates?|inflation|cpi|ppi|pce|"
                   r"jobs report|payrolls?|unemployment|jobless|labor market|gdp|recession|economy|economic|"
                   r"treasur(y|ies)|yields?|bonds?|dollar|euro|yen|yuan|currenc(y|ies)|oil|crude|brent|opec|"
                   r"natural gas|gold|bitcoin|crypto|tariffs?|trade war|trade deal|sanctions?|s&p|s&p 500|nasdaq|"
                   r"dow|russell|stocks|stock market|equities|wall street|futures|earnings|guidance|outlook|"
                   r"profit warning|ecb|boj|bank of england|pboc|stimulus|debt ceiling|shutdown|deficit|ipos?|"
                   r"mergers?|acquisitions?|acquires?|buyouts?|takeover|deal|antitrust|vix|volatility|sell-?off|"
                   r"rall(y|ies)|bull market|bear market|correction|record high|all-time high|semiconductors?|"
                   r"chips?|chipmakers?|ai spending|data centers?|capex|layoffs?|bankruptcy|default|credit|"
                   r"housing|retail sales|consumer|manufacturing|pmi|ism|opec\+|central bank|rate decision|"
                   r"downgrades?|upgrades?|price target|buyback|dividend|split)\b", re.I)
NOISE = re.compile(r"(mortgage rates today|cd rates|savings rates|\b\d+ best\b|\bbest .{0,30}\b(cards?|"
                   r"accounts?|rates|deals|gifts?|stocks to buy|etfs to buy)\b|\bstocks? to buy (now|today)\b|"
                   r"\bquiz\b|crossword|\bpodcast\b|^watch:|^video:|\bhoroscope|\brecipe|\bhow to (save|retire|"
                   r"budget|pay off)|\bretire (early|with)|\bsocial security (check|payment)|travel tips|"
                   r"\bwedding\b|\bdating\b|\bcelebrit|\bsweepstakes\b|\bcoupon|\bprime day deals?\b|"
                   r"\bdeals? of the day\b|\bopinion:|\bletters to the editor\b)", re.I)
STOP = set("""a an the and or but of to in on at for from by with as is are was were be been it its this that these those
than then so if into over under after before about up down out new says said say will would could may might can
amid while why how what when who where which more most less least very just not no yes his her their our your
has have had do does did via per vs versus report reports reported according""".split())


def tokens(title):
    words = re.findall(r"[a-z0-9$%&.]+", title.lower().replace("’", "'").replace("'s ", " "))
    out = set()
    for w in words:
        w = w.strip(".")
        if not w or w in STOP or len(w) < 2:
            continue
        if len(w) > 4 and w.endswith("s") and not w.endswith("ss"):
            w = w[:-1]
        out.add(w)
    return out


def same_story(a, b):
    if not a or not b:
        return False
    inter = len(a & b)
    if inter < 3:
        return False
    return inter / min(len(a), len(b)) >= 0.7 or inter / len(a | b) >= 0.5


def cluster(items, window=36 * 3600):
    """The same story from several feeds, once: [{...first item, 'also': [items], 'n_sources'}], newest first."""
    items = sorted([i for i in items if i.get("time")], key=lambda i: i["time"])
    groups, by_link, index = [], {}, {}
    for it in items:
        g = by_link.get(it["link"])
        if g is None:
            tk_ = tokens(it["title"])
            cand = set()
            for w in tk_:
                cand.update(index.get(w, ()))
            for gi in sorted(cand, reverse=True):
                h = groups[gi]
                if it["time"] - h["time"] <= window and same_story(tk_, h["_tokens"]):
                    g = gi
                    break
            if g is None:
                g = len(groups)
                groups.append({**it, "also": [], "_tokens": tk_, "last": it["time"]})
                for w in tk_:
                    index.setdefault(w, []).append(g)
                by_link[it["link"]] = g
                continue
            by_link[it["link"]] = g
        h = groups[g]
        if it["link"] == h["link"] or any(x["link"] == it["link"] for x in h["also"]):
            continue
        h["also"].append({k: it[k] for k in ("title", "link", "time", "source", "section")})
        h["last"] = max(h["last"], it["time"])
    for h in groups:
        h["sources"] = list(dict.fromkeys([h["source"]] + [x["source"] for x in h["also"]]))
        h.pop("_tokens", None)
    return sorted(groups, key=lambda h: -h["time"])


def classify(groups, matcher, mine):
    """Adds to each story: tickers [[sym, cap]] (largest first), mine, macro, noise."""
    for h in groups:
        found = {}
        for t in [h["title"]] + [x["title"] for x in h["also"]]:
            found.update(matcher.find(t) if matcher else {})
        h["tickers"] = sorted(([s, c] for s, c in found.items()), key=lambda x: -(x[1] or 0))
        h["mine"] = [s for s in found if s in mine]
        h["macro"] = bool(MACRO.search(h["title"]))
        h["noise"] = bool(NOISE.search(h["title"]))
    return groups


def keep(h, view, min_cap):
    """Whether a story shows in a view: 'relevant' (default), 'mine' or 'all'."""
    if view == "all":
        return True
    if view == "mine":
        return bool(h["mine"])
    if h["mine"]:
        return True
    if h["noise"]:
        return False
    caps = [c for _s, c in h["tickers"]]
    if any(c and c >= min_cap for c in caps):
        return True
    if caps and all(c is not None and c < min_cap for c in caps):
        return False                             # only small companies: noise for this page
    if h["macro"]:
        return True
    return len(h["sources"]) >= 2                # nothing recognised: only when several outlets carry it


def score(h, now=None):
    """For 'Top': yours first, then what many outlets carry, big companies and the economy; older counts less."""
    now = now or time.time()
    big = max((c or 0 for _s, c in h["tickers"]), default=0)
    s = (4 if h["mine"] else 0) + 1.5 * math.log2(len(h["sources"])) + (h["macro"] and 1 or 0)
    if big:
        s += max(0.0, 0.6 * math.log10(big / 1e9))
    return s - (now - h["time"]) / 3600 / 8


# ---------- kept on disk -----------------------------------------------------------------------------------------
_lock = threading.Lock()


def load():
    try:
        with open(CACHE, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {"fetched": 0, "feeds": {}, "items": []}


def _save(d):
    os.makedirs(paths.CACHE, exist_ok=True)
    with open(CACHE + ".tmp", "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(CACHE + ".tmp", CACHE)


def fresh(d=None):
    d = d or load()
    return time.time() - d.get("fetched", 0) < FRESH


def fetch(progress=None, workers=8):
    """Every feed again (in parallel), merged with what is kept; drops what is older than KEEP_HOURS."""
    with _lock:
        d = load()
        old = {i["link"]: i for i in d.get("items", [])}
        feeds = {}
        new = 0
        with ThreadPoolExecutor(max_workers=workers) as ex:
            for url, items, err in ex.map(_fetch_one, FEEDS):
                feeds[url] = {"ok": err is None, "n": len(items), "err": err, "time": time.time()}
                for it in items:
                    if it["time"] is None:
                        it["time"] = (old.get(it["link"]) or {}).get("time") or time.time()
                    if it["link"] not in old:
                        new += 1
                    old.setdefault(it["link"], it)
                if progress:
                    progress(f"News: {sum(1 for f in feeds.values() if f['ok'])} of {len(FEEDS)} feeds")
        cut = time.time() - KEEP_HOURS * 3600
        d = {"fetched": time.time(), "feeds": feeds,
             "items": sorted((i for i in old.values() if (i.get("time") or 0) >= cut), key=lambda i: -i["time"])}
        _save(d)
        d["new"] = new
        return d


def mine_tickers():
    """Your tickers (watchlist and portfolio) and the names they go by."""
    from . import excel, portfolio
    out = set()
    try:
        out |= {str(w["ticker"]).upper() for w in excel.read_watchlist(paths.WATCHLIST) if w.get("ticker")}
    except Exception:
        pass
    try:
        out |= {str(r["ticker"]).upper() for r in portfolio.load()["rows"] if r.get("ticker")
                and str(r["ticker"]).upper() != str(getattr(portfolio, "CASH", "")).upper()}
    except Exception:
        pass
    return {_norm_sym(t) for t in out}


def build(d=None, refresh_universe=False):
    """The stories to show, every filter left to the page: {stories, feeds, fetched, n_items}."""
    d = d or load()
    return stories_from(d, universe(refresh_universe), mine_tickers())


def stories_from(d, rows, mine):
    """The PC and the phone (phone_engine.news_update) both end here."""
    mine = {_norm_sym(t) for t in mine}
    names = {}
    for sym, name, _cap in rows:
        if sym in mine and name:
            names[name] = sym
            names[name.split()[0]] = sym if len(name.split()[0]) >= 4 else None
    m = Matcher(rows, {k: v for k, v in names.items() if v})
    groups = classify(cluster(d.get("items", [])), m, mine)
    return {"stories": groups, "feeds": d.get("feeds", {}), "fetched": d.get("fetched", 0),
            "n_items": len(d.get("items", [])), "universe": len(rows), "mine": sorted(mine)}
