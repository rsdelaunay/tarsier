"""How a grade was worked out, in words: shared by the window's balloons and the phone app."""
from . import rules, scorecard

# the scale behind each measure: (table, unit, lower is better)
SCALES = {
    "revenue_growth": (rules.REVENUE_GROWTH, "%", False), "gross": (rules.MARGIN_CHANGE, "pp", False),
    "operating": (rules.MARGIN_CHANGE, "pp", False), "net": (rules.MARGIN_CHANGE, "pp", False),
    "ebitda": (rules.MARGIN_CHANGE, "pp", False), "rule_of_40": (rules.RULE_OF_40, "", False),
    "fcf_margin": (rules.FCF_MARGIN, "%", False), "fcf_margin_change": (rules.FCF_MARGIN_CHANGE, "pp", False),
    "fcf_after_sbc": (rules.FCF_AFTER_SBC_MARGIN, "%", False), "cfo_margin": (rules.CFO_MARGIN, "%", False),
    "interest_cover": (rules.INTEREST_COVER, "x", False), "maturity": (rules.NEAR_TERM_COVER, "x", False),
    "debt_pace": (rules.DEBT_PACE_PP, "pp", False), "rev_vs_consensus": (rules.BEAT_PCT, "%", False),
    "rev_vs_guidance": (rules.BEAT_PCT, "%", False), "eps_vs_consensus": (rules.EPS_BEAT_PCT, "%", False),
    "beat_vs_habit": (rules.BEAT_VS_HABIT_PP, "pp", False),
}


def clean_label(label):
    return label.replace(" (pp)", "").replace(" (%)", "").replace(" (x)", "")


def fmt_value(p):
    v, lab = p["value"], p["label"]
    if v is None:
        return "—"
    if isinstance(v, str):
        return v
    if p["id"] == "net_debt":
        return f"{'net cash' if v >= 0 else 'net debt'} ${abs(v) / 1e6:,.0f}M"
    if "(pp)" in lab:
        return f"{v:+.1f}pp"
    if "(x)" in lab:
        return f"{v:.1f}x"
    if "YoY" in lab or "vs " in lab or "growth" in lab.lower() or "beat" in lab.lower():
        return f"{v:+.1f}%"
    if "(%)" in lab:
        return f"{v:.1f}%"
    return f"{v:,.1f}"


def scale_text(table, unit):
    return " · ".join(f"{'below' if lo == -rules.INF else f'{lo:g}{unit}+'} = {pts}" for lo, pts in table)


def block_detail(r, k):
    """[{label, value, points, share, why, scale}] for one block of one quarter, plus the lines not used."""
    parts = r.get("parts", {}).get(k, [])
    used = [p for p in parts if p["applies"] and p["points"] is not None]
    total_w = sum(q["weight"] for q in used) or 1
    items = []
    for p in used:
        it = {"label": clean_label(p["label"]), "value": fmt_value(p), "points": round(p["points"]),
              "share": round(p["weight"] * 100 / total_w) if len(used) > 1 else None, "why": p.get("note"),
              "scale": None}
        sc = SCALES.get(p["id"])
        if sc and isinstance(p["value"], (int, float)):
            table, unit, low = sc
            base = (scorecard.band_low if low else scorecard.band)(p["value"], table)
            if base != p["points"]:
                why = p.get("note") or "a house rule"
                if p["id"] == "revenue_growth" and "decelerat" in why:
                    why = f"growth slowed by {rules.ACCELERATION_PP:g}pp or more vs the quarter before"
                elif p["id"] == "revenue_growth" and "accelerat" in why:
                    why = f"growth sped up by {rules.ACCELERATION_PP:g}pp or more vs the quarter before"
                it["why"] = f"band {base} pts, {p['points'] - base:+.0f}: {why}"
            it["scale"] = scale_text(table, unit)
        items.append(it)
    waiting = [clean_label(p["label"]) for p in parts if p["applies"] and p["points"] is None]
    skipped = [f"{clean_label(p['label'])}: {p['note']}" for p in parts if not p["applies"] and p.get("note")]
    return {"items": items, "waiting": waiting, "skipped": skipped}


def _m(v):
    """Dollars in plain words: $13.4B, $850M."""
    if v is None:
        return "—"
    a = abs(v)
    t = f"${a / 1e9:,.1f}B" if a >= 1e9 else f"${a / 1e6:,.0f}M"
    return ("−" if v < 0 else "") + t


def _pct(a, b):
    return None if a is None or b in (None, 0) else a / b * 100


def headlines(r, k, co=None):
    """Plain sentences for one block: what moved, from what to what. No points, no weights."""
    parts = {p["id"]: p for p in r.get("parts", {}).get(k, [])}
    use = lambda i: i in parts and parts[i]["applies"] and parts[i]["points"] is not None
    snap = prev = None
    if co is not None:
        try:
            snap = co.snapshot(r["end"])
            pe = co.previous(r["end"], 4)
            prev = co.snapshot(pe) if pe else None
        except Exception:
            snap = prev = None
    g = lambda s, key: (s or {}).get(key)
    rev, rev_p = g(snap, "revenue"), g(prev, "revenue")
    out = []

    def margin(key, name, est=False):
        a, b = _pct(g(snap, key), rev), _pct(g(prev, key), rev_p)
        if a is None:
            return None
        tail = f", was {b:.1f}% ({a - b:+.1f}pp)" if b is not None else ""
        return f"{name} margin {a:.1f}%{tail}" + (" (estimated)" if est else "")

    if k == "growth" and use("revenue_growth"):
        v = parts["revenue_growth"]["value"]
        if rev and rev_p:
            out.append(f"Revenue {_m(rev)}, {v:+.1f}% YoY (was {_m(rev_p)})")
        else:
            out.append(f"Revenue {v:+.1f}% YoY")
        try:
            q1 = co.previous(r["end"], 1) if co is not None else None
            r1, r1p = g(co.snapshot(q1), "revenue"), g(co.snapshot(co.previous(q1, 4)), "revenue")
            g1 = (r1 / r1p - 1) * 100 if r1 and r1p else None
        except Exception:
            g1 = None
        if g1 is not None:
            verb = "sped up" if v - g1 >= 1 else "slowed" if g1 - v >= 1 else "held"
            out.append(f"Growth {verb}: {g1:+.1f}% last quarter → {v:+.1f}%")

    elif k == "profitability":
        for pid, key, name in (("gross", "gross_profit", "Gross"), ("operating", "operating_income", "Operating"),
                               ("net", "net_income", "Net"), ("ebitda", "ebitda", "EBITDA")):
            if use(pid):
                ln = margin(key, name, pid == "operating" and g(snap, "oi_estimated"))
                out.append(ln or f"{name} margin {parts[pid]['value']:+.1f}pp YoY")
        if use("eps"):
            p, a, b = parts["eps"], g(snap, "eps_diluted"), g(prev, "eps_diluted")
            if a is not None and b is not None:
                d = lambda x: f"{'−' if x < 0 else ''}${abs(x):.2f}"
                out.append(f"GAAP EPS {d(a)}, was {d(b)}" + (f" ({p['note']})" if p.get("note") else ""))
            else:
                out.append(f"GAAP EPS: {p['value']}" + (f" ({p['note']})" if p.get("note") else ""))
        if use("leverage"):
            v = parts["leverage"]["value"]
            out.append("All cost lines grew slower than revenue" if v >= 99.5 else
                       "No cost line grew slower than revenue" if v <= 0.5 else
                       f"{v:.0f}% of cost lines grew slower than revenue")
        if use("rule_of_40"):
            out.append(f"Rule of 40: {parts['rule_of_40']['value']:.0f} (revenue growth + FCF margin)")

    elif k == "cash":
        f = r.get("fcf") or {}
        if use("fcf_margin") and f.get("margin_ttm") is not None:
            mp = f.get("margin_pp")
            out.append(f"FCF margin {f['margin_ttm']:.1f}% (12 months)"
                       + (f", was {f['margin_ttm'] - mp:.1f}%" if mp is not None else ""))
        if use("fcf_margin_change"):
            out.append("Quarter: " + (margin("fcf", "FCF") or
                       f"FCF margin {parts['fcf_margin_change']['value']:+.1f}pp YoY"))
        if use("fcf_after_sbc"):
            out.append(f"After stock pay: {parts['fcf_after_sbc']['value']:.1f}% (12 months)")
        if use("sbc_trend"):
            a, b = _pct(g(snap, "sbc"), rev), _pct(g(prev, "sbc"), rev_p)
            out.append(f"Stock pay {a:.1f}% of revenue, was {b:.1f}%" if a is not None and b is not None
                       else f"Stock pay {parts['sbc_trend']['value']:+.1f}pp of revenue YoY")
        if use("cfo_margin"):
            out.append(f"Operating cash flow {parts['cfo_margin']['value']:.1f}% of revenue")

    elif k == "balance":
        if use("net_debt"):
            v, b = parts["net_debt"]["value"], g(prev, "net_cash")
            word = lambda x: f"net cash {_m(x)}" if x >= 0 else f"net debt {_m(-x)}"
            ln = word(v)
            out.append(ln[0].upper() + ln[1:] + (f", was {word(b)}" if b is not None else ""))
        if use("interest_cover"):
            p = parts["interest_cover"]
            if p["value"] is not None and not (p.get("note") or "").startswith("net cash"):
                out.append(f"Interest covered {p['value']:.1f}× by operating profit")
        if use("maturity"):
            p = parts["maturity"]
            out.append(f"Debt due soon covered {p['value']:.1f}× by cash" if p["value"] is not None
                       else "No debt due soon" if "nothing" in (p.get("note") or "") else (p.get("note") or ""))
        if use("debt_pace"):
            v = parts["debt_pace"]["value"]
            out.append(f"Revenue grew {v:.1f}pp faster than debt" if v >= 0 else
                       f"Debt grew {-v:.1f}pp faster than revenue")
        if use("dilution"):
            v = parts["dilution"]["value"]
            out.append(f"Share count {v:+.1f}% YoY")

    elif k == "execution":
        p = parts
        if use("guidance"):
            out.append(f"Full-year guidance: {p['guidance']['value']}")
        for pid, what in (("rev_vs_consensus", "Revenue {} consensus"), ("rev_vs_guidance", "Revenue {} the guidance midpoint"),
                          ("eps_vs_consensus", "EPS {} consensus")):
            if use(pid):
                v = p[pid]["value"]
                out.append(what.format(f"{abs(v):.1f}% {'above' if v >= 0 else 'below'}"))
        if use("beat_vs_habit"):
            v = p["beat_vs_habit"]["value"]
            out.append(f"Beat {abs(v):.1f}pp {'bigger' if v >= 0 else 'smaller'} than its usual beat")
        if not out:
            out.append("Nothing entered yet: guidance and consensus go in the boxes below.")
    return [ln for ln in out if ln]


def block_text(r, k, co=None):
    """The balloon of one block: a few plain headlines."""
    if not r or "parts" not in r:
        return ""
    s = r["blocks"].get(k)
    head = f"{k.capitalize()} · {'n/a' if s is None else f'{s:.0f} / 100'}"
    lines = [f"•  {ln}" for ln in headlines(r, k, co)]
    missing = [clean_label(p["label"]) for p in r["parts"].get(k, []) if p["applies"] and p["points"] is None]
    if missing and k != "execution":
        lines.append("Not reported this quarter: " + ", ".join(missing))
    return head + "\n\n" + "\n".join(lines)


def grade_rows(r):
    """[(block, score, weight %, points)] behind the final score; weights of missing blocks are shared out."""
    avail = {k: v for k, v in r["blocks"].items() if v is not None}
    wsum = sum(r["weights"][k] for k in avail) or 1
    return [(k, v, r["weights"][k] * 100 / wsum, v * r["weights"][k] / wsum) for k, v in avail.items()]


def grade_text(r):
    if not r or r.get("score") is None:
        return ""
    rows = [f"{k.capitalize():<14} {v:5.0f}  ×  {w:4.1f}%  =  {pts:5.1f}" for k, v, w, pts in grade_rows(r)]
    missing = [k for k, v in r["blocks"].items() if v is None]
    txt = (f"{r['grade']} · {r['score']:.1f} / 100\n\n" + "\n".join(rows)
           + (f"\n\n{', '.join(m.capitalize() for m in missing)}: no data, so its weight is shared by the others."
              if missing else ""))
    if r.get("house_rules"):
        txt += "\n\nHouse rule: " + r["house_rules"]
    return txt + "\n\n" + "  ".join(f"{g} {lo}+" for lo, g in rules.GRADES[:9])
