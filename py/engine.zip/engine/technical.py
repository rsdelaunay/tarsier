"""Entry & sizing: WHEN and HOW MUCH to buy a company already judged worth buying (below its fair value).
Technical analysis does not choose the company; it spreads the buying: bigger first steps when the trend is
up and the price is not stretched, small steps at support levels (or with time) when the trend is down.

Long-term holder's view: daily and weekly bars, 10 years of history (Yahoo, kept 12 hours).

    trend      price vs EMA 50/200, the EMA 200's slope, the weekly trend          bull / neutral / bear
    stretch    RSI 14 (daily, weekly), distance above the EMA 20 in ATRs          extended / oversold
    levels     swing lows, EMA 50 and 200, VWAP since the last earnings, Fibonacci of the last big move, 52w low
    volume     up-day vs down-day volume (50 days), OBV's slope
    context    strength vs the S&P 500 (6 months); earnings in the next days

The plan: target weight (by conviction, or what you set) minus what you hold, in batches whose size depends on
the trend (a share of the whole portfolio), the first now and the next at the support levels below, or after a
few weeks when no level is reached. Whole shares only, rounded down."""
import json
import math
import os
import time
from datetime import date, datetime, timedelta, timezone

from . import paths

CACHE_DIR = os.path.join(paths.CACHE, "technical")
FRESH = 12 * 3600

# the rules (calibrated with backtest())
EXTENDED_RSI, EXTENDED_RSI_W, EXTENDED_ATR = 70, 75, 3.0
OVERSOLD_RSI = 30
DIST50_WARN, DIST50_STRETCHED = 2.5, 3.0     # distance from the SMA 50 in ATRs: stretched from ±2.5, overextended ±3
BATCH = {"buy_zone": 0.04, "extended": 0.02, "accumulate": 0.025, "downtrend": 0.015}   # of the whole portfolio
FIRST = {"buy_zone": 0.60, "extended": 0.30, "accumulate": 0.40, "downtrend": None}     # of what is left to buy
WAIT_DAYS = {"buy_zone": 30, "extended": 30, "accumulate": 30, "downtrend": 30}           # no level reached: buy anyway
MAX_BATCHES = 8
# the discount to the fair value sets the pace: the cheaper, the bigger the batches and the shorter the waits
# (the backtest showed the technical state alone does not tell good from bad moments; the discount is the edge)
PACE = [(0.40, 1.75), (0.25, 1.40), (0.10, 1.00), (0.0, 0.75), (-9, 0.50)]   # (discount at least, × batch)


def pace(discount):
    """× the batch size for a discount to the fair value (0.30 = 30% below it); 1.0 when it is not known."""
    if discount is None:
        return 1.0
    return next(m for d, m in PACE if discount >= d)
LEVEL_GAP_ATR = 0.75          # two levels closer than this are one
STATES = {
    "buy_zone": ("Buy zone", "Uptrend and not stretched: buy most of it now, the rest on a pullback"),
    "extended": ("Extended", "Uptrend but stretched (RSI or far above the 20-day average): a starter now, the "
                             "rest on pullbacks"),
    "accumulate": ("Accumulate", "No clear trend: buy in steps, at support levels or with time"),
    "downtrend": ("Downtrend", "Falling trend: small batches at support levels or every few weeks, never all "
                               "at once"),
}
# above the fair value the fundamentals decide, whatever the trend: no buying, except one small first batch
# when nothing is held yet; the rest only at levels under the fair value
GATE = {
    "starter": ("Starter only", "Above the fair value: at most one small first batch (you hold none); the rest "
                                "only under the fair value"),
    "wait": ("Wait", "Above the fair value: do not add; buy only if the price comes under the fair value"),
}
STARTER_SHARE = 0.5           # the first batch above the fair value: half a normal batch


def verdict(a, discount, held_value=0.0):
    """(key, label, meaning): the technical state below the fair value (or with none), else Wait / Starter only."""
    if discount is not None and discount < 0:
        k = "starter" if (held_value or 0) <= 0 else "wait"
        return (k,) + GATE[k]
    return a["state"], a["label"], a["meaning"]


# ---------- price history ----------------------------------------------------------------------------------------
def history(ticker, refresh=False):
    """[(date, open, high, low, close, volume)] daily, 10 years; kept 12 hours. [] when not available."""
    t = ticker.upper()
    f = os.path.join(CACHE_DIR, t.replace("^", "_") + ".json")
    try:
        with open(f, encoding="utf-8") as fh:
            c = json.load(fh)
    except (OSError, ValueError):
        c = {}
    if c.get("rows") and not refresh and time.time() - c.get("fetched", 0) < FRESH:
        return [tuple(r) for r in c["rows"]]
    from . import fundamentals as F
    try:
        r = F._chart(t, "range=10y&interval=1d")
        rows = [x for x in F._rows(r) if x[4]] if r else []
    except Exception:
        rows = []
    if rows:
        os.makedirs(CACHE_DIR, exist_ok=True)
        with open(f + ".tmp", "w", encoding="utf-8") as fh:
            json.dump({"fetched": time.time(), "rows": rows}, fh)
        os.replace(f + ".tmp", f)
        return rows
    return [tuple(r) for r in c.get("rows", [])]


def cached(ticker):
    """The kept daily history, however old ([] when none): for work that must not wait on the network."""
    f = os.path.join(CACHE_DIR, ticker.upper().replace("^", "_") + ".json")
    try:
        with open(f, encoding="utf-8") as fh:
            return [tuple(r) for r in json.load(fh).get("rows", [])]
    except (OSError, ValueError):
        return []


# ---------- indicators (plain lists; None until there is enough history) -----------------------------------------
def ema(xs, n):
    """Exponential average, started at the first value; None for the first n-1 days."""
    out, k, e = [], 2 / (n + 1), None
    for i, x in enumerate(xs):
        if x is not None:
            e = x if e is None else x * k + e * (1 - k)
        out.append(e if i >= n - 1 else None)
    return out


def sma(xs, n):
    out, run = [None] * len(xs), 0.0
    for k, x in enumerate(xs):
        run += x
        if k >= n:
            run -= xs[k - n]
        if k >= n - 1:
            out[k] = run / n
    return out


def rsi(xs, n=14):
    out = [None] * len(xs)
    if len(xs) <= n:
        return out
    gains = [max(xs[i] - xs[i - 1], 0) for i in range(1, n + 1)]
    losses = [max(xs[i - 1] - xs[i], 0) for i in range(1, n + 1)]
    ag, al = sum(gains) / n, sum(losses) / n
    out[n] = 100 - 100 / (1 + ag / al) if al else 100.0
    for i in range(n + 1, len(xs)):
        d = xs[i] - xs[i - 1]
        ag = (ag * (n - 1) + max(d, 0)) / n
        al = (al * (n - 1) + max(-d, 0)) / n
        out[i] = 100 - 100 / (1 + ag / al) if al else 100.0
    return out


def atr(hs, ls, cs, n=14):
    out = [None] * len(cs)
    trs = [hs[0] - ls[0]] + [max(hs[i] - ls[i], abs(hs[i] - cs[i - 1]), abs(ls[i] - cs[i - 1]))
                             for i in range(1, len(cs))]
    if len(cs) < n:
        return out
    a = sum(trs[:n]) / n
    out[n - 1] = a
    for i in range(n, len(cs)):
        a = (a * (n - 1) + trs[i]) / n
        out[i] = a
    return out


def weekly(rows):
    """Weekly closes: (last date of the week, close), weeks ending on their last trading day."""
    out, key = [], None
    for r in rows:
        y, w, _d = date.fromisoformat(r[0]).isocalendar()
        if (y, w) != key:
            out.append([r[0], r[4]])
            key = (y, w)
        else:
            out[-1] = [r[0], r[4]]
    return out


def swing_lows(lows, k=10, start=0, end=None):
    """Indexes of lows lower than the k bars on each side."""
    end = len(lows) if end is None else end
    out = []
    for i in range(max(start, k), end - k):
        x = lows[i]
        if all(x <= lows[j] for j in range(i - k, i + k + 1) if j != i):
            out.append(i)
    return out


def swing_highs(highs, k=10, start=0, end=None):
    end = len(highs) if end is None else end
    return [i for i in range(max(start, k), end - k)
            if all(highs[i] >= highs[j] for j in range(i - k, i + k + 1) if j != i)]


class Series:
    """Every indicator once for a price history, so analyze() at any day is cheap (the backtest asks often)."""
    def __init__(self, rows, spy_rows=None):
        self.rows = rows
        self.d = [r[0] for r in rows]
        self.h = [r[2] if r[2] is not None else r[4] for r in rows]
        self.l = [r[3] if r[3] is not None else r[4] for r in rows]
        self.c = [r[4] for r in rows]
        self.v = [r[5] or 0 for r in rows]
        self.e20, self.e50, self.e200 = ema(self.c, 20), ema(self.c, 50), ema(self.c, 200)
        self.sma20, self.sma50 = sma(self.c, 20), sma(self.c, 50)
        self.rsi = rsi(self.c)
        self.atr = atr(self.h, self.l, self.c)
        # Bollinger bands (20 days, 2 standard deviations)
        self.bb_up, self.bb_lo = [None] * len(self.c), [None] * len(self.c)
        for k in range(19, len(self.c)):
            w = self.c[k - 19:k + 1]
            mu = sum(w) / 20
            sd = (sum((x - mu) ** 2 for x in w) / 20) ** 0.5
            self.bb_up[k], self.bb_lo[k] = mu + 2 * sd, mu - 2 * sd
        # distance from the 50-day simple average, in 14-day ATRs: volatility-normalised stretch
        self.dist50 = [((c - m) / a) if m is not None and a else None
                       for c, m, a in zip(self.c, self.sma50, self.atr)]
        wk = weekly(rows)
        wr, we = rsi([x[1] for x in wk]), ema([x[1] for x in wk], 40)
        self.w_idx, j = [], 0                   # for each day: the last finished week's index
        for i, dd in enumerate(self.d):
            while j + 1 < len(wk) and wk[j + 1][0] <= dd:
                j += 1
            self.w_idx.append(j if wk and wk[j][0] <= dd else None)
        self.w_rsi, self.w_ema, self.w_close = wr, we, [x[1] for x in wk]
        obv, o = [], 0.0
        for i in range(len(self.c)):
            if i:
                o += self.v[i] if self.c[i] > self.c[i - 1] else -self.v[i] if self.c[i] < self.c[i - 1] else 0
            obv.append(o)
        self.obv = obv
        # MACD 12/26/9
        e12, e26 = ema(self.c, 12), ema(self.c, 26)
        self.macd = [a - b if a is not None and b is not None else None for a, b in zip(e12, e26)]
        first = next((k for k, x in enumerate(self.macd) if x is not None), len(self.c))
        sig = ema([x for x in self.macd[first:]], 9)
        self.macd_sig = [None] * first + sig
        # ADX 14 (Wilder): how strong the trend is, up or down
        n = 14
        self.adx = [None] * len(self.c)
        if len(self.c) > 3 * n:
            pdm, mdm, tr = [0.0], [0.0], [self.h[0] - self.l[0]]
            for k in range(1, len(self.c)):
                up, dn = self.h[k] - self.h[k - 1], self.l[k - 1] - self.l[k]
                pdm.append(up if up > dn and up > 0 else 0.0)
                mdm.append(dn if dn > up and dn > 0 else 0.0)
                tr.append(max(self.h[k] - self.l[k], abs(self.h[k] - self.c[k - 1]), abs(self.l[k] - self.c[k - 1])))
            atr_, p_, m_ = sum(tr[1:n + 1]), sum(pdm[1:n + 1]), sum(mdm[1:n + 1])
            dxs = []
            for k in range(n + 1, len(self.c)):
                atr_ = atr_ - atr_ / n + tr[k]
                p_ = p_ - p_ / n + pdm[k]
                m_ = m_ - m_ / n + mdm[k]
                pdi, mdi = (100 * p_ / atr_, 100 * m_ / atr_) if atr_ else (0, 0)
                dx = 100 * abs(pdi - mdi) / (pdi + mdi) if pdi + mdi else 0
                dxs.append(dx)
                if len(dxs) == n:
                    adx = sum(dxs) / n
                    self.adx[k] = adx
                elif len(dxs) > n:
                    adx = (adx * (n - 1) + dx) / n
                    self.adx[k] = adx
                if len(dxs) >= n:
                    self.adx[k] = (adx, pdi, mdi)
        self.spy = None
        if spy_rows:
            m = {r[0]: r[4] for r in spy_rows}
            self.spy = [m.get(x) for x in self.d]


def _vwap_from(s, i0, i):
    pv = vv = 0.0
    for j in range(i0, i + 1):
        tp = (s.h[j] + s.l[j] + s.c[j]) / 3
        pv += tp * s.v[j]
        vv += s.v[j]
    return pv / vv if vv else None


def analyze(s, i=None, earnings=None):
    """The technical reading at day i (default: the last). earnings: [ISO dates] of past earnings releases."""
    i = len(s.c) - 1 if i is None else i
    c, a = s.c[i], s.atr[i]
    e20, e50, e200 = s.e20[i], s.e50[i], s.e200[i]
    out = {"date": s.d[i], "price": c, "ema20": e20, "ema50": e50, "ema200": e200, "atr": a, "rsi": s.rsi[i]}
    if e200 is None or a is None or i < 240:
        out.update(state="accumulate", trend="neutral", short=True, reasons=["Less than a year of prices: no "
                                                                             "trend read, buy in steps"])
        out["levels"] = []
        return out
    sl200 = (e200 / s.e200[i - 40] - 1) if s.e200[i - 40] else 0
    wi = s.w_idx[i]
    w_close, w_ema, w_rsi = (s.w_close[wi], s.w_ema[wi], s.w_rsi[wi]) if wi is not None else (None, None, None)
    if c > e200 and e50 > e200 and sl200 >= 0:
        trend = "bull"
    elif c < e200 and e50 < e200 and sl200 < 0:
        trend = "bear"
    else:
        trend = "neutral"
    ext = (c - e20) / a if e20 else 0
    extended = (s.rsi[i] or 0) >= EXTENDED_RSI or (w_rsi or 0) >= EXTENDED_RSI_W or ext >= EXTENDED_ATR
    oversold = (s.rsi[i] or 100) <= OVERSOLD_RSI or (w_rsi or 100) <= OVERSOLD_RSI
    state = ("extended" if extended else "buy_zone") if trend == "bull" else \
        "downtrend" if trend == "bear" else "accumulate"
    # volume: up-day vs down-day volume, and OBV against price, over 50 days
    up = sum(s.v[j] for j in range(i - 49, i + 1) if s.c[j] > s.c[j - 1])
    dn = sum(s.v[j] for j in range(i - 49, i + 1) if s.c[j] < s.c[j - 1])
    udr = up / dn if dn else None
    obv_slope = (s.obv[i] - s.obv[i - 50]) / (sum(s.v[i - 49:i + 1]) or 1)
    # strength vs the S&P 500, 6 months
    rs = None
    if s.spy and s.spy[i] and s.spy[i - 126] and s.c[i - 126]:
        rs = (c / s.c[i - 126]) / (s.spy[i] / s.spy[i - 126]) - 1
    # levels below the price
    lv = []
    for j in swing_lows(s.l, 10, max(0, i - 260), i + 1):
        if s.l[j] < c:
            lv.append((s.l[j], "swing low " + s.d[j][:7]))
    for v, name in ((e50, "EMA 50"), (e200, "EMA 200")):
        if v and v < c:
            lv.append((v, name))
    last_e = max((x for x in (earnings or []) if x <= s.d[i]), default=None)
    if last_e and last_e in s.d:
        vw = _vwap_from(s, s.d.index(last_e), i)
        if vw and vw < c:
            lv.append((vw, "VWAP since the " + last_e + " results"))
    lo_i = min(range(max(0, i - 251), i + 1), key=lambda j: s.l[j])
    hi_i = max(range(lo_i, i + 1), key=lambda j: s.h[j])
    fib = None
    if hi_i > lo_i and s.h[hi_i] > s.l[lo_i] * 1.15:          # a real move up: retracements of it
        H, L = s.h[hi_i], s.l[lo_i]
        fib = {"high": H, "low": L, "from": s.d[lo_i], "to": s.d[hi_i]}
        for f in (0.382, 0.5, 0.618):
            v = H - (H - L) * f
            if v < c:
                lv.append((v, f"Fibonacci {f * 100:.1f}%"))
    lv.append((min(s.l[max(0, i - 251):i + 1]), "52-week low"))
    lv.sort(key=lambda x: -x[0])
    merged = []
    for v, name in lv:                         # levels within LEVEL_GAP_ATR of each other are one zone
        if merged and merged[-1][0] - v < LEVEL_GAP_ATR * a:
            merged[-1] = (merged[-1][0], merged[-1][1] + [name])
        else:
            merged.append((v, [name]))
    r = s.rsi[i]
    why = [f"Trend {trend}: price {'above' if c > e200 else 'below'} the 200-day average "
           f"({(c / e200 - 1) * 100:+.0f}%), which is {'rising' if sl200 >= 0 else 'falling'}"]
    if w_close and w_ema:
        why.append(f"Weekly: {'above' if w_close > w_ema else 'below'} the 40-week average")
    why.append(f"RSI {r:.0f} daily" + (f", {w_rsi:.0f} weekly" if w_rsi else "")
               + (" (stretched)" if extended else " (oversold)" if oversold else ""))
    why.append(f"{ext:+.1f} ATR from the 20-day average")
    if udr:
        why.append(f"Volume: {udr:.2f}× more on up days than down days (50 days)"
                   if udr >= 1 else f"Volume: more on down days ({1 / udr:.2f}×, 50 days): distribution")
    if rs is not None:
        why.append(f"vs S&P 500, 6 months: {rs * 100:+.0f}%")
    out.update(weekly_above=(w_close > w_ema) if w_close and w_ema else None, from_e200=c / e200 - 1)
    # more readings: MACD, ADX, Bollinger, the 52-week high, the last 50/200 cross, volatility
    m, sg = s.macd[i], s.macd_sig[i]
    if m is not None and sg is not None and s.macd[i - 5] is not None and s.macd_sig[i - 5] is not None:
        out["macd"] = {"hist": m - sg, "hist_5d": s.macd[i - 5] - s.macd_sig[i - 5], "above_zero": m > 0}
    if s.adx[i]:
        adx, pdi, mdi = s.adx[i]
        out["adx"] = {"adx": adx, "up": pdi > mdi}
    win = s.c[i - 19:i + 1]
    mu = sum(win) / 20
    sd = (sum((x - mu) ** 2 for x in win) / 20) ** 0.5
    out["boll_b"] = (c - (mu - 2 * sd)) / (4 * sd) if sd else None
    out["from_high"] = c / max(s.h[max(0, i - 251):i + 1]) - 1
    cross = None
    for k in range(i, max(201, i - 504), -1):
        if s.e50[k] is None or s.e200[k] is None or s.e50[k - 1] is None or s.e200[k - 1] is None:
            break
        if (s.e50[k] > s.e200[k]) != (s.e50[k - 1] > s.e200[k - 1]):
            cross = {"date": s.d[k], "golden": s.e50[k] > s.e200[k]}
            break
    out["cross"] = cross
    out["atr_pct"] = a / c
    past = [s.atr[k] / s.c[k] for k in range(max(0, i - 251), i + 1) if s.atr[k] and s.c[k]]
    out["atr_vs_year"] = (a / c) / sorted(past)[len(past) // 2] if past else None
    out["sma20"], out["sma50"] = s.sma20[i], s.sma50[i]
    out["dist50"] = s.dist50[i]
    if s.bb_up[i] is not None:
        out["bb"] = {"up": s.bb_up[i], "lo": s.bb_lo[i], "width": (s.bb_up[i] - s.bb_lo[i]) / ((s.bb_up[i] + s.bb_lo[i]) / 2)}
    if "macd" in out:                                  # the last MACD / signal cross, within 3 months
        for k in range(i, max(1, i - 63), -1):
            a1, b1, a0, b0 = s.macd[k], s.macd_sig[k], s.macd[k - 1], s.macd_sig[k - 1]
            if None in (a1, b1, a0, b0):
                break
            if (a1 > b1) != (a0 > b0):
                out["macd"]["cross"] = {"date": s.d[k], "bullish": a1 > b1, "days": i - k}
                break
    # key levels above the price: resistance (swing highs, the 52-week high, averages, retracements)
    rv = []
    for j in swing_highs(s.h, 10, max(0, i - 260), i + 1):
        if s.h[j] > c:
            rv.append((s.h[j], "swing high " + s.d[j][:7]))
    for v, name in ((e50, "EMA 50"), (e200, "EMA 200"), (s.sma50[i], "SMA 50")):
        if v and v > c:
            rv.append((v, name))
    if fib:
        for f in (0.382, 0.5, 0.618):
            v = fib["high"] - (fib["high"] - fib["low"]) * f
            if v > c:
                rv.append((v, f"Fibonacci {f * 100:.1f}%"))
    hi52 = max(s.h[max(0, i - 251):i + 1])
    if hi52 > c:
        rv.append((hi52, "52-week high"))
    rv.sort(key=lambda x: x[0])
    rmerged = []
    for v, name in rv:
        if rmerged and v - rmerged[-1][0] < LEVEL_GAP_ATR * a:
            rmerged[-1] = (rmerged[-1][0], rmerged[-1][1] + [name])
        else:
            rmerged.append((v, [name]))
    out["resistance"] = [{"price": v, "what": names} for v, names in rmerged[:5]]
    out.update(state=state, trend=trend, extended=extended, oversold=oversold, ext_atr=ext, rsi_w=w_rsi,
               slope200=sl200, updown=udr, obv=obv_slope, rs_spy=rs, fib=fib,
               levels=[{"price": v, "what": names} for v, names in merged[:8]], reasons=why,
               label=STATES[state][0], meaning=STATES[state][1])
    out["zones"] = volume_zones(s, max(0, i - 251), i + 1)            # the last year's high-volume zones
    mark_zones(out["levels"], out["zones"])
    mark_zones(out["resistance"], out["zones"])
    d50 = out.get("dist50")
    if d50 is not None and abs(d50) >= DIST50_STRETCHED:
        out["reasons"].append(f"{d50:+.1f} ATR from the 50-day average: "
                              + ("overextended up, a pause or pullback is common (unless a strong trend or a catalyst)"
                                 if d50 > 0 else "stretched down, a bounce toward the average is common"))
    return out


# ---------- how much, in how many steps, where ---------------------------------------------------------------------
def plan(a, target_weight, portfolio_value, held_value=0.0, cash_free=None, fx=1.0, today=None, discount=None):
    """The buying plan: [{step, when, price, amount, shares, why, days}], amounts in the portfolio's currency,
    shares at the stock's price ÷ fx (stock currency per portfolio currency unit). cash_free: what can be spent now
    without going under the cash floor (None: not limited). discount: below the fair value (0.30 = 30% below),
    sets the pace: bigger batches and shorter waits the cheaper it is."""
    today = today or date.today()
    st = a["state"]
    left = max(0.0, target_weight * portfolio_value - held_value)
    if left <= 0 or not a.get("price"):
        return {"left": left, "steps": [], "note": "Already at (or over) the target weight"}
    if discount is not None and discount < 0:
        return _plan_above(a, left, portfolio_value, held_value, fx, today, discount)
    m = pace(discount)
    batch = BATCH[st] * m * portfolio_value
    n = max(1, min(MAX_BATCHES, math.ceil(left / batch - 1e-9)))
    if FIRST[st] is not None and n > 1:
        first = max(left * FIRST[st], min(batch, left))
        amts = [first] + [(left - first) / (n - 1)] * (n - 1)
    else:
        amts = [left / n] * n
    levels = [lv for lv in a.get("levels") or [] if lv["price"] < a["price"] * 0.995]
    steps, wait = [], int(round(min(60, max(14, WAIT_DAYS[st] / m))))
    for k, amt in enumerate(amts):
        if k == 0:
            px, when, why = a["price"], "now", a["label"]
        elif k - 1 < len(levels):
            lv = levels[k - 1]
            px, when = lv["price"], f"at ${lv['price']:,.2f}, or in {wait * k} days if not reached"
            why = " + ".join(lv["what"])
        else:
            px, when, why = a["price"], f"in {wait * k} days, at the market", "time (no level left)"
        sh = math.floor(amt * fx / px) if px else 0
        steps.append({"step": k + 1, "when": when, "price": px, "amount": amt, "shares": sh, "why": why,
                      "date": (today + timedelta(days=wait * k)).isoformat(), "days": wait * k})
    out = {"left": left, "steps": steps, "batch": batch, "n": n, "pace": m, "wait": wait}
    if cash_free is not None and steps and steps[0]["amount"] > cash_free:
        out["note"] = (f"Step 1 needs {steps[0]['amount']:,.0f} but only {max(cash_free, 0):,.0f} can be spent "
                       f"without going under your cash floor")
    return out


def _plan_above(a, left, portfolio_value, held_value, fx, today, discount):
    """Price above the fair value: one small first batch now if nothing is held, then only at support levels
    under the fair value (no buying with time)."""
    px = a["price"]
    fv = px / (1 - discount)
    st = a["state"]
    steps = []
    if (held_value or 0) <= 0:
        amt = min(left, BATCH[st] * pace(discount) * STARTER_SHARE * portfolio_value)
        steps.append({"step": 1, "when": "now (a first position only)", "price": px, "amount": amt,
                      "shares": math.floor(amt * fx / px) if px else 0, "why": f"above the fair value ${fv:,.2f}: "
                      "starter only", "date": today.isoformat(), "days": 0})
        left -= amt
    for lv in [lv for lv in a.get("levels") or [] if lv["price"] <= fv and lv["price"] < px * 0.995]:
        if left <= 1e-9 or len(steps) >= MAX_BATCHES:
            break
        d = 1 - lv["price"] / fv
        amt = min(left, BATCH[st] * pace(d) * portfolio_value)
        steps.append({"step": len(steps) + 1, "when": f"at ${lv['price']:,.2f} (under the fair value)",
                      "price": lv["price"], "amount": amt, "shares": math.floor(amt * fx / lv["price"]),
                      "why": " + ".join(lv["what"]), "date": None, "days": None})
        left -= amt
    note = (f"Above the fair value (${fv:,.2f}): "
            + ("no buying with time; only at levels under the fair value" if steps else
               "nothing to buy until the price comes under it"))
    return {"left": left, "steps": steps, "batch": None, "n": len(steps), "pace": pace(discount), "wait": None,
            "note": note, "above": True}


def volume_zones(s, i0, i1=None, bins=60, keep=4):
    """High-volume zones (volume profile) over days i0..i1: each day's volume spread evenly over its low-high
    range, in price bins; bins with 1.5× the average volume or more, next to each other, make one zone. The
    biggest `keep` zones: [{lo, hi, share (of the period's volume), top (the busiest)}], low to high. Prices where
    many shares changed hands tend to act as support or resistance."""
    i1 = len(s.c) if i1 is None else i1
    lo = min(s.l[i] for i in range(i0, i1))
    hi = max(s.h[i] for i in range(i0, i1))
    if not hi > lo:
        return []
    w = (hi - lo) / bins
    vol = [0.0] * bins
    for i in range(i0, i1):
        a, b, v = s.l[i], s.h[i], s.v[i] or 0
        if v <= 0:
            continue
        ka, kb = min(bins - 1, int((a - lo) / w)), min(bins - 1, int((b - lo) / w))
        share = v / (kb - ka + 1)
        for k in range(ka, kb + 1):
            vol[k] += share
    tot = sum(vol) or 1.0
    avg = tot / bins
    zones, cur = [], None
    for k, x in enumerate(vol):
        if x >= 1.5 * avg:
            if cur and cur["k1"] == k - 1:
                cur["k1"], cur["v"] = k, cur["v"] + x
            else:
                cur = {"k0": k, "k1": k, "v": x}
                zones.append(cur)
        else:
            cur = None
    zones = sorted(zones, key=lambda z: -z["v"])[:keep]
    out = [{"lo": lo + z["k0"] * w, "hi": lo + (z["k1"] + 1) * w, "share": z["v"] / tot} for z in zones]
    if out:
        out[0]["top"] = True
    return sorted(out, key=lambda z: z["lo"])


def mark_zones(levels, zones):
    """Adds 'high-volume zone' to the reasons of the support levels that sit in one."""
    for lv in levels or []:
        if any(z["lo"] <= lv["price"] <= z["hi"] for z in zones) and "high-volume zone" not in lv["what"]:
            lv["what"] = list(lv["what"]) + ["high-volume zone"]
    return levels


def reading_rows(a):
    """The technical reading as rows: (name, value, what it means, tone 'good' | 'bad' | 'warn' | None); a value of
    None is a group heading. The PC's table and the phone's."""
    G, R, A, INK = "good", "bad", "warn", None
    r, rw, ext, udr, rs = a.get("rsi"), a.get("rsi_w"), a.get("ext_atr") or 0, a.get("updown"), a.get("rs_spy")
    rows = [("TREND", None, None, None),
            ("Trend (200 days)", {"bull": "Up", "bear": "Down", "neutral": "Mixed"}[a["trend"]],
             f"price {a['from_e200'] * 100:+.0f}% vs the 200-day average, which is "
             f"{'rising' if a['slope200'] >= 0 else 'falling'}", {"bull": G, "bear": R}.get(a["trend"], A)),
            ("Weekly trend", "Up" if a.get("weekly_above") else "Down", "price vs the 40-week average",
             G if a.get("weekly_above") else R)]
    cr = a.get("cross")
    if cr:
        rows.append(("50/200 cross", "Golden" if cr["golden"] else "Death",
                     f"the 50-day crossed {'above' if cr['golden'] else 'below'} the 200-day on {cr['date']}",
                     G if cr["golden"] else R))
    ad = a.get("adx")
    if ad:
        strength = "Strong" if ad["adx"] >= 25 else "Weak" if ad["adx"] < 20 else "Moderate"
        rows.append(("Trend strength (ADX)", f"{ad['adx']:.0f} · {strength}",
                     f"{'buyers' if ad['up'] else 'sellers'} in control · 25+ strong, under 20 no real trend",
                     (G if ad["up"] else R) if ad["adx"] >= 20 else INK))
    rows.append(("MOMENTUM", None, None, None))
    rows.append(("RSI 14 days", f"{r:.0f}", "the daily RSI: 70+ stretched (wait), 30- oversold (buying chance)",
                 R if (r or 0) >= 70 else G if (r or 100) <= 30 else INK))
    if rw:
        rows.append(("RSI 14 weeks", f"{rw:.0f}", "the same on weekly bars: the long-term view, slower to "
                                                  "turn (75+ stretched)", R if rw >= 75 else G if rw <= 30 else INK))
    mc = a.get("macd")
    if mc:
        turning = mc["hist"] > mc["hist_5d"]
        rows.append(("MACD (12/26/9)", ("Rising" if mc["hist"] > 0 else "Falling") + (", improving" if turning
                                                                                    else ", weakening"),
                     "momentum: the gap between the 12- and 26-day averages vs its 9-day signal; "
                     + ("above zero (the trend is up)" if mc.get("above_zero") else "below zero (the trend is down)"),
                     G if mc["hist"] > 0 else (A if turning else R)))
        x = mc.get("cross")
        if x:
            rows.append(("MACD signal", ("Bullish" if x["bullish"] else "Bearish") + " cross",
                         f"the MACD crossed {'above' if x['bullish'] else 'below'} its signal line on {x['date']} "
                         f"({x['days']} trading days ago)", G if x["bullish"] else R))
    rows.append(("PRICE", None, None, None))
    d50 = a.get("dist50")
    if d50 is not None:
        hot = DIST50_STRETCHED
        rows.append(("Distance to SMA 50", f"{d50:+.1f} ATR",
                     "the gap to the 50-day simple average in 14-day ATRs, so it compares across stocks and years: "
                     f"±{DIST50_WARN:g} stretched, ±{hot:g} overextended (a pause or mean reversion is common). In a "
                     "strong trend or after a catalyst it can stay high for long",
                     R if d50 >= hot else A if d50 >= DIST50_WARN else G if d50 <= -DIST50_WARN else INK))
    rows.append(("Stretch (20 days)", f"{ext:+.1f} ATR", "distance from the 20-day average in days' ranges "
                                                         "(3+ stretched)", R if ext >= 3 else G if ext <= -2 else INK))
    if a.get("sma20") and a.get("sma50"):
        p = a["price"]
        rows.append(("SMA 20 / SMA 50", f"{(p / a['sma20'] - 1) * 100:+.1f}% / {(p / a['sma50'] - 1) * 100:+.1f}%",
                     "the price against the 20- and 50-day simple averages: above both, the short-term trend is up",
                     G if p > a["sma20"] and p > a["sma50"] else R if p < a["sma20"] and p < a["sma50"] else INK))
    bb = a.get("boll_b")
    if bb is not None:
        rows.append(("Bollinger (20, 2)", f"{bb * 100:.0f}%", "where the price sits in its 20-day band: 0% the lower "
                                                             "edge (cheap short term), 100% the upper",
                     G if bb <= 0.1 else R if bb >= 0.95 else INK))
    if a.get("from_high") is not None:
        rows.append(("From 52-week high", f"{a['from_high'] * 100:+.0f}%", "how far under the year's top",
                     G if a["from_high"] <= -0.25 else INK))
    if a.get("atr_pct"):
        vy = a.get("atr_vs_year")
        rows.append(("ATR (14 days)", f"${a['atr']:,.2f} · {a['atr_pct'] * 100:.1f}%",
                     "a normal day's move (volatility): the bigger, the more room the steps need"
                     + (f"; {vy:.1f}× its usual level this year" if vy else ""),
                     A if vy and vy >= 1.4 else INK))
    bb = a.get("bb")
    if bb:
        rows.append(("Bollinger width", f"{bb['width'] * 100:.0f}%", "how wide the 20-day bands are vs the price: "
                     "narrow bands (a squeeze) often come before a big move", INK))
    rows.append(("KEY LEVELS", None, None, None))
    rs_ = (a.get("resistance") or [])[:1]
    if rs_:
        x = rs_[0]
        rows.append(("Nearest resistance", f"${x['price']:,.2f} · {(x['price'] / a['price'] - 1) * 100:+.1f}%",
                     " + ".join(x["what"]) + ": where sellers showed up before", A))
    sp_ = (a.get("levels") or [])[:1]
    if sp_:
        x = sp_[0]
        rows.append(("Nearest support", f"${x['price']:,.2f} · {(x['price'] / a['price'] - 1) * 100:+.1f}%",
                     " + ".join(x["what"]) + ": where buyers showed up before", G))
    rows.append(("FLOWS", None, None, None))
    if udr:
        rows.append(("Volume (50 days)", "Buying" if udr >= 1 else "Selling",
                     f"{max(udr, 1 / udr):.2f}× more volume on {'up' if udr >= 1 else 'down'} days",
                     G if udr >= 1.1 else R if udr <= 0.9 else INK))
    if rs is not None:
        rows.append(("vs S&P 500", f"{rs * 100:+.0f}%", "the last 6 months, relative", G if rs > 0.02 else R if rs < -0.02
                     else INK))
    return rows


# ---------- does it help? the backtest -------------------------------------------------------------------------
def _simulate(s, i0, earnings, horizon=126, target=0.10):
    """Buy 1.0 (money) for a 10% position by the plan from day i0; levels filled when the low reaches them, the
    time fallback at the close; whatever is left at i0+horizon bought at that close. → (avg cost, shares)"""
    a = analyze(s, i0, earnings)
    p = plan(a, target, 10.0, 0.0, today=date.fromisoformat(s.d[i0]))     # 10% of 10 = 1.0 to buy
    pend = [(st["price"], st["amount"], i0 + st["days"] * 5 // 7) for st in p["steps"]]
    sh = spent = 0.0
    px0, amt0, _ = pend.pop(0)
    sh += amt0 / s.c[i0]
    spent += amt0
    end = min(len(s.c) - 1, i0 + horizon)
    for j in range(i0 + 1, end + 1):
        keep = []
        for px, amt, due in pend:
            if s.l[j] <= px:                   # reached: at the level, or at the open when it opened below
                fill = px if s.h[j] >= px else (s.rows[j][1] or s.c[j])
                sh += amt / fill
                spent += amt
            elif j >= due:
                sh += amt / s.c[j]
                spent += amt
            else:
                keep.append((px, amt, due))
        pend = keep
        if not pend:
            break
    for px, amt, due in pend:
        sh += amt / s.c[end]
        spent += amt
    return spent / sh, sh, a["state"]


def backtest(tickers, progress=None, spy="SPY", earnings_of=None, step=21):
    """For each ticker, every month over 10 years (with a year of history before and after):
    - buying 1.0 all at once (lump), in 6 monthly parts (DCA), or by the plan (rule, up to 6 months);
      → average cost vs the lump, and the value a year later;
    - the state that day and the return 3, 6 and 12 months later (and the worst drop in the next 6 months).
    Returns {by_method, by_state, n, tickers, per_ticker}."""
    say = progress or (lambda _m: None)
    sp = history(spy)
    rows_m, rows_s, per = [], [], {}
    for n, t in enumerate(tickers, 1):
        say(f"Backtest: {t} ({n} of {len(tickers)})")
        rows = history(t)
        if len(rows) < 600:
            continue
        s = Series(rows, sp)
        earn = (earnings_of or (lambda _t: []))(t)
        tm = []
        for i0 in range(260, len(s.c) - 253, step):
            c0, c1 = s.c[i0], s.c[i0 + 252]
            lump = c1 / c0
            dca_sh = sum((1 / 6) / s.c[min(i0 + 21 * k, len(s.c) - 1)] for k in range(6))
            dca = dca_sh * c1
            cost, sh, st = _simulate(s, i0, earn)
            rule = sh * c1
            low = min(s.l[i0:i0 + 127])
            row = {"t": t, "d": s.d[i0], "state": st, "lump": lump, "dca": dca, "rule": rule,
                   "lump_dd": low / c0 - 1, "rule_dd": low / cost - 1,
                   "cost_vs_lump": cost / c0 - 1, "cost_vs_dca": cost / (1 / dca_sh) - 1}
            rows_m.append(row)
            tm.append(row)
            f3, f6 = s.c[i0 + 63] / c0 - 1, s.c[i0 + 126] / c0 - 1
            dd = min(s.l[i0:i0 + 127]) / c0 - 1
            rows_s.append({"t": t, "state": st, "r3": f3, "r6": f6, "r12": lump - 1, "dd6": dd})
        if tm:
            per[t] = {k: _mean([r[k] for r in tm]) for k in ("lump", "dca", "rule", "cost_vs_lump", "cost_vs_dca")}
            per[t]["n"] = len(tm)

    def summ(rs, keys):
        return {k: {"mean": _mean([r[k] for r in rs]), "median": _median([r[k] for r in rs]),
                    "p10": _pct([r[k] for r in rs], 0.10)} for k in keys} | {"n": len(rs)}
    by_method = summ(rows_m, ("lump", "dca", "rule", "cost_vs_lump", "cost_vs_dca", "lump_dd", "rule_dd"))
    by_method["rule_beats_lump"] = _mean([1.0 if r["rule"] > r["lump"] else 0.0 for r in rows_m])
    by_method["rule_beats_dca"] = _mean([1.0 if r["rule"] > r["dca"] else 0.0 for r in rows_m])
    by_state = {}
    for st in list(STATES) + ["all"]:
        rs = [r for r in rows_s if st == "all" or r["state"] == st]
        if rs:
            by_state[st] = summ(rs, ("r3", "r6", "r12", "dd6"))
    by_state_method = {}
    for st in STATES:
        rs = [r for r in rows_m if r["state"] == st]
        if rs:
            by_state_method[st] = summ(rs, ("lump", "dca", "rule", "cost_vs_lump"))
    return {"by_method": by_method, "by_state": by_state, "by_state_method": by_state_method,
            "n": len(rows_m), "tickers": sorted(per), "per_ticker": per,
            "rules": {"BATCH": BATCH, "FIRST": FIRST, "WAIT_DAYS": WAIT_DAYS, "EXTENDED_RSI": EXTENDED_RSI,
                      "EXTENDED_ATR": EXTENDED_ATR}, "run": datetime.now(timezone.utc).isoformat()[:16]}


def _mean(xs):
    xs = [x for x in xs if x is not None]
    return sum(xs) / len(xs) if xs else None


def _pct(xs, q):
    xs = sorted(x for x in xs if x is not None)
    if not xs:
        return None
    return xs[min(len(xs) - 1, int(q * len(xs)))]


def _median(xs):
    xs = sorted(x for x in xs if x is not None)
    if not xs:
        return None
    m = len(xs) // 2
    return xs[m] if len(xs) % 2 else (xs[m - 1] + xs[m]) / 2


def save_backtest(res):
    f = os.path.join(CACHE_DIR, "backtest.json")
    os.makedirs(CACHE_DIR, exist_ok=True)
    with open(f, "w", encoding="utf-8") as fh:
        json.dump(res, fh, indent=1)
    return f
