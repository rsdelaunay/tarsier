"""One company, end to end: SEC data -> every gradable quarter -> its folder."""
import json
from datetime import datetime
import os

from . import (edgar, excel, metrics, model_xlsx, paths, peers, prelim, presentation, profile, projection,
               report, scorecard, xbrl)

QUARTERS_KEPT = 8   # how many recent quarters are graded and kept in the history


def _m(x):
    return None if x is None else round(x / 1e6, 1)


def _r(x, n=1):
    return None if x is None else round(x, n)


def engine_inputs(row, watch, past_beats, prev_row=None):
    row = row or {}
    change = (row.get("fy_guidance_change") or "")
    change = str(change).strip().lower() or None
    return {
        "industry_group": watch.get("industry_group"),
        "company_type": (watch.get("company_type") or "auto").lower(),
        "organic_revenue_yoy_pct": row.get("organic_revenue_yoy_pct"),
        "organic_revenue_yoy_pct_prev_quarter": (prev_row or {}).get("organic_revenue_yoy_pct"),
        "consensus": {"revenue_musd": row.get("consensus_revenue_musd"),
                      "eps_gaap": row.get("consensus_eps_gaap"),
                      "eps_nongaap": row.get("consensus_eps_nongaap")},
        "guidance_for_this_quarter": {"revenue_low_musd": row.get("guidance_low_musd"),
                                      "revenue_high_musd": row.get("guidance_high_musd"),
                                      "revenue_mid_musd": row.get("guidance_mid_musd")},
        "past_beats_vs_guidance_pct": past_beats,
        "full_year_guidance": {"change": change, "detail": row.get("fy_guidance_detail")},
        "eps_nongaap": {"cur": row.get("eps_nongaap"), "prior": row.get("eps_nongaap_prior_year")},
        "peer_median_dilution_pct": row.get("peer_median_dilution_pct"),
    }


def _guide_mid(row):
    if not row:
        return None
    if row.get("guidance_mid_musd"):
        return row["guidance_mid_musd"]
    lo, hi = row.get("guidance_low_musd"), row.get("guidance_high_musd")
    return (lo + hi) / 2 if lo and hi else None


def past_beats(co, rows, end, ends):
    """The company's habit: revenue beat vs guidance midpoint in up to 4 earlier quarters."""
    out = []
    for e in [x for x in ends if x < end][-4:]:
        mid, rev = _guide_mid(rows.get(e)), co.v("revenue", e)
        if mid and rev:
            out.append((rev / 1e6 - mid) / mid * 100)
    return out


def _part(g, block, pid):
    for p in g["blocks"][block]["parts"]:
        if p["id"] == pid:
            return p
    return {}


def grade_row(m, g):
    r, e, c, mg, b, d, s = (m["revenue"], m["eps"], m["cash"], m["margins"], m["balance"],
                            m["dilution"], m["sbc"])
    blk = {k: _r(v["score"], 0) for k, v in g["blocks"].items()}
    dbt, ast = m["debt"], m["assets"]
    return {
        "period_end": m["period"]["end"], "quarter": m["period"]["label"],
        "grade": g["grade"], "score": _r(g["score"]), "provisional": "yes" if g["provisional"] else None,
        "growth": blk["growth"], "profitability": blk["profitability"], "cash": blk["cash"],
        "balance": blk["balance"], "execution": blk["execution"],
        "company_type": g["company_type"], "industry_group": g["industry_group"],
        "revenue_musd": _m(r["cur"]), "revenue_yoy_pct": _r(r["yoy_pct"]),
        "organic_yoy_pct": _r(r["organic_yoy_pct"]), "revenue_yoy_prev_q_pct": _r(r["yoy_pct_prev_quarter"]),
        "beat_vs_guidance_pct": _r(_part(g, "execution", "rev_vs_guidance").get("value")),
        "beat_vs_consensus_pct": _r(_part(g, "execution", "rev_vs_consensus").get("value")),
        "fy_guidance": _part(g, "execution", "guidance").get("value"),
        "gross_margin_pct": _r(mg["gross"]["cur"]), "gross_margin_pp": _r(mg["gross"]["pp"]),
        "operating_margin_pct": _r(mg["operating"]["cur"]), "operating_margin_pp": _r(mg["operating"]["pp"]),
        "net_margin_pct": _r(mg["net"]["cur"]), "net_margin_pp": _r(mg["net"]["pp"]),
        "eps_gaap": _r(e["gaap_cur"], 2), "eps_gaap_prior_year": _r(e["gaap_prior"], 2),
        "eps_change": e["classification"], "eps_nongaap": e["nongaap_cur"],
        "fcf_musd": _m(c["fcf_cur"]), "fcf_margin_pct": _r(c["fcf_margin_cur"]),
        "fcf_margin_pp": _r(c["fcf_margin_pp"]), "fcf_after_sbc_margin_pct": _r(c["fcf_after_sbc_margin"]),
        "fcf_margin_ttm_pct": _r(c["fcf_margin_ttm"]),
        "fcf_ttm_musd": _m(m["fcf"]["ttm"]), "fcf_ttm_growth_pct": _r(m["fcf"]["growth_pct"]),
        "fcf_after_sbc_ttm_musd": _m(m["fcf"]["after_sbc_ttm"]),
        "buybacks_ttm_musd": _m(m["fcf"]["uses"]["buybacks"]), "dividends_ttm_musd": _m(m["fcf"]["uses"]["dividends"]),
        "acquisitions_ttm_musd": _m(m["fcf"]["uses"]["acquisitions"]),
        "sbc_pct_revenue": _r(s["pct_rev_cur"]), "sbc_pp_yoy": _r(s["pp_yoy"]),
        "rule_of_40": _r(m["rule_of_40"]) if g["industry_group"] == "Software" and not g["asset_heavy"] else None,
        "net_cash_musd": _m(b["net_cash"]), "debt_musd": _m(dbt["total"]),
        "debt_yoy_pct": _r(dbt["yoy_pct"]), "net_debt_to_ebitda": _r(dbt["net_debt_to_ebitda"], 2),
        "interest_musd": _m(dbt["interest_q"]), "avg_interest_rate_pct": _r(dbt["avg_rate_pct"], 2),
        "interest_pct_revenue": _r(dbt["interest_pct_revenue"], 2), "interest_cover_x": _r(dbt["interest_cover"]),
        "debt_due_soon_musd": _m(dbt["near_term"]), "cash_cover_of_debt_due_x": _r(dbt["near_term_cover"]),
        "avg_debt_maturity_years": _r(dbt["avg_maturity_years"]),
        "ppe_net_musd": _m(ast["ppe_net"]), "ppe_pct_ttm_revenue": _r(ast["intensity_pct"]),
        "capex_pct_revenue": _r(ast["capex_pct_revenue"]), "da_pct_revenue": _r(ast["da_pct_revenue"]),
        "ebitda_margin_pct": _r(ast["ebitda_margin"]), "asset_heavy": "yes" if ast["asset_heavy"] else "no",
        "basic_shares_yoy_pct": _r(d["yoy_pct"]),
        "house_rules": "; ".join(g["house_rules_applied"]) or None,
        "data_gaps": "; ".join(g["warnings"]) or None,
        "questions": len(m["questions"]),
        "source": f"{m['period']['form']} filed {m['period']['filed']}",
        "method_version": g["method_version"],
    }


def headline(m):
    """One line of key facts for the window."""
    r, mg, c, d = m["revenue"], m["margins"], m["cash"], m["debt"]
    bits = []
    if r["yoy_pct"] is not None:
        bits.append(f"Revenue {r['yoy_pct']:+.1f}%")
    if mg["operating"]["cur"] is not None:
        bits.append(f"operating margin {mg['operating']['cur']:.1f}%")
    if c["fcf_margin_cur"] is not None:
        bits.append(f"FCF margin {c['fcf_margin_cur']:.1f}%")
    if d["net_cash"] is not None:
        bits.append(f"net {'cash' if d['net_cash'] >= 0 else 'debt'} ${abs(d['net_cash']) / 1e6:,.0f}M")
    if d["total"]:
        debt = f"debt ${d['total'] / 1e6:,.0f}M"
        if d["avg_rate_pct"] is not None:
            debt += f" at ~{d['avg_rate_pct']:.1f}%"
        bits.append(debt)
    if m["assets"]["asset_heavy"]:
        bits.append("asset-heavy")
    return "  ·  ".join(bits)


def fcf_card(m):
    """Free cash flow facts for the window, in $M and %."""
    f = m["fcf"]
    sh = m["cur"].get("shares_diluted") or m["cur"].get("shares_basic")
    return {"ttm": _m(f["ttm"]), "ttm_prior": _m(f["ttm_prior"]), "growth_pct": f["growth_pct"],
            "margin_ttm": f["margin_ttm"], "margin_pp": f["margin_pp"],
            "after_sbc_ttm": _m(f["after_sbc_ttm"]), "after_sbc_margin_ttm": f["after_sbc_margin_ttm"],
            "cfo_ttm": _m(f["cfo_ttm"]), "capex_ttm": _m(f["capex_ttm"]), "sbc_ttm": _m(f["sbc_ttm"]),
            "uses": {k: _m(v) for k, v in f["uses"].items()}, "verdict": f["verdict"], "points": f.get("points"),
            "shares_m": None if not sh else sh / 1e6, "net_cash": _m(m["debt"]["net_cash"])}


def statement_rows(m, g):
    circled = set(g["circled"])
    return [{"period_end": m["period"]["end"], "quarter": m["period"]["label"], "line": ln["name"],
             "same_q_last_year_musd": _m(ln["prior"]), "this_q_musd": _m(ln["cur"]),
             "yoy_pct": _r(ln["yoy_pct"]), "sign_flip": "yes" if ln["sign_flip"] else None,
             "pct_rev_last_year": _r(ln["pct_rev_prior"]), "pct_rev_this_q": _r(ln["pct_rev_cur"]),
             "pp_change": _r(ln["pp"]),
             "good_bad": None if ln["good"] is None else ("good" if ln["good"] else "bad"),
             "circled": "yes" if ln["key"] in circled else None}
            for ln in m["statement"] if ln["cur"] is not None or ln["prior"] is not None]


def scorecard_rows(m, g):
    out = []
    for k, b in g["blocks"].items():
        for p in b["parts"]:
            v = p["value"]
            if p["id"] == "net_debt":
                v = _m(v)
            out.append({"period_end": m["period"]["end"], "quarter": m["period"]["label"], "block": k,
                        "block_score": _r(b["score"], 0), "block_weight": g["weights"][k],
                        "item": p["label"], "value": _r(v) if isinstance(v, float) else v,
                        "points": _r(p["points"], 0), "item_weight": p["weight"], "note": p["note"]})
    return out


def run(ticker, watch, offline=False, seed_inputs=None):
    t = ticker.upper()
    facts, subs, status = edgar.update(t, offline)
    co = metrics.Company(facts)
    press = prelim.state(t, co, subs, offline)          # results day: a press-release quarter, if any
    ends = co.quarter_ends()
    gradable = [e for e in ends if xbrl.find_end(ends, e, 364, 12)][-QUARTERS_KEPT:]
    if not gradable:
        forms = set((subs or {}).get("filings", {}).get("recent", {}).get("form", []))
        if forms & {"20-F", "40-F", "6-K"} and not forms & {"10-Q", "10-K"}:
            raise RuntimeError(f"{t} is a foreign filer (20-F / 6-K): the SEC has no quarterly data for it, "
                               "so it cannot be graded yet.")
        raise RuntimeError(f"{t}: fewer than five quarters of SEC data, so there is no same quarter last year "
                           "to compare with.")
    folder = paths.company_dir(t)
    if not offline:                        # a fresh check at the SEC brings every quarter back
        set_hidden(t, [])
    else:
        hide = set(hidden(t))
        shown = [e for e in gradable if e not in hide]
        gradable = shown or gradable
    labels = {e: co.label(e) for e in gradable}

    inputs_path = os.path.join(folder, f"{t}_inputs.xlsx")
    grades_path = os.path.join(folder, f"{t}_report.xlsx")
    pre = press.get("prelim") or {}
    pre_end = pre.get("period_end") if press["mode"] == "preliminary" else None
    if press["mode"] == "superseded":       # what you typed on results day moves to the exact 10-Q date
        excel.rename_period(inputs_path, pre["period_end"], pre["superseded"]["sec_end"])
    seed = dict(seed_inputs or {})
    if pre_end and pre.get("adjusted_eps") is not None:
        seed.setdefault(pre_end, {}).setdefault("eps_nongaap", pre["adjusted_eps"])
    stale = [e for e in excel.read_inputs(inputs_path) if e > gradable[-1]]   # e.g. a removed press-release quarter
    excel.drop_empty_periods(inputs_path, stale)
    rows = excel.ensure_inputs(inputs_path, [(e, labels[e]) for e in gradable], seed)

    name = facts.get("entityName") or t
    previous = {}
    if os.path.exists(grades_path):
        for r in excel._read_rows(grades_path, "Grades"):
            previous[str(r.get("period_end"))[:10]] = r.get("grade")

    grades, stmt, score, quest, results, quarters = [], [], [], [], [], []
    for e in gradable:
        inp = engine_inputs(rows.get(e), watch, past_beats(co, rows, e, gradable),
                            rows.get(co.previous(e)))
        m = metrics.build(co, e, inp)
        if m.get("error"):
            continue
        g = scorecard.grade(m, inp, subs.get("sic"))
        report.write_quarter(t, name, m, g, os.path.join(folder, "reports"))
        quarters.append((m, g))
        grades.append(grade_row(m, g))
        stmt += statement_rows(m, g)
        score += scorecard_rows(m, g)
        quest += [{"period_end": e, "quarter": m["period"]["label"], "done": None, "question": q}
                  for q in m["questions"]]
        results.append({"end": e, "label": m["period"]["label"], "grade": g["grade"], "score": g["score"],
                        "new": e not in previous, "changed": e in previous and previous[e] != g["grade"],
                        "was": previous.get(e), "gaps": g["warnings"],
                        "blocks": {k: b["score"] for k, b in g["blocks"].items()},
                        "provisional": g["provisional"], "unsupported": g["unsupported"],
                        "preliminary": e == pre_end, "headline": headline(m),
                        "house_rules": "; ".join(g["house_rules_applied"]) or None, "fcf": fcf_card(m),
                        "holder_risks": m["holder_risks"],
                        "weights": g["weights"], "company_type": g["company_type"], "asset_heavy": g["asset_heavy"],
                        "parts": {k: [{x: p[x] for x in ("id", "label", "value", "points", "weight", "note",
                                                         "applies")} for p in b["parts"]]
                                  for k, b in g["blocks"].items()},
                        "execution": {p["id"]: p["points"] is not None
                                      for p in g["blocks"]["execution"]["parts"]}})
    by_end = {r["end"]: r["grade"] for r in results}
    if pre_end and pre.get("grade") != by_end.get(pre_end):
        pre["grade"] = by_end.get(pre_end)
        prelim.save(t, pre)
    if press["mode"] == "superseded" and pre["superseded"].get("grade_now") is None:
        pre["superseded"]["grade_now"] = by_end.get(pre["superseded"]["sec_end"])
        prelim.save(t, pre)
    newest_first = lambda L: sorted(L, key=lambda r: r["period_end"], reverse=True)
    profile_path = os.path.join(folder, f"{t}_profile.json")
    prof = None
    if quarters:
        m_, g_ = quarters[-1]
        pdata = profile.load(profile_path)
        pauto = profile.auto_facts(subs, co, m_, g_)
        prof = {"path": profile_path, "data": pdata, "auto": pauto}
        try:
            cached_peers = peers.load(t, offline=True)      # never downloads here: the window does that
        except Exception:
            cached_peers = None
        profile_rows = profile.table_rows(pdata, pauto, profile.score(pdata, pauto, cached_peers))
    if quarters:
        presentation.write(grades_path, t, name, quarters,
                           [("Grades", newest_first(grades)), ("Statement", newest_first(stmt)),
                            ("Scorecard", newest_first(score)), ("ToExplain", newest_first(quest)),
                            ("Profile", profile_rows)])
    model_path = os.path.join(folder, f"{t}_model.xlsx")
    proj, proj_error = None, None
    if quarters:
        m, g = quarters[-1]
        try:
            hist = projection.history(co, facts, m, g, rows.get(m["period"]["end"]), ticker=t)
            user = model_xlsx.read_user(model_path)
            model_xlsx.write(model_path, hist, user, t, name)
            hist["ticker"], hist["name"] = t, name
            proj = {"hist": hist, "user": user}
        except excel.FileOpenError:
            raise
        except RuntimeError as e:
            proj_error = str(e)
    return {"ticker": t, "name": name, "status": status, "results": results, "folder": folder,
            "inputs_path": inputs_path, "report_path": grades_path, "model_path": model_path,
            "projection": proj, "projection_error": proj_error, "profile": prof, "press": press,
            "company": co}


def hidden(ticker):
    """Quarters you removed from the list; they come back with the next check at the SEC."""
    p = os.path.join(paths.COMPANIES, ticker.upper(), f"{ticker.upper()}_hidden.json")
    try:
        with open(p, encoding="utf-8") as f:
            return list(json.load(f))
    except (OSError, ValueError):
        return []


def set_hidden(ticker, ends):
    p = os.path.join(paths.COMPANIES, ticker.upper(), f"{ticker.upper()}_hidden.json")
    if not ends and not os.path.exists(p):
        return
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(sorted(set(ends)), f)


def _quick_path(ticker):
    return os.path.join(paths.COMPANIES, ticker.upper(), f"{ticker.upper()}_quick.json")


def quick(ticker):
    """A company graded automatically (from Compare, or looked up on the phone) that you have not analysed yet:
    {"source": "compare" | "phone", "at": date}, or None."""
    try:
        with open(_quick_path(ticker), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def mark_quick(ticker, source):
    p = _quick_path(ticker)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump({"source": source, "at": datetime.now().strftime("%Y-%m-%d %H:%M")}, f)


def clear_quick(ticker):
    """You opened it and graded it yourself on the Companies page: it is analysed now."""
    try:
        os.remove(_quick_path(ticker))
    except OSError:
        pass


def save_projection(out, user):
    """Called by the window: write what you typed into TICKER_model.xlsx."""
    p = out["projection"]
    model_xlsx.write(out["model_path"], p["hist"], user, out["ticker"], out["name"])
    p["user"] = user
