"""Debt and assets: how much, how expensive, when it falls due, and what stands behind it.

Why it matters: a company that borrows to buy assets that wear out (data centres, GPUs,
fleets) can show soaring revenue and falling EPS at the same time, because depreciation
and interest arrive before the revenue does. The grade has to see the difference between
that and a company that is simply losing money.
"""
from . import rules as R

M = 1e6


def pct(cur, prior):
    if cur is None or prior in (None, 0):
        return None
    return (cur - prior) / abs(prior) * 100


def share(x, base):
    return None if x is None or not base else x / base * 100


def _fmt(x):
    return "n/a" if x is None else ("−" if x < 0 else "") + f"${abs(x) / M:,.1f}M"


def _quarter_number(label):
    try:
        return int(label.split("Q")[-1])
    except (ValueError, AttributeError):
        return None


def _fiscal_year(label):
    try:
        return int(label.split()[0].replace("FY", ""))
    except (ValueError, AttributeError, IndexError):
        return None


def _schedule(co, end, label, principal):
    """Maturity ladder from the debt note: [(label, amount, years from now to the midpoint)]."""
    q, fy = _quarter_number(label), _fiscal_year(label)
    rem_years = 0.0 if q in (None, 4) else (4 - q) * 0.25
    first_fy = None if fy is None else (fy + 1 if q == 4 else fy)
    rows, k_last = [], 0
    rem = co.iv("mat_rem", end)
    if rem is not None and rem_years > 0:
        rows.append((f"rest of FY{first_fy}" if first_fy else "rest of this year", rem, rem_years / 2))
    for k in range(1, 6):
        v = co.iv(f"mat_y{k}", end)
        if v is None:
            continue
        year = None if first_fy is None else first_fy + k - (0 if rem_years > 0 else 1)
        rows.append((f"FY{year}" if year else f"year {k}", v, rem_years + k - 0.5))
        k_last = k
    after = co.iv("mat_after", end)
    if after is not None:
        rows.append(("after 5 years", after, rem_years + 5.5))
        k_last = 6
    if rows and principal:
        left = principal - sum(a for _, a, _ in rows)
        if left > 0.02 * principal:      # buckets the filing did not tag: everything later
            rows.append(("later years", left, rem_years + k_last + 0.5))
    near = None
    if rows:
        near = (rem or 0) * (1 if rem_years > 0 else 0) + (co.iv("mat_y1", end) or 0)
    total = sum(a for _, a, _ in rows)
    avg = sum(a * y for _, a, y in rows) / total if total else None
    return rows, near, int(round(rem_years * 12)) + 12, avg


def build(co, end, py_end, pq_end, m):
    cur, prior = m["cur"], m["prior"]
    pq = co.snapshot(pq_end) or {}
    rev, rev_p = cur["revenue"], prior["revenue"]
    rev_ttm = m["revenue"]["ttm"]
    debt, debt_p, debt_pq = cur["debt"], prior.get("debt"), pq.get("debt")
    liquid = None if cur["cash"] is None else cur["cash"] + (cur["st_investments"] or 0)

    ebitda_ttm = co.ttm("ebitda", end)
    ebitda_annual = ebitda_ttm if ebitda_ttm is not None else (None if cur["ebitda"] is None else cur["ebitda"] * 4)
    net_cash = cur["net_cash"]
    nd_ebitda = None
    if net_cash is not None and net_cash < 0 and ebitda_annual and ebitda_annual > 0:
        nd_ebitda = -net_cash / ebitda_annual

    # --- cost of the debt
    i_q, i_p = cur["interest_expense"], prior.get("interest_expense")
    i_ttm = co.ttm("interest_expense", end)
    avg_debt = None if debt is None else (debt + debt_pq) / 2 if debt_pq is not None else debt
    avg_debt_p = prior.get("debt")
    rate = i_q * 4 / avg_debt * 100 if i_q and i_q > 0 and avg_debt else None
    rate_p = i_p * 4 / avg_debt_p * 100 if i_p and i_p > 0 and avg_debt_p else None
    cover = None
    if i_ttm and i_ttm > 0 and ebitda_ttm is not None:
        cover, cover_basis = ebitda_ttm / i_ttm, "last 12 months"
    elif i_q and i_q > 0 and cur["ebitda"] is not None:
        cover, cover_basis = cur["ebitda"] / i_q, "this quarter"
    else:
        cover_basis = None
    disclosed = [(e, r["val"]) for e, r in co.disclosed_rate.items() if e <= end]
    disclosed_rate = max(disclosed)[1] * 100 if disclosed else None

    # --- when it falls due
    principal = cur.get("debt_principal") or cur.get("debt_long")
    rows, near, near_months, avg_maturity = _schedule(co, end, m["period"]["label"], principal)
    if near is None and (cur.get("debt_current") is not None or cur.get("st_borrowings") is not None):
        near, near_months = (cur.get("debt_current") or 0), 12
    if near is not None:
        near += cur.get("st_borrowings") or 0
    near_cover = None if near is None or liquid is None else (liquid / near if near > 0 else None)

    d = {
        "total": debt, "total_prior_year": debt_p, "total_prev_quarter": debt_pq,
        "yoy_pct": pct(debt, debt_p) if debt and debt_p else None,
        "long_term": cur.get("debt_long"), "st_borrowings": cur.get("st_borrowings"),
        "finance_leases": cur.get("finance_leases"), "secured": cur.get("secured_debt"),
        "liquid": liquid, "net_cash": net_cash, "net_cash_prior_year": prior.get("net_cash"),
        "ebitda_ttm": ebitda_ttm, "net_debt_to_ebitda": nd_ebitda,
        "pct_revenue_ttm": share(debt, rev_ttm),
        "interest_q": i_q, "interest_prior": i_p, "interest_ttm": i_ttm,
        "avg_rate_pct": rate, "avg_rate_prior_pct": rate_p, "disclosed_rate_pct": disclosed_rate,
        "interest_pct_revenue": share(i_q, rev) if i_q is not None else None,
        "interest_pct_revenue_prior": share(i_p, rev_p) if i_p is not None else None,
        "interest_cover": cover, "interest_cover_basis": cover_basis,
        "interest_capitalized": cur.get("interest_capitalized"),
        "interest_paid_ytd": co.ytd["interest_paid"].get(end),
        "schedule": [(lab, amt) for lab, amt, _ in rows], "avg_maturity_years": avg_maturity,
        "near_term": near, "near_term_months": near_months, "near_term_cover": near_cover,
        "issued_ytd": sum(co.ytd[k].get(end) or 0 for k in ("debt_issued", "credit_drawn", "convert_issued")) or None,
        "repaid_ytd": sum(co.ytd[k].get(end) or 0 for k in ("debt_repaid", "credit_repaid")) or None,
    }
    rev_yoy = m["revenue"]["yoy_pct"]
    d["revenue_minus_debt_growth_pp"] = (None if rev_yoy is None or d["yoy_pct"] is None
                                         else rev_yoy - d["yoy_pct"])
    d["material"] = bool(debt and d["pct_revenue_ttm"] is not None
                         and d["pct_revenue_ttm"] >= R.DEBT_MATERIAL_PCT_OF_REVENUE)

    # --- what stands behind it
    ppe, ppe_p = cur.get("ppe_net"), prior.get("ppe_net")
    da, da_p = cur.get("da"), prior.get("da")
    dep = cur.get("depreciation") if cur.get("depreciation") is not None else da
    capex_ttm = co.ttm("capex", end)
    soft = (cur.get("goodwill") or 0) + (cur.get("intangibles") or 0)
    e_c, e_p = share(cur.get("ebitda"), rev), share(prior.get("ebitda"), rev_p)
    o_c = m["margins"]["operating"]["cur"]
    a = {
        "ppe_net": ppe, "ppe_net_prior": ppe_p, "ppe_yoy_pct": pct(ppe, ppe_p) if ppe and ppe_p else None,
        "ppe_gross": cur.get("ppe_gross"), "total_assets": cur.get("total_assets"),
        "goodwill_intangibles": soft or None,
        "goodwill_intangibles_pct_assets": share(soft, cur.get("total_assets")) if soft else None,
        "intensity_pct": share(ppe, rev_ttm),
        "capex_q": cur.get("capex"), "capex_pct_revenue": share(cur.get("capex"), rev),
        "capex_ttm_pct_revenue": share(capex_ttm, rev_ttm),
        "da_q": da, "da_prior": da_p, "da_yoy_pct": pct(da, da_p) if da and da_p else None,
        "da_pct_revenue": share(da, rev), "da_pct_revenue_prior": share(da_p, rev_p),
        "depreciation_q": dep,
        # capex against depreciation of what the company owns (amortisation of acquired intangibles left out)
        "capex_to_depreciation": cur["capex"] / dep if cur.get("capex") is not None and dep and dep > 0 else None,
        "remaining_life_years": ppe / (dep * 4) if ppe and dep and dep > 0 else None,
        "debt_to_ppe": debt / ppe if debt and ppe else None,
        "ebitda_margin": e_c, "ebitda_margin_prior": e_p,
        "ebitda_margin_pp": None if e_c is None or e_p is None else e_c - e_p,
        "depreciation_drag_pp": None if e_c is None or o_c is None else e_c - o_c,
    }
    a["asset_heavy"] = bool((a["intensity_pct"] or 0) >= R.ASSET_HEAVY_PPE_PCT_OF_REVENUE
                            or (a["capex_ttm_pct_revenue"] or 0) >= R.ASSET_HEAVY_CAPEX_PCT_OF_REVENUE)
    a["profile"] = _profile(d, a)
    return d, a


def _profile(d, a):
    if a["asset_heavy"]:
        txt = (f"Asset-heavy: property and equipment equal {a['intensity_pct']:.0f}% of a year's revenue"
               if a["intensity_pct"] is not None else "Asset-heavy")
        if a["depreciation_drag_pp"] is not None:
            txt += (f"; depreciation and amortisation take {a['depreciation_drag_pp']:.1f}pp of margin "
                    f"between EBITDA and operating income")
        txt += ". EBITDA margin and cash from operations are scored alongside GAAP profit."
    else:
        txt = "Asset-light"
        if a["intensity_pct"] is not None:
            txt += f": property and equipment equal {a['intensity_pct']:.0f}% of a year's revenue"
        txt += "."
    if d["total"]:
        if a["debt_to_ppe"] is not None and a["debt_to_ppe"] <= 1:
            txt += f" Debt is covered {1 / a['debt_to_ppe']:.1f}x by property and equipment."
        else:
            txt += " Debt is not backed by hard assets: it is repaid from cash flow."
    if (a["goodwill_intangibles_pct_assets"] or 0) >= 30:
        txt += (f" {a['goodwill_intangibles_pct_assets']:.0f}% of total assets are goodwill and acquired "
                f"intangibles.")
    return txt


def questions(m):
    d, a, q = m["debt"], m["assets"], []
    if d["total"] and d["total_prev_quarter"] and abs(d["total"] - d["total_prev_quarter"]) >= 0.1 * d["total_prev_quarter"]:
        flows = []
        if d["issued_ytd"]:
            flows.append(f"borrowed {_fmt(d['issued_ytd'])}")
        if d["repaid_ytd"]:
            flows.append(f"repaid {_fmt(d['repaid_ytd'])}")
        q.append(f"Debt moved {_fmt(d['total_prev_quarter'])} -> {_fmt(d['total'])} since last report"
                 + (f" (year to date: {', '.join(flows)})" if flows else "")
                 + ". Explain: new borrowing or a refinancing, and on what terms.")
    if d["avg_rate_pct"] is not None and d["avg_rate_pct"] < R.IMPLIED_RATE_TOO_LOW_PCT and d["total"]:
        q.append(f"Interest expense implies only {d['avg_rate_pct']:.1f}% a year on {_fmt(d['total'])} of debt: "
                 "probably reported net of interest income. Check the debt note for the real rate.")
    if d["interest_q"] is not None and d["interest_q"] <= 0 and d["total"]:
        q.append("Interest expense is zero or negative despite debt: reported net of interest income. "
                 "Check the debt note for the real rate.")
    if (d["interest_pct_revenue"] or 0) >= R.INTEREST_HEAVY_PCT_OF_REVENUE:
        q.append(f"Interest takes {d['interest_pct_revenue']:.1f}% of revenue. Explain the path to bring it down.")
    if d["interest_capitalized"]:
        q.append(f"{_fmt(d['interest_capitalized'])} of interest was capitalised this quarter: it is not in the "
                 "income statement yet and will come back as depreciation.")
    if d["near_term_cover"] is not None and d["near_term_cover"] < 1:
        q.append(f"{_fmt(d['near_term'])} of debt falls due within about {d['near_term_months']} months, more than "
                 f"cash on hand ({_fmt(d['liquid'])}). Explain the refinancing plan.")
    if d["material"] and (d["revenue_minus_debt_growth_pp"] or 0) < 0:
        q.append(f"Debt is growing faster than revenue ({d['yoy_pct']:+.0f}% vs "
                 f"{m['revenue']['yoy_pct']:+.0f}%). When does revenue overtake it?")
    if (a["asset_heavy"] and a["remaining_life_years"] is not None and d["avg_maturity_years"] is not None
            and a["remaining_life_years"] < d["avg_maturity_years"]):
        q.append(f"Assets have about {a['remaining_life_years']:.1f} years of life left at the current depreciation "
                 f"rate, but debt matures in about {d['avg_maturity_years']:.1f} years on average: the assets wear "
                 "out before the debt is repaid.")
    if a["asset_heavy"] and a["da_yoy_pct"] is not None and m["revenue"]["yoy_pct"] is not None \
            and a["da_yoy_pct"] > m["revenue"]["yoy_pct"] + 2:
        q.append(f"Depreciation and amortisation grew {a['da_yoy_pct']:+.0f}% vs revenue "
                 f"{m['revenue']['yoy_pct']:+.0f}%: new assets are not yet earning their keep.")
    return q
