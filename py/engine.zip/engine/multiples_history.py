"""What the market paid for a company over the last year: the median of its daily multiples (price history ×
the twelve-month numbers known on each day), next to today's. Analysts mostly price a stock on the multiple it
has traded at lately, not on one day's mood; the projection uses the ratio of the two (history factor).

Works from the SEC quarters (metrics.Company) and the daily prices kept by technical.py. Share counts are put on
today's basis across stock splits (prices from Yahoo are already split-adjusted)."""
import datetime as dt

SPLITS = (2, 3, 4, 5, 8, 10, 15, 20, 25, 30, 40, 50)
LAG_DAYS = 45            # a quarter's numbers are known about this long after it ends
WINDOW_DAYS = 365
MIN_DAYS = 120           # fewer days with a meaningful multiple: no history factor
KEYS = ("pe", "ev_sales", "ps", "ev_ebitda")


def split_adjusted_shares(co, ends):
    """{quarter end: diluted shares on today's basis}: a jump of ~2×, 3×, 10×… from one quarter to the next is a
    split, so every earlier count is multiplied by it."""
    adj, factor, later = {}, 1.0, None
    for e in reversed(ends):
        s = (co.snapshot(e) or {}).get("shares_diluted")
        if s and later:
            r = later / s
            for n in SPLITS:
                if abs(r / n - 1) < 0.08:
                    factor *= n
                    break
        if s:
            adj[e] = s * factor
            later = s
    return adj


def _median(xs):
    xs = sorted(xs)
    n = len(xs)
    return None if not n else (xs[n // 2] if n % 2 else (xs[n // 2 - 1] + xs[n // 2]) / 2)


def build(co, rows, today=None):
    """{"median": {key: multiple}, "days": {key: n}, "since": date, "ttm": today's twelve-month numbers ($M, M
    shares)} or None. rows: [(date, open, high, low, close, volume)] daily."""
    ends = co.quarter_ends()
    if not ends or not rows:
        return None
    sh = split_adjusted_shares(co, ends)
    last_day = rows[-1][0]
    today = today or last_day
    start = (dt.date.fromisoformat(today) - dt.timedelta(days=WINDOW_DAYS)).isoformat()
    cache = {}

    def numbers(q):
        if q not in cache:
            sn = co.snapshot(q) or {}
            cache[q] = {"revenue": co.ttm("revenue", q), "net_income": co.ttm("net_income", q),
                        "ebitda": co.ttm("ebitda", q), "net_debt": -(sn.get("net_cash") or 0.0), "shares": sh.get(q)}
        return cache[q]

    known_q, qi = None, 0
    series = {k: [] for k in KEYS}
    for r in rows:
        d, close = r[0], r[4]
        lim = (dt.date.fromisoformat(d) - dt.timedelta(days=LAG_DAYS)).isoformat()
        while qi < len(ends) and ends[qi] <= lim:
            known_q, qi = ends[qi], qi + 1
        if d < start or not known_q or not close:
            continue
        n = numbers(known_q)
        if not n["shares"]:
            continue
        mcap = close * n["shares"]
        ev = mcap + n["net_debt"]
        if n["revenue"] and n["revenue"] > 0:
            series["ev_sales"].append(ev / n["revenue"])
            series["ps"].append(mcap / n["revenue"])
        if n["net_income"] and n["net_income"] > 0:
            series["pe"].append(mcap / n["net_income"])
        if n["ebitda"] and n["ebitda"] > 0:
            series["ev_ebitda"].append(ev / n["ebitda"])
    med = {k: _median(v) for k, v in series.items() if len(v) >= MIN_DAYS}
    if not med:
        return None
    n = numbers(ends[-1])
    m = 1e6
    return {"median": med, "days": {k: len(series[k]) for k in med}, "since": start, "to": last_day,
            "ttm": {"revenue": (n["revenue"] or 0) / m if n["revenue"] else None,
                    "net_income": n["net_income"] / m if n["net_income"] is not None else None,
                    "ebitda": n["ebitda"] / m if n["ebitda"] is not None else None,
                    "net_debt": (n["net_debt"] or 0) / m, "shares": (n["shares"] or 0) / m or None}}


def now_multiples(hm, price):
    """Today's multiples on the same basis (twelve-month numbers) at this price."""
    t = (hm or {}).get("ttm") or {}
    if not price or not t.get("shares"):
        return {}
    mcap = price * t["shares"]
    ev = mcap + (t.get("net_debt") or 0)
    pos = lambda a, b: a / b if a and b and a > 0 and b > 0 else None
    return {"ev_sales": pos(ev, t.get("revenue")), "ps": pos(mcap, t.get("revenue")),
            "pe": pos(mcap, t.get("net_income")), "ev_ebitda": pos(ev, t.get("ebitda"))}


def factor(hm, price):
    """(history factor, {key: ratio}): the median over the multiples of (last year's median ÷ today's). Several
    multiples, so one distorted line (a one-off tax gain in net income, say) does not decide it alone."""
    now = now_multiples(hm, price)
    ratios = {k: hm["median"][k] / now[k] for k in (hm or {}).get("median", {}) if now.get(k)}
    if "ev_sales" in ratios:                 # P/S moves with EV/Sales: one vote for sales, not two
        ratios.pop("ps", None)
    if not ratios:
        return None, {}
    return _median(list(ratios.values())), ratios
