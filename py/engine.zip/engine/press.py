"""Read an earnings press release (8-K exhibit HTML, or text pasted from the IR page) into numbers.

How a line is recognised: the press release always shows the same quarter of last year next to this one, and
those numbers are already known from the SEC (XBRL). A row whose year-ago value equals last year's revenue is
the revenue row; the match also tells the unit (thousands or millions) and the sign convention. Labels are
only a tie-breaker and a fallback, because every company names its lines differently.
"""
import re
from datetime import date, timedelta
from html.parser import HTMLParser

# ---------- what we look for -----------------------------------------------------------------------
# key: (statement, kind, label pattern, words that rule a label out)
#   kind q = quarter flow · cf = cash flow (quarter or year to date) · bs = balance sheet · ps = per share · sh = shares
FIELDS = {
    "revenue": ("is", "q", r"^(total )?(net )?(revenues?|sales|net sales)\b|^revenues?,? net",
                r"cost|deferred|unearned|per |%|margin|marketing|expense|proceeds|purchase|segment"),
    "cost_of_revenue": ("is", "q", r"\bcost of (revenues?|sales|goods|products|services)", r"%|margin"),
    "gross_profit": ("is", "q", r"\bgross (profit|margin)\b", r"%|non-?gaap|adjusted"),
    "rnd": ("is", "q", r"research(,| and) development|\br&d\b", r"in-?process|acquired"),
    "sales_marketing": ("is", "q", r"^(selling|sales) and marketing", r"general"),
    "ga": ("is", "q", r"^general and administrative", r"selling|sales|marketing"),
    "sga": ("is", "q", r"(selling|sales|marketing),? general,? and administrative", r""),
    "operating_income": ("is", "q", r"(income|loss|profit)[^,]{0,25}from operations|operating (income|loss|profit)",
                         r"non-?gaap|adjusted|margin|%|expenses"),
    "interest_expense": ("is", "q", r"^interest expense", r"income"),
    "pretax": ("is", "q", r"before (provision for |benefit from )?(income )?tax", r"non-?gaap|adjusted|margin"),
    "tax": ("is", "q", r"(provision for|benefit from|\(benefit\)|provision|expense).{0,25}income tax|"
                       r"^income tax", r"before|deferred|non-?gaap|paid|withholding|payable"),
    "net_income": ("is", "q", r"^net (income|loss|earnings)\b", r"per share|non-?gaap|adjusted|margin|attributable to non"),
    "eps_diluted": ("is", "ps", r"diluted", r"non-?gaap|adjusted|continuing|discontinued"),
    "shares_diluted": ("is", "sh", r"diluted", r"non-?gaap|adjusted|per share"),
    "shares_basic": ("is", "sh", r"^basic\b|basic (shares|weighted)", r"per share|earnings"),
    "cfo": ("cf", "cf", r"net cash.{0,40}operating activities", r"discontinued|continuing"),
    "capex_ppe": ("cf", "cf", r"(purchases?|acquisitions?|additions?|payments?)( related)? (of|to|for) property|"
                              r"capital expenditures|purchases of property",
                  r"discontinued|principal"),
    "capex_software": ("cf", "cf", r"(capitalized|internal[- ]use|website and) software|software development costs",
                       r"amortization|net$"),
    "sbc": ("cf", "cf", r"(stock|share|equity)[- ]based compensation", r"withholding|tax"),
    "da_cf": ("cf", "cf", r"^depreciation and amortization|^depreciation, amortization", r"intangible|acquisition"),
    "acquisitions": ("cf", "cf", r"acquisitions?.{0,40}net of cash", r""),
    "buybacks": ("cf", "cf", r"repurchases? of (common )?(stock|shares)|share repurchases|"
                             r"payments? (related )?(to|for) repurchases?|repurchase of shares", r"tax|withholding"),
    "dividends": ("cf", "cf", r"dividends paid|payments? of dividends|cash dividends", r""),
    "tax_withheld": ("cf", "cf", r"tax(es)? (withholding|withheld|related to|on|paid).{0,50}(stock|equity|share|employee)|"
                                 r"employee stock plan taxes|for tax withholding|net share settlement", r""),
    "stock_issued": ("cf", "cf", r"proceeds.{0,50}(employee (stock|equity)|stock plans|issuance of common stock|"
                                 r"exercise of (stock )?options|stock options)|^exercise of options|"
                                 r"employee stock purchase|issuance under employee", r"debt|notes|tax"),
    "debt_issued": ("cf", "cf", r"proceeds.{0,50}(debt|notes|borrowings|credit facilit|term loan|commercial paper|"
                                r"senior)", r"repay|securities|sales|maturit|investment"),
    "debt_repaid": ("cf", "cf", r"repayments?.{0,40}(debt|borrowings|notes|credit facilit|term loan|commercial paper)|"
                                r"payments? (on|of) (long-term )?(debt|borrowings|notes)", r"lease|property"),
    "cash": ("bs", "bs", r"^cash and cash equivalents$|^cash and cash equivalents\b(?!.*(beginning|end|restricted))",
             r"beginning|end of|restricted|increase|decrease|marketable|short-term"),
    "st_investments": ("bs", "bs", r"^(short-term investments|marketable (debt )?securities)", r"equity|non-?current"),
    "total_assets": ("bs", "bs", r"^total assets$", r""),
    "goodwill": ("bs", "bs", r"^goodwill$", r""),
    "ppe_net": ("bs", "bs", r"^property(,)? (plant )?(and )?equipment", r"purchase"),
    "debt_current": ("bs", "bs", r"(current portion of|short-term) (long-term )?(debt|borrowings)|^short-term debt",
                     r""),
    "debt_noncurrent": ("bs", "bs", r"^long-term (debt|borrowings)|^convertible (senior )?notes|^notes payable",
                        r"current portion|lease"),
}
STATEMENT_NAME = {"is": "Income statement · this quarter", "cf": "Cash flow", "bs": "Balance sheet · end of quarter"}
LABEL = {
    "revenue": "Revenue", "cost_of_revenue": "Cost of revenue", "gross_profit": "Gross profit",
    "rnd": "Research and development", "sales_marketing": "Sales and marketing", "ga": "General and administrative",
    "sga": "SG&A (combined)", "operating_income": "Operating income", "interest_expense": "Interest expense",
    "pretax": "Pre-tax income", "tax": "Income tax", "net_income": "Net income", "eps_diluted": "Diluted EPS (GAAP)",
    "shares_diluted": "Diluted shares", "shares_basic": "Basic shares",
    "cfo": "Cash from operations", "capex_ppe": "Capital expenditure", "capex_software": "Capitalised software", "sbc": "Stock-based compensation",
    "da_cf": "Depreciation and amortisation", "acquisitions": "Acquisitions", "buybacks": "Share buybacks",
    "dividends": "Dividends paid", "tax_withheld": "Taxes paid on employee stock",
    "stock_issued": "Stock issued to employees", "debt_issued": "Debt issued", "debt_repaid": "Debt repaid",
    "cash": "Cash and equivalents", "st_investments": "Short-term investments", "total_assets": "Total assets",
    "goodwill": "Goodwill", "ppe_net": "Property and equipment, net", "debt_current": "Debt due within a year",
    "debt_noncurrent": "Long-term debt",
}
# always shown as positive numbers (the statement's parentheses only mean "cash out" or "cost")
POSITIVE = {"cost_of_revenue", "rnd", "sales_marketing", "ga", "sga", "interest_expense", "capex_ppe",
            "capex_software", "sbc",
            "da_cf", "acquisitions", "buybacks", "dividends", "tax_withheld", "stock_issued", "debt_issued",
            "debt_repaid", "cash", "st_investments", "total_assets", "goodwill",
            "ppe_net", "debt_current", "debt_noncurrent", "shares_diluted", "shares_basic"}
MONTHS = ("january february march april may june july august september october november december").split()


# ---------- turning cells into numbers -------------------------------------------------------------
NUM = re.compile(r"^\(?\s*\$?\s*\(?\s*-?\s*\d[\d,]*(\.\d+)?\s*\)?$")
DASH = {"—", "–", "-", "--", "$—", "$-", "$–", "— ", "nm", "n/m", "*"}


def _value(cell):
    """(number, decimal places) or None; dashes are zero."""
    c = cell.replace(" ", " ").strip()
    if not c:
        return None
    if c.replace(" ", "") in DASH:
        return 0.0, 0
    if not NUM.match(c):
        return None
    neg = "(" in c or re.search(r"(^|\$|\s)-\s*\d", c) is not None
    digits = re.sub(r"[^\d.]", "", c)
    try:
        v = float(digits)
    except ValueError:
        return None
    return (-v if neg else v), (len(digits.split(".")[1]) if "." in digits else 0)


def _clean_label(text):
    t = re.sub(r"\s+", " ", text.replace(" ", " ")).strip(" :|*")
    t = re.sub(r"\s*\(\d{1,2}\)", "", t)                     # footnote markers (1)
    t = re.sub(r"[’']", "'", t)
    return t.strip()


def row_from_cells(cells):
    """[label, (value, has_decimals)…] from the cells of one table row, or None when it holds no numbers."""
    joined = " | ".join(c.replace(" ", " ").strip() for c in cells)
    joined = re.sub(r"\$\s*\|\s*", "$", joined)               # "$ | 1,234"  -> "$1,234"
    joined = re.sub(r"\s*\|\s*\)", ")", joined)                # "(1,234 | )" -> "(1,234)"
    joined = re.sub(r"\s*\|\s*%", "%", joined)                 # "54 | %"     -> "54%"
    parts = [p.strip() for p in joined.split("|")]
    label, vals = [], []
    for p in parts:
        if not p:
            continue
        if p.endswith("%") or p.lower().endswith("pts") or re.search(r"^(up|down)\b", p.lower()):
            continue                                          # percentages are not columns we use
        v = _value(p)
        if v is not None and (label or vals):
            vals.append(v)
        elif v is None and not vals:
            label.append(p)
    lab = _clean_label(" ".join(label))
    if not vals or not re.search(r"[a-zA-Z]", lab):
        return None
    return {"label": lab, "vals": [v for v, _d in vals], "dp": [d for _v, d in vals],
            "dec": [d > 0 for _v, d in vals]}


TOKEN = re.compile(r"\(?\$?\s?\(?-?\d[\d,]*(?:\.\d+)?\)?\s?%?|(?<!\w)[—–](?!\w)")


def row_from_text(line):
    """A pasted line without separators: 'Net revenue $13,377 $11,536 (62) —'."""
    line = line.replace(" ", " ").strip()
    if "\t" in line or "|" in line:
        return row_from_cells(re.split(r"\t|\|", line))
    toks = list(TOKEN.finditer(line))
    if not toks:
        return None
    # the numbers are the run of tokens at the end of the line
    start = len(toks)
    for i in range(len(toks) - 1, -1, -1):
        gap = line[toks[i].end():toks[i + 1].start()] if i + 1 < len(toks) else line[toks[i].end():]
        if gap.strip(" $") and not re.fullmatch(r"\s*(pts|ppts|%)?\s*", gap):
            break
        start = i
    label = line[:toks[start].start()] if start < len(toks) else line
    cells = [label] + [t.group(0) for t in toks[start:]]
    # a footnote like "(1)" stuck to the label is not a column
    while len(cells) > 2 and re.fullmatch(r"\(\d\)", cells[1].strip()):
        cells.pop(1)
    return row_from_cells(cells)


class _Tables(HTMLParser):
    """Every <table> of an HTML document as rows of cell texts, with the text just before it."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tables, self.text = [], []
        self._stack = []           # open tables: {"rows": [...], "before": str}
        self._row = self._cell = None
        self._skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self._skip += 1
        elif tag == "table":
            self._stack.append({"rows": [], "before": "".join(self.text[-60:])})
        elif tag == "tr" and self._stack:
            self._row = []
        elif tag in ("td", "th") and self._row is not None:
            self._cell = []
        elif tag in ("br", "p", "div") and self._cell is not None:
            self._cell.append(" ")

    def handle_endtag(self, tag):
        if tag in ("script", "style"):
            self._skip = max(0, self._skip - 1)
        elif tag in ("td", "th") and self._cell is not None and self._row is not None:
            self._row.append("".join(self._cell))
            self._cell = None
        elif tag == "tr" and self._row is not None and self._stack:
            self._stack[-1]["rows"].append(self._row)
            self._row = None
        elif tag == "table" and self._stack:
            self.tables.append(self._stack.pop())

    def handle_data(self, data):
        if self._skip:
            return
        if self._cell is not None:
            self._cell.append(data)
        self.text.append(data)


UNIT_WORDS = [
    (1e9, r"in billions|\(\s*\$?\s*billions|billions of|\(\s*\$\s*b\s*\)|\$\s*in\s*b\b|\$bn\b|\(\s*bn\s*\)"),
    (1e6, r"in millions|\(\s*\$?\s*millions|millions of|\(\s*\$\s*m{1,2}\s*\)|\$\s*in\s*m{1,2}\b|\$mm\b|"
          r"\(\s*mm\s*\)"),
    (1e3, r"in thousands|\(\s*\$?\s*thousands|thousands of|000s omitted|\$\s*000|in 000s|\(\s*000s?\s*\)|"
          r"\(\s*\$\s*k\s*\)"),
]
UNIT_NAME = {1e3: "thousands", 1e6: "millions", 1e9: "billions", 1.0: "units"}


def _unit(text):
    """The unit a statement says it is in ('(In millions, except per share data)'), or None."""
    t = text.lower()
    for scale, pat in UNIT_WORDS:
        if re.search(pat, t):
            return scale
    return None


def parse_html(html):
    """[{'rows': [...], 'unit': 1e6|1e3|None}] plus the plain text of the document."""
    p = _Tables()
    p.feed(html)
    tables = []
    for t in p.tables:
        rows = [r for r in (row_from_cells(cells) for cells in t["rows"]) if r]
        if rows:
            head = " ".join(" ".join(c) for c in t["rows"][:3])
            tables.append({"rows": rows, "unit": _unit(head) or _unit(t["before"])})
    text = re.sub(r"\s+", " ", "".join(p.text))
    return tables, text


def parse_text(text):
    """Text pasted from an IR page or a PDF. Blocks are split at blank lines and statement titles."""
    tables, cur, unit = [], [], _unit(text[:3000])
    for line in text.splitlines():
        low = line.lower()
        if not line.strip() or re.search(r"(statements? of|balance sheets?|cash flows?\b).{0,40}$", low) and not \
                re.search(r"\d", line):
            if cur:
                tables.append({"rows": cur, "unit": unit})
                cur = []
            u = _unit(line)
            unit = u or unit
            continue
        u = _unit(line)
        if u:
            unit = u
        r = row_from_text(line)
        if r:
            cur.append(r)
    if cur:
        tables.append({"rows": cur, "unit": unit})
    # blank lines inside one statement split it into small pieces: join pieces with the same unit
    merged = []
    for t in tables:
        if merged and len(t["rows"]) < 4 and merged[-1]["unit"] == t["unit"]:
            merged[-1]["rows"] += t["rows"]
        else:
            merged.append(t)
    return merged, re.sub(r"\s+", " ", text)


# ---------- matching rows to what we know --------------------------------------------------------------
def _label_ok(key, label):
    _st, _k, good, bad = FIELDS[key]
    low = label.lower()
    if not re.search(good, low):
        return False
    return not (bad and re.search(bad, low))


def _scales(kind):
    return (1.0,) if kind == "ps" else (1e3, 1e6, 1e9, 1.0)


def _close(shown, scale, ref, kind, dp=0):
    """Does a shown number, at this scale and with these decimals, equal the known value (after rounding)?
    '13.4' in billions has the same precision as '13,377' in millions only to one decimal: the last digit
    shown sets the rounding allowed."""
    if ref is None or shown == 0:
        return False
    a, r = abs(shown) * scale, abs(ref)
    if kind == "ps":
        return abs(a - r) <= 0.0051 + 0.002 * r
    step = scale * 10 ** -dp                                    # value of the last digit shown
    if r / step < 20:                                          # too few digits shown to tell
        return False
    return abs(a - r) <= 0.5 * step + 0.0025 * r


def _current_col(kind, basis, col_ref, n):
    if col_ref == 0:
        return 1 if n > 1 else None                            # last year first: this year is next
    if basis == "ytd":
        return col_ref - 1                                     # year-to-date columns come in pairs
    return 0


def extract(tables, refs, unit=None):
    """{key: {'val', 'basis', 'label', 'how', 'shown'}} from parsed tables and the known year-ago values.

    refs: {key: [(value, basis), ...]} with basis 'q' (same quarter last year), 'ytd' (same year-to-date last
    year) or 'bs' (balance sheet at the last fiscal year end or a year ago).
    unit: force thousands / millions / billions (1e3, 1e6, 1e9) for money lines; None = work it out."""
    found, table_layout, table_st = {}, {}, {}
    for key, (st, kind, _good, _bad) in FIELDS.items():
        best = None
        for ti, t in enumerate(tables):
            for ri, row in enumerate(t["rows"]):
                vals = row["vals"]
                label_ok = _label_ok(key, row["label"])
                for ref, basis in refs.get(key, []):
                    for ci, shown in enumerate(vals):
                        for scale in _scales(kind):
                            if unit and kind not in ("ps", "sh") and scale != unit:
                                continue
                            if not _close(shown, scale, ref, kind, row["dp"][ci]):
                                continue
                            cc = _current_col(kind, basis, ci, len(vals))
                            if cc is None or cc >= len(vals):
                                continue
                            sign = (1 if ref >= 0 else -1) * (1 if shown >= 0 else -1)
                            val = vals[cc] * scale * sign
                            score = (2 if label_ok else 0) + (1 if basis == "q" else 0) + \
                                (0.5 if t["unit"] in (None, scale) else -1) - (1 if ci == 0 else 0)
                            cand = {"val": val, "basis": "bs" if kind == "bs" else ("ytd" if basis == "ytd" else "q"),
                                    "label": row["label"], "how": "matched", "score": score, "table": ti,
                                    "scale": scale, "cur_col": cc, "label_ok": label_ok}
                            if best is None or score > best["score"]:
                                best = cand
        if best and not best["label_ok"]:
            # a number alone can be a coincidence: accept it only when it has many digits and the row is not
            # obviously some other line (a 'Stock-based compensation' row is never net income)
            r = max((abs(x) for x, _b in refs.get(key, []) if x is not None), default=0)
            other = any(_label_ok(k2, best["label"]) for k2 in FIELDS if k2 != key)
            if other or kind != "ps" and r / best["scale"] < 100:
                best = None
        if best:
            found[key] = best
            table_layout.setdefault((best["table"], best["basis"]), (best["cur_col"], best["scale"]))
            if best["label_ok"]:
                table_st.setdefault(best["table"], set()).add(st)

    # second pass: lines with no year-ago value at the SEC, found by label in a table we already understand
    for key, (st, kind, _good, _bad) in FIELDS.items():
        if key in found:
            continue
        for (ti, basis), (cc, scale) in sorted(table_layout.items(), key=lambda x: x[0][1] != "q"):
            if unit and kind not in ("ps", "sh"):
                scale = unit
            if kind == "bs" and basis != "bs" or kind != "bs" and basis == "bs":
                continue
            if st not in table_st.get(ti, set()):          # only in a statement we already recognised
                continue
            rows = [r for r in tables[ti]["rows"] if _label_ok(key, r["label"]) and cc < len(r["vals"])]
            if kind in ("ps",):
                rows = [r for r in rows if r["dec"][cc]]
                scale = 1.0
            elif kind == "sh":
                rows = [r for r in rows if not r["dec"][cc]]
            if rows:
                r = rows[0]
                found[key] = {"val": r["vals"][cc] * scale, "basis": basis, "label": r["label"], "how": "label",
                              "score": 0, "table": ti, "scale": scale, "cur_col": cc, "label_ok": True}
                break

    for key, f in found.items():
        if key in POSITIVE:
            f["val"] = abs(f["val"])
        for k in ("score", "table", "cur_col", "label_ok"):
            f.pop(k, None)
    return found


def unit_of(found, tables):
    """(scale, how) of the money lines: what the matches show, else what the tables say."""
    seen = [f["scale"] for k, f in found.items() if FIELDS[k][1] not in ("ps", "sh") and f.get("scale")]
    if seen:
        s = max(set(seen), key=seen.count)
        said = [t["unit"] for t in tables if t["unit"]]
        clash = bool(said) and max(set(said), key=said.count) != s
        return s, "read from last year's numbers" + (" (the table header says otherwise: check)" if clash else "")
    said = [t["unit"] for t in tables if t["unit"]]
    return (max(set(said), key=said.count), "from the table header") if said else (None, "unknown")


def rounding_note(found, tables, scale):
    """In billions with one decimal, every line can be off by up to $50M: say so."""
    if not scale or scale < 1e9:
        return None
    dps = [d for t in tables for r in t["rows"] for d in r["dp"]]
    common = max(set(dps), key=dps.count) if dps else 0
    half = scale * 10 ** -common / 2
    return f"In billions: each line is rounded to ±${half / 1e6:,.0f}M." if half >= 5e6 else None


def adjusted_eps(tables):
    """Adjusted (non-GAAP) diluted EPS for this quarter, if a line says so."""
    for t in tables:
        for r in t["rows"]:
            low = r["label"].lower()
            if re.search(r"non-?gaap|adjusted", low) and re.search(r"diluted|per share|eps", low):
                cents = [v for v, d in zip(r["vals"], r["dp"]) if d == 2 and abs(v) < 1000]
                if cents:                                   # an EPS has two decimals; $3.5 billion has one
                    return cents[0]
                for v, d in zip(r["vals"], r["dp"]):
                    if d and abs(v) < 1000:
                        return v
    return None


def period_end_in(text, today=None):
    """The latest period end named in the text: in a results release, the quarter just reported."""
    lim = today or date.today()
    best = None
    for m in re.finditer(r"(" + "|".join(MONTHS) + r")\s+(\d{1,2}),?\s+(20\d\d)", text.lower()):
        try:
            d = date(int(m.group(3)), MONTHS.index(m.group(1)) + 1, int(m.group(2)))
        except ValueError:
            continue
        if d <= lim and (best is None or d > best):
            best = d
    return best.isoformat() if best else None


def quarter_end(text, expected, window=25):
    """The quarter end named in the release ('three months ended July 26, 2026'), near the expected date."""
    exp = date.fromisoformat(expected)
    best = None
    for m in re.finditer(r"(" + "|".join(MONTHS) + r")\s+(\d{1,2}),?\s+(20\d\d)", text.lower()):
        try:
            d = date(int(m.group(3)), MONTHS.index(m.group(1)) + 1, int(m.group(2)))
        except ValueError:
            continue
        gap = abs((d - exp).days)
        if gap <= window and (best is None or gap < best[0]):
            best = (gap, d)
    return best[1].isoformat() if best else expected


def expected_end(ya_end, last_end):
    """Next quarter end: a year after the matching quarter last year (52-week years keep the weekday)."""
    ya = date.fromisoformat(ya_end)
    nxt = (ya.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
    if ya == nxt:                                              # month-end calendar
        y = ya.replace(year=ya.year + 1, day=1)
        return ((y + timedelta(days=32)).replace(day=1) - timedelta(days=1)).isoformat()
    _ = last_end
    return (ya + timedelta(days=364)).isoformat()
