"""Company profile: who the company is, the market it sells into, and how defensible it is.

Part comes from the SEC (where it is based, industry, R&D, acquisitions, margins against peers);
the rest is yours to fill from the 10-K and the investor presentation, and is kept in
companies/TICKER/TICKER_profile.json. Five pillars give a business grade, separate from the
quarter grade: financial health, margins, market share, market growth (TAM CAGR) and moat.
"""
import json
from datetime import date

from . import peers as peers_mod, scorecard

MOAT_SOURCES = [
    ("switching", "Switching costs", "customers lose time, data or money if they leave"),
    ("network", "Network effects", "each new user makes the product better for the others"),
    ("intangibles", "Intangible assets", "patents, brand, licences, proprietary data"),
    ("cost", "Cost or scale advantage", "it produces cheaper than rivals can"),
    ("niche", "Efficient scale", "a market too small for a second player to enter profitably"),
]
MOAT_LEVELS = ("none", "narrow", "wide")
TRENDS = ("gaining", "stable", "losing")
VS_PEERS = ("stronger", "similar", "weaker")
PILLARS = [("health", "Financial health"), ("margins", "Margins"), ("share", "Market share"),
           ("tam", "Market growth"), ("moat", "Moat")]
# Bands: first threshold reached gives the points
TAM_CAGR = [(30, 100), (20, 85), (10, 70), (5, 50), (-1e9, 30)]          # % a year: 30%+ is top
MARKET_SHARE = [(50, 100), (30, 90), (15, 75), (5, 60), (-1e9, 40)]      # % of the market
SHARE_TREND = {"gaining": 10, "stable": 0, "losing": -15}
MARGIN_VS_PEERS = [(10, 100), (3, 85), (-3, 70), (-10, 45), (-1e9, 25)]  # pp above the peer median
MARGIN_ABSOLUTE = [(30, 100), (20, 85), (10, 70), (0, 50), (-1e9, 25)]   # operating margin %, without peers
MOAT_VS_PEERS = {"stronger": 10, "similar": 0, "weaker": -10}
N_SEGMENTS = 6


def empty():
    return {"founded": None, "ceo": None, "hq": None, "business": "", "segments": [],
            "tam_busd": None, "tam_year": None, "tam_cagr_pct": None, "tam_source": "",
            "market_share_pct": None, "share_trend": None, "acquisitions_rd": "",
            "moat": {}, "moat_vs_peers": None, "moat_notes": "", "updated": None}


def load(path):
    data = empty()
    try:
        with open(path, encoding="utf-8") as f:
            data.update(json.load(f))
    except (OSError, ValueError):
        pass
    return data


def save(path, data):
    data = dict(data)
    data["updated"] = date.today().isoformat()
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    return data


def _band(v, table):
    for thr, pts in table:
        if v >= thr:
            return pts
    return table[-1][1]


def auto_facts(subs, co, m, g):
    """What the SEC data says without any typing. Money in $M, ratios in %."""
    subs = subs or {}
    addr = (subs.get("addresses") or {}).get("business") or {}
    place = ", ".join(x for x in (str(addr.get("city") or "").title(),
                                  addr.get("stateOrCountryDescription") or addr.get("stateOrCountry")) if x)
    fye = str(subs.get("fiscalYearEnd") or "")
    months = ["", "January", "February", "March", "April", "May", "June", "July", "August", "September",
              "October", "November", "December"]
    fye_txt = f"{int(fye[2:])} {months[int(fye[:2])]}" if len(fye) == 4 and fye.isdigit() and 1 <= int(fye[:2]) <= 12 else None
    end = m["period"]["end"]
    own = peers_mod.stats_from(co) or {}
    rev = m["revenue"]["ttm"]
    rnd = co.ttm("rnd", end)
    gp = co.ttm("gross_profit", end)

    def M_(x):
        return None if x is None else x / 1e6

    def pct(a, b):
        return None if a is None or not b else a / b * 100
    return {
        "name": subs.get("name"), "hq": place or None,
        "incorporated": subs.get("stateOfIncorporationDescription") or subs.get("stateOfIncorporation"),
        "industry": subs.get("sicDescription"), "sic": subs.get("sic"),
        "exchange": ", ".join(x for x in (subs.get("exchanges") or []) if x) or None,
        "website": subs.get("website") or None, "fiscal_year_end": fye_txt,
        "period": m["period"]["label"],
        "revenue_ttm": M_(rev), "rnd_ttm": M_(rnd), "rnd_pct": pct(rnd, rev),
        "acquisitions_ttm": M_(m["fcf"]["uses"].get("acquisitions")),
        "gross_margin": pct(gp, rev),
        "op_margin": None if own.get("op_margin") is None else own["op_margin"] * 100,
        "net_margin": None if own.get("net_margin") is None else own["net_margin"] * 100,
        "fcf_margin": None if own.get("fcf_margin") is None else own["fcf_margin"] * 100,
        "rev_growth": None if own.get("rev_growth") is None else own["rev_growth"] * 100,
        "balance_score": g["blocks"]["balance"]["score"], "quarter_grade": g["grade"],
        "net_cash": M_(m["debt"]["net_cash"]), "debt": M_(m["debt"]["total"]),
        "net_debt_to_ebitda": m["debt"]["net_debt_to_ebitda"], "interest_cover": m["debt"]["interest_cover"],
    }


def segments(data):
    """[(name, value, share %)] for the segments that have a number."""
    rows = [(s.get("name") or "", s.get("value")) for s in data.get("segments") or []
            if s.get("value") not in (None, "") and (s.get("name") or "").strip()]
    total = sum(v for _n, v in rows if v > 0)
    return [(n, v, v / total * 100 if total else None) for n, v in rows]


def score(data, auto, peers=None):
    """Five pillars, 0-100 each, and the business grade. A pillar with no data is left out."""
    out = {}
    # 1. financial health: the balance-sheet block of the latest quarter (debt, cover, maturities, dilution)
    b = auto.get("balance_score")
    note = []
    if auto.get("net_cash") is not None:
        note.append(f"net {'cash' if auto['net_cash'] >= 0 else 'debt'} ${abs(auto['net_cash']):,.0f}M")
    if auto.get("net_debt_to_ebitda") is not None:
        note.append(f"{auto['net_debt_to_ebitda']:.1f}x EBITDA")
    out["health"] = {"score": b, "note": " · ".join(note) or "from the balance-sheet block", "auto": True}
    # 2. margins against the peer median (operating, net, FCF); absolute bands until peers are loaded
    med = (peers or {}).get("median") or {}
    diffs = []
    for k in ("op_margin", "net_margin", "fcf_margin"):
        if auto.get(k) is not None and med.get(k) is not None:
            diffs.append(auto[k] - med[k] * 100)
    if diffs:
        pts = sum(_band(d, MARGIN_VS_PEERS) for d in diffs) / len(diffs)
        avg = sum(diffs) / len(diffs)
        out["margins"] = {"score": pts, "auto": True,
                          "note": f"{avg:+.1f}pp vs the peer median, on average ({len(diffs)} margins)"}
    elif auto.get("op_margin") is not None:
        out["margins"] = {"score": _band(auto["op_margin"], MARGIN_ABSOLUTE), "auto": True,
                          "note": f"operating margin {auto['op_margin']:.1f}% (no peers to compare yet)"}
    else:
        out["margins"] = {"score": None, "note": "no margin data", "auto": True}
    # 3. market share, and whether it is being gained or lost
    ms = data.get("market_share_pct")
    if ms is None:
        out["share"] = {"score": None, "note": "enter the market share"}
    else:
        pts = _band(ms, MARKET_SHARE) + SHARE_TREND.get(data.get("share_trend"), 0)
        out["share"] = {"score": max(0, min(100, pts)),
                        "note": f"{ms:.0f}% of the market" + (f", {data['share_trend']}" if data.get("share_trend") else "")}
    # 4. market growth
    cg = data.get("tam_cagr_pct")
    out["tam"] = ({"score": None, "note": "enter the TAM growth"} if cg is None else
                  {"score": _band(cg, TAM_CAGR), "note": f"TAM growing {cg:.0f}% a year" + (" (top: 30%+)" if cg >= 30 else "")})
    # 5. moat: the two strongest sources, adjusted by the comparison with peers
    levels = sorted((int(v) for v in (data.get("moat") or {}).values() if v is not None), reverse=True)
    if not levels:
        out["moat"] = {"score": None, "note": "rate the five moat sources"}
    else:
        top = levels[:2] + [0] * (2 - len(levels[:2]))
        pts = 40 + 15 * (top[0] + top[1]) + MOAT_VS_PEERS.get(data.get("moat_vs_peers"), 0)
        wide = sum(1 for v in levels if v == 2)
        narrow = sum(1 for v in levels if v == 1)
        out["moat"] = {"score": max(0, min(100, pts)),
                       "note": f"{wide} wide, {narrow} narrow" + (f" · {data['moat_vs_peers']} than peers"
                                                                  if data.get("moat_vs_peers") in ("stronger", "weaker")
                                                                  else " · similar to peers" if data.get("moat_vs_peers") else "")}
    have = [p["score"] for p in out.values() if p["score"] is not None]
    total = sum(have) / len(have) if have else None
    return {"pillars": out, "score": total, "filled": len(have),
            "grade": None if total is None else scorecard.grade_for(round(total)),
            "complete": len(have) == len(PILLARS)}


def table_rows(data, auto, sc):
    """Flat rows for the Profile sheet of the report workbook."""
    rows = [("Business grade", sc["grade"] if sc["complete"] else f"{sc['grade'] or 'n/a'} ({sc['filled']} of 5 pillars)"),
            ("Business score", None if sc["score"] is None else round(sc["score"], 1))]
    for k, label in PILLARS:
        p = sc["pillars"][k]
        rows.append((f"Pillar · {label}", None if p["score"] is None else round(p["score"])))
        rows.append((f"Pillar · {label} · why", p["note"]))
    for label, v in (("Company", auto.get("name")), ("Headquarters", data.get("hq") or auto.get("hq")),
                     ("Incorporated in", auto.get("incorporated")), ("Founded", data.get("founded")),
                     ("CEO", data.get("ceo")), ("Industry (SEC)", auto.get("industry")),
                     ("Exchange", auto.get("exchange")), ("Fiscal year ends", auto.get("fiscal_year_end")),
                     ("What it does", data.get("business")),
                     ("Revenue, 12 months ($M)", auto.get("revenue_ttm")),
                     ("TAM ($B)", data.get("tam_busd")), ("TAM year", data.get("tam_year")),
                     ("TAM CAGR (%)", data.get("tam_cagr_pct")), ("TAM source", data.get("tam_source")),
                     ("Market share (%)", data.get("market_share_pct")), ("Share trend", data.get("share_trend")),
                     ("R&D, 12 months ($M)", auto.get("rnd_ttm")), ("R&D % of revenue", auto.get("rnd_pct")),
                     ("Acquisitions, 12 months ($M)", auto.get("acquisitions_ttm")),
                     ("Acquisitions and R&D notes", data.get("acquisitions_rd")),
                     ("Moat vs peers", data.get("moat_vs_peers")), ("Moat notes", data.get("moat_notes"))):
        rows.append((label, round(v, 1) if isinstance(v, float) else v))
    for key, label, _h in MOAT_SOURCES:
        lv = (data.get("moat") or {}).get(key)
        rows.append((f"Moat · {label}", None if lv is None else MOAT_LEVELS[int(lv)]))
    for n, v, sh in segments(data):
        rows.append((f"Segment · {n}", f"{v:,.1f} ({sh:.0f}%)" if sh is not None else v))
    return [{"item": a, "value": b} for a, b in rows]
