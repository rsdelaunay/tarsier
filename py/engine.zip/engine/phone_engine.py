"""The PC engine, run inside the phone's browser (Pyodide): grade a company from SEC data the phone fetched.

Same code as Tarsier.exe, so the same grade. The phone writes the SEC files into Pyodide's in-memory disk,
this runs the usual pipeline offline on them and returns the company exactly as the PC would publish it,
marked as a quick look.
"""
import json
import os

from . import mobile, paths, pipeline


def grade(ticker, facts_text, subs_text=None, price=None, price_time=None):
    """JSON text of one company, in the same shape as data.json's companies (grades, numbers, valuation, Compare)."""
    t = ticker.upper()
    os.makedirs(paths.CACHE, exist_ok=True)
    with open(os.path.join(paths.CACHE, f"{t}_companyfacts.json"), "w", encoding="utf-8") as f:
        f.write(facts_text)
    if subs_text:
        with open(os.path.join(paths.CACHE, f"{t}_submissions.json"), "w", encoding="utf-8") as f:
            f.write(subs_text)
    pipeline.mark_quick(t, "phone")
    market = {"price": float(price), "source": "Yahoo Finance (phone)", "time": price_time or ""} if price else None
    company = mobile.company(t, market)
    return mobile.dumps(company)


def revalue(payload_text):
    """Rework one company's projection on the phone: the PC's history and choices plus what was typed on the
    phone (growth, multiples, method). Same code as page 2 on the PC; JSON text shaped like data.json's
    valuation."""
    import datetime as dt
    p = json.loads(payload_text)
    h = p["hist"]
    h["fya_end"] = dt.date.fromisoformat(h["fya_end"])
    user = p.get("user") or {}
    fy = lambda d: {int(k): v for k, v in (d or {}).items() if v is not None}   # JSON keys are text
    user = {"settings": user.get("settings") or {},
            "consensus": {k: fy(v) for k, v in (user.get("consensus") or {}).items()},
            "scen": {s: {k: fy(v) for k, v in (d or {}).items()} for s, d in (user.get("scen") or {}).items()}}
    market = {"price": float(p["price"]), "source": p.get("price_source") or "the phone", "time": ""} \
        if p.get("price") else None
    v = mobile._valuation({"projection": {"hist": h, "user": user}}, None, market)
    return mobile.dumps(v)


def call_reading(call_text, prev_text=None, ctx_text=None):
    """Read an earnings call on the phone with the PC's rules (calls.py). The phone fetched the transcript from
    Alpha Vantage itself and keeps it; nothing here is published. JSON text: the reading, and each turn with where
    to mark it (numbers, guidance, hedging, dodges)."""
    from . import calls
    call = json.loads(call_text)
    prev = json.loads(prev_text) if prev_text else None
    r = calls.analyze(call, prev if prev and prev.get("turns") else None)
    r.pop("bigrams", None)
    for t in r["turns"]:
        t["marks"] = calls.marks(t["text"]) if t["role"] != "operator" else []
    for g in r["guidance"]:
        g["marks"] = [m for m in calls.marks(g["text"]) if m[2] == "number"]
    r["tone_word"] = calls.tone_word(r["tone"]["net"])
    # the day of the call (as on the PC): said in the call, else the results release at the SEC (8-K 2.02).
    # ctx: {"history": [{label, end}], "earnings": [dates]} from the PC's data
    ctx = json.loads(ctx_text) if ctx_text else {}
    r["date"] = r["date_how"] = None
    q = call.get("quarter")
    ends = [h for h in (ctx.get("history") or []) if h.get("end")]
    subs = {"filings": {"recent": {"form": ["8-K"] * len(ctx.get("earnings") or []),
                                   "items": ["2.02"] * len(ctx.get("earnings") or []),
                                   "filingDate": list(ctx.get("earnings") or [])}}}
    for h in sorted(ends, key=lambda x: x["end"], reverse=True):
        if q in (calls.quarter_of(h.get("label"), h["end"]), calls.quarter_of(None, h["end"])):
            r["date"], r["date_how"] = calls.call_date(call, h["end"], subs)
            break
    return json.dumps(r)


def call_quarters(label, end):
    """The quarters to ask Alpha Vantage for, in order (same as the PC)."""
    from . import calls
    q = calls.quarter_of(label, end)
    cal = calls.quarter_of(None, end)
    out = [q] + ([cal] if cal and cal != q else []) + [calls.previous(q)]
    return json.dumps([x for i, x in enumerate(out) if x and x not in out[:i]])


def version():
    from . import VERSION, rules
    return json.dumps({"version": VERSION, "method": rules.METHOD_VERSION})


def news_update(payload):
    """The News page on the phone. payload: {texts: {feed id: XML}, errors: {feed id: text}, stories: [kept],
    universe_raw: Nasdaq JSON text or null, universe: [[sym, name, cap]] kept, mine: [tickers], now: seconds}.
    Returns {stories, feeds, fetched, n_items, universe (rows, only when new), n_universe, mine}."""
    import time as _t
    from . import news
    p = json.loads(payload)
    now = p.get("now") or _t.time()
    items = {}
    for s in p.get("stories") or []:                     # what the phone kept: the stories, back to headlines
        for x in [s] + (s.get("also") or []):
            items.setdefault(x["link"], {k: x.get(k) for k in ("title", "link", "time", "source", "section",
                                                                 "symbols")})
    texts, errors = p.get("texts") or {}, p.get("errors") or {}
    feeds = dict(p.get("feeds") or {}) if p.get("fast_only") else {}
    for src, sec, url in news.FEEDS:
        fid = news.feed_id(src, sec)
        if fid not in texts:
            if fid in errors:
                feeds[url] = {"ok": False, "n": 0, "err": errors[fid], "time": now}
            continue
        try:
            got = news.read(texts[fid], src, sec)
            feeds[url] = {"ok": True, "n": len(got), "err": None, "time": now}
        except Exception as e:
            got = []
            feeds[url] = {"ok": False, "n": 0, "err": f"{type(e).__name__}", "time": now}
        for it in got:
            if it["time"] is None:
                it["time"] = (items.get(it["link"]) or {}).get("time") or now
            items.setdefault(it["link"], it)
    cut = now - news.KEEP_HOURS * 3600
    kept = [i for i in items.values() if (i.get("time") or 0) >= cut]
    rows, new_rows = p.get("universe") or [], None
    if p.get("universe_raw"):
        try:
            got = news.parse_universe(json.loads(p["universe_raw"]))
            if len(got) > 1000:
                rows = new_rows = got
        except Exception:
            pass
    full = texts and not p.get("fast_only")
    out = news.stories_from({"items": kept, "feeds": feeds, "fetched": now if full else p.get("fetched", 0)},
                            rows, p.get("mine") or [])
    out["fast_fetched"] = now
    out["n_universe"] = len(rows)
    out["universe"] = new_rows
    out.pop("feeds_all", None)
    return json.dumps(out)


def entry(payload):
    """6 · Entry & sizing on the phone, with the PC's rules (technical.py). payload (JSON text): ticker, chart and
    spy (Yahoo chart JSON, 10 years daily, fetched by the phone), earnings (release dates), fv (fair value), held
    (amount held, 0 when none), target (weight), total (portfolio value; 100,000 when unknown), fx, span (days)."""
    from . import technical as TA, fundamentals as F
    p = json.loads(payload)

    def rows_of(txt):
        if not txt:
            return []
        d = json.loads(txt) if isinstance(txt, str) else txt
        r = ((d or {}).get("chart") or {}).get("result") or []
        return [x for x in F._rows(r[0]) if x[4]] if r else []
    rows, spy = rows_of(p.get("chart")), rows_of(p.get("spy"))
    if len(rows) < 30:
        return json.dumps({"error": "No price history from Yahoo for " + p.get("ticker", "")})
    s = TA.Series(rows, spy)
    a = TA.analyze(s, earnings=p.get("earnings") or [])
    fv, px = p.get("fv"), a["price"]
    disc = (1 - px / fv) if fv else None
    held = float(p.get("held") or 0)
    key, label, meaning = TA.verdict(a, disc, held)
    total = float(p.get("total") or 100000.0)
    plan = TA.plan(a, float(p.get("target") or 0.10), total, held, fx=float(p.get("fx") or 1.0), discount=disc)
    flag = 1e-9 if held > 0 else 0.0
    marks = {}
    for st in TA.plan(a, 0.10, 100.0, flag, discount=disc).get("steps") or []:
        if st["price"] < px * 0.999 and not st["why"].startswith("time"):
            marks.setdefault(round(st["price"], 2), st["step"])
    levels = [{"price": lv["price"], "what": " + ".join(lv["what"]), "buy": marks.get(round(lv["price"], 2))}
              for lv in a.get("levels") or []]
    n = int(p.get("span") or 504)
    i0 = max(0, len(s.c) - n)
    r2 = lambda x, k=2: None if x is None else round(x, k)
    chart = {"d": s.d[i0:], "c": [r2(x) for x in s.c[i0:]], "h": [r2(x) for x in s.h[i0:]],
             "l": [r2(x) for x in s.l[i0:]], "v": s.v[i0:], "e50": [r2(x) for x in s.e50[i0:]],
             "e200": [r2(x) for x in s.e200[i0:]], "rsi": [r2(x, 1) for x in s.rsi[i0:]]}
    if plan.get("above"):
        pace = plan.get("note") or ""
    elif plan.get("steps"):
        pace = (f"Pace: {disc * 100:.0f}% below the fair value → batches ×{plan['pace']:.2f}, next step every "
                f"{plan['wait']} days if no level is reached" if disc is not None else
                f"Pace: no fair value → normal batches, every {plan['wait']} days")
    else:
        pace = ""
    return json.dumps({"ticker": p.get("ticker"), "state": key, "label": label, "meaning": meaning, "price": px,
                       "date": s.d[-1], "fv": fv, "discount": disc, "reading": TA.reading_rows(a),
                       "short": bool(a.get("short")), "reasons": a.get("reasons") or [], "levels": levels,
                       "plan": {"steps": plan.get("steps") or [], "note": None if plan.get("above") else plan.get("note"),
                                "left": plan.get("left"), "pace": pace}, "chart": chart}, default=str)
