"""The PC engine, run inside the phone's browser (Pyodide): grade a company from SEC data the phone fetched.

Same code as Tarsier.exe, so the same grade. The phone writes the SEC files into Pyodide's in-memory disk,
this runs the usual pipeline offline on them and returns the company exactly as the PC would publish it,
marked as a quick look.
"""
import json
import os

from . import mobile, paths, pipeline


def grade(ticker, facts_text, subs_text=None, price=None, price_time=None):
    """JSON text of one company, in the same shape as data.json's companies (grades, numbers, valuation, Compare)."""
    t = ticker.upper()
    os.makedirs(paths.CACHE, exist_ok=True)
    with open(os.path.join(paths.CACHE, f"{t}_companyfacts.json"), "w", encoding="utf-8") as f:
        f.write(facts_text)
    if subs_text:
        with open(os.path.join(paths.CACHE, f"{t}_submissions.json"), "w", encoding="utf-8") as f:
            f.write(subs_text)
    pipeline.mark_quick(t, "phone")
    market = {"price": float(price), "source": "Yahoo Finance (phone)", "time": price_time or ""} if price else None
    company = mobile.company(t, market)
    return mobile.dumps(company)


def version():
    from . import VERSION, rules
    return json.dumps({"version": VERSION, "method": rules.METHOD_VERSION})
