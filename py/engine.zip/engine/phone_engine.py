"""The PC engine, run inside the phone's browser (Pyodide): grade a company from SEC data the phone fetched.

Same code as Tarsier.exe, so the same grade. The phone writes the SEC files into Pyodide's in-memory disk,
this runs the usual pipeline offline on them and returns the company exactly as the PC would publish it,
marked as a quick look.
"""
import json
import os

from . import mobile, paths, pipeline


def grade(ticker, facts_text, subs_text=None, price=None, price_time=None):
    """JSON text of one company, in the same shape as data.json's companies (grades, numbers, valuation, Compare)."""
    t = ticker.upper()
    os.makedirs(paths.CACHE, exist_ok=True)
    with open(os.path.join(paths.CACHE, f"{t}_companyfacts.json"), "w", encoding="utf-8") as f:
        f.write(facts_text)
    if subs_text:
        with open(os.path.join(paths.CACHE, f"{t}_submissions.json"), "w", encoding="utf-8") as f:
            f.write(subs_text)
    pipeline.mark_quick(t, "phone")
    market = {"price": float(price), "source": "Yahoo Finance (phone)", "time": price_time or ""} if price else None
    company = mobile.company(t, market)
    return mobile.dumps(company)


def revalue(payload_text):
    """Rework one company's projection on the phone: the PC's history and choices plus what was typed on the
    phone (growth, multiples, method). Same code as page 2 on the PC; JSON text shaped like data.json's
    valuation."""
    import datetime as dt
    p = json.loads(payload_text)
    h = p["hist"]
    h["fya_end"] = dt.date.fromisoformat(h["fya_end"])
    user = p.get("user") or {}
    fy = lambda d: {int(k): v for k, v in (d or {}).items() if v is not None}   # JSON keys are text
    user = {"settings": user.get("settings") or {},
            "consensus": {k: fy(v) for k, v in (user.get("consensus") or {}).items()},
            "scen": {s: {k: fy(v) for k, v in (d or {}).items()} for s, d in (user.get("scen") or {}).items()}}
    market = {"price": float(p["price"]), "source": p.get("price_source") or "the phone", "time": ""} \
        if p.get("price") else None
    v = mobile._valuation({"projection": {"hist": h, "user": user}}, None, market)
    return mobile.dumps(v)


def call_reading(call_text, prev_text=None):
    """Read an earnings call on the phone with the PC's rules (calls.py). The phone fetched the transcript from
    Alpha Vantage itself and keeps it; nothing here is published. JSON text: the reading, and each turn with where
    to mark it (numbers, guidance, hedging, dodges)."""
    from . import calls
    call = json.loads(call_text)
    prev = json.loads(prev_text) if prev_text else None
    r = calls.analyze(call, prev if prev and prev.get("turns") else None)
    r.pop("bigrams", None)
    for t in r["turns"]:
        t["marks"] = calls.marks(t["text"]) if t["role"] != "operator" else []
    for g in r["guidance"]:
        g["marks"] = [m for m in calls.marks(g["text"]) if m[2] == "number"]
    r["tone_word"] = calls.tone_word(r["tone"]["net"])
    return json.dumps(r)


def call_quarters(label, end):
    """The quarters to ask Alpha Vantage for, in order (same as the PC)."""
    from . import calls
    q = calls.quarter_of(label, end)
    cal = calls.quarter_of(None, end)
    out = [q] + ([cal] if cal and cal != q else []) + [calls.previous(q)]
    return json.dumps([x for i, x in enumerate(out) if x and x not in out[:i]])


def version():
    from . import VERSION, rules
    return json.dumps({"version": VERSION, "method": rules.METHOD_VERSION})
