"""What the next years should look like, from people who know: the company's own guidance (read from its
earnings call) and the analysts' consensus (Alpha Vantage, EARNINGS_ESTIMATES). Page 2 uses them in this
order, after what you typed: yours → guidance you accepted → analysts.

Kept in companies/<TICKER>/estimates.json until the next earnings (estimated) or 60 days at most, so a stock
costs one Alpha Vantage request a quarter. The raw answer is kept too, to check it if a field looks wrong.
"""
import json
import os
import re
import time
from datetime import date, timedelta

KEEP_DAYS = 60


def _path(ticker):
    from . import paths
    return os.path.join(paths.company_dir(ticker), "estimates.json")


def load(ticker):
    try:
        with open(_path(ticker), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save(ticker, rec):
    p = _path(ticker)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(rec, f, ensure_ascii=False)
    os.replace(tmp, p)


def fresh(rec, today=None):
    today = today or date.today().isoformat()
    return bool(rec.get("analysts_fetched")) and today < (rec.get("valid_until") or "")


# ---------- the analysts: Alpha Vantage EARNINGS_ESTIMATES ---------------------------------------------------
def _num(x):
    try:
        v = float(str(x).replace(",", ""))
        return v if v == v else None
    except (TypeError, ValueError):
        return None


def _pick(row, *names):
    """The first field whose name (lower case, no _ or spaces) matches one of the names."""
    norm = {re.sub(r"[_\s]", "", str(k).lower()): v for k, v in row.items()}
    for n in names:
        if n in norm and norm[n] not in (None, "", "None", "-"):
            return norm[n]
    return None


def parse_av(data):
    """[{end, horizon, eps, revenue (USD), eps_n, revenue_n}] from Alpha Vantage's answer, whatever the list is called."""
    rows = None
    for k in ("estimates", "data", "annualEstimates", "earningsEstimates", "quarterlyEstimates"):
        if isinstance((data or {}).get(k), list):
            rows = data[k]
            break
    if rows is None:
        rows = next((v for v in (data or {}).values() if isinstance(v, list) and v and isinstance(v[0], dict)), [])
    out = []
    for r in rows:
        end = _pick(r, "date", "fiscaldateending", "fiscalperiodend", "period", "enddate")
        hz = str(_pick(r, "horizon", "periodtype", "type") or "").lower()
        eps = _num(_pick(r, "epsestimateaverage", "epsestimateavg", "estimatedepsavg", "epsavg", "eps", "epsestimate"))
        rev = _num(_pick(r, "revenueestimateaverage", "revenueestimateavg", "estimatedrevenueavg", "revenueavg",
                         "revenue", "revenueestimate"))
        if not end or (eps is None and rev is None):
            continue
        annual = any(w in hz for w in ("year", "annual", "fy")) or (not hz and "q" not in str(end).lower())
        out.append({"end": str(end)[:10], "horizon": "year" if annual else "quarter", "eps": eps, "revenue": rev,
                    "eps_n": _num(_pick(r, "epsestimateanalystcount", "numberanalystsestimatedeps", "epsanalysts")),
                    "revenue_n": _num(_pick(r, "revenueestimateanalystcount", "numberanalystsestimatedrevenue",
                                            "revenueanalysts"))})
    return out


def fetch_analysts(ticker, say=None):
    """One Alpha Vantage request. Raises calls.Limit when there is no key or no requests left."""
    import urllib.parse
    import urllib.request
    from . import calls
    key = calls.api_key()
    if not key:
        raise calls.Limit("no Alpha Vantage key: add the free key in Settings → Earnings calls")
    if say:
        say(f"Asking Alpha Vantage for {ticker}'s analyst estimates…")
    url = calls.AV_URL + "?" + urllib.parse.urlencode({"function": "EARNINGS_ESTIMATES", "symbol": ticker,
                                                       "apikey": key})

    def ask(_t, _q, _k):
        req = urllib.request.Request(url, headers={"User-Agent": "Tarsier Research", "Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=30) as r:
            data = json.loads(r.read().decode("utf-8"))
        for k in ("Information", "Note", "Error Message"):
            if isinstance(data, dict) and data.get(k):
                raise calls.Limit(str(data[k])[:240])
        return data
    return calls._get_av(ticker, "", key, ask=ask)      # the same pacing and retries as the transcripts


def refresh(ticker, next_earnings=None, say=None):
    """Ask the analysts again (1 request) and keep the answer until the next earnings or 60 days."""
    rec = load(ticker)
    raw = fetch_analysts(ticker, say)
    today = date.today()
    until = (today + timedelta(days=KEEP_DAYS)).isoformat()
    if next_earnings and today.isoformat() < next_earnings < until:
        until = (date.fromisoformat(next_earnings) + timedelta(days=2)).isoformat()   # after the results are out
    rec.update(analysts=parse_av(raw), analysts_raw=raw, analysts_fetched=time.strftime("%Y-%m-%d %H:%M"),
               valid_until=until)
    save(ticker, rec)
    return rec


# ---------- the company: guidance from its latest earnings call -------------------------------------------------
MONEY = re.compile(r"\$\s?(\d[\d,]*(?:\.\d+)?)\s?(billion|million|bn|b|m)?\b", re.I)
EPS_WORD = re.compile(r"\b(eps|earnings per (?:diluted )?share|per share)\b", re.I)
REV_WORD = re.compile(r"\b(revenue|revenues|sales)\b", re.I)
YEAR_WORD = re.compile(r"\b(full[- ]year|fiscal (?:year )?(20\d\d)|for the (?:full )?year|annual|fiscal 20\d\d|"
                       r"fy ?(20)?\d\d)\b", re.I)
QUARTER_WORD = re.compile(r"\b(quarter|q[1-4])\b", re.I)
NOT_TOTAL = re.compile(r"\b(subscription|segment|cloud|services|product|data center|organic|recurring|arr)\b", re.I)


def _range_mid(s, kind):
    """The midpoint of '$4.2 billion to $4.25 billion' ($M), or of '$1.10 to $1.20' (EPS)."""
    vals = []
    for m in MONEY.finditer(s):
        v = float(m.group(1).replace(",", ""))
        unit = (m.group(2) or "").lower()
        if kind == "revenue":
            if unit in ("billion", "bn", "b"):
                v *= 1000
            elif unit not in ("million", "m"):
                continue
        elif unit:
            continue
        vals.append(v)
    if not vals:
        return None
    vals = vals[:2]
    return sum(vals) / len(vals)


def guidance_proposals(ticker, h):
    """[{fy, kind, value, sentence, how}] the latest saved call suggests for page 2. Nothing is used until you
    accept it: reading numbers out of sentences can go wrong."""
    from . import calls, projection as P
    have = calls.stored(ticker)
    if not have:
        return []
    call = calls.load(ticker, have[0])
    try:
        r = calls.analyze(call)
    except Exception:
        return []
    fy0 = h["fy0"]
    c = P.constants(h)
    out, seen = [], set()
    for g in r["guidance"]:
        s = g["text"]
        is_eps, is_rev = bool(EPS_WORD.search(s)), bool(REV_WORD.search(s))
        kind = "eps" if is_eps and not is_rev else "revenue" if is_rev and not is_eps else None
        if not kind or (kind == "revenue" and NOT_TOTAL.search(s)):
            continue
        v = _range_mid(s, kind)
        if v is None:
            continue
        ym = YEAR_WORD.search(s)
        if ym:
            yr = re.search(r"20(\d\d)", ym.group(0))
            fy = int("20" + yr.group(1)) if yr else fy0
            if fy < fy0 or fy > fy0 + P.YEARS - 1:
                continue
            how = "full-year guidance"
        elif QUARTER_WORD.search(s) and kind == "revenue" and c.get("ytd_n") == 3 and c.get("ytd_rev") is not None:
            fy, how = fy0, "next quarter's guidance + the 3 quarters already reported"
            v = c["ytd_rev"] + v
        else:
            continue
        key = (fy, kind)
        if key in seen:
            continue
        seen.add(key)
        out.append({"fy": fy, "kind": kind, "value": v, "sentence": s, "how": how, "speaker": g.get("speaker"),
                    "quarter": have[0]})
    return out


def accept(ticker, prop):
    rec = load(ticker)
    acc = rec.setdefault("guidance", {})
    acc.setdefault(prop["kind"], {})[str(prop["fy"])] = {k: prop[k] for k in ("value", "sentence", "how", "quarter")}
    save(ticker, rec)


def drop(ticker, kind, fy):
    rec = load(ticker)
    (rec.get("guidance") or {}).get(kind, {}).pop(str(fy), None)
    save(ticker, rec)


# ---------- what page 2 uses ---------------------------------------------------------------------------------------
def for_history(ticker, h):
    """{'revenue': {fy: {value ($M), src, n}}, 'eps': {...}, fetched, valid_until} for projection.compute."""
    from . import projection as P
    rec = load(ticker) if ticker else {}
    if not rec:
        return {}
    fys = [h["fy0"] + i for i in range(P.YEARS)]
    ends = [P.add_years(h["fya_end"], i + 1) for i in range(P.YEARS)]
    out = {"revenue": {}, "eps": {}, "fetched": rec.get("analysts_fetched"), "valid_until": rec.get("valid_until")}
    for row in rec.get("analysts") or []:
        if row["horizon"] != "year":
            continue
        try:
            d = date.fromisoformat(row["end"])
        except ValueError:
            continue
        for fy, e in zip(fys, ends):
            if abs((d - e).days) <= 45:
                if row.get("revenue"):
                    out["revenue"][fy] = {"value": row["revenue"] / 1e6, "src": "consensus", "n": row.get("revenue_n")}
                if row.get("eps") is not None:
                    out["eps"][fy] = {"value": row["eps"], "src": "consensus", "n": row.get("eps_n")}
    for kind, d in (rec.get("guidance") or {}).items():
        for fy, g in d.items():
            if int(fy) in fys:
                out[kind][int(fy)] = {"value": g["value"], "src": "guidance", "sentence": g.get("sentence")}
    return out
