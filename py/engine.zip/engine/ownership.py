"""Who owns the company and what they do, free:
- insiders (officers, directors, 10% owners): their Form 4 filings at the SEC, read one by one and kept, so only
  new ones are read again. Open-market buys (code P) and sales (code S); sales under a Rule 10b5-1 plan (set in
  advance) are told apart from the others. Grants, option exercises and tax withholding are left out.
- institutions (13F filers): Nasdaq's free summary of the latest 13F filings: % owned, holders, who added or
  cut, the largest holders. Kept a week (13F filings are quarterly)."""
import json
import os
import re
import time
import urllib.request
import xml.etree.ElementTree as ET
from datetime import date, timedelta

from . import paths

INSIDER_FRESH = 24 * 3600
INST_FRESH = 7 * 24 * 3600
WINDOW_DAYS = 400            # Form 4 filings read: the last 13 months (12 months shown, the extra for holdings)
MAX_NEW = 250                # at most this many Form 4 read in one go (the first time for a busy company)
TITLES_TOP = re.compile(r"\b(chief executive|ceo|chief financial|cfo|president|chair|founder)\b", re.I)


def _file(ticker, name):
    return os.path.join(paths.company_dir(ticker.upper()), name)


def _read(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _write(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path + ".tmp", "w", encoding="utf-8") as f:
        json.dump(obj, f)
    os.replace(path + ".tmp", path)


# ---------- insiders: SEC Form 4 ---------------------------------------------------------------------------------
def _txt(el, path):
    x = el.find(path)
    if x is None:
        return None
    v = x.find("value")
    t = (v.text if v is not None else x.text) or ""
    return t.strip() or None


def _num(s):
    try:
        return float(str(s).replace(",", ""))
    except (TypeError, ValueError):
        return None


def parse_form4(xml_text):
    """{owners: [{cik, name, title, director, officer, ten_pct}], plan: bool, tx: [...], hold: [...]}.
    tx: {date, code, shares, price, ad, after, direct, security}; hold: {shares, direct, security}."""
    t = re.sub(r"^\s*<\?xml[^>]*\?>", "", xml_text.strip())
    root = ET.fromstring(t)
    owners = []
    for ro in root.findall("reportingOwner"):
        rel = ro.find("reportingOwnerRelationship")
        flag = (lambda k: (rel is not None and (_txt(rel, k) or "").lower() in ("1", "true")))
        owners.append({"cik": _txt(ro, "reportingOwnerId/rptOwnerCik"),
                       "name": _txt(ro, "reportingOwnerId/rptOwnerName") or "?",
                       "title": (_txt(rel, "officerTitle") if rel is not None else None) or "",
                       "director": flag("isDirector"), "officer": flag("isOfficer"),
                       "ten_pct": flag("isTenPercentOwner")})
    notes = " ".join((f.text or "") for f in root.iter("footnote"))
    plan = (_txt(root, "aff10b5One") or "").lower() in ("1", "true") or bool(re.search(r"10b5-?1", notes, re.I))
    tx, hold = [], []
    for kind in ("nonDerivativeTable/nonDerivativeTransaction", "nonDerivativeTable/nonDerivativeHolding"):
        for el in root.findall(kind):
            sec = _txt(el, "securityTitle") or ""
            after = _num(_txt(el, "postTransactionAmounts/sharesOwnedFollowingTransaction"))
            direct = (_txt(el, "ownershipNature/directOrIndirectOwnership") or "D").upper() == "D"
            if kind.endswith("Holding"):
                hold.append({"shares": after, "direct": direct, "security": sec})
                continue
            tx.append({"date": _txt(el, "transactionDate"), "code": _txt(el, "transactionCoding/transactionCode"),
                       "shares": _num(_txt(el, "transactionAmounts/transactionShares")),
                       "price": _num(_txt(el, "transactionAmounts/transactionPricePerShare")),
                       "ad": _txt(el, "transactionAmounts/transactionAcquiredDisposedCode"),
                       "after": after, "direct": direct, "security": sec})
    return {"owners": owners, "plan": plan, "tx": tx, "hold": hold}


def _form4_list(subs, since):
    r = ((subs or {}).get("filings") or {}).get("recent") or {}
    out = []
    for i, form in enumerate(r.get("form") or []):
        if form != "4":
            continue
        fd = (r.get("filingDate") or [""])[i]
        if fd < since:
            continue
        out.append((r["accessionNumber"][i], fd, (r.get("primaryDocument") or [""])[i]))
    return out


def insiders_load(ticker):
    return _read(_file(ticker, "insiders.json")) or {"fetched": 0, "filings": {}}


RETRY = 6 * 3600              # after a failed try, the next one waits this long


def _fresh(d, ttl):
    now = time.time()
    return now - d.get("fetched", 0) < ttl or now - d.get("tried", 0) < RETRY


def insiders_fresh(ticker):
    return _fresh(insiders_load(ticker), INSIDER_FRESH)


def insiders_update(ticker, progress=None):
    """Reads the Form 4 filings not read yet (newest first), keeps them in companies/<T>/insiders.json."""
    from . import edgar
    say = progress or (lambda _m: None)
    t = ticker.upper()
    ua = edgar.load_config()["sec_user_agent"]
    cik = edgar.ticker_to_cik(t, ua)
    subs = edgar._get(edgar.SUBS_URL.format(cik=cik), ua)
    d = insiders_load(t)
    since = (date.today() - timedelta(days=WINDOW_DAYS)).isoformat()
    have = d.get("filings") or {}
    todo = [f for f in _form4_list(subs, since) if f[0] not in have][:MAX_NEW]
    errors = 0
    for n, (acc, fd, doc) in enumerate(todo, 1):
        say(f"Reading {t}'s insider filings (Form 4): {n} of {len(todo)}")
        name = doc.split("/")[-1] if doc else ""
        url = f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{acc.replace('-', '')}/{name}"
        try:
            have[acc] = {"filed": fd, **parse_form4(edgar.get_text(url, ua))}
        except Exception:
            errors += 1
            have[acc] = {"filed": fd, "error": True, "owners": [], "tx": [], "hold": [], "plan": False}
    have = {a: f for a, f in have.items() if f.get("filed", "") >= since}
    d = {"fetched": time.time(), "cik": cik, "filings": have, "errors": errors}
    _write(_file(t, "insiders.json"), d)
    return d


def _role(o):
    if o.get("title"):
        return o["title"]
    return "Director" if o.get("director") else "10% owner" if o.get("ten_pct") else "Officer" if o.get("officer") else ""


def _common(sec):
    s = (sec or "").lower()
    return not s or any(w in s for w in ("common", "ordinary", "class a", "class b", "class c", "shares"))


def insiders_summary(d, shares_out=None, today=None):
    """Open-market buys and sales over 3 and 12 months, who, planned or not; insider ownership."""
    today = today or date.today()
    c12, c3 = (today - timedelta(days=365)).isoformat(), (today - timedelta(days=91)).isoformat()
    trades, latest = [], {}
    for acc, f in (d.get("filings") or {}).items():
        if f.get("error"):
            continue
        owners = f.get("owners") or []
        o = owners[0] if owners else {}
        who = " · ".join(x["name"] for x in owners[:2])
        role = _role(o)
        insider = any(x.get("director") or x.get("officer") for x in owners)
        for x in f.get("tx") or []:
            if x.get("code") in ("P", "S") and x.get("shares") and _common(x.get("security")):
                trades.append({"date": x.get("date") or f["filed"], "who": who, "role": role,
                               "kind": "buy" if x["code"] == "P" else "sell", "shares": x["shares"],
                               "price": x.get("price"), "value": (x.get("price") or 0) * x["shares"],
                               "plan": bool(f.get("plan")) and x["code"] == "S", "top": bool(TITLES_TOP.search(role)),
                               "insider": insider})
        # holdings after the filing, per owner and direct/indirect: the newest filing wins
        for x in (f.get("tx") or []) + (f.get("hold") or []):
            if x.get("after") is None or not _common(x.get("security")) or not owners:
                continue
            key = (o.get("cik") or o.get("name"), x.get("direct"))
            when = (x.get("date") or f["filed"], f["filed"])
            if key not in latest or when >= latest[key][0]:
                latest[key] = (when, x["after"], insider, bool(o.get("ten_pct")) and not insider)
    trades.sort(key=lambda x: x["date"], reverse=True)

    def agg(since, kind, plan=None):
        xs = [x for x in trades if x["date"] >= since and x["kind"] == kind and (plan is None or x["plan"] == plan)]
        return sum(x["value"] for x in xs), len({x["who"] for x in xs}), len(xs)
    b12, nb12, _ = agg(c12, "buy")
    s12, ns12, _ = agg(c12, "sell")
    sp12, _, _ = agg(c12, "sell", True)
    b3, nb3, _ = agg(c3, "buy")
    s3, _, _ = agg(c3, "sell")
    held = sum(v[1] for v in latest.values() if v[2])
    big = sum(v[1] for v in latest.values() if v[3])
    top_buy = [x for x in trades if x["date"] >= (today - timedelta(days=182)).isoformat() and x["kind"] == "buy"
               and x["top"]]
    return {"buys_12m": b12, "buyers_12m": nb12, "sells_12m": s12, "sellers_12m": ns12,
            "sells_plan_12m": sp12, "buys_3m": b3, "buyers_3m": nb3, "sells_3m": s3,
            "own_insiders": held / shares_out if shares_out and held else None,
            "own_10pct": big / shares_out if shares_out and big else None,
            "top_bought": sorted({x["who"] + " (" + x["role"] + ")" for x in top_buy}),
            "trades": [x for x in trades if x["date"] >= c12][:40],
            "n_filings": len(d.get("filings") or {}), "fetched": d.get("fetched")}


# ---------- institutions: Nasdaq's 13F summary --------------------------------------------------------------------
NASDAQ = ("https://api.nasdaq.com/api/company/{t}/institutional-holdings?limit=15&type=TOTAL"
          "&sortColumn=marketValue&sortOrder=DESC")


def _get_json(url):
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                      "Chrome/131.0 Safari/537.36",
        "Accept": "application/json, text/plain, */*", "Accept-Language": "en-US,en",
        "Origin": "https://www.nasdaq.com", "Referer": "https://www.nasdaq.com/"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def _n(s):
    if s is None:
        return None
    s = str(s).strip().replace(",", "").replace("$", "").replace("%", "")
    if s in ("", "N/A", "NA", "--"):
        return None
    try:
        return float(s)
    except ValueError:
        return None


def _rows(block):
    """Rows of a Nasdaq table, wherever they sit ({rows}, {table: {rows}}, [..])."""
    if isinstance(block, list):
        return block
    if not isinstance(block, dict):
        return []
    if isinstance(block.get("rows"), list):
        return block["rows"]
    if isinstance(block.get("table"), dict):
        return _rows(block["table"])
    return []


def _pick(row, *names):
    low = {k.lower(): v for k, v in (row or {}).items()}
    for n in names:
        if n.lower() in low:
            return low[n.lower()]
    return None


def parse_institutions(j):
    """{pct, inst_shares, holders, increased: (holders, shares), decreased, held, new, sold_out, top: [...]}"""
    d = (j or {}).get("data") or {}
    out = {"top": []}
    summ = d.get("ownershipSummary") or {}
    for k, v in summ.items():
        lab = (v.get("label") if isinstance(v, dict) else k) or k
        val = v.get("value") if isinstance(v, dict) else v
        l = lab.lower()
        if "institutional ownership" in l or k.lower() == "sharesoutstandingpct":
            x = _n(val)
            out["pct"] = x / 100 if x is not None else None
        elif "total value" in l:
            x = _n(val)
            out["value"] = x * 1e6 if x is not None else None
    for r in _rows(d.get("activePositions")) + _rows(d.get("newSoldOutPositions")):
        lab = str(_pick(r, "positions", "label") or "").lower()
        pair = (_n(_pick(r, "holders")), _n(_pick(r, "shares")))
        for key, word in (("increased", "increased"), ("decreased", "decreased"), ("held", "held"),
                          ("new", "new"), ("sold_out", "sold out"), ("total", "total")):
            if word in lab:
                out[key] = pair
    ht = d.get("holdingsTransactions") or {}
    out["holders"] = _n(_pick(ht, "institutionalHolders")) or (out.get("total") or (None,))[0]
    out["inst_shares"] = _n(_pick(ht, "sharesHeld")) or (out.get("total") or (None, None))[1]
    for r in _rows(ht):
        out["top"].append({"name": str(_pick(r, "ownerName", "name") or "").strip(),
                           "date": _pick(r, "date"), "shares": _n(_pick(r, "sharesHeld")),
                           "change": _n(_pick(r, "sharesChange")), "change_pct": _n(_pick(r, "sharesChangePCT")),
                           "value": (_n(_pick(r, "marketValue")) or 0) * 1000 or None})
    inc, dec = out.get("increased"), out.get("decreased")
    tot = out.get("inst_shares")
    if inc and dec and inc[1] is not None and dec[1] is not None and tot:
        out["net_change"] = (inc[1] - dec[1]) / tot
    return out


def institutions_load(ticker):
    return _read(_file(ticker, "institutions.json")) or {}


def institutions_fresh(ticker):
    return _fresh(institutions_load(ticker), INST_FRESH)


def institutions_update(ticker):
    t = ticker.upper()
    raw = _get_json(NASDAQ.format(t=t.replace("-", ".").lower()))
    p = parse_institutions(raw)
    if p.get("pct") is None and not p.get("top"):
        raise ValueError("Nasdaq has no institutional data for " + t)
    d = {"fetched": time.time(), **p}
    _write(_file(t, "institutions.json"), d)
    return d


def refresh(ticker, force=False, progress=None):
    """Whatever is stale, again; a failure keeps what was kept and waits 6 hours. Returns the problems, in words."""
    errs = []
    if force or not insiders_fresh(ticker):
        try:
            insiders_update(ticker, progress)
        except Exception as e:
            d = insiders_load(ticker)
            d.update(tried=time.time(), error=f"{type(e).__name__}: {e}")
            _write(_file(ticker, "insiders.json"), d)
            errs.append(f"insider filings (SEC) not read now: {e}")
    if force or not institutions_fresh(ticker):
        if progress:
            progress(f"Getting {ticker.upper()}'s institutional holders (13F, Nasdaq)…")
        try:
            institutions_update(ticker)
        except Exception as e:
            d = institutions_load(ticker)
            d.update(tried=time.time(), error=f"{type(e).__name__}: {e}")
            _write(_file(ticker, "institutions.json"), d)
            errs.append(f"institutional holders (Nasdaq) not available now: {type(e).__name__}")
    return errs


# ---------- for the fundamentals page ----------------------------------------------------------------------------
def values(ticker, shares_out=None):
    """The ownership rows of page 1 (fundamentals.build adds them), from what is kept: no network."""
    out = {}
    d = insiders_load(ticker)
    if d.get("fetched"):
        s = insiders_summary(d, shares_out)
        out.update({"insider_own": s["own_insiders"], "insider_buys": s["buys_12m"], "insider_sells": s["sells_12m"],
                    "_ins": s})
    i = institutions_load(ticker)
    if i.get("fetched") and (i.get("pct") is not None or i.get("top")):
        out.update({"inst_own": i.get("pct"), "inst_holders": i.get("holders"), "inst_change": i.get("net_change"),
                    "_inst": {k: v for k, v in i.items() if k != "fetched"} | {"fetched": i["fetched"]}})
    return out
