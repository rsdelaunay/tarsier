"""Checks on the numbers read from the SEC, so a misread (the wrong revenue line, a lender's loans in its cash
flow, a merger's share count) shows up instead of hiding inside a grade. Each check: (level, text), level
"warn" (look before trusting the grade) or "info". Used on Earnings results (PC and phone) and in Settings."""
from . import xbrl


def _pct(x):
    return f"{x * 100:+.0f}%"


def _m(x):
    a = abs(x)
    s = f"${a / 1e9:.1f}B" if a >= 1e9 else f"${a / 1e6:.0f}M"
    return ("−" if x < 0 else "") + s


def checks(co, end):
    out = []
    ends = co.quarter_ends()
    if end not in ends:
        return out
    k = ends.index(end)
    rt, ft, nt = co.ttm("revenue", end), co.ttm("fcf", end), co.ttm("net_income", end)
    sn = co.snapshot(end) or {}
    # 1. free cash flow far below the profit: loans, deposits or customer money in operating cash flow
    if rt and ft is not None and nt is not None and nt > 0 and ft < -0.5 * rt:
        out.append(("warn", f"Free cash flow {_m(ft)} against a profit of {_m(nt)} in 12 months: operating cash "
                            "flow probably includes loans, deposits or customers' money. Check the cash flow "
                            "statement before trusting the Cash block."))
    hfs = co.ttm("hfs_out", end)
    if hfs:
        out.append(("info", f"Lender: {_m(hfs)} of loans made to sell were taken out of operating cash flow "
                            f"(reported: {_m(co.ttm('cfo_reported', end) or 0)})."))
    # 2. a net margin no business earns: a one-off gain, or revenue missing a part
    if rt and nt is not None and rt > 0 and nt / rt > 0.8:
        out.append(("warn", f"Net margin {nt / rt * 100:.0f}% over 12 months: a one-off gain (a sale, a tax "
                            "benefit) or a revenue line that misses part of the revenue."))
    # 3. revenue jumping from one quarter to the next
    if k >= 1:
        a, b = co.v("revenue", ends[k - 1]), co.v("revenue", end)
        if a and b and a > 0 and (b / a >= 2.5 or b / a <= 0.4):
            out.append(("warn", f"Revenue {_m(a)} → {_m(b)} from one quarter to the next: an acquisition, a "
                                "disposal or a change in how revenue is reported. Growth may not compare."))
    # 4. the revenue line changed (the tag the company uses)
    recent = [co.q["revenue"].get(e, {}).get("concept") for e in ends[max(0, k - 4):k + 1]]
    if len({c for c in recent if c}) > 1:
        out.append(("info", "The company changed the line it reports revenue on in the last year ("
                            + " → ".join(dict.fromkeys(c for c in recent if c)) + "): growth compares across it."))
    # 5. EPS that does not match profit ÷ shares
    eps, ni, sh = sn.get("eps_diluted"), sn.get("net_income"), sn.get("shares_diluted")
    if eps is not None and ni is not None and sh and not sn.get("eps_approx"):
        calc = ni / sh
        if abs(calc - eps) > max(0.05, abs(eps) * 0.25):
            out.append(("warn", f"EPS reported {eps:.2f} but profit ÷ diluted shares gives {calc:.2f}: preferred "
                                "dividends, a share class, or a figure read from the wrong line."))
    # 6. the share count jumping (splits are already restated)
    if k >= 1:
        a = (co.snapshot(ends[k - 1]) or {}).get("shares_diluted")
        if a and sh and (sh / a > 1.4 or sh / a < 0.6):
            out.append(("warn", f"Diluted shares {_pct(sh / a - 1)} in one quarter: a merger, a conversion or a "
                                "share class change. Per-share figures may not compare."))
    # 7. no revenue tag at all for the latest quarter
    if co.v("revenue", end) is None:
        out.append(("warn", "No revenue line for this quarter at the SEC."))
    return out


def run_all(tickers, say=None):
    """{ticker: [(level, text)]} for every company with SEC data kept on disk (no network)."""
    from . import edgar, metrics
    res = {}
    for i, t in enumerate(tickers):
        if say:
            say(f"Checking {t} ({i + 1}/{len(tickers)})…")
        try:
            facts, _subs, _st = edgar.update(t, offline=True)
            co = metrics.Company(facts)
            ends = co.quarter_ends()
            res[t] = checks(co, ends[-1]) if ends else [("info", "No quarters at the SEC: a foreign filer (20-F), not graded")]
        except Exception as e:
            res[t] = [("warn", f"Could not read: {type(e).__name__}: {e}")]
    return res
