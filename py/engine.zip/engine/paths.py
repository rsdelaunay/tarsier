"""Where everything lives: next to Tarsier.exe (or tarsier.py when run from source)."""
import os
import sys

if getattr(sys, "frozen", False):          # running as Tarsier.exe
    BASE = os.path.dirname(sys.executable)
else:
    BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

CONFIG = os.path.join(BASE, "config.json")
WATCHLIST = os.path.join(BASE, "watchlist.xlsx")
CACHE = os.path.join(BASE, "_cache")          # SEC downloads (engine only)
COMPANIES = os.path.join(BASE, "companies")   # one folder per company


def company_dir(ticker):
    d = os.path.join(COMPANIES, ticker.upper())
    os.makedirs(os.path.join(d, "reports"), exist_ok=True)
    return d
PORTFOLIO = os.path.join(BASE, "portfolio.xlsx")
