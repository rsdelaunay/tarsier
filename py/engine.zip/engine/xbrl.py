"""Turn SEC companyfacts JSON into clean quarterly numbers.

10-Qs report the quarter (3 months) for the income statement but only
year-to-date figures for the cash flow statement; 10-Ks report the full year.
So a quarter is either reported directly or derived by subtraction:
  Q3 cash flow = 9-month YTD - 6-month YTD
  Q4           = full year - 9-month YTD
Per-share and share-count facts are never derived by subtraction.
"""
from datetime import date

FORMS = {"10-Q", "10-K", "10-Q/A", "10-K/A", "10-KT", "10-QT"}
NAMESPACES = ("us-gaap", "dei", "ifrs-full")


def _d(s):
    return date.fromisoformat(s)


def _days(start, end):
    return (_d(end) - _d(start)).days


def _entries(facts, concept, unit):
    for ns in NAMESPACES:
        c = facts.get("facts", {}).get(ns, {}).get(concept)
        if c and unit in c.get("units", {}):
            return c["units"][unit]
    return []


def _latest(entries, key):
    """Keep one value per key: the most recently filed (restated values win)."""
    best = {}
    for e in entries:
        if e.get("form") not in FORMS:
            continue
        k = key(e)
        if k is None:
            continue
        if k not in best or e.get("filed", "") > best[k].get("filed", ""):
            best[k] = e
    return best


def splits(facts, concepts):
    """Stock splits, found where a later filing restates the share count of a period it had already
    reported: [(date of the first filing on the new basis, factor)]. Filings before that date are on
    the old basis and are never re-filed, so their share counts and per-share numbers must be adjusted."""
    found = []
    for concept in concepts:
        by_period = {}
        for e in _entries(facts, concept, "shares"):
            if "start" in e and e.get("form") in FORMS and e.get("filed") and e.get("val"):
                by_period.setdefault((e["start"], e["end"]), []).append(e)
        for lst in by_period.values():
            lst.sort(key=lambda e: e["filed"])
            for old, new in zip(lst, lst[1:]):
                r = new["val"] / old["val"]
                if 1.25 <= r < 100 or 0.01 < r <= 0.8:       # ×1000 is a units typo in a filing, not a split
                    found.append((new["filed"], r))
    out = []                                    # one entry per split: earliest filing, median factor
    for filed, r in sorted(found):
        for sp in out:
            if abs(r / sp["r"][0] - 1) <= 0.03 and _days(sp["filed"], filed) <= 400:
                sp["r"].append(r)
                break
        else:
            out.append({"filed": filed, "r": [r]})
    res = []
    for sp in out:
        if len(sp["r"]) < 2:                    # a split restates several periods; one odd value is a typo
            continue
        k = sorted(sp["r"])[len(sp["r"]) // 2]
        whole = round(k) if k >= 1 else 1 / round(1 / k)
        res.append((sp["filed"], whole if abs(k / whole - 1) <= 0.02 else k))
    return res


def _adjusted(entries, splits_, per_share):
    """Entries from filings made before a split, restated to today's share basis."""
    if not splits_:
        return entries
    out = []
    for e in entries:
        k = 1.0
        for filed, factor in splits_:
            if e.get("filed", "9999") < filed:
                k *= factor
        out.append(e if k == 1.0 else {**e, "val": e["val"] / k if per_share else e["val"] * k})
    return out


def _quarters_from_durations(d, derive):
    by_end = {}
    for (s, e), rec in d.items():
        by_end.setdefault(e, []).append((s, rec))
    out = {}
    for end, lst in by_end.items():
        direct = [(s, r) for s, r in lst if 80 <= _days(s, end) <= 100]
        if direct:
            s, r = max(direct, key=lambda x: x[1].get("filed", ""))
            out[end] = {"val": r["val"], "start": s, "derived": False}
            continue
        if not derive:
            continue
        # longest period first: YTD or full year minus the YTD ending ~3 months earlier
        for s, r in sorted(lst, key=lambda x: x[0]):
            match = [(e2, r2) for (s2, e2), r2 in d.items()
                     if s2 == s and 80 <= _days(e2, end) <= 100]
            if match:
                e2, r2 = match[0]
                out[end] = {"val": r["val"] - r2["val"], "start": e2, "derived": True}
                break
    return out


def quarterly(facts, concepts, unit="USD", derive=True, splits_=None):
    """end date -> {val, start, derived, concept}; first concept in the list wins."""
    out = {}
    for concept in concepts:
        ents = [e for e in _entries(facts, concept, unit) if "start" in e]
        ents = _adjusted(ents, splits_, unit != "shares")
        d = _latest(ents, lambda e: (e["start"], e["end"]))
        for end, rec in _quarters_from_durations(d, derive).items():
            if end not in out:
                rec["concept"] = concept
                out[end] = rec
    return out


def longest(facts, concepts, unit, splits_=None):
    """end date -> value of the longest period ending there (e.g. full-year share count)."""
    out = {}
    for concept in concepts:
        ents = [e for e in _entries(facts, concept, unit) if "start" in e]
        ents = _adjusted(ents, splits_, unit != "shares")
        d = _latest(ents, lambda e: (e["start"], e["end"]))
        for (s, e), r in d.items():
            if e not in out or _days(s, e) > out[e][0]:
                out[e] = (_days(s, e), r["val"])
    return {e: v for e, (_, v) in out.items()}


def longest_with_days(facts, concepts, unit="USD"):
    """end date -> (days, value) of the longest period ending there: year-to-date cash flow items."""
    out = {}
    for concept in concepts:
        ents = [e for e in _entries(facts, concept, unit) if "start" in e]
        d = _latest(ents, lambda e: (e["start"], e["end"]))
        for (s, e), r in d.items():
            if e not in out or _days(s, e) > out[e][0]:
                out[e] = (_days(s, e), r["val"])
    return out


def instants(facts, concepts, unit="USD"):
    """end date -> {val, concept} for balance-sheet items."""
    out = {}
    for concept in concepts:
        ents = [e for e in _entries(facts, concept, unit) if "start" not in e]
        for end, r in _latest(ents, lambda e: e["end"]).items():
            if end not in out:
                out[end] = {"val": r["val"], "concept": concept}
    return out


def period_label(facts, concepts, end):
    """Fiscal label (e.g. 'FY2026 Q3') from the filing that first reported this quarter."""
    first = None
    for concept in concepts:
        for e in _entries(facts, concept, "USD"):
            if e.get("end") == end and e.get("form") in FORMS:
                if first is None or e.get("filed", "") < first.get("filed", ""):
                    first = e
    if not first:
        return end, None, None
    fp = first.get("fp")
    fp = "Q4" if fp == "FY" else fp
    return f"FY{first.get('fy')} {fp}", first.get("form"), first.get("filed")


def find_end(ends, target_end, days_back, tol):
    """The period end closest to target_end - days_back, within tol days."""
    t = _d(target_end).toordinal() - days_back
    best = None
    for e in ends:
        gap = abs(_d(e).toordinal() - t)
        if gap <= tol and (best is None or gap < best[0]):
            best = (gap, e)
    return best[1] if best else None
