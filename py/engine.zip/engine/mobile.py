"""Everything the phone app shows, in one data.json. Built from the same engine as the window.

The phone app is published as a public web page, so nothing private goes in: the portfolio is shown as
percentages only (no amounts), and nothing from config.json is ever included.
"""
import json
import os
from datetime import datetime

from . import VERSION, edgar, excel, explain, paths, pipeline, portfolio, projection, rules

BLOCK_ORDER = ("growth", "profitability", "cash", "balance", "execution")


def companies():
    """Your companies: the watchlist (active) and every company already graded, if its SEC data is cached."""
    names = set()
    try:
        names |= {w["ticker"].upper() for w in excel.read_watchlist(paths.WATCHLIST) if w.get("active", True)}
    except Exception:
        pass
    if os.path.isdir(paths.COMPANIES):
        names |= {d.upper() for d in os.listdir(paths.COMPANIES) if os.path.isdir(os.path.join(paths.COMPANIES, d))}
    return sorted(t for t in names if os.path.exists(os.path.join(paths.CACHE, f"{t}_companyfacts.json")))


def _watch_row(t):
    try:
        for w in excel.read_watchlist(paths.WATCHLIST):
            if w["ticker"].upper() == t:
                return w
    except Exception:
        pass
    return {"ticker": t}


def _r(x, n=1):
    return None if x is None else round(float(x), n)


def _quarter(r, co=None):
    return {
        "end": r["end"], "label": r["label"], "grade": r["grade"], "score": _r(r["score"]),
        "provisional": r.get("provisional"), "preliminary": r.get("preliminary"),
        "unsupported": r.get("unsupported"), "headline": r.get("headline"), "house_rules": r.get("house_rules"),
        "checks": [list(c) for c in r.get("checks") or []],
        "company_type": r.get("company_type"),
        "blocks": [{"key": k, "score": _r(r["blocks"].get(k), 0), "weight": r["weights"][k],
                    "detail": explain.block_detail(r, k), "lines": explain.headlines(r, k, co)}
                   for k in BLOCK_ORDER],
        "grade_rows": [{"block": k, "score": _r(v, 0), "weight": _r(w), "points": _r(p)}
                       for k, v, w, p in explain.grade_rows(r)],
        "fcf": {k: (_r(v) if isinstance(v, (int, float)) else v) for k, v in r["fcf"].items()
                if k in ("ttm", "ttm_prior", "growth_pct", "margin_ttm", "margin_pp", "after_sbc_ttm",
                         "after_sbc_margin_ttm", "cfo_ttm", "capex_ttm", "sbc_ttm", "verdict", "shares_m")},
        "uses": {k: _r(v) for k, v in (r["fcf"].get("uses") or {}).items()},
        "cash_points": _cash_points(r),
        "holder_risks": r.get("holder_risks") or [],
    }


def _cash_points(r):
    """Where the free cash flow went, as short pointers (last 12 months)."""
    f = r.get("fcf") or {}
    u, ttm = f.get("uses") or {}, f.get("ttm")
    m = lambda v: explain._m(v * 1e6)
    share = lambda v: f" ({v / ttm * 100:.0f}% of FCF)" if ttm and ttm > 0 else ""
    pts = []
    for key, name in (("buybacks", "Buybacks"), ("dividends", "Dividends"), ("tax_withheld", "Taxes on employee stock"),
                      ("acquisitions", "Acquisitions")):
        v = u.get(key)
        if v and v > 0:
            pts.append(f"{name} {m(v)}{share(v)}")
    nb = u.get("net_borrowing")
    if nb and abs(nb) >= 1:
        pts.append(f"Borrowed {m(nb)} net" if nb > 0 else f"Repaid {m(-nb)} of debt net")
    if u.get("stock_issued") and u["stock_issued"] > 0:
        pts.append(f"Issued {m(u['stock_issued'])} of new shares")
    dil = next((p for p in r.get("parts", {}).get("balance", []) if p["id"] == "dilution"), None)
    if dil and isinstance(dil.get("value"), (int, float)):
        v = dil["value"]
        pts.append(f"Share count {v:+.1f}% YoY")
    sbc, bb = f.get("sbc_ttm"), u.get("buybacks")
    if sbc and bb and sbc > 0:
        pts.append(f"Buybacks = {bb / sbc:.1f}× stock pay")
    return pts


def _valuation(out, co=None, market=None):
    p = out.get("projection")
    if not p:
        return None
    user = p["user"] or {}
    typed = (user.get("settings") or {}).get("price")
    live = bool(market and market.get("price") and not market.get("stale"))
    if live or (not typed and market and market.get("price")):
        # the market price fetched at publish time is fresher than one typed on page 2 days ago
        user = {**user, "settings": {**(user.get("settings") or {}), "price": market["price"]}}
        typed = None
    try:
        res = projection.compute(p["hist"], user)
    except Exception:
        return None
    out["_res"] = res                      # for the fundamentals' estimates (_fundamentals)
    S = res["settings"]
    labels = res["labels"]
    scen = {}
    for s in projection.SCENARIOS:
        o = res["scen"][s]["out"]
        scen[s] = {"targets": [_r(o["target"][T], 2) for T in projection.TARGETS],
                   "eps": [_r(o["eps"][y], 2) for y in range(projection.YEARS)],
                   "revenue": [_r(o["revenue"][y] / 1e6 if o["revenue"][y] else None, 0)
                               for y in range(projection.YEARS)]}
    w = res["weighted"]
    return {
        "price": _r(S.get("price"), 2), "price_date": S.get("price_date"),
        "fair_value": _r(res["fair_value"], 2), "dcf_value": _r(res["dcf_value"], 2),
        "upside": _r(res["upside"] * 100 if res.get("upside") is not None else None),
        "dcf_upside": _r(res["dcf_upside"] * 100 if res.get("dcf_upside") is not None else None),
        "expected_return": _r(res["expected_return"] * 100 if res.get("expected_return") is not None else None),
        "margin_of_safety": _r((S.get("margin_of_safety") or 0) * 100, 0),
        "years": labels, "target_years": [labels[T] for T in projection.TARGETS],
        "weighted_targets": [_r(w["target"][T], 2) for T in projection.TARGETS],
        "weights": {s: _r(res["weights"][s] * 100, 0) for s in projection.SCENARIOS},
        "scenarios": scen, "reconcile": (res.get("reconcile") or {}).get("lines", []),
        "how": _how(res, S),
        "price_source": "typed on the PC" if typed else (
            f"{market.get('source')}, {market.get('time') or ''}".strip(", ") + (" (old)" if market.get("stale") else "")
            if market and market.get("price") else None),
        "multiples": _multiples(p["hist"], res, S, co),
        "how_points": _how_points(res, S), "why_points": _why_points(res, S),
        "method": (res.get("model") or {}).get("method_short"), "business_model": (res.get("model") or {}).get("label"),
        "holder_risks": res.get("holder_risks") or [],
        "methods": _methods(p["hist"], user, res),
        "drivers": _drivers(res),
        "weighted_ret": [_r(w["ret"][T] * 100 if w["ret"][T] is not None else None) for T in projection.TARGETS],
        "fair_value_raw": _r(res.get("fair_value_raw"), 2), "dcf_sbc_value": _r(res.get("dcf_sbc_value"), 2),
        "wacc": _r((S.get("wacc") or 0) * 100, 2),
        "consensus": _consensus(res), "nongaap": _nongaap(res, S), "anchor": _anchor(res),
        # what the phone needs to rework the projection itself, with the same code (phone_engine.revalue)
        "engine": {"hist": _json_safe(p["hist"]), "user": user},
    }


def _anchor(res):
    """The market anchor for the phone: the 12-month line, its explanation, and the numbers behind it."""
    a = res.get("anchor") or {}
    if not a.get("on"):
        return {"on": False, "why": a.get("why")}
    line, why = projection.anchor_text(a)
    r = lambda v, n=2: None if v is None else round(v, n)
    return {"on": True, "line": line, "why": why, "warn": bool(a.get("warn") or a.get("capped") == "high"),
            "tarsier_12m": r(a.get("tarsier_12m")), "analysts_style": r(a.get("analysts_style")), "gap": r(a.get("gap"), 4),
            "own": r(a.get("own")), "H": r(a.get("H"), 3), "k": r(a.get("k"), 3), "basis": a.get("basis")}


def _consensus(res):
    """Page 2's first box: guidance / analysts / yours per year, and the years nobody forecasts yet."""
    src = res.get("cons_src") or {}
    n = len(res["labels"])
    nofc = [not (src.get("revenue") or [None] * n)[y] and not (src.get("eps") or [None] * n)[y] for y in range(n)]
    info = res.get("cons_info") or {}
    return {"labels": res["labels"], "revenue": [_r(x, 1) for x in res.get("cons_rev") or [None] * n],
            "eps": [_r(x, 2) for x in res.get("cons_eps") or [None] * n],
            "src": {k: list(v) for k, v in src.items()}, "no_forecast": nofc,
            "fetched": info.get("fetched"), "valid_until": info.get("valid_until")}


def _nongaap(res, S):
    """P/E on non-GAAP EPS (with a consensus): the GAAP target beside it, and what makes the difference."""
    o, used = res["scen"]["base"]["out"], res["scen"]["base"]["used"]
    ts = [T for T in projection.TARGETS if o.get("nongaap") and o["nongaap"][T]]
    if not ts:
        return None
    f = ts[-1] + 1
    diff = (o["adj_eps"][f] or 0) - (o["eps"][f] or 0)
    rev, sh, tax = o["revenue"][f], o["shares"][f] or 1, used["tax_rate"][f]
    sbc, amort = used["sbc_pct"][f] * rev, S.get("amort_musd") or 0

    def m_(x):
        return f"${x / 1000:,.1f}B" if abs(x) >= 1000 else f"${x:,.0f}M"
    parts = [f"stock pay {m_(sbc)} ({used['sbc_pct'][f] * 100:.1f}% of revenue)"]
    if amort:
        parts.append(f"amortisation of acquired intangibles {m_(amort)} (acquisitions)")
    return {"target_gaap": {s: [_r(res["scen"][s]["out"]["target_gaap"][T], 2) for T in projection.TARGETS]
                            for s in projection.SCENARIOS},
            "line": f"Non-GAAP vs GAAP EPS in {res['labels'][f]}: +${diff:,.2f} a share = " + " + ".join(parts)
                    + f", after {tax * 100:.0f}% tax, ÷ {sh:,.0f}M shares.",
            "sbc_high": used["sbc_pct"][f] >= 0.10}


def _json_safe(x):
    import datetime as _dt
    if isinstance(x, dict):
        return {k: _json_safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_json_safe(v) for v in x]
    if isinstance(x, (_dt.date, _dt.datetime)):
        return x.isoformat()
    return x


def _drivers(res):
    """What the targets rest on, year by year and per scenario: revenue growth, EPS growth, EPS, the multiple
    and the metric it is applied to (the PC's page 2, in short). pct values in %, typed ones flagged."""
    cs = res.get("cons_src") or {}
    n = len(res["labels"])
    out = {"labels": res["labels"], "targets_at": list(projection.TARGETS), "scen": {},
           "no_forecast": [not (cs.get("revenue") or [None] * n)[y] and not (cs.get("eps") or [None] * n)[y]
                           for y in range(n)]}
    for s in projection.SCENARIOS:
        sc = res["scen"][s]
        used, dflt, typed, o = sc["used"], sc["default"], sc["user"], sc["out"]
        pct = lambda xs: [_r(x * 100 if x is not None else None, 1) for x in xs]
        out["scen"][s] = {
            "rev_growth": pct(used["rev_growth"]), "rev_growth_d": pct(dflt["rev_growth"]),
            "rev_growth_typed": [v is not None for v in typed["rev_growth"]],
            "eps_growth": pct(used["eps_growth"]), "eps_growth_d": pct(dflt["eps_growth"]),
            "eps_growth_typed": [v is not None for v in typed["eps_growth"]],
            "eps": [_r(x, 2) for x in o["eps"]],
            "revenue": [_r(x / 1e3 if x else None, 2) for x in o["revenue"]],          # $B
            "multiple": [_r(x, 1) for x in used["multiple"]], "multiple_d": [_r(x, 1) for x in dflt["multiple"]],
            "multiple_typed": [v is not None for v in typed["multiple"]],
            "basis": list(o["basis"]), "target": [_r(x, 2) for x in o["target"]]}
    return out


def _methods(h, user, res):
    """Every valuation method, worked out on the PC, so the phone can switch between them instantly."""
    from . import holders
    cur, sug = res["settings"]["method"], res["settings_default"]["method"]
    out = []
    for code in projection.METHODS:
        if code == "none":
            continue
        r2 = res
        if code != cur:
            try:
                r2 = projection.compute(h, {**user, "settings": {**(user.get("settings") or {}), "method": code}})
            except Exception:
                continue
        if r2.get("fair_value") is None:
            continue
        key = (_r(r2["fair_value"], 2), tuple(_r(r2["weighted"]["target"][T], 2) for T in projection.TARGETS))
        twin = next((o for o in out if o["_key"] == key), None)
        if twin and code not in (cur, sug):          # this method falls back to one already listed here
            continue
        out.append({"_key": key, "code": code, "label": projection.METHODS[code], "short": projection.METHOD_SHORT[code],
                    "suggested": code == sug, "current": code == cur,
                    "fair_value": _r(r2["fair_value"], 2),
                    "upside": _r(r2["upside"] * 100 if r2.get("upside") is not None else None),
                    "expected_return": _r(r2["expected_return"] * 100 if r2.get("expected_return") is not None else None),
                    "weighted_targets": [_r(r2["weighted"]["target"][T], 2) for T in projection.TARGETS],
                    "targets": {s: [_r(r2["scen"][s]["out"]["target"][T], 2) for T in projection.TARGETS]
                                for s in projection.SCENARIOS},
                    "note": holders.method_note(code, h.get("sbc_pct_rev")), "drivers": _drivers(r2)})
    for o in out:
        o.pop("_key")
    return out if len(out) > 1 else []


def _multiples(h, res, S, co=None):
    """Trailing and forward multiples at the price in use. Forward = Tarsier's base case, not analysts'."""
    price = S.get("price")
    if not price:
        return None
    ttm, shares = h.get("ttm") or {}, S.get("shares_now") or h.get("shares_now")
    eps_ttm = None
    if co is not None:
        try:
            ends = [h["latest_end"]]
            for _ in range(3):
                ends.append(co.previous(ends[-1], 1))
            vals = [(co.snapshot(e) or {}).get("eps_diluted") if e else None for e in ends]
            if all(v is not None for v in vals):
                eps_ttm = sum(vals)
        except Exception:
            eps_ttm = None
    if eps_ttm is None and ttm.get("net_income") is not None and shares:
        eps_ttm = ttm["net_income"] / shares
    o = res["scen"]["base"]["out"]
    i = next((k for k, y in enumerate(o["years"]) if y is not None and y >= 0.5), None)   # next full fiscal year
    eps_f = o["eps"][i] if i is not None else None
    j = min(i + 2, len(o["eps"]) - 1) if i is not None else None
    g = None
    if i is not None and j > i and eps_f and eps_f > 0 and o["eps"][j] and o["eps"][j] > 0:
        g = ((o["eps"][j] / eps_f) ** (1 / (j - i)) - 1) * 100
    mcap = price * shares if shares else None                      # $M (shares in millions)
    ev = mcap - (S.get("net_cash_musd") or h.get("net_cash") or 0) if mcap else None
    ebitda = (ttm.get("op_income") or 0) + (ttm.get("da") or 0) if ttm.get("op_income") is not None else None
    pe = price / eps_ttm if eps_ttm and eps_ttm > 0 else None
    fpe = price / eps_f if eps_f and eps_f > 0 else None
    return {
        "price": _r(price, 2), "market_cap": _r(mcap, 0), "ev": _r(ev, 0),
        "eps_ttm": _r(eps_ttm, 2), "pe": _r(pe, 1),
        "fwd_year": res["labels"][i] if i is not None else None, "eps_fwd": _r(eps_f, 2), "fpe": _r(fpe, 1),
        "eps_growth": _r(g, 1), "peg": _r(fpe / g, 2) if fpe and g and g > 0 else None,
        "ev_sales": _r(ev / ttm["revenue"], 1) if ev and ttm.get("revenue") else None,
        "ev_ebitda": _r(ev / ebitda, 1) if ev and ebitda and ebitda > 0 else None,
        "fcf_yield": _r(ttm["fcf"] / mcap * 100, 1) if mcap and ttm.get("fcf") is not None else None,
        # the inputs, so the phone can redo the price rows with a newer price
        "base": {"eps_ttm": _r(eps_ttm, 4), "eps_fwd": _r(eps_f, 4), "eps_growth": _r(g, 2), "shares_m": _r(shares, 3),
                 "net_cash": _r(S.get("net_cash_musd") or h.get("net_cash") or 0, 1), "rev_ttm": _r(ttm.get("revenue"), 1),
                 "ebitda_ttm": _r(ebitda, 1), "fcf_ttm": _r(ttm.get("fcf"), 1)},
    }


def _how_points(res, S):
    h = _how(res, S)
    if h["target"] is None:
        return []
    yr = h["year"].replace("E", "")
    mod = res.get("model") or {}
    pts = [f"Method: {mod['method_short']} ({mod['label'].lower()})"] if mod else []
    pts += [n for n in (res.get("method_notes") or [])[1:2]]
    pts.append(f"Weighted {yr} target: ${h['target']:,.2f}")
    if h["multiple"] is not None:
        pts.append(f"Base case at {h['multiple']:.1f}× {h['basis']}")
    pts.append(f"Back to today: {h['years_ahead']} years at {h['discount_rate']:g}%/yr → ${h['pv']:,.2f}")
    if res.get("fair_value") is not None:
        pts.append(f"Less {h['margin_of_safety']:g}% margin of safety → ${res['fair_value']:,.2f}")
    return pts


def _why_points(res, S):
    """Why the multiple and the free-cash-flow values differ, in four short lines."""
    import re
    rc = res.get("reconcile") or {}
    lines = " ".join(rc.get("lines") or [])
    yr = (re.search(r"after (FY\d{4})E", lines) or re.search(r"In (FY\d{4})E", lines))
    yr = yr.group(1) if yr else "the last year"
    pts = []
    if rc.get("pe") is not None:
        pts.append(f"Multiple value: {rc['pe']:.1f}× earnings, discounted at {(S.get('discount_rate') or 0) * 100:g}%")
    if S.get("exit_multiple") is not None and S.get("wacc") is not None:
        pts.append(f"FCF value: exits at {S['exit_multiple']:.1f}× cash flow, discounted at {S['wacc'] * 100:.2f}% (WACC)")
    if rc.get("implied_growth") is not None:
        pts.append(f"That exit assumes {rc['implied_growth'] * 100:.1f}%/yr growth forever"
                   + (f" ({S.get('terminal_growth', 0) * 100:g}% would be {rc['growth_multiple']:.1f}×)"
                      if rc.get("growth_multiple") else ""))
    if rc.get("conversion") is not None:
        pts.append(f"FCF is {rc['conversion'] * 100:.0f}% of net income in {yr}: the FCF value counts only cash")
    return pts


def _how(res, S):
    """How the fair value was reached: the last target year, at what multiple, discounted at what rate."""
    T = projection.TARGETS[-1]
    base = res["scen"]["base"]["out"]
    w = res["weighted"]
    basis, mult = base["basis"][T], base["suggested"][T]
    return {"year": res["labels"][T], "basis": basis, "multiple": _r(mult, 1),
            "target": _r(w["target"][T], 2), "pv": _r(w["pv"][T], 2),
            "discount_rate": _r((S.get("discount_rate") or 0) * 100, 1),
            "years_ahead": _r(base["years"][T], 1), "margin_of_safety": _r((S.get("margin_of_safety") or 0) * 100, 0)}


def _business(out):
    pr = out.get("profile")
    if not pr:
        return None
    from . import profile, peers
    try:
        pe = peers.load(out["ticker"], offline=True)
    except Exception:
        pe = None
    sc = profile.score(pr["data"], pr["auto"], pe)
    return {"grade": sc["grade"] if sc["complete"] else None, "score": _r(sc["score"]) if sc["complete"] else None,
            "filled": sc["filled"],
            "pillars": {k: {"score": _r(v["score"], 0), "note": v.get("note")} for k, v in sc["pillars"].items()},
            "facts": {k: pr["data"].get(k) for k in ("founded", "ceo", "what") if pr["data"].get(k)},
            "hq": pr["auto"].get("hq"), "industry": pr["auto"].get("industry")}


def _numbers(co, end):
    """The quarter in plain numbers, next to the same quarter a year earlier."""
    def one(e):
        s = co.snapshot(e) if e else None
        if not s or not s.get("revenue"):
            return None
        rev = s["revenue"]
        pc = lambda k: _r(s[k] / rev * 100) if s.get(k) is not None else None
        return {"revenue": _r(rev / 1e6), "gross": pc("gross_profit"), "operating": pc("operating_income"),
                "net": pc("net_income"), "eps": _r(s.get("eps_diluted"), 2), "fcf": pc("fcf"),
                "oi_estimated": bool(s.get("oi_estimated")), "eps_approx": bool(s.get("eps_approx"))}
    if co is None:
        return None
    cur, prior = one(end), one(co.previous(end, 4))
    if cur is None:
        return None
    cur["revenue_yoy"] = _r((cur["revenue"] / prior["revenue"] - 1) * 100) if prior and prior["revenue"] else None
    return {"cur": cur, "prior": prior}


def _sector(t):
    """Sector and industry: the Peer Groups workbook first, the SEC industry code otherwise."""
    from . import portfolio as PO
    try:
        sec, ind = PO._workbook_sectors().get(t.upper(), (None, None))
        if not sec:
            f = PO.facts(t, offline=True) or {}
            sec = PO._sic_sector(f.get("sic"))
            ind = ind or (f.get("industry") or "").title() or None
    except Exception:
        sec = ind = None
    return {"sector": sec or "Other", "industry": ind}


def company(t, market=None, fetch=False, peer_prices=None):
    out = pipeline.run(t, _watch_row(t), offline=True)
    co = out.get("company")
    rs = sorted(out["results"], key=lambda r: r["end"])
    val, biz = _valuation(out, co, market), _business(out)
    fund = _fundamentals(out, co, fetch, peer_prices)
    return {
        "ticker": out["ticker"], "name": out["name"], "group": _watch_row(t).get("industry_group"),
        **_sector(out["ticker"]),
        "latest": _quarter(rs[-1], co),
        "history": [{"label": r["label"], "end": r["end"], "grade": r["grade"], "score": _r(r["score"]),
                     "preliminary": r.get("preliminary"), "numbers": _numbers(co, r["end"])} for r in rs],
        "valuation": val, "business": biz, "fundamentals": fund,
        "compare": _compare_col(out, market, val, biz),
        "earnings_dates": _earnings_dates(out["ticker"]),
    }


def _fundamentals(out, co, fetch=False, peer_prices=None):
    """Page 1 on the PC (Stock fundamentals and the stock grade), worked out here so the phone only shows it.
    Price history from Yahoo only when publishing with prices; otherwise the PC's 30-minute cache, if any."""
    from . import fundamentals as F, fund_view as FV, stockgrade as G, peers as PE
    t = out["ticker"]
    try:
        mk = F.market(t) if fetch else (F._load_cache().get(t.upper()) or {})
    except Exception:
        mk = {}
    try:
        pe = (PE.load(t, offline=True) or {}).get("peers") or {}
    except Exception:
        pe = {}
    try:
        _f, subs, _s = edgar.update(t, offline=True)
    except Exception:
        subs = {}
    try:
        inputs = excel.read_inputs(out["inputs_path"]) if out.get("inputs_path") else {}
    except Exception:
        inputs = {}
    pp = {k: v for k, v in (peer_prices or {}).items() if k in pe}
    try:
        d = F.build(co, subs, mk, out.get("_res"), inputs, pe, pp, ticker=t)
        g = G.grade(d)
    except Exception:
        return None
    v, med = d["values"], d["peers"]
    groups = []
    for name, keys in FV.GROUPS:
        rows = []
        for k in keys:
            label, kind, better, what = FV.D[k]
            m, est = med.get(k), k in FV.ESTIMATES
            tips = list(what)
            if est:
                tips.append("Estimate: it moves with the projection. Tap to open Projections")
            if m:
                tips.append(f"Peers' median: {FV.fmt(k, kind, m[0], {})} ({m[1]} peers)")
            rows.append([k, label, FV.fmt(k, kind, v.get(k), v), None if est else FV.tone(k, v.get(k), m), est, tips])
        groups.append([name, rows])

    def axis_tips(k):
        s, parts = g["axes"].get(k), g["parts"].get(k) or []
        if k == "Dividend" and s is None:
            return ["No dividend: this axis does not count"]
        if s is None and parts and parts[0][1] is None and parts[0][2] == 0:
            return [parts[0][0]]
        pts = [f"{n}: {'—' if sc is None else round(sc)} (weight {w})" for n, sc, w in parts]
        if k in g["weights"]:
            pts.append(f"Counts {g['weights'][k]} of {sum(g['weights'].values())} in the grade")
        if k == "Future":
            pts.append("From the projection (Projections tab): an estimate")
        return pts
    return {"grade": {"grade": g["grade"], "score": _r(g["score"], 0), "summary": g["summary"], "model": g.get("model"),
                      "rewards": g["rewards"], "risks": g["risks"],
                      "axes": [[k, _r(g["axes"].get(k), 0), axis_tips(k)] for k in G.AXES]},
            "groups": groups, "price": _r(v.get("price"), 2), "label": v.get("label"), "own": _ownership(v),
            "n_peers": d["n_peers"], "asof": d["asof"]}


def _earnings_dates(t):
    """Results releases (SEC 8-K item 2.02), for the phone's Entry & sizing and the call date."""
    try:
        subs = edgar._read(f"{t.upper()}_submissions.json") or {}
    except Exception:
        return []
    r = (subs.get("filings") or {}).get("recent") or {}
    return sorted(d for f, it, d in zip(r.get("form", []), r.get("items", []), r.get("filingDate", []))
                  if f in ("8-K", "8-K/A") and "2.02" in (it or ""))[-24:]


def _ownership(v):
    """Insiders' open-market trades (12 months) and the largest institutional holders, as on the PC's page 1."""
    s, i, sh = v.get("_ins"), v.get("_inst"), v.get("shares")
    ins = None
    if s:
        ins = {"n_filings": s.get("n_filings"),
               "trades": [{"kind": x["kind"], "plan": bool(x.get("plan")), "date": str(x.get("date"))[:10],
                           "who": x.get("who"), "role": x.get("role"), "shares": x.get("shares"),
                           "price": x.get("price"), "value": x.get("value")} for x in (s.get("trades") or [])[:14]]}
    inst = None
    if i:
        inst = {"new": (i.get("new") or [None])[0], "sold_out": (i.get("sold_out") or [None])[0],
                "top": [{"name": x.get("name"), "shares": x.get("shares"),
                         "pct": (x["shares"] / sh * 100) if x.get("shares") and sh else None,
                         "change_pct": x.get("change_pct"), "date": str(x.get("date") or "")}
                        for x in (i.get("top") or [])[:10]]}
    return {"insiders": ins, "institutions": inst} if ins or inst else None


def _compare_col(out, market, val, biz):
    """The Compare column for this company: the same rows as the Compare page on the PC."""
    from . import compare
    try:
        c = compare.from_out(out, market, val or {}, biz or {})
    except Exception:
        return None
    keep = {k for _s, k, *_ in compare.ROWS} | {"fwd_year", "price_source", "base", "quick"}
    rnd = lambda v: round(v, 4) if isinstance(v, float) else v
    return {k: ([rnd(x) for x in v] if isinstance(v, tuple) else rnd(v)) for k, v in c.items() if k in keep}


def _compare_rows():
    from . import compare
    return [{"section": s, "key": k, "label": l, "kind": kind, "better": b, "help": h}
            for s, k, l, kind, b, h in compare.ROWS]


def _valued_portfolio(fetch=True):
    """portfolio.xlsx at today's value (shares x last close), as the window shows it."""
    d = portfolio.load()
    if fetch:
        try:
            from . import market as mk
            held = [r["ticker"] for r in d["rows"] if r.get("ticker") and r["ticker"] != portfolio.CASH]
            hi, _miss = mk.highs(held)
            rates = mk.fx(d.get("currency") or "€", {v.get("currency") for v in hi.values()})
            d["rows"] = portfolio.valued(d["rows"], hi, rates)
        except Exception:
            pass
    return d


def private_payload():
    """What only the phone that knows the passphrase may read: share counts and amounts (see private.py)."""
    d = _valued_portfolio()
    return {"saved": datetime.now().strftime("%Y-%m-%d %H:%M"), "currency": d.get("currency") or "€",
            "rows": [{"t": r["ticker"], "shares": r.get("shares"), "invested": _r(r.get("cost", r.get("amount")), 2),
                      "value": _r(r.get("amount"), 2)} for r in d["rows"]
                     if r.get("ticker") and ((r.get("amount") or 0) > 0 or r.get("shares"))]}


def portfolio_shares(fetch=False):
    """Weights only: the app is public, so amounts never leave the PC (they go, locked, in private.json)."""
    d = _valued_portfolio(fetch)
    s = portfolio.summary(d["rows"])
    if not s["total"]:
        return None
    live = [r for r in d["rows"] if r.get("ticker") and (r.get("amount") or 0) > 0]
    holdings = {}
    for r in live:                     # one line per ticker, its weight only (never the amount)
        h = holdings.setdefault(r["ticker"], {"t": r["ticker"], "w": 0.0, "sector": portfolio.used(r, "sector"),
                                              "style": portfolio.used(r, "style"), "conviction": r.get("conviction"),
                                              "fund": r["ticker"] in portfolio.FUNDS})
        h["w"] += r["amount"] / s["total"] * 100
    for h in holdings.values():
        h["w"] = round(h["w"], 2)
    return {k: [[n, round(w * 100, 1)] for n, _a, w in s[k]] for k in ("ticker", "sector", "style")} | {
        "positions": len(s["ticker"]), "holdings": sorted(holdings.values(), key=lambda h: -h["w"]),
        "currency": d.get("currency") or "€",
        "rules": _port_rules()}


def _port_rules():
    """The numbers of your portfolio rules (rules.py), so the phone checks exactly what the PC checks."""
    return {"caps": rules.CONVICTION_CAPS, "default": rules.CONVICTION_DEFAULT, "cash_min": rules.CASH_MIN,
            "cash_max": rules.CASH_MAX, "dd_highs": rules.CASH_DD_HIGHS, "dd_correction": rules.CASH_DD_CORRECTION,
            "tolerance": rules.CASH_TOLERANCE, "sector_max": rules.SECTOR_MAX, "defensive_min": rules.DEFENSIVE_MIN,
            "gambles_max": rules.GAMBLES_MAX, "weak": list(rules.WEAK_GRADES),
            "discount": rules.DISCOUNT_FROM_HIGH, "weights": {k or "": v for k, v in rules.CONTRIBUTION_WEIGHTS.items()},
            "defensive_styles": list(rules.DEFENSIVE_STYLES), "defensive_share": rules.DEFENSIVE_MONTH_SHARE}


def build(progress=None, fetch_prices=False):
    data = {"generated": datetime.now().strftime("%Y-%m-%d %H:%M"), "version": VERSION,
            "method": rules.METHOD_VERSION, "grades": [[lo, g] for lo, g in rules.GRADES if lo > -1e9],
            "companies": [], "skipped": [], "compare_rows": _compare_rows()}
    names = companies()
    market, data["prices_missed"] = {}, []
    if fetch_prices:
        from . import prices
        try:
            market, data["prices_missed"] = prices.get_many(names, progress)
        except Exception as e:                       # no prices is never a reason not to publish
            data["prices_missed"] = [f"all ({type(e).__name__})"]
    peer_px = {}
    if fetch_prices:
        try:
            from . import peers as PE
            want = sorted({x for t in names for x in ((PE.load(t, offline=True) or {}).get("peers") or {})}
                          - {n.upper() for n in names})
            peer_px, _m = prices.get_many(want, progress, max_age=prices.PEER_MAX_AGE)   # medians only
            peer_px.update(market)
        except Exception:
            peer_px = dict(market)
    for i, t in enumerate(names, 1):
        if progress:
            progress(f"phone: {t} ({i} of {len(names)})")
        try:
            data["companies"].append(company(t, market.get(t.upper()), fetch_prices, peer_px))
        except (edgar.SecError, RuntimeError, ValueError, KeyError) as e:
            data["skipped"].append([t, str(e)[:120]])
    data["companies"].sort(key=lambda c: -(c["latest"]["score"] or 0))
    try:
        data["portfolio"] = portfolio_shares(fetch=fetch_prices)
    except Exception:
        data["portfolio"] = None
    if fetch_prices:                                 # the Macroeconomy page, as of this Sync (FRED, futures)
        try:
            from . import macro as mc
            ind, when, missed = mc.get(progress=progress)
            data["macro"] = {**ind, "when": when, "missed": missed, "meetings": mc.next_meetings(n=6),
                             "terms": mc.TERMS}
        except Exception:
            data["macro"] = None
    if fetch_prices:                                 # QQQ, S&P 500, VIX as of this Sync (the phone gets them live too)
        try:
            from . import market as mk
            snap, _miss = mk.get()
            data["market"] = {k: {x: v.get(x) for x in ("symbol", "name", "price", "ytd", "ath", "from_ath", "time")}
                              for k, v in snap.items()}
        except Exception:
            data["market"] = None
    return data


def _clean(x):
    """Browsers reject NaN and Infinity in JSON: those become null."""
    if isinstance(x, float) and (x != x or x in (float("inf"), float("-inf"))):
        return None
    if isinstance(x, dict):
        return {k: _clean(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_clean(v) for v in x]
    return x


def dumps(data):
    return json.dumps(_clean(data), ensure_ascii=False, separators=(",", ":"), default=str, allow_nan=False)


def write(data, folder):
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, "data.json")
    with open(path, "w", encoding="utf-8") as f:
        f.write(dumps(data))
    return path
