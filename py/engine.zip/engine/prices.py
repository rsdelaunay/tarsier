"""Latest share prices, fetched when you publish to the phone.

Source: Yahoo Finance's public chart endpoint (no key, no account). It is unofficial, so if it ever stops
answering, a free Finnhub key in config.json ("finnhub_key") is used as a second source.
Prices are cached for 15 minutes in _cache/prices.json; a price you typed on page 2 always wins over these.
"""
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone

from . import paths

CACHE = os.path.join(paths.CACHE, "prices.json")
FRESH_SECONDS = 15 * 60
PEER_MAX_AGE = 24 * 3600     # peers' prices only feed the medians: a day old changes nothing that shows
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36"


def _load():
    try:
        with open(CACHE, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _save(c):
    os.makedirs(paths.CACHE, exist_ok=True)
    with open(CACHE, "w", encoding="utf-8") as f:
        json.dump(c, f, indent=1)


def _get_json(url, timeout=12):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def _symbol(ticker):
    return ticker.upper().replace(".", "-")          # BRK.B → BRK-B


def parse_yahoo(data):
    """{price, currency, time, prev_close} from a v8 chart answer, or None."""
    try:
        meta = data["chart"]["result"][0]["meta"]
    except (KeyError, IndexError, TypeError):
        return None
    p = meta.get("regularMarketPrice")
    if not isinstance(p, (int, float)) or p <= 0:
        return None
    t = meta.get("regularMarketTime")
    return {"price": float(p), "currency": meta.get("currency") or "USD",
            "time": datetime.fromtimestamp(t, timezone.utc).strftime("%Y-%m-%d %H:%M UTC") if t else None,
            "prev_close": meta.get("chartPreviousClose") or meta.get("previousClose"), "source": "Yahoo Finance"}


def _yahoo(ticker):
    q = urllib.parse.quote(_symbol(ticker))
    last = None
    for host in ("query1", "query2"):
        try:
            got = parse_yahoo(_get_json(f"https://{host}.finance.yahoo.com/v8/finance/chart/{q}?range=5d&interval=1d"))
            if got:
                return got
        except (urllib.error.URLError, OSError, ValueError) as e:
            last = e
    if last:
        raise last
    return None


def parse_finnhub(data):
    p = (data or {}).get("c")
    if not isinstance(p, (int, float)) or p <= 0:
        return None
    t = data.get("t")
    return {"price": float(p), "currency": "USD", "prev_close": data.get("pc"), "source": "Finnhub",
            "time": datetime.fromtimestamp(t, timezone.utc).strftime("%Y-%m-%d %H:%M UTC") if t else None}


def _finnhub(ticker, key):
    q = urllib.parse.quote(_symbol(ticker))
    return parse_finnhub(_get_json(f"https://finnhub.io/api/v1/quote?symbol={q}&token={urllib.parse.quote(key)}"))


def _finnhub_key():
    try:
        with open(paths.CONFIG, encoding="utf-8") as f:
            return (json.load(f).get("finnhub_key") or "").strip()
    except (OSError, ValueError):
        return ""


def cached(tickers):
    """The prices kept on disk, however old (no network): to show at once while newer ones are fetched."""
    cache = _load()
    return {t.upper(): cache[t.upper()] for t in tickers if t.upper() in cache}


def stale(tickers, max_age=FRESH_SECONDS):
    """The tickers with no price kept, or one older than max_age."""
    cache, now = _load(), time.time()
    return [t for t in tickers if now - (cache.get(t.upper()) or {}).get("fetched", 0) >= max_age]


def get_many(tickers, progress=None, max_age=FRESH_SECONDS):
    """{ticker: {price, currency, time, source}} for the tickers it could price; also returns the misses.
    A price kept for less than max_age seconds is used as it is."""
    say = progress or (lambda _m: None)
    cache, now, key = _load(), time.time(), _finnhub_key()
    out, missed, fails = {}, [], 0
    for t in tickers:
        t = t.upper()
        c = cache.get(t)
        if c and now - c.get("fetched", 0) < max_age:
            out[t] = c
            continue
        say(f"price: {t}")
        got, err = None, None
        if fails < 3:                              # three misses in a row: the source is down, stop waiting on it
            try:
                got = _yahoo(t)
                fails = 0 if got else fails + 1
            except Exception as e:                 # network, blocked, format changed: try the next source
                err, fails = e, fails + 1
        if not got and key:
            try:
                got = _finnhub(t, key)
            except Exception as e:
                err = e
        if got:
            got["fetched"] = now
            cache[t] = out[t] = got
        else:
            missed.append(t)
            if c:                                   # an older price is better than none: say how old it is
                out[t] = dict(c, stale=True)
            if err:
                say(f"price: {t} not found ({type(err).__name__})")
        time.sleep(0.15)                            # be gentle with a free service
    try:
        _save(cache)
    except OSError:
        pass
    return out, missed
