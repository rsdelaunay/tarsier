"""Projections: three scenarios over five fiscal years, a price target at the end of each of the
next three fiscal years, the yearly return each implies, and a weighted fair value today.

Rule of the house: GAAP EPS is the scored and valued number; adjusted EPS is shown next to it,
with the gap between them taken apart (stock pay vs acquisition items).

The same arithmetic is written as live formulas in TICKER_model.xlsx (model_xlsx.py). The window
uses this module, so the numbers move as you type. Money in $ millions, shares in millions,
rates as fractions (0.30 = 30%).
"""
from datetime import date

from . import holders, rules as R, wacc_data


# ---------- the business model: how the market values this kind of company (section 10) ----------
def _sic(h):
    try:
        return int(h.get("sic"))
    except (TypeError, ValueError):
        return None


def business_model(h, override=None):
    """(code, why) from rules.BUSINESS_MODELS."""
    if override in R.BUSINESS_MODELS:
        return override, "set in the Peer Groups workbook"
    sic, grp = _sic(h), (h.get("group") or "")
    t = h["ttm"]
    rev, ni = t.get("revenue") or 0, t.get("net_income")
    if sic == 6798 or grp == "REITs":
        return "reit", "real estate investment trust"
    if grp == "Insurance" or (sic and 6311 <= sic <= 6411):
        return "insurer", "insurance company"
    if grp in ("Financials", "Banks and fintech lenders") or (sic and 6000 <= sic <= 6299):
        return "bank", "bank or lender"
    if rev < R.PRE_REVENUE_MAX_MUSD and (ni is None or ni <= 0):
        return "pre_revenue", f"under ${R.PRE_REVENUE_MAX_MUSD}M of revenue in 12 months and a loss"
    if sic == 7372 or (grp == "Software" and sic not in R.NOT_SUBSCRIPTION_SIC):
        return "software", "software sold by subscription"
    if grp == "Semiconductors" or sic in R.CYCLICAL_SIC:
        return "cyclical", "semiconductors and hardware move in cycles"
    if sic and any(lo <= sic <= hi for lo, hi in R.ENERGY_SIC):
        return "energy", "earnings follow commodity prices"
    payout, g = h.get("payout"), h.get("g0") or 0
    if payout is not None and payout >= R.DIVIDEND_MIN_PAYOUT and (ni or 0) > 0 and g < R.DIVIDEND_MAX_GROWTH:
        return "dividend", f"pays out {payout * 100:.0f}% of earnings and grows under {R.DIVIDEND_MAX_GROWTH * 100:.0f}%"
    if h.get("asset_heavy") or (sic and any(lo <= sic <= hi for lo, hi in R.CAPITAL_HEAVY_SIC)):
        return "capital_heavy", "large asset base"
    if ni is not None and ni < 0 and g >= R.UNPROFITABLE_GROWTH_MIN:
        return "unprofitable_growth", f"a loss and revenue growing {g * 100:.0f}%"
    return "standard", "profitable, valued on earnings"


def fade_decay(h, model):
    """Share of the growth gap kept each year: smaller for big companies and for cycles."""
    dec = R.PROJ_GROWTH_DECAY
    rev = h["ttm"].get("revenue") or 0
    for floor_, d in R.PROJ_DECAY_BY_SIZE:
        if rev >= floor_:
            dec = min(dec, d)
            break
    return min(dec, R.MODEL_DECAY.get(model, dec))

SCENARIOS = ("bear", "base", "bull")
SCEN_LABEL = {"bear": "Bear", "base": "Base", "bull": "Bull"}
YEARS = 5                  # current fiscal year + 4
TARGETS = (1, 2, 3)        # price at the end of years 1, 2 and 3, priced on the following year
# key, label, unit (pct | musd | x), first year, last year, shown in the window
INPUTS = [
    ("rev_growth", "Revenue growth", "pct", 0, 4, True),
    ("op_margin", "Operating margin (GAAP)", "pct", 0, 4, True),
    ("net_margin", "Net margin (GAAP)", "pct", 0, 4, True),
    ("eps_growth", "EPS growth (GAAP)", "pct", 0, 4, True),
    ("multiple", "Multiple at year end", "x", 1, 3, True),
    ("fcf_margin", "FCF margin", "pct", 0, 4, True),
    # behind the defaults of net margin and EPS growth: edit in the workbook (Assumptions sheet)
    ("other_musd", "Interest & other, net", "musd", 0, 4, False),
    ("tax_rate", "Tax rate", "pct", 0, 4, False),
    ("share_growth", "Diluted share growth", "pct", 1, 4, False),
    ("sbc_pct", "SBC % of revenue", "pct", 0, 4, False),
    ("da_pct", "D&A % of revenue", "pct", 0, 4, False),
]
INPUT_KEYS = [k for k, *_ in INPUTS]
# key, label, unit
SETTINGS = [
    ("price", "Share price today", "usd"),
    ("price_date", "Price date", "date"),
    ("method", "Valuation method", "text"),
    ("margin_of_safety", "Margin of safety on every fair value", "pct"),
    ("discount_rate", "Discount rate for price targets (return you require)", "pct"),
    ("wacc", "WACC for the FCF valuation (sector)", "pct"),
    ("terminal_method", "Value after year 5: multiple or growth", "text"),
    ("exit_multiple", "Exit multiple on year-5 FCF", "x"),
    ("terminal_growth", "Perpetual FCF growth (growth method)", "pct"),
    ("w_bear", "Weight: bear", "pct"),
    ("w_base", "Weight: base", "pct"),
    ("w_bull", "Weight: bull", "pct"),
    ("quality", "Quality factor (from the grade)", "x"),
    ("base_pe", "Starting P/E for the sector", "x"),
    ("base_ps", "Starting P/S for the sector", "x"),
    ("base_ev_ebitda", "Starting EV/EBITDA for the sector", "x"),
    ("organic", "Organic growth (start of the fade)", "pct"),
    ("amort_musd", "Amortisation of acquired intangibles a year", "musd"),
    ("net_cash_musd", "Net cash (debt)", "musd"),
    ("shares_now", "Diluted shares now", "mshares"),
    # valuation by business model (methodology section 10)
    ("lt_growth", "Long-run growth, end of the fade", "pct"),
    ("decay", "Growth fade: share of the gap kept each year", "pct"),
    ("base_ev_sales", "Starting EV/Sales at a Rule of 40 of 40", "x"),
    ("base_p_ffo", "Starting P/FFO (REITs)", "x"),
    ("midcycle_margin", "Mid-cycle operating margin (cyclicals)", "pct"),
    ("cycle_factor", "Multiple × this at peak margins (cyclicals)", "x"),
    ("payout", "Dividend payout ratio", "pct"),
    ("coe", "Cost of equity (dividends, banks, insurers)", "pct"),
    ("book_now", "Book value now (tangible for banks)", "musd"),
    ("roe_now", "Return on equity now (banks, insurers)", "pct"),
    # the market anchor (method v0.3): today's multiple, and how the peers price the same growth
    ("own_multiple", "Today's multiple (price ÷ the next twelve months' numbers)", "x"),
    ("fair_multiple", "Fair multiple: peers for the same growth, and this stock's last year (targets go to it)", "x"),
]
# the multiple each method is anchored on, and the driver it is paid for
ANCHOR_KEY = {"auto": "pe", "pe_midcycle": "pe", "ps": "ps", "ev_sales": "ev_sales", "ev_sales_r40": "ev_sales",
              "ev_ebitda": "ev_ebitda", "p_ffo": "p_ffo", "p_tbv": "p_tbv", "p_b": "p_b"}
KEY_BASIS = {"pe": "P/E", "ps": "P/S", "ev_sales": "EV/Sales", "ev_ebitda": "EV/EBITDA", "p_ffo": "P/FFO",
             "p_tbv": "P/TBV", "p_b": "P/B"}
METHODS = {"auto": "P/E (P/S while net margin < 5%)", "ps": "P/S", "ev_ebitda": "EV/EBITDA (P/S when EBITDA ≤ 0)",
           "ev_sales_r40": "EV/Sales set by the Rule of 40", "ev_sales": "EV/Sales",
           "pe_midcycle": "P/E on mid-cycle margins", "ddm": "Dividends (DDM)", "p_ffo": "P/FFO",
           "p_tbv": "P/TBV vs ROE", "p_b": "P/B vs ROE", "none": "Not valued"}
METHOD_SHORT = {"auto": "P/E", "ps": "P/S", "ev_ebitda": "EV/EBITDA", "ev_sales_r40": "EV/Sales · Rule of 40",
                "ev_sales": "EV/Sales", "pe_midcycle": "P/E mid-cycle", "ddm": "Dividends (DDM)", "p_ffo": "P/FFO",
                "p_tbv": "P/TBV", "p_b": "P/B", "none": "Not valued"}
BASIS_KEY = {"P/E": "pe", "P/S": "ps", "EV/EBITDA": "ev_ebitda", "EV/Sales": "ev_sales", "P/FFO": "p_ffo",
             "P/D": "p_d", "P/TBV": "p_tbv", "P/B": "p_b"}
OUT_KEYS = ["revenue", "op_income", "pretax", "tax", "net_income", "shares", "eps", "adj_eps",
            "eps_vs_consensus", "ebitda", "fcf", "fcf_after_sbc", "basis", "suggested", "target", "years",
            "ret", "pv", "ahead", "df", "book", "ffo", "r40", "roe", "target_gaap", "nongaap"]


# ---------- helpers ---------------------------------------------------------------------------
def _fy_q(label):
    try:
        return int(label.split()[0].replace("FY", "")), int(label.split("Q")[-1])
    except (ValueError, AttributeError, IndexError):
        return None


def add_years(d, n):
    try:
        return d.replace(year=d.year + n)
    except ValueError:                       # 29 February
        return d.replace(year=d.year + n, day=28)


def _m(x):
    return None if x is None else x / 1e6


def _div(a, b):
    return None if a is None or not b else a / b


def clamp(x, lo, hi):
    return min(hi, max(lo, x))


# ---------- history ---------------------------------------------------------------------------
def history(co, facts, m, g, inputs_row=None, ticker=None):
    """Everything the projection starts from, in $M. Raises RuntimeError when no full fiscal year exists."""
    inputs_row = inputs_row or {}
    ends = co.quarter_ends()
    q = {}
    for e in ends:
        p = _fy_q(co.label(e))
        if p:
            q[p] = e
    snaps = {}

    def snap(e):
        if e not in snaps:
            s = co.snapshot(e)
            s["amort"] = co.v("amort_intangibles", e)
            snaps[e] = s
        return snaps[e]

    def total(pairs, field, missing_is_zero=False):
        vals = [snap(q[p]).get(field) for p in pairs]
        if missing_is_zero:
            vals = [v or 0 for v in vals]
        return None if any(v is None for v in vals) else _m(sum(vals))

    complete = sorted({fy for fy, _ in q if all((fy, k) in q for k in (1, 2, 3, 4))})
    if not complete:
        raise RuntimeError("no complete fiscal year in the SEC data yet: projections need one")
    fya = complete[-1]
    fy0 = fya + 1

    def fy_record(fy):
        pairs = [(fy, k) for k in (1, 2, 3, 4)]
        r = {"fy": fy, "end": q[(fy, 4)]}
        for f, key in (("revenue", "revenue"), ("gross_profit", "gross_profit"),
                       ("operating_income", "operating_income"), ("below_operating", "other"),
                       ("pretax", "pretax"), ("tax", "tax"), ("net_income", "net_income"),
                       ("sbc", "sbc"), ("da", "da"), ("fcf", "fcf")):
            r[key] = total(pairs, f)
        for f in ("amort", "acq_costs", "restructuring"):
            r[f] = total(pairs, f, missing_is_zero=True)
        sh = [snap(q[p]).get("shares_diluted") for p in pairs]
        r["shares"] = None if any(x is None for x in sh) else _m(sum(sh) / 4)
        r["eps"] = _div(r["net_income"], r["shares"])
        r["op_margin"] = _div(r["operating_income"], r["revenue"])
        r["ebitda"] = None if r["operating_income"] is None else r["operating_income"] + (r["da"] or 0)
        r["tax_rate"] = (_div(r["tax"], r["pretax"]) if r["pretax"] and r["pretax"] > 0 else None)
        return r

    fy_actual = [fy_record(fy) for fy in complete[-3:]]
    fya_rec = fy_actual[-1]

    ytd_q = []
    for k in (1, 2, 3):
        if (fy0, k) in q:
            ytd_q.append(k)
        else:
            break
    ytd = {"quarters": len(ytd_q)}
    if ytd_q:
        now, before = [(fy0, k) for k in ytd_q], [(fya, k) for k in ytd_q]
        ytd.update(revenue=total(now, "revenue"), revenue_prior=total(before, "revenue"),
                   op_income=total(now, "operating_income"), other=total(now, "below_operating"))
        ytd["growth"] = (None if not ytd["revenue_prior"] or ytd["revenue"] is None
                         else ytd["revenue"] / ytd["revenue_prior"] - 1)
    end = m["period"]["end"]
    cur = m["cur"]

    def ttm(field, zero=False):
        tot = 0.0
        e = end
        for _ in range(4):
            if e is None:
                return None
            v = snap(e).get(field)
            if v is None:
                if not zero:
                    return None
                v = 0
            tot += v
            e = co.previous(e)
        return _m(tot)

    t = {k: ttm(f) for k, f in (("revenue", "revenue"), ("op_income", "operating_income"),
                                ("other", "below_operating"), ("pretax", "pretax"), ("tax", "tax"),
                                ("sbc", "sbc"), ("da", "da"), ("net_income", "net_income"), ("fcf", "fcf"))}
    for k in ("amort", "acq_costs", "restructuring"):
        t[k] = ttm(k, zero=True)
    etr = _div(t["tax"], t["pretax"]) if t["pretax"] and t["pretax"] > 0 else None

    lastq_m = _div(cur["operating_income"], cur["revenue"])
    shares_now = max(x for x in (cur.get("shares_diluted"), cur.get("shares_basic"), 0) if x is not None) / 1e6
    if not shares_now:
        raise RuntimeError("no share count for the latest quarter: projections need one")
    group = g["industry_group"]
    organic = inputs_row.get("organic_revenue_yoy_pct")
    h = {
        "ticker": None, "name": None, "group": group, "grade": g["grade"], "provisional": g["provisional"],
        "company_type": g["company_type"], "asset_heavy": m["assets"]["asset_heavy"],
        "latest_end": end, "latest_label": m["period"]["label"],
        "fya": fya, "fy0": fy0, "fya_end": date.fromisoformat(fya_rec["end"]),
        "fy_actual": fy_actual, "fya_rec": fya_rec, "ytd": ytd, "ttm": t,
        "lastq_margin": lastq_m, "lastq_other": _m(cur.get("below_operating")),
        "sic": g.get("sic"),
        "g0": ytd.get("growth") if ytd.get("growth") is not None else (m["revenue"]["yoy_pct"] or 0) / 100,
        "ttm_margin": _div(t["op_income"], t["revenue"]),
        "ttm_tax_rate": etr,
        "ttm_share_growth": (m["dilution"]["yoy_pct"] or 0) / 100,
        "organic": None if organic is None else organic / 100,
        "shares_now": shares_now,
        "net_cash": _m(m["debt"]["net_cash"]),
        "bridge": bridge(co, m, cur, inputs_row, t, fya_rec),
        "holder_risks": m.get("holder_risks") or [],
        "sbc_pct_rev": m["sbc"]["pct_rev_cur"],
    }
    # what the business-model valuations need
    s_now = snap(end)
    eq = s_now.get("equity")
    h["equity"] = _m(eq)
    h["tbv"] = None if eq is None else _m(eq - (s_now.get("goodwill") or 0) - (s_now.get("intangibles") or 0))
    div = co.cf_ttm("dividends", end)
    h["dividends_ttm"] = None if div is None else abs(_m(div))
    ni = t.get("net_income")
    h["payout"] = (clamp(h["dividends_ttm"] / ni, 0.0, 1.0) if h["dividends_ttm"] and ni and ni > 0 else
                   (0.0 if h["dividends_ttm"] == 0 else None))
    h["fy_margins"] = []                                   # operating margin of up to 7 full years: the cycle
    for fy in complete[-7:]:
        rec = fy_actual[[x["fy"] for x in fy_actual].index(fy)] if fy in [x["fy"] for x in fy_actual] else fy_record(fy)
        if rec["op_margin"] is not None:
            h["fy_margins"].append(rec["op_margin"])
    liquid = None if cur.get("cash") is None else cur["cash"] + (cur.get("st_investments") or 0)
    h["cash_now"] = _m(liquid)
    override = None
    if ticker:
        try:
            from . import peers
            override = peers.model_for(ticker)
        except Exception:
            override = None
    h["model"], h["model_why"] = business_model(h, override)
    h["decay"] = fade_decay(h, h["model"])
    h["warnings"] = []
    return h


def bridge(co, m, cur, inputs_row, t, fya_rec):
    """What separates GAAP from adjusted EPS, from the filing: latest quarter, last 12 months, last year."""
    sh = cur.get("shares_diluted")
    items_q = {"sbc": cur.get("sbc"), "amort": co.v("amort_intangibles", m["period"]["end"]),
               "acq_costs": cur.get("acq_costs"), "restructuring": cur.get("restructuring")}
    rows = []
    for key, label in (("sbc", "Stock-based compensation"), ("amort", "Amortisation of acquired intangibles"),
                       ("acq_costs", "Acquisition-related costs"), ("restructuring", "Restructuring")):
        q_val = _m(items_q[key] or 0)
        rows.append({"key": key, "label": label, "quarter": q_val,
                     "per_share_q": None if not sh else (items_q[key] or 0) / sh,
                     "ttm": t.get(key), "last_fy": fya_rec.get(key)})
    tot_q = sum(r["quarter"] for r in rows)
    acq_q = sum(r["quarter"] for r in rows if r["key"] in ("amort", "acq_costs"))
    gaap = m["eps"]["gaap_cur"]
    adj = inputs_row.get("eps_nongaap")
    gap = None if adj is None or gaap is None else adj - gaap
    pre_tax_ps = None if not sh else sum((items_q[r["key"]] or 0) for r in rows) / sh
    out = {"rows": rows, "total_q": tot_q, "acq_share": _div(acq_q, tot_q), "sbc_share": _div(rows[0]["quarter"], tot_q),
           "gaap_eps": gaap, "adj_eps": adj, "gap": gap, "items_per_share": pre_tax_ps,
           "other": None if gap is None or pre_tax_ps is None else gap - pre_tax_ps,
           "label": m["period"]["label"]}
    msg = []
    if tot_q:
        msg.append(f"Acquisition items (amortisation of acquired intangibles + deal costs) are "
                   f"{out['acq_share'] * 100:.0f}% of the add-backs; stock-based pay {out['sbc_share'] * 100:.0f}%.")
        if (out["acq_share"] or 0) >= 0.4:
            msg.append("Most of the gap comes from past acquisitions: a non-cash charge that ends when the "
                       "intangibles are fully amortised. Judge whether the deals are paying off.")
        elif (out["sbc_share"] or 0) >= 0.6:
            msg.append("Most of the gap is stock-based pay: a real, recurring cost paid in shares (see dilution).")
    if gap is not None and out["other"] is not None:
        msg.append(f"Reported gap ${gap:.2f}/share; these items ${pre_tax_ps:.2f} before tax; "
                   f"the rest (${out['other']:+.2f}) is the tax effect and other items in the press release.")
    msg.append("SEC data does not split SBC from acquisitions (retention grants): check the press release reconciliation.")
    out["text"] = " ".join(msg)
    out["points"] = msg
    return out


# ---------- the market anchor ------------------------------------------------------------------------------------
def _driver(key, growth, fcf_margin=None, roe=None):
    """What a multiple is paid for: Rule of 40 for sales multiples, 8 + growth % for earnings ones, ROE for book.
    Growth counts up to 50% (beyond it the market does not pay)."""
    if growth is not None:
        growth = clamp(growth, -0.2, R.ANCHOR_GROWTH_CAP)
    if key in ("ev_sales", "ps"):
        return None if growth is None or fcf_margin is None else (growth + fcf_margin) * 100
    if key in ("pe", "ev_ebitda", "p_ffo"):
        return None if growth is None else R.ANCHOR_GROWTH_OFFSET + growth * 100
    if key in ("p_b", "p_tbv"):
        return None if roe is None else roe * 100
    return None


def _multiples_now(price, shares, net_cash, revenue, ebitda, eps, equity, ffo=None):
    """Today's multiples on twelve-month numbers (same units for all: $M and M shares, or $ and shares)."""
    if not price or not shares:
        return {}
    mcap = price * shares
    ev = mcap - (net_cash or 0)
    pos = lambda a, b: a / b if a and b and a > 0 and b > 0 else None
    return {"ev_sales": pos(ev, revenue), "ps": pos(mcap, revenue), "ev_ebitda": pos(ev, ebitda),
            "pe": pos(price, eps), "p_b": pos(mcap, equity), "p_tbv": pos(mcap, equity), "p_ffo": pos(mcap, ffo)}


def peer_relative(h, peer_stats, peer_prices):
    """{key: {k, n, peers, own}} — for each multiple, the median over the peers of (multiple ÷ driver), divided by
    this company's (multiple ÷ driver), all on today's prices and twelve-month numbers. k > 1: peers are paid more
    for the same growth, so this company's multiple drifts up toward them; k < 1: down."""
    t = h.get("ttm") or {}
    price = h.get("price_live")
    shares = h.get("shares_now")
    rev = t.get("revenue")
    g = h["organic"] if h.get("organic") is not None else h.get("g0")
    fcf_m = (t.get("fcf") / rev) if rev and t.get("fcf") is not None else None
    ebitda = (t.get("op_income") or 0) + (t.get("da") or 0) if t.get("op_income") is not None else None
    eps = (t.get("net_income") / shares) if shares and t.get("net_income") is not None else None
    roe = (t.get("net_income") / h["equity"]) if h.get("equity") and t.get("net_income") is not None else None
    own_m = _multiples_now(price, shares, h.get("net_cash"), rev, ebitda, eps, h.get("equity"))
    out = {}
    for key in ("ev_sales", "ps", "pe", "ev_ebitda", "p_b"):
        lo, hi = R.PROJ_MULTIPLE_LIMITS[key]
        od = _driver(key, g, fcf_m, roe)
        om = own_m.get(key)
        if not om or not od or od <= 0:
            continue
        mults, drvs, names = [], [], []
        for p, st in (peer_stats or {}).items():
            px = (peer_prices or {}).get(p)
            if not px or not st:
                continue
            nc = (st.get("cash") or 0) - (st.get("debt") or 0)
            pm = _multiples_now(px, st.get("shares"), nc, st.get("revenue"), st.get("ebitda"), st.get("eps"),
                                st.get("equity")).get(key)
            pd = _driver(key, st.get("rev_growth"), st.get("fcf_margin"), st.get("roe"))
            if pm and pd and pd > 0 and lo <= pm <= hi:
                mults.append(pm)
                drvs.append(pd)
                names.append(p)
        if len(mults) < R.ANCHOR_MIN_PEERS:
            continue
        med = lambda xs: sorted(xs)[len(xs) // 2] if len(xs) % 2 else \
            (sorted(xs)[len(xs) // 2 - 1] + sorted(xs)[len(xs) // 2]) / 2
        mp, dp = med(mults), med(drvs)
        fair = mp * (od / dp) ** R.ANCHOR_PEER_EXP
        out[key] = {"k": fair / om, "n": len(mults), "peers": names, "own_now_ttm": om, "own_driver": od,
                    "peer_multiple": mp, "peer_driver": dp, "fair_ttm": fair}
    return out


def ntm(xs, ahead0, shift=0):
    """Next twelve months of a yearly line, from today (shift 0) or a year from today (shift 1): the part of the
    current fiscal year still ahead plus the matching part of the next one."""
    a = min(max(ahead0 if ahead0 is not None else 1.0, 0.0), 1.0)
    i = shift
    if i + 1 >= len(xs) or xs[i] is None or xs[i + 1] is None:
        return None
    return a * xs[i] + (1 - a) * xs[i + 1]


def _key_numbers(key, o, S, shift=0):
    """(numerator kind, next-twelve-months metric) for a multiple: 'ev' or 'mcap' or 'price' over the metric."""
    a0 = o["ahead"][0]
    if key == "pe":
        eps = o["adj_eps"] if S.get("_ng") and all(v is not None for v in o["adj_eps"]) else o["eps"]
        return "price", ntm(eps, a0, shift)
    if key in ("ev_sales", "ps"):
        return ("ev" if key == "ev_sales" else "mcap"), ntm(o["revenue"], a0, shift)
    if key == "ev_ebitda":
        return "ev", ntm(o["ebitda"], a0, shift)
    if key == "p_ffo":
        return "mcap", ntm(o["ffo"], a0, shift)
    if key in ("p_b", "p_tbv"):
        return "mcap", (S.get("book_now") if shift == 0 else o["book"][0])
    return None, None


def own_multiple(key, o, S, raw=False):
    """Today's multiple on the next twelve months (base case): what the market pays now, looking forward. Held to
    the house limits unless raw."""
    if key is None or not S.get("price") or not S.get("shares_now"):
        return None
    kind, m = _key_numbers(key, o, S)
    if not m or m <= 0:
        return None
    mcap = S["price"] * S["shares_now"]
    num = {"price": S["price"], "mcap": mcap, "ev": mcap - (S["net_cash_musd"] or 0)}[kind]
    if num <= 0:
        return None
    x = num / m
    if raw:
        return x
    lo, hi = R.PROJ_MULTIPLE_LIMITS[key]
    return clamp(x, lo, hi)


def scenario_fair(s, own, fair):
    """The fair multiple for every case: bear and bull differ by their numbers (growth, margins), not by it."""
    return fair or own


def quality_tilt(quality):
    return 1 + clamp((quality or 1) - 1, -R.ANCHOR_QUALITY_BAND, R.ANCHOR_QUALITY_BAND)


def anchored_multiple(key, own, fair, today_w, adj, quality):
    lo, hi = R.PROJ_MULTIPLE_LIMITS[key]
    return clamp((own * today_w + fair * (1 - today_w)) * adj * quality_tilt(quality), lo, hi)


def fair_parts(h, S, key):
    """(k: peers ÷ today's, H: last year's median ÷ today's, peer weight), each limited; None when not known."""
    cyc = S["method"] in R.ANCHOR_CYCLICAL
    pk = ((h.get("peer_k") or {}).get(key) or {}).get("k")
    k = clamp(pk, *(R.ANCHOR_K_LIMITS_CYCLICAL if cyc else R.ANCHOR_K_LIMITS)) if pk else None
    from . import multiples_history as MH
    Hraw, ratios = MH.factor(h.get("hist_mult"), S["price"])
    H = clamp(Hraw, *R.ANCHOR_HIST_LIMITS) if Hraw else None
    return k, H, (R.ANCHOR_PEER_WEIGHT_CYCLICAL if cyc else R.ANCHOR_PEER_WEIGHT), ratios


def fair_multiple(key, own, k, H, wp):
    if not own:
        return None
    lo, hi = R.PROJ_MULTIPLE_LIMITS[key]
    wp = wp if k else 0.0                 # no peers: the stock's own last year alone
    return clamp(own * (k or 1.0) ** wp * (H or 1.0) ** (1 - wp), lo, hi)


def anchor_adj(key, o, used, f):
    """√(growth the multiple pays for at year f ÷ the same next year), within limits: slower growth ahead, a lower
    multiple. Sales multiples: Rule of 40; earnings multiples: 8 + growth %; book: return on equity."""
    def drv(y):
        if key in ("ev_sales", "ps"):
            return o["r40"][y]
        if key in ("pe", "ev_ebitda", "p_ffo"):
            return R.ANCHOR_GROWTH_OFFSET + growth_after(used["rev_growth"], y) * 100
        if key in ("p_b", "p_tbv"):
            return (o["roe"][y] or 0) * 100
        return None
    a, b = drv(f), drv(1)
    if a is None or b is None or a <= 0 or b <= 0:
        return 1.0
    return clamp((a / b) ** 0.5, *R.ANCHOR_ADJ_LIMITS)


# ---------- defaults --------------------------------------------------------------------------
def fast_lender(h):
    """A bank or lender growing 15%+ a year with a profit (a fintech like SoFi): the market and the analysts value
    it on earnings, not on book value (P/TBV vs ROE assumes a mature bank)."""
    g = h["organic"] if h.get("organic") is not None else h.get("g0")
    return h["model"] == "bank" and (g or 0) >= R.BANK_GROWTH_FOR_PE and (h["ttm"].get("net_income") or 0) > 0


def default_method(h):
    if fast_lender(h):
        return "auto"
    return R.BUSINESS_MODELS[h["model"]][1] if h["model"] != "standard" else \
        ("ev_ebitda" if h["asset_heavy"] else "auto")


def setting_defaults(h):
    base = R.PROJ_BASE_MULTIPLES.get(h["group"], R.PROJ_BASE_MULTIPLES["default"])
    wacc, _src = wacc_data.for_company(h["group"], h.get("sic"))
    return {
        "price": h.get("price_live"), "price_date": date.today(),       # Yahoo Finance, set by the window
        "method": default_method(h),
        "margin_of_safety": R.PROJ_MARGIN_OF_SAFETY,
        "discount_rate": R.PROJ_DISCOUNT_RATE, "wacc": wacc, "terminal_growth": R.PROJ_TERMINAL_GROWTH,
        "terminal_method": R.PROJ_TERMINAL_METHOD, "exit_multiple": None,   # filled from the base case
        "w_bear": R.PROJ_WEIGHTS["bear"], "w_base": R.PROJ_WEIGHTS["base"], "w_bull": R.PROJ_WEIGHTS["bull"],
        "quality": R.PROJ_QUALITY.get(h["grade"], 1.0),
        "base_pe": base["pe"], "base_ps": base["ps"], "base_ev_ebitda": base["ev_ebitda"],
        "organic": h["organic"], "amort_musd": h["ttm"].get("amort") or 0.0,
        "net_cash_musd": h["net_cash"] or 0.0, "shares_now": h["shares_now"],
        "lt_growth": R.PROJ_LONG_RUN_GROWTH, "decay": h["decay"],
        "base_ev_sales": base.get("ev_sales", R.PROJ_BASE_MULTIPLES["default"]["ev_sales"]),
        "base_p_ffo": base.get("p_ffo", R.PROJ_BASE_MULTIPLES["default"]["p_ffo"]),
        "midcycle_margin": midcycle(h), "cycle_factor": cycle_factor(h),
        "payout": h["payout"] or 0.0,
        "coe": R.COST_OF_EQUITY.get(h["model"], R.COST_OF_EQUITY["default"]),
        "book_now": (h["tbv"] if h["model"] == "bank" else h["equity"]) or 0.0,
        "roe_now": roe_now(h),
        "own_multiple": None,            # worked out from the base case's next twelve months (compute)
        "fair_multiple": None,           # peers and last year's prices, from today's multiple (compute)
    }


def roe_now(h):
    book = (h["tbv"] if h["model"] == "bank" else h["equity"]) or 0.0
    ni = h["ttm"].get("net_income")
    return ni / book if ni is not None and book > 0 else 0.0


def midcycle(h):
    """Cyclicals at a peak: the average operating margin over the last years (losses count as 0).
    None when the company is not a cyclical, or its margin is not near a record: no pull back then."""
    if h["model"] not in ("cyclical", "energy") or h["ttm_margin"] is None:
        return None
    hist = [max(0.0, x) for x in h["fy_margins"]]
    if not hist:
        return None
    now = h["ttm_margin"]
    mid = sum(hist + [max(0.0, now)]) / (len(hist) + 1)
    peak = now >= R.CYCLE_PEAK_SHARE * max(hist + [now])
    return mid if peak and now > mid else None


def cycle_factor(h):
    mid, now = midcycle(h), h["ttm_margin"]
    if mid is None or now is None or now <= mid or now <= 0:
        return 1.0
    return clamp(mid / now, *R.CYCLE_FACTOR_LIMITS)


def dilution_ahead(h):
    """Share-count growth to carry forward: last year's, but at most stock pay ÷ market cap (+0.5pt) — shares
    issued for an acquisition or a capital raise are not repeated every year. Buybacks are kept as they are."""
    g = h["ttm_share_growth"] or 0.0
    sbc, px, sh = (h["ttm"].get("sbc") or 0.0), h.get("price_live"), h.get("shares_now")
    if g > 0 and px and sh:
        g = min(g, sbc / (px * sh) + R.PROJ_SHARE_GROWTH_SBC_CAP)
    return g


def wacc_source(h):
    return wacc_data.for_company(h["group"], h.get("sic"))[1]


def constants(h):
    """History-based starting values: written as plain numbers in the workbook."""
    t = h["ttm"]
    rev = t["revenue"] or 0
    tax = h["ttm_tax_rate"]
    group = h["group"]
    n, ytd = h["ytd"]["quarters"], h["ytd"]
    lastq_other = h.get("lastq_other")
    # what is left of this fiscal year: recurring costs continue, one-off gains are not repeated
    if 0 < n < 4 and ytd.get("other") is not None and lastq_other is not None:
        other0 = ytd["other"] + (4 - n) * min(0.0, lastq_other)
    else:
        other0 = t["other"] or 0.0
    other_run = 4 * min(0.0, lastq_other) if lastq_other is not None else min(0.0, t["other"] or 0.0)
    g0 = h["g0"]
    if n == 0:      # no quarter of this fiscal year reported yet: it is a future year, so the fade and cap apply
        g0 = min(R.PROJ_DEFAULT_GROWTH_CAP, R.PROJ_LONG_RUN_GROWTH + (g0 - R.PROJ_LONG_RUN_GROWTH) * h["decay"])
    return {
        "g0": g0,
        "om0_ttm": h["ttm_margin"] or 0.0,
        "ytd_n": n, "ytd_rev": ytd.get("revenue"), "ytd_oi": ytd.get("op_income"),
        "lastq_m": h["lastq_margin"] if h["lastq_margin"] is not None else (h["ttm_margin"] or 0.0),
        "other0": other0, "other_run": other_run,
        "tax0": tax if tax is not None and 0 <= tax <= 0.35 else R.PROJ_TAX_DEFAULT,
        "sg1": dilution_ahead(h) * R.PROJ_SHARE_FADE,
        "sbc0": (t["sbc"] or 0) / rev if rev else 0.0,
        "da0": (t["da"] or 0) / rev if rev else 0.0,
        "fcf0": (t["fcf"] or 0) / rev if rev and t.get("fcf") is not None else 0.0,
        # how much of net income arrives as free cash flow (None when either is not positive)
        # software: stock pay keeps FCF far above net income, so FCF follows the operating margin instead
        "conv": (clamp(t["fcf"] / t["net_income"], *R.PROJ_FCF_CONVERSION_LIMITS)
                 if (t.get("fcf") or 0) > 0 and (t.get("net_income") or 0) > 0 and h["model"] != "software"
                 else None),
        "cap": R.PROJ_MARGIN_CAP.get(group, R.PROJ_MARGIN_CAP["default"]),
        "step": R.PROJ_MARGIN_STEP if h["company_type"] == "growth" else 0.0,
        # asset-heavy: borrowing grows with the asset base, so interest grows with revenue
        "other_scales": bool(h["asset_heavy"]),
        "growth_cap_later": R.ENERGY_GROWTH_CAP if h["model"] == "energy" else None,
    }


def growth_after(used_growth, f):
    """Average revenue growth from the forward year to the last projected year: what the multiple pays for."""
    vals = used_growth[f:YEARS]
    return sum(vals) / len(vals)


def ddm_growth(growth, S):
    """Dividend growth for ever: the revenue growth ahead, at most 6% and 2 points under the cost of equity."""
    return min(R.DDM_MAX_GROWTH, max(0.0, growth or 0), S["coe"] - R.DDM_MIN_SPREAD)


def suggested_multiple(basis, growth, S, method=None, x=None):
    """x: what some methods need beyond growth — r40 (Rule of 40, in points), roe (return on equity)."""
    x = x or {}
    k = BASIS_KEY[basis]
    lo, hi = R.PROJ_MULTIPLE_LIMITS[k]
    if k == "ev_sales" and method == "ev_sales_r40":
        r40 = x.get("r40")
        return clamp(S["base_ev_sales"] * max(r40 or 0, 0) / R.RULE_OF_40_PIVOT * S["quality"], lo, hi)
    if k == "ev_sales":
        return clamp((S["base_ev_sales"] + R.PROJ_GROWTH_PER_POINT[k] * (growth or 0) * 100) / 2 * S["quality"],
                     lo, hi)
    if k == "p_d":
        g = ddm_growth(growth, S)
        return clamp((1 + g) / (S["coe"] - g), lo, hi)
    if k in ("p_tbv", "p_b"):
        roe, g = x.get("roe"), S["lt_growth"]
        if roe is None:
            return lo
        return clamp((roe - g) / (S["coe"] - g), lo, hi)
    m = clamp((S["base_" + k] + R.PROJ_GROWTH_PER_POINT[k] * (growth or 0) * 100) / 2 * S["quality"], lo, hi)
    if k == "pe" and method == "pe_midcycle":
        m = max(lo, m * (S["cycle_factor"] or 1.0))
    return m


def basis_for(method, eps_f, ebitda_f, net_margin_f=None, ffo_f=None, book_f=None, payout=None):
    if method == "none":
        return None
    if method == "ps":
        return "P/S"
    if method in ("ev_sales", "ev_sales_r40"):
        return "EV/Sales"
    if method == "ev_ebitda":
        return "EV/EBITDA" if ebitda_f is not None and ebitda_f > 0 else "P/S"
    if method == "p_ffo":
        return "P/FFO" if ffo_f is not None and ffo_f > 0 else "P/S"
    if method in ("p_tbv", "p_b"):
        return ("P/TBV" if method == "p_tbv" else "P/B") if book_f is not None and book_f > 0 else "P/S"
    ok = eps_f is not None and eps_f > 0 and (net_margin_f or 0) >= R.PROJ_PE_MIN_NET_MARGIN
    if method == "ddm" and ok and (payout or 0) > 0:
        return "P/D"
    return "P/E" if ok else "P/S"


# ---------- the model -------------------------------------------------------------------------
def _used(user_val, default):
    return default if user_val is None else user_val


def compute(h, user=None):
    """user = {"settings": {k: v}, "consensus": {"revenue": {fy: v}, "eps": {fy: v}},
               "scen": {scenario: {input: {fy: v}}}} — only what you typed."""
    user = user or {}
    us, uc, uscen = user.get("settings", {}), user.get("consensus", {}), user.get("scen", {})
    sd = setting_defaults(h)
    S = {k: _used(us.get(k), sd[k]) for k in sd}
    akey = ANCHOR_KEY.get(S["method"])
    S["_k"], S["_H"], S["_wp"], S["_hist_ratios"] = fair_parts(h, S, akey) if akey else (None, None, 0, {})
    S["_anchor_key"] = akey
    S["_fair_typed"] = us.get("fair_multiple") is not None
    S["_own_typed"] = us.get("own_multiple") is not None
    c = constants(h)
    fys = [h["fy0"] + i for i in range(YEARS)]
    fy_ends = [add_years(h["fya_end"], i + 1) for i in range(YEARS)]
    # consensus: what you typed first, then the company's guidance you accepted, then the analysts' (estimates.py)
    auto = h.get("auto_consensus") or {}
    cons_rev, cons_eps, cons_src = [], [], {"revenue": [], "eps": []}
    for k, out in (("revenue", cons_rev), ("eps", cons_eps)):
        for fy in fys:
            mine = uc.get(k, {}).get(fy)
            got = (auto.get(k) or {}).get(fy) or (auto.get(k) or {}).get(str(fy))
            if mine is not None:
                out.append(mine)
                cons_src[k].append("yours")
            elif got and got.get("value") is not None:
                out.append(got["value"])
                cons_src[k].append(got.get("src") or "consensus")
            else:
                out.append(None)
                cons_src[k].append(None)
    a = h["fya_rec"]
    res = {"fys": fys, "labels": [f"FY{fy}E" for fy in fys], "fy_ends": fy_ends, "settings": S,
           "settings_default": sd, "constants": c, "cons_rev": cons_rev, "cons_eps": cons_eps,
           "cons_src": cons_src, "cons_info": {k: auto.get(k) for k in ("fetched", "valid_until", "source_note")},
           "actual": a, "scen": {}, "warnings": list(h.get("warnings", [])), "wacc_source": wacc_source(h)}
    S["_ng"] = any(v is not None for v in cons_eps) and S["method"] != "ddm"
    for s in ("base", "bear", "bull"):
        res["scen"][s] = _scenario(s, h, S, c, fys, fy_ends, cons_rev, cons_eps, uscen.get(s, {}),
                                   res["scen"].get("base"))
        if s == "base":
            sd["own_multiple"] = S.pop("_own_default", None)
            sd["fair_multiple"] = S.pop("_fair_default", None)
    # value after year 5: default exit multiple = the P/E the base case's final-year growth supports
    sd["exit_multiple"] = suggested_multiple("P/E", res["scen"]["base"]["used"]["rev_growth"][-1], S)
    S["exit_multiple"] = _used(us.get("exit_multiple"), sd["exit_multiple"])
    for s in SCENARIOS:
        o = res["scen"][s]["out"]
        res["scen"][s]["dcf"] = _dcf(o["fcf"], o, S)
        res["scen"][s]["dcf_sbc"] = _dcf(o["fcf_after_sbc"], o, S)
    _weigh(res, S)
    res["model"] = {"code": h["model"], "label": R.BUSINESS_MODELS[h["model"]][0], "why": h["model_why"],
                    "method": S["method"], "method_label": METHODS.get(S["method"], S["method"]),
                    "method_short": METHOD_SHORT.get(S["method"], S["method"])}
    res["method_notes"] = method_notes(res, S, h)
    res["holder_risks"] = holder_risks(S, h)
    res["reconcile"] = reconcile(res)
    res["anchor"] = anchor_summary(res, S, h)
    return res


def _scenario(s, h, S, c, fys, fy_ends, cons_rev, cons_eps, mine, base):
    U = {k: [mine.get(k, {}).get(fy) for fy in fys] for k in INPUT_KEYS}
    used = {k: [None] * YEARS for k in INPUT_KEYS}
    dflt = {k: [None] * YEARS for k in INPUT_KEYS}
    o = {k: [None] * YEARS for k in OUT_KEYS}
    a = h["fya_rec"]
    off = R.PROJ_SCENARIO_OFFSETS.get(s)
    LT, DEC, SF = S["lt_growth"], S["decay"], R.PROJ_SHARE_FADE
    CAP = R.PROJ_DEFAULT_GROWTH_CAP
    model = h["model"]
    MID = S["midcycle_margin"]          # set (cyclicals at a peak, or typed): margins drift back to it

    def set_(k, y, d):
        dflt[k][y] = d
        used[k][y] = _used(U[k][y], d)
        return used[k][y]

    prev_rev, prev_eps = a["revenue"], a["eps"]
    gap = 0.0      # base: how far the net margin sits from its default to meet the consensus EPS; held after it
    derived = [None] * YEARS
    for y in range(YEARS):
        B = (lambda k: base["used"][k][y]) if base else None
        BD = (lambda k: base["default"][k][y]) if base else None
        # 1. revenue growth
        if s == "base":
            if cons_rev[y] is not None:
                d = cons_rev[y] / prev_rev - 1
            elif y == 0:
                d = c["g0"]
            elif y == 1:
                d = min(CAP, LT + ((S["organic"] if S["organic"] is not None else used["rev_growth"][0]) - LT) * DEC)
            else:
                d = min(CAP, LT + (used["rev_growth"][y - 1] - LT) * DEC)
            if y >= 1 and cons_rev[y] is None and c["growth_cap_later"] is not None:
                d = min(d, c["growth_cap_later"])
        else:
            d = B("rev_growth") + (off["g0"] if y == 0 else off["g"])
        g = set_("rev_growth", y, d)
        rev = prev_rev * (1 + g)
        # 2. operating margin
        if s == "base":
            if y == 0:
                if 0 < c["ytd_n"] < 4 and c["ytd_rev"] is not None and c["ytd_oi"] is not None:
                    d = (c["ytd_oi"] + (rev - c["ytd_rev"]) * c["lastq_m"]) / rev
                else:
                    d = c["om0_ttm"]
            elif MID is not None:       # cyclicals: back toward the mid-cycle margin, not up from the peak
                prev = used["op_margin"][y - 1]
                d = prev + (MID - prev) * R.MIDCYCLE_PULL
            else:
                prev = max(used["op_margin"][0], c["lastq_m"]) if y == 1 else used["op_margin"][y - 1]
                step = max(c["step"], (c["cap"] - prev) * R.PROJ_MARGIN_CONVERGE_LOSS) if prev < 0 else c["step"]
                d = prev if prev >= c["cap"] else min(c["cap"], prev + step)
        else:
            d = B("op_margin") + off["om"]
        om = set_("op_margin", y, d)
        # behind the defaults: interest & other, tax, dilution, SBC, D&A
        if s == "base":
            grow = (1 + g) if c["other_scales"] else 1.0
            set_("other_musd", y, c["other0"] if y == 0 else
                 c["other_run"] * grow if y == 1 else used["other_musd"][y - 1] * grow)
            set_("tax_rate", y, c["tax0"] if y == 0 else max(R.PROJ_TAX_FLOOR, used["tax_rate"][y - 1]))
            set_("da_pct", y, c["da0"] if y == 0 else used["da_pct"][y - 1])
            set_("sbc_pct", y, c["sbc0"] if y == 0 else max(0.0, used["sbc_pct"][y - 1] + R.PROJ_SBC_STEP))
        else:
            for k in ("other_musd", "tax_rate", "da_pct", "sbc_pct"):
                set_(k, y, B(k))
        if y >= 1:
            if s == "base":
                set_("share_growth", y, c["sg1"] if y == 1 else used["share_growth"][y - 1] * SF)
            else:
                set_("share_growth", y, B("share_growth") + off["sg"])
        oi = rev * om
        pretax = oi + used["other_musd"][y]
        tax = max(0.0, pretax) * used["tax_rate"][y]
        shares_path = S["shares_now"] if y == 0 else o["shares"][y - 1] * (1 + used["share_growth"][y])
        # 3. net margin: default = what the operating margin leaves after interest and tax. With a consensus EPS
        # (adjusted, as analysts quote it), the base case's net margin is set so its adjusted EPS meets it,
        # and that difference is kept for the years after
        derived_nm = (pretax - tax) / rev
        if s == "base":
            if cons_eps[y] is not None and shares_path and rev:
                fit = (cons_eps[y] * shares_path - (used["sbc_pct"][y] * rev + S["amort_musd"])
                       * (1 - used["tax_rate"][y])) / rev
                gap = fit - derived_nm
            d_nm = derived_nm + gap
        else:   # the base case's whole difference from its own derived margin (consensus fit, your number)
            d_nm = derived_nm + (B("net_margin") - base["derived_nm"][y])
        derived[y] = derived_nm
        nm = set_("net_margin", y, d_nm)
        ni = rev * nm
        # 4. EPS growth: default = net income over the projected share count
        eps_derived = ni / shares_path if shares_path else None
        can_grow = prev_eps is not None and prev_eps > 0
        d = (eps_derived / prev_eps - 1) if can_grow and eps_derived is not None else None
        if s != "base" and d is not None and B("eps_growth") is not None and BD("eps_growth") is not None:
            d += B("eps_growth") - BD("eps_growth")
        eg = set_("eps_growth", y, d)
        eps = prev_eps * (1 + eg) if can_grow and eg is not None else eps_derived
        shares = ni / eps if eps is not None and eps > 0 and ni > 0 else shares_path
        # 5. free cash flow
        if c["conv"] is not None:
            # FCF follows net income at the conversion of the last 12 months
            d = nm * c["conv"]
            if s != "base":
                d += B("fcf_margin") - BD("fcf_margin")
        elif s == "base":
            # no positive base: FCF margin moves with the operating margin, after tax
            d = (c["fcf0"] if y == 0 else
                 used["fcf_margin"][y - 1] + (om - used["op_margin"][y - 1]) * (1 - used["tax_rate"][y]))
        else:
            d = B("fcf_margin") + (om - B("op_margin")) * (1 - used["tax_rate"][y])
        fm = set_("fcf_margin", y, d)
        o["revenue"][y], o["op_income"][y], o["pretax"][y], o["tax"][y], o["net_income"][y] = rev, oi, pretax, tax, ni
        o["shares"][y], o["eps"][y] = shares, eps
        o["adj_eps"][y] = ((ni + (used["sbc_pct"][y] * rev + S["amort_musd"]) * (1 - used["tax_rate"][y])) / shares
                           if shares else None)
        o["eps_vs_consensus"][y] = ((o["adj_eps"][y] / cons_eps[y] - 1) if cons_eps[y] and o["adj_eps"][y] is not None
                                    else None)
        o["ebitda"][y] = oi + used["da_pct"][y] * rev
        o["fcf"][y] = rev * fm
        o["fcf_after_sbc"][y] = rev * (fm - used["sbc_pct"][y])
        yrs = (fy_ends[y] - S["price_date"]).days / 365.25
        o["years"][y] = yrs
        o["ahead"][y] = clamp(yrs, 0.0, 1.0)                       # part of the fiscal year still ahead
        o["df"][y] = 1 / (1 + S["wacc"]) ** max(yrs, 0.0)
        # book value: today's, plus the earnings still ahead that are not paid out. Banks and insurers:
        # earnings = return on equity × book (their revenue lines do not fit the operating model)
        before = S["book_now"] if y == 0 else o["book"][y - 1]
        if S["method"] in ("p_tbv", "p_b"):
            roe = S["roe_now"] + (off["roe"] if off else 0.0)
            earned = roe * before
        else:
            roe = ni / before if before and before > 0 else None
            earned = ni
        o["roe"][y] = roe
        o["book"][y] = before + (1 - S["payout"]) * earned * o["ahead"][y]
        o["ffo"][y] = ni + used["da_pct"][y] * rev                    # REITs: earnings + depreciation
        o["r40"][y] = (g + fm) * 100                                  # Rule of 40: growth + FCF margin
        prev_rev, prev_eps = rev, eps

    price, r = S["price"], S["discount_rate"]
    if s == "base":
        own = own_multiple(S.get("_anchor_key"), o, S)
        S["_own_default"] = own
        if not S.get("_own_typed"):
            S["own_multiple"] = own
        fair = fair_multiple(S["_anchor_key"], S["own_multiple"], S["_k"], S["_H"], S["_wp"]) \
            if S.get("_anchor_key") else None
        S["_fair_default"] = fair
        if not S.get("_fair_typed"):
            S["fair_multiple"] = fair
    for T in TARGETS:
        f = T + 1
        ga = growth_after(used["rev_growth"], f)
        # with a consensus, P/E is on non-GAAP (adjusted) EPS, as the market quotes it; GAAP is shown beside
        ng = any(v is not None for v in cons_eps) and S["method"] != "ddm"
        eps_b = o["adj_eps"][f] if ng and o["adj_eps"][f] is not None else o["eps"][f]
        nm_b = (eps_b * o["shares"][f] / o["revenue"][f]) if ng and eps_b is not None and o["shares"][f] \
            else o["net_income"][f] / o["revenue"][f]
        b = basis_for(S["method"], eps_b, o["ebitda"][f], nm_b, o["ffo"][f], o["book"][f], S["payout"])
        o["basis"][T] = b
        if b is None:                                 # not valued (pre-revenue)
            o["suggested"][T] = None
            set_("multiple", T, None)
            o["target"][T] = o["ret"][T] = o["pv"][T] = None
            continue
        akey = S.get("_anchor_key")
        if akey and S.get("own_multiple") and BASIS_KEY.get(b) == akey:
            # the market anchor: today's multiple, growth change, drifting toward the peers
            o["suggested"][T] = anchored_multiple(akey, S["own_multiple"],
                                                  scenario_fair(s, S["own_multiple"], S.get("fair_multiple")),
                                                  R.ANCHOR_TODAY_WEIGHT[T], anchor_adj(akey, o, used, f), S["quality"])
        else:
            o["suggested"][T] = suggested_multiple(b, ga, S, S["method"], {"r40": o["r40"][f], "roe": o["roe"][f]})
        mult = set_("multiple", T, o["suggested"][T])
        sh = o["shares"][f]
        o["nongaap"][T] = ng and b == "P/E"
        o["target_gaap"][T] = (o["eps"][f] * mult if b == "P/E" and o["eps"][f] is not None and o["eps"][f] > 0
                               else None)
        if b == "P/E":
            tgt = eps_b * mult
        elif b == "P/S":
            tgt = o["revenue"][f] * mult / sh
        elif b == "EV/Sales":
            tgt = (o["revenue"][f] * mult + S["net_cash_musd"]) / sh
        elif b == "P/FFO":
            tgt = o["ffo"][f] * mult / sh
        elif b == "P/D":
            tgt = o["eps"][f] * S["payout"] * mult
        elif b in ("P/TBV", "P/B"):
            tgt = o["book"][f] * mult / sh
        else:
            tgt = (o["ebitda"][f] * mult + S["net_cash_musd"]) / sh
        o["target"][T] = tgt
        o["ret"][T] = _ret(tgt, price, o["years"][T])
        o["pv"][T] = tgt / (1 + r) ** max(o["years"][T], 0)
    return {"used": used, "default": dflt, "user": U, "out": o, "derived_nm": derived}


def anchor_summary(res, S, h):
    """How the multiple was set, in numbers, and the 12-month comparison: Tarsier's weighted figure a year from
    now next to the analysts' average price target (Alpha Vantage), or an analysts-style figure when there is none
    (today's multiple × the stock's last-year history, on the numbers twelve months from now)."""
    key = S.get("_anchor_key")
    base = res["scen"]["base"]
    o, used = base["out"], base["used"]
    raw = own_multiple(key, o, S, raw=True) if key else None
    if not key or not S.get("own_multiple"):
        return {"on": False, "why": "No market anchor: today's multiple is not meaningful for this method (a loss "
                                    "on the next twelve months' numbers, say); the house multiples are used."}
    T = TARGETS[0]
    if BASIS_KEY.get(o["basis"][T]) != key:
        return {"on": False, "why": f"No market anchor: valued on {o['basis'][T]}, the anchor is "
                                    f"{KEY_BASIS[key]}."}
    own, fair, k, H, wp = S["own_multiple"], S.get("fair_multiple"), S.get("_k"), S.get("_H"), S.get("_wp")
    lo, hi = R.PROJ_MULTIPLE_LIMITS[key]
    capped = "high" if raw is not None and raw > hi * 1.001 else "low" if raw is not None and raw < lo * 0.999 \
        else None
    kind, m12 = _key_numbers(key, o, S, shift=1)
    sh12 = ntm(o["shares"], o["ahead"][0], 1)
    style = None
    if m12 and m12 > 0 and sh12:
        mult = (raw or own) * (H or 1.0)          # analysts follow the market, past Tarsier's limits too
        style = {"price": mult * m12, "mcap": mult * m12 / sh12, "ev": (mult * m12 + S["net_cash_musd"]) / sh12}[kind]
    pt = ((h.get("auto_consensus") or {}).get("price_target") or {})
    analysts = pt.get("value")
    ref = analysts or style
    # Tarsier's 12-month figure: each case's multiple a year from now on its own numbers, weighted
    mine12, wsum = 0.0, 0.0
    for sc in SCENARIOS:
        so, su = res["scen"][sc]["out"], res["scen"][sc]["used"]
        _k, m = _key_numbers(key, so, S, shift=1)
        sh = ntm(so["shares"], so["ahead"][0], 1)
        if not m or m <= 0 or not sh:
            mine12 = None
            break
        mult = anchored_multiple(key, own, scenario_fair(sc, own, fair), R.ANCHOR_TODAY_WEIGHT[1],
                                 anchor_adj(key, so, su, 2), S["quality"])
        v = {"price": mult * m, "mcap": mult * m / sh, "ev": (mult * m + S["net_cash_musd"]) / sh}[kind]
        mine12 += res["weights"][sc] * v
        wsum += res["weights"][sc]
    mine12 = mine12 / wsum if mine12 and wsum else None
    gap = (mine12 / ref - 1) if mine12 and ref else None
    hm = h.get("hist_mult") or {}
    pk = (h.get("peer_k") or {}).get(key) or {}
    return {"on": True, "key": key, "basis": KEY_BASIS[key], "own": own, "own_raw": raw, "capped": capped,
            "fair": fair, "fair_typed": bool(S.get("_fair_typed")), "k": k, "H": H, "wp": wp,
            "H_ratios": S.get("_hist_ratios") or {}, "hist_since": hm.get("since"),
            "n_peers": pk.get("n") or 0, "peers": pk.get("peers") or [], "peer_multiple": pk.get("peer_multiple"),
            "peer_driver": pk.get("peer_driver"), "own_driver": pk.get("own_driver"),
            "q": quality_tilt(S["quality"]), "adj": anchor_adj(key, o, used, T + 1), "mult_y1": o["suggested"][T],
            "analysts": analysts, "analysts_n": pt.get("n"), "analysts_fetched": pt.get("fetched"),
            "analysts_style": style, "tarsier_12m": mine12, "gap": gap,
            "warn": gap is not None and abs(gap) >= R.ANCHOR_GAP_WARN}


def anchor_text(a):
    """(one line, explanation) for the fair multiple and the 12-month comparison."""
    x = lambda v: "—" if v is None else f"{v:.1f}x"
    m = lambda v: "—" if v is None else f"${v:,.0f}"
    gap = a.get("gap")
    if a.get("analysts"):
        who = f"analysts ${a['analysts']:,.0f}" + (f" ({a['analysts_n']})" if a.get("analysts_n") else "")
    else:
        who = f"analysts-style ~{m(a.get('analysts_style'))}"
    line = (f"FAIR MULTIPLE {x(a.get('fair'))} {a['basis']} (today {x(a['own'])})   ·   12 MONTHS: Tarsier "
            f"{m(a.get('tarsier_12m'))} vs {who}" + (f"  ({gap * 100:+.0f}%)" if gap is not None else ""))
    reasons = []
    if a.get("capped") == "high":
        reasons.append(f"The market pays {x(a.get('own_raw'))} {a['basis']} today, above Tarsier's ceiling of "
                       f"{x(a['own'])}: the targets cannot follow the price (type your own multiple to override).")
        line += f"  ·  market pays {x(a.get('own_raw'))}, above the ceiling"
    elif a.get("capped") == "low":
        reasons.append(f"The market pays {x(a.get('own_raw'))} {a['basis']} today, under Tarsier's floor of "
                       f"{x(a['own'])}.")
    if a.get("warn") and gap is not None:
        reasons.append(f"Tarsier is {abs(gap) * 100:.0f}% {'above' if gap > 0 else 'below'} "
                       + ("the analysts' average target." if a.get("analysts") else "the analysts-style figure.")
                       + " The steps below show where it comes from; type over the fair multiple to change it.")
    k, H, wp = a.get("k"), a.get("H"), a.get("wp") or 0
    steps = [f"Today: {x(a['own'])} {a['basis']} on the next twelve months."]
    if k:
        steps.append(f"Peers ({a.get('n_peers', 0)}): median {x(a.get('peer_multiple'))} for a median "
                     f"{'Rule of 40' if a['key'] in ('ev_sales', 'ps') else 'growth score (8 + growth %)'} of "
                     f"{a.get('peer_driver') or 0:.0f}; this company scores {a.get('own_driver') or 0:.0f} "
                     f"(growth counts by the square root) → ×{k:.2f} today's. Weight {wp * 100:.0f}%.")
    else:
        steps.append("Peers: too few with data (Peer Groups workbook) — not used.")
    if H:
        rat = ", ".join(f"{KEY_BASIS.get(kk, kk)} {v:.2f}" for kk, v in (a.get("H_ratios") or {}).items())
        steps.append(f"Its own last year: median multiple since {a.get('hist_since') or 'a year ago'} → ×{H:.2f} "
                     f"today's" + (f" ({rat})" if rat else "") + f". Weight {(1 - (wp if k else 0)) * 100:.0f}%.")
    else:
        steps.append("Its own last year: no price history yet — not used.")
    steps.append(f"Fair multiple {x(a.get('fair'))}" + (" (yours)" if a.get("fair_typed") else "")
                 + ". Year 1: 75% fair + 25% today's; then the fair multiple, in all three cases (bear and "
                 "bull differ by their growth and margins).")
    steps.append(f"Growth change ×{a['adj']:.2f}  ·  quality ×{a['q']:.2f}  →  {x(a.get('mult_y1'))} at the end of "
                 "the first target year (base case).")
    if a.get("analysts"):
        steps.append(f"Analysts: average 12-month price target, Alpha Vantage ({a.get('analysts_fetched')}).")
    else:
        steps.append("No analysts' target kept yet (Update consensus fetches it): the analysts-style figure is "
                     "today's multiple × its last year, on the numbers a year from now.")
    return line, "\n".join(reasons + steps)


def _dcf(flows, o, S):
    """Five years of free cash flow discounted at the WACC, plus what the business is worth at the end
    of year 5 (an exit multiple on that year's FCF, or perpetual growth), plus net cash, per share today."""
    wacc, gt, m = S["wacc"], S["terminal_growth"], S["exit_multiple"]
    growth = S["terminal_method"] == "growth"
    none = {"value": None, "pv_flows": None, "pv_terminal": None, "ev": None, "terminal_share": None}
    if wacc is None or not S["shares_now"]:
        return none
    if growth and (gt is None or wacc - gt < 0.005):
        return none
    if not growth and m is None:
        return none
    pv = sum(f * a * d for f, a, d in zip(flows, o["ahead"], o["df"]))
    tv = flows[-1] * (1 + gt) / (wacc - gt) if growth else flows[-1] * m
    pv_tv = tv * o["df"][-1]
    ev = pv + pv_tv
    return {"value": (ev + S["net_cash_musd"]) / S["shares_now"], "pv_flows": pv, "pv_terminal": pv_tv, "ev": ev,
            "terminal_share": pv_tv / ev if ev else None}


def reconcile(res):
    """Why the two valuations agree or differ, in plain numbers (base case)."""
    S, b = res["settings"], res["scen"]["base"]
    o, w, gt, m = b["out"], S["wacc"], S["terminal_growth"], S["exit_multiple"]
    out = {"implied_growth": None, "growth_multiple": None, "conversion": None, "pe": None, "lines": []}
    if m is not None and w is not None:
        out["implied_growth"] = (m * w - 1) / (m + 1)          # the perpetual growth an exit multiple pays for
    if w is not None and gt is not None and w - gt >= 0.005:
        out["growth_multiple"] = (1 + gt) / (w - gt)           # the exit multiple perpetual growth is worth
    ni, f = o["net_income"][-1], o["fcf"][-1]
    out["conversion"] = f / ni if ni and ni > 0 else None
    lastT = TARGETS[-1]
    out["pe"] = b["used"]["multiple"][lastT] if o["basis"][lastT] == "P/E" else None
    label = res["labels"][-1]
    L = out["lines"]
    if S["terminal_method"] == "growth":
        if out["growth_multiple"] is not None:
            L.append(f"Perpetual growth of {gt * 100:.1f}% at a WACC of {w * 100:.2f}% values the business at "
                     f"{out['growth_multiple']:.1f}x its {label} free cash flow.")
    elif out["implied_growth"] is not None:
        L.append(f"An exit multiple of {m:.1f}x free cash flow at a WACC of {w * 100:.2f}% assumes cash flows "
                 f"growing {out['implied_growth'] * 100:.1f}% a year for ever after {label}"
                 + (f" (perpetual growth of {gt * 100:.1f}% would be worth {out['growth_multiple']:.1f}x)."
                    if out["growth_multiple"] is not None else "."))
    if out["conversion"] is not None:
        L.append(f"In {label}, free cash flow is {out['conversion'] * 100:.0f}% of net income: the multiple "
                 f"values the profit, the FCF method values only the cash.")
    if out["pe"] is not None and m is not None and S["terminal_method"] != "growth":
        L.append(f"Multiples used: {out['pe']:.1f}x earnings for the price target, {m:.1f}x free cash flow at the "
                 f"exit; discount rates {S['discount_rate'] * 100:.1f}% and {w * 100:.2f}%.")
    return out


def _ret(target, price, yrs):
    if not price or target is None or target <= 0 or yrs <= 0:
        return None
    return (target / price) ** (1 / yrs) - 1 if yrs > 0.25 else target / price - 1


def _weigh(res, S):
    w = {s: S["w_" + s] or 0 for s in SCENARIOS}
    tot = sum(w.values()) or 1
    w = {s: v / tot for s, v in w.items()}
    res["weights"] = w
    W = {"target": [None] * YEARS, "pv": [None] * YEARS, "ret": [None] * YEARS}
    for T in TARGETS:
        if any(res["scen"][s]["out"]["target"][T] is None for s in SCENARIOS):
            continue
        W["target"][T] = sum(w[s] * res["scen"][s]["out"]["target"][T] for s in SCENARIOS)
        W["pv"][T] = sum(w[s] * res["scen"][s]["out"]["pv"][T] for s in SCENARIOS)
        W["ret"][T] = _ret(W["target"][T], S["price"], res["scen"]["base"]["out"]["years"][T])
    res["weighted"] = W
    last = TARGETS[-1]
    mos = 1 - (S["margin_of_safety"] or 0)
    price = S["price"]

    def weighted(key):
        vals = [res["scen"][s][key]["value"] for s in SCENARIOS]
        return None if any(v is None for v in vals) else sum(w[s] * v for s, v in zip(SCENARIOS, vals))
    res["fair_value_raw"] = W["pv"][last]                     # multiples, before the margin of safety
    res["fair_value"] = None if W["pv"][last] is None else W["pv"][last] * mos
    res["dcf_value_raw"] = weighted("dcf")
    res["dcf_value"] = None if res["dcf_value_raw"] is None else res["dcf_value_raw"] * mos
    res["dcf_sbc_value_raw"] = weighted("dcf_sbc")
    res["dcf_sbc_value"] = None if res["dcf_sbc_value_raw"] is None else res["dcf_sbc_value_raw"] * mos
    res["upside"] = (res["fair_value"] / price - 1) if price and res["fair_value"] is not None else None
    res["dcf_upside"] = (res["dcf_value"] / price - 1) if price and res["dcf_value"] is not None else None
    res["expected_return"] = W["ret"][last]
    notes = []
    for s in SCENARIOS:
        o = res["scen"][s]["out"]
        ps_years = [res["labels"][T + 1] for T in TARGETS if o["basis"][T] == "P/S"]
        if ps_years and S["method"] in ("auto", "pe_midcycle", "ddm", "ev_ebitda"):
            notes.append(f"{SCEN_LABEL[s]}: not (yet meaningfully) GAAP-profitable in {', '.join(ps_years)} — "
                         f"net margin below {R.PROJ_PE_MIN_NET_MARGIN * 100:.0f}%, so valued on sales (P/S).")
    if S["method"] == "ev_ebitda":
        notes.append("EV/EBITDA: net cash (debt) held at today's level; debt taken on later is not included.")
    if res["dcf_value_raw"] is not None and res["dcf_value_raw"] <= 0:
        notes.append("FCF valuation is negative: free cash flow stays below zero in the projected years. "
                     "Enter the FCF margin you expect, or rely on the multiple.")
    if not price:
        notes.append("Enter today's share price to see returns and upside.")
    res["warnings"] += notes


def holder_risks(S, h):
    """Shareholder risks from the filing, plus a note when the method never sees stock pay."""
    hr = [dict(x) for x in h.get("holder_risks") or []]
    note = holders.method_note(S["method"], h.get("sbc_pct_rev"))
    if note:
        hr.insert(0, {"level": "high" if h["sbc_pct_rev"] >= R.HOLDER_SBC_REVENUE_PCT[1] else "watch",
                      "head": "This valuation ignores stock pay", "text": note})
    hr.sort(key=lambda r: r["level"] != "high")
    return hr


def method_notes(res, S, h):
    """What the method is and what drives it, in a line or two (the window and the phone show these)."""
    model, why = h["model"], h["model_why"]
    label = R.BUSINESS_MODELS[model][0]
    b = res["scen"]["base"]["out"]
    lastT = TARGETS[-1]
    out = [f"Valued as {label.lower()} ({why}): {METHODS.get(S['method'], S['method'])}."]
    if fast_lender(h) and S["method"] == "auto":
        out[0] = (f"Valued as a fast-growing lender ({why}, growing 15%+ with a profit): P/E, as the market and the "
                  "analysts do; P/TBV vs ROE (Other methods) fits a mature bank.")
    m = S["method"]
    if m == "ev_sales_r40" and b["r40"][lastT + 1] is not None:
        out.append(f"Rule of 40 in {res['labels'][lastT + 1]}: {b['r40'][lastT + 1]:.0f} (growth + FCF margin) → "
                   f"{b['suggested'][lastT]:.1f}x EV/Sales; P/E is only a cross-check for this kind of business.")
    elif m == "pe_midcycle" and S["midcycle_margin"] is not None:
        out.append(f"Mid-cycle operating margin {S['midcycle_margin'] * 100:.0f}% (average of the last years); "
                   f"margins drift back to it and the P/E is × {S['cycle_factor']:.2f} while margins sit above it.")
    elif m == "ddm":
        g = ddm_growth(growth_after(res["scen"]["base"]["used"]["rev_growth"], lastT + 1), S)
        out.append(f"Dividend paid out: {S['payout'] * 100:.0f}% of earnings, growing {g * 100:.1f}% a year for "
                   f"ever, at a cost of equity of {S['coe'] * 100:.1f}%.")
    elif m in ("p_tbv", "p_b"):
        roe = b["roe"][lastT + 1]
        if roe is not None:
            out.append(f"Return on equity {roe * 100:.1f}% vs a cost of equity of {S['coe'] * 100:.1f}%: the "
                       f"multiple of book is (ROE − growth) ÷ (cost of equity − growth).")
    elif m == "p_ffo":
        out.append("FFO = net income + depreciation (gains on property sales not taken out: check the filing).")
    elif m == "none":
        out.append("Pre-revenue: no fair value. Judge the pipeline and the cash.")
    if model in ("unprofitable_growth", "pre_revenue", "software"):
        fcf, cash = h["ttm"].get("fcf"), h.get("cash_now")
        if fcf is not None and fcf < 0 and cash:
            out.append(f"Cash runway: about {cash / -fcf:.1f} years at the last 12 months' cash burn.")
        om = b and res["scen"]["base"]["used"]["op_margin"]
        if om and om[0] is not None and om[0] < 0:
            pos = next((res["labels"][y] for y, v in enumerate(om) if v is not None and v > 0), None)
            out.append(f"Operating margin turns positive in {pos}." if pos else
                       "Operating margin stays negative in all five years of the base case.")
    return out