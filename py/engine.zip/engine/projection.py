"""Projections: three scenarios over five fiscal years, a price target at the end of each of the
next three fiscal years, the yearly return each implies, and a weighted fair value today.

Rule of the house: GAAP EPS is the scored and valued number; adjusted EPS is shown next to it,
with the gap between them taken apart (stock pay vs acquisition items).

The same arithmetic is written as live formulas in TICKER_model.xlsx (model_xlsx.py). The window
uses this module, so the numbers move as you type. Money in $ millions, shares in millions,
rates as fractions (0.30 = 30%).
"""
from datetime import date

from . import rules as R, wacc_data

SCENARIOS = ("bear", "base", "bull")
SCEN_LABEL = {"bear": "Bear", "base": "Base", "bull": "Bull"}
YEARS = 5                  # current fiscal year + 4
TARGETS = (1, 2, 3)        # price at the end of years 1, 2 and 3, priced on the following year
# key, label, unit (pct | musd | x), first year, last year, shown in the window
INPUTS = [
    ("rev_growth", "Revenue growth", "pct", 0, 4, True),
    ("op_margin", "Operating margin (GAAP)", "pct", 0, 4, True),
    ("net_margin", "Net margin (GAAP)", "pct", 0, 4, True),
    ("eps_growth", "EPS growth (GAAP)", "pct", 0, 4, True),
    ("multiple", "Multiple at year end", "x", 1, 3, True),
    ("fcf_margin", "FCF margin", "pct", 0, 4, True),
    # behind the defaults of net margin and EPS growth: edit in the workbook (Assumptions sheet)
    ("other_musd", "Interest & other, net", "musd", 0, 4, False),
    ("tax_rate", "Tax rate", "pct", 0, 4, False),
    ("share_growth", "Diluted share growth", "pct", 1, 4, False),
    ("sbc_pct", "SBC % of revenue", "pct", 0, 4, False),
    ("da_pct", "D&A % of revenue", "pct", 0, 4, False),
]
INPUT_KEYS = [k for k, *_ in INPUTS]
# key, label, unit
SETTINGS = [
    ("price", "Share price today", "usd"),
    ("price_date", "Price date", "date"),
    ("method", "Valuation method", "text"),
    ("margin_of_safety", "Margin of safety on every fair value", "pct"),
    ("discount_rate", "Discount rate for price targets (return you require)", "pct"),
    ("wacc", "WACC for the FCF valuation (sector)", "pct"),
    ("terminal_method", "Value after year 5: multiple or growth", "text"),
    ("exit_multiple", "Exit multiple on year-5 FCF", "x"),
    ("terminal_growth", "Perpetual FCF growth (growth method)", "pct"),
    ("w_bear", "Weight: bear", "pct"),
    ("w_base", "Weight: base", "pct"),
    ("w_bull", "Weight: bull", "pct"),
    ("quality", "Quality factor (from the grade)", "x"),
    ("base_pe", "Starting P/E for the sector", "x"),
    ("base_ps", "Starting P/S for the sector", "x"),
    ("base_ev_ebitda", "Starting EV/EBITDA for the sector", "x"),
    ("organic", "Organic growth (start of the fade)", "pct"),
    ("amort_musd", "Amortisation of acquired intangibles a year", "musd"),
    ("net_cash_musd", "Net cash (debt)", "musd"),
    ("shares_now", "Diluted shares now", "mshares"),
]
METHODS = {"auto": "P/E (P/S while net margin < 5%)", "ps": "P/S", "ev_ebitda": "EV/EBITDA (P/S when EBITDA ≤ 0)"}
BASIS_KEY = {"P/E": "pe", "P/S": "ps", "EV/EBITDA": "ev_ebitda"}
OUT_KEYS = ["revenue", "op_income", "pretax", "tax", "net_income", "shares", "eps", "adj_eps",
            "eps_vs_consensus", "ebitda", "fcf", "fcf_after_sbc", "basis", "suggested", "target", "years",
            "ret", "pv", "ahead", "df"]


# ---------- helpers ---------------------------------------------------------------------------
def _fy_q(label):
    try:
        return int(label.split()[0].replace("FY", "")), int(label.split("Q")[-1])
    except (ValueError, AttributeError, IndexError):
        return None


def add_years(d, n):
    try:
        return d.replace(year=d.year + n)
    except ValueError:                       # 29 February
        return d.replace(year=d.year + n, day=28)


def _m(x):
    return None if x is None else x / 1e6


def _div(a, b):
    return None if a is None or not b else a / b


def clamp(x, lo, hi):
    return min(hi, max(lo, x))


# ---------- history ---------------------------------------------------------------------------
def history(co, facts, m, g, inputs_row=None):
    """Everything the projection starts from, in $M. Raises RuntimeError when no full fiscal year exists."""
    inputs_row = inputs_row or {}
    ends = co.quarter_ends()
    q = {}
    for e in ends:
        p = _fy_q(co.label(e))
        if p:
            q[p] = e
    snaps = {}

    def snap(e):
        if e not in snaps:
            s = co.snapshot(e)
            s["amort"] = co.v("amort_intangibles", e)
            snaps[e] = s
        return snaps[e]

    def total(pairs, field, missing_is_zero=False):
        vals = [snap(q[p]).get(field) for p in pairs]
        if missing_is_zero:
            vals = [v or 0 for v in vals]
        return None if any(v is None for v in vals) else _m(sum(vals))

    complete = sorted({fy for fy, _ in q if all((fy, k) in q for k in (1, 2, 3, 4))})
    if not complete:
        raise RuntimeError("no complete fiscal year in the SEC data yet: projections need one")
    fya = complete[-1]
    fy0 = fya + 1

    def fy_record(fy):
        pairs = [(fy, k) for k in (1, 2, 3, 4)]
        r = {"fy": fy, "end": q[(fy, 4)]}
        for f, key in (("revenue", "revenue"), ("gross_profit", "gross_profit"),
                       ("operating_income", "operating_income"), ("below_operating", "other"),
                       ("pretax", "pretax"), ("tax", "tax"), ("net_income", "net_income"),
                       ("sbc", "sbc"), ("da", "da"), ("fcf", "fcf")):
            r[key] = total(pairs, f)
        for f in ("amort", "acq_costs", "restructuring"):
            r[f] = total(pairs, f, missing_is_zero=True)
        sh = [snap(q[p]).get("shares_diluted") for p in pairs]
        r["shares"] = None if any(x is None for x in sh) else _m(sum(sh) / 4)
        r["eps"] = _div(r["net_income"], r["shares"])
        r["op_margin"] = _div(r["operating_income"], r["revenue"])
        r["ebitda"] = None if r["operating_income"] is None else r["operating_income"] + (r["da"] or 0)
        r["tax_rate"] = (_div(r["tax"], r["pretax"]) if r["pretax"] and r["pretax"] > 0 else None)
        return r

    fy_actual = [fy_record(fy) for fy in complete[-3:]]
    fya_rec = fy_actual[-1]

    ytd_q = []
    for k in (1, 2, 3):
        if (fy0, k) in q:
            ytd_q.append(k)
        else:
            break
    ytd = {"quarters": len(ytd_q)}
    if ytd_q:
        now, before = [(fy0, k) for k in ytd_q], [(fya, k) for k in ytd_q]
        ytd.update(revenue=total(now, "revenue"), revenue_prior=total(before, "revenue"),
                   op_income=total(now, "operating_income"), other=total(now, "below_operating"))
        ytd["growth"] = (None if not ytd["revenue_prior"] or ytd["revenue"] is None
                         else ytd["revenue"] / ytd["revenue_prior"] - 1)
    end = m["period"]["end"]
    cur = m["cur"]

    def ttm(field, zero=False):
        tot = 0.0
        e = end
        for _ in range(4):
            if e is None:
                return None
            v = snap(e).get(field)
            if v is None:
                if not zero:
                    return None
                v = 0
            tot += v
            e = co.previous(e)
        return _m(tot)

    t = {k: ttm(f) for k, f in (("revenue", "revenue"), ("op_income", "operating_income"),
                                ("other", "below_operating"), ("pretax", "pretax"), ("tax", "tax"),
                                ("sbc", "sbc"), ("da", "da"), ("net_income", "net_income"), ("fcf", "fcf"))}
    for k in ("amort", "acq_costs", "restructuring"):
        t[k] = ttm(k, zero=True)
    etr = _div(t["tax"], t["pretax"]) if t["pretax"] and t["pretax"] > 0 else None

    lastq_m = _div(cur["operating_income"], cur["revenue"])
    shares_now = max(x for x in (cur.get("shares_diluted"), cur.get("shares_basic"), 0) if x is not None) / 1e6
    if not shares_now:
        raise RuntimeError("no share count for the latest quarter: projections need one")
    group = g["industry_group"]
    organic = inputs_row.get("organic_revenue_yoy_pct")
    h = {
        "ticker": None, "name": None, "group": group, "grade": g["grade"], "provisional": g["provisional"],
        "company_type": g["company_type"], "asset_heavy": m["assets"]["asset_heavy"],
        "latest_end": end, "latest_label": m["period"]["label"],
        "fya": fya, "fy0": fy0, "fya_end": date.fromisoformat(fya_rec["end"]),
        "fy_actual": fy_actual, "fya_rec": fya_rec, "ytd": ytd, "ttm": t,
        "lastq_margin": lastq_m, "lastq_other": _m(cur.get("below_operating")),
        "sic": g.get("sic"),
        "g0": ytd.get("growth") if ytd.get("growth") is not None else (m["revenue"]["yoy_pct"] or 0) / 100,
        "ttm_margin": _div(t["op_income"], t["revenue"]),
        "ttm_tax_rate": etr,
        "ttm_share_growth": (m["dilution"]["yoy_pct"] or 0) / 100,
        "organic": None if organic is None else organic / 100,
        "shares_now": shares_now,
        "net_cash": _m(m["debt"]["net_cash"]),
        "bridge": bridge(co, m, cur, inputs_row, t, fya_rec),
    }
    h["warnings"] = []
    if group in ("Financials", "Banks and fintech lenders", "Insurance", "REITs"):
        h["warnings"].append(f"{group}: earnings-based targets are a rough guide until the sector scorecard exists.")
    return h


def bridge(co, m, cur, inputs_row, t, fya_rec):
    """What separates GAAP from adjusted EPS, from the filing: latest quarter, last 12 months, last year."""
    sh = cur.get("shares_diluted")
    items_q = {"sbc": cur.get("sbc"), "amort": co.v("amort_intangibles", m["period"]["end"]),
               "acq_costs": cur.get("acq_costs"), "restructuring": cur.get("restructuring")}
    rows = []
    for key, label in (("sbc", "Stock-based compensation"), ("amort", "Amortisation of acquired intangibles"),
                       ("acq_costs", "Acquisition-related costs"), ("restructuring", "Restructuring")):
        q_val = _m(items_q[key] or 0)
        rows.append({"key": key, "label": label, "quarter": q_val,
                     "per_share_q": None if not sh else (items_q[key] or 0) / sh,
                     "ttm": t.get(key), "last_fy": fya_rec.get(key)})
    tot_q = sum(r["quarter"] for r in rows)
    acq_q = sum(r["quarter"] for r in rows if r["key"] in ("amort", "acq_costs"))
    gaap = m["eps"]["gaap_cur"]
    adj = inputs_row.get("eps_nongaap")
    gap = None if adj is None or gaap is None else adj - gaap
    pre_tax_ps = None if not sh else sum((items_q[r["key"]] or 0) for r in rows) / sh
    out = {"rows": rows, "total_q": tot_q, "acq_share": _div(acq_q, tot_q), "sbc_share": _div(rows[0]["quarter"], tot_q),
           "gaap_eps": gaap, "adj_eps": adj, "gap": gap, "items_per_share": pre_tax_ps,
           "other": None if gap is None or pre_tax_ps is None else gap - pre_tax_ps,
           "label": m["period"]["label"]}
    msg = []
    if tot_q:
        msg.append(f"Acquisition items (amortisation of acquired intangibles + deal costs) are "
                   f"{out['acq_share'] * 100:.0f}% of the add-backs; stock-based pay {out['sbc_share'] * 100:.0f}%.")
        if (out["acq_share"] or 0) >= 0.4:
            msg.append("Most of the gap comes from past acquisitions: a non-cash charge that ends when the "
                       "intangibles are fully amortised. Judge whether the deals are paying off.")
        elif (out["sbc_share"] or 0) >= 0.6:
            msg.append("Most of the gap is stock-based pay: a real, recurring cost paid in shares (see dilution).")
    if gap is not None and out["other"] is not None:
        msg.append(f"Reported gap ${gap:.2f}/share; these items ${pre_tax_ps:.2f} before tax; "
                   f"the rest (${out['other']:+.2f}) is the tax effect and other items in the press release.")
    msg.append("SEC data does not split SBC from acquisitions (retention grants): check the press release reconciliation.")
    out["text"] = " ".join(msg)
    return out


# ---------- defaults --------------------------------------------------------------------------
def setting_defaults(h):
    base = R.PROJ_BASE_MULTIPLES.get(h["group"], R.PROJ_BASE_MULTIPLES["default"])
    wacc, _src = wacc_data.for_company(h["group"], h.get("sic"))
    return {
        "price": None, "price_date": date.today(),
        "method": "ev_ebitda" if h["asset_heavy"] else "auto",
        "margin_of_safety": R.PROJ_MARGIN_OF_SAFETY,
        "discount_rate": R.PROJ_DISCOUNT_RATE, "wacc": wacc, "terminal_growth": R.PROJ_TERMINAL_GROWTH,
        "terminal_method": R.PROJ_TERMINAL_METHOD, "exit_multiple": None,   # filled from the base case
        "w_bear": R.PROJ_WEIGHTS["bear"], "w_base": R.PROJ_WEIGHTS["base"], "w_bull": R.PROJ_WEIGHTS["bull"],
        "quality": R.PROJ_QUALITY.get(h["grade"], 1.0),
        "base_pe": base["pe"], "base_ps": base["ps"], "base_ev_ebitda": base["ev_ebitda"],
        "organic": h["organic"], "amort_musd": h["ttm"].get("amort") or 0.0,
        "net_cash_musd": h["net_cash"] or 0.0, "shares_now": h["shares_now"],
    }


def wacc_source(h):
    return wacc_data.for_company(h["group"], h.get("sic"))[1]


def constants(h):
    """History-based starting values: written as plain numbers in the workbook."""
    t = h["ttm"]
    rev = t["revenue"] or 0
    tax = h["ttm_tax_rate"]
    group = h["group"]
    n, ytd = h["ytd"]["quarters"], h["ytd"]
    lastq_other = h.get("lastq_other")
    # what is left of this fiscal year: recurring costs continue, one-off gains are not repeated
    if 0 < n < 4 and ytd.get("other") is not None and lastq_other is not None:
        other0 = ytd["other"] + (4 - n) * min(0.0, lastq_other)
    else:
        other0 = t["other"] or 0.0
    other_run = 4 * min(0.0, lastq_other) if lastq_other is not None else min(0.0, t["other"] or 0.0)
    g0 = h["g0"]
    if n == 0:      # no quarter of this fiscal year reported yet: it is a future year, so the fade and cap apply
        g0 = min(R.PROJ_DEFAULT_GROWTH_CAP, R.PROJ_LONG_RUN_GROWTH + (g0 - R.PROJ_LONG_RUN_GROWTH) * R.PROJ_GROWTH_DECAY)
    return {
        "g0": g0,
        "om0_ttm": h["ttm_margin"] or 0.0,
        "ytd_n": n, "ytd_rev": ytd.get("revenue"), "ytd_oi": ytd.get("op_income"),
        "lastq_m": h["lastq_margin"] if h["lastq_margin"] is not None else (h["ttm_margin"] or 0.0),
        "other0": other0, "other_run": other_run,
        "tax0": tax if tax is not None and 0 <= tax <= 0.35 else R.PROJ_TAX_DEFAULT,
        "sg1": h["ttm_share_growth"] * R.PROJ_SHARE_FADE,
        "sbc0": (t["sbc"] or 0) / rev if rev else 0.0,
        "da0": (t["da"] or 0) / rev if rev else 0.0,
        "fcf0": (t["fcf"] or 0) / rev if rev and t.get("fcf") is not None else 0.0,
        # how much of net income arrives as free cash flow (None when either is not positive)
        "conv": (clamp(t["fcf"] / t["net_income"], *R.PROJ_FCF_CONVERSION_LIMITS)
                 if (t.get("fcf") or 0) > 0 and (t.get("net_income") or 0) > 0 else None),
        "cap": R.PROJ_MARGIN_CAP.get(group, R.PROJ_MARGIN_CAP["default"]),
        "step": R.PROJ_MARGIN_STEP if h["company_type"] == "growth" else 0.0,
        # asset-heavy: borrowing grows with the asset base, so interest grows with revenue
        "other_scales": bool(h["asset_heavy"]),
    }


def growth_after(used_growth, f):
    """Average revenue growth from the forward year to the last projected year: what the multiple pays for."""
    vals = used_growth[f:YEARS]
    return sum(vals) / len(vals)


def suggested_multiple(basis, growth, S):
    k = BASIS_KEY[basis]
    lo, hi = R.PROJ_MULTIPLE_LIMITS[k]
    return clamp((S["base_" + k] + R.PROJ_GROWTH_PER_POINT[k] * (growth or 0) * 100) / 2 * S["quality"], lo, hi)


def basis_for(method, eps_f, ebitda_f, net_margin_f=None):
    if method == "ps":
        return "P/S"
    if method == "ev_ebitda":
        return "EV/EBITDA" if ebitda_f is not None and ebitda_f > 0 else "P/S"
    ok = eps_f is not None and eps_f > 0 and (net_margin_f or 0) >= R.PROJ_PE_MIN_NET_MARGIN
    return "P/E" if ok else "P/S"


# ---------- the model -------------------------------------------------------------------------
def _used(user_val, default):
    return default if user_val is None else user_val


def compute(h, user=None):
    """user = {"settings": {k: v}, "consensus": {"revenue": {fy: v}, "eps": {fy: v}},
               "scen": {scenario: {input: {fy: v}}}} — only what you typed."""
    user = user or {}
    us, uc, uscen = user.get("settings", {}), user.get("consensus", {}), user.get("scen", {})
    sd = setting_defaults(h)
    S = {k: _used(us.get(k), sd[k]) for k in sd}
    c = constants(h)
    fys = [h["fy0"] + i for i in range(YEARS)]
    fy_ends = [add_years(h["fya_end"], i + 1) for i in range(YEARS)]
    cons_rev = [uc.get("revenue", {}).get(fy) for fy in fys]
    cons_eps = [uc.get("eps", {}).get(fy) for fy in fys]
    a = h["fya_rec"]
    res = {"fys": fys, "labels": [f"FY{fy}E" for fy in fys], "fy_ends": fy_ends, "settings": S,
           "settings_default": sd, "constants": c, "cons_rev": cons_rev, "cons_eps": cons_eps,
           "actual": a, "scen": {}, "warnings": list(h.get("warnings", [])), "wacc_source": wacc_source(h)}
    for s in ("base", "bear", "bull"):
        res["scen"][s] = _scenario(s, h, S, c, fys, fy_ends, cons_rev, cons_eps, uscen.get(s, {}),
                                   res["scen"].get("base"))
    # value after year 5: default exit multiple = the P/E the base case's final-year growth supports
    sd["exit_multiple"] = suggested_multiple("P/E", res["scen"]["base"]["used"]["rev_growth"][-1], S)
    S["exit_multiple"] = _used(us.get("exit_multiple"), sd["exit_multiple"])
    for s in SCENARIOS:
        o = res["scen"][s]["out"]
        res["scen"][s]["dcf"] = _dcf(o["fcf"], o, S)
        res["scen"][s]["dcf_sbc"] = _dcf(o["fcf_after_sbc"], o, S)
    _weigh(res, S)
    res["reconcile"] = reconcile(res)
    return res


def _scenario(s, h, S, c, fys, fy_ends, cons_rev, cons_eps, mine, base):
    U = {k: [mine.get(k, {}).get(fy) for fy in fys] for k in INPUT_KEYS}
    used = {k: [None] * YEARS for k in INPUT_KEYS}
    dflt = {k: [None] * YEARS for k in INPUT_KEYS}
    o = {k: [None] * YEARS for k in OUT_KEYS}
    a = h["fya_rec"]
    off = R.PROJ_SCENARIO_OFFSETS.get(s)
    LT, DEC, SF = R.PROJ_LONG_RUN_GROWTH, R.PROJ_GROWTH_DECAY, R.PROJ_SHARE_FADE
    CAP = R.PROJ_DEFAULT_GROWTH_CAP

    def set_(k, y, d):
        dflt[k][y] = d
        used[k][y] = _used(U[k][y], d)
        return used[k][y]

    prev_rev, prev_eps = a["revenue"], a["eps"]
    for y in range(YEARS):
        B = (lambda k: base["used"][k][y]) if base else None
        BD = (lambda k: base["default"][k][y]) if base else None
        # 1. revenue growth
        if s == "base":
            if cons_rev[y] is not None:
                d = cons_rev[y] / prev_rev - 1
            elif y == 0:
                d = c["g0"]
            elif y == 1:
                d = min(CAP, LT + ((S["organic"] if S["organic"] is not None else used["rev_growth"][0]) - LT) * DEC)
            else:
                d = min(CAP, LT + (used["rev_growth"][y - 1] - LT) * DEC)
        else:
            d = B("rev_growth") + (off["g0"] if y == 0 else off["g"])
        g = set_("rev_growth", y, d)
        rev = prev_rev * (1 + g)
        # 2. operating margin
        if s == "base":
            if y == 0:
                if 0 < c["ytd_n"] < 4 and c["ytd_rev"] is not None and c["ytd_oi"] is not None:
                    d = (c["ytd_oi"] + (rev - c["ytd_rev"]) * c["lastq_m"]) / rev
                else:
                    d = c["om0_ttm"]
            else:
                prev = max(used["op_margin"][0], c["lastq_m"]) if y == 1 else used["op_margin"][y - 1]
                step = max(c["step"], (c["cap"] - prev) * R.PROJ_MARGIN_CONVERGE_LOSS) if prev < 0 else c["step"]
                d = prev if prev >= c["cap"] else min(c["cap"], prev + step)
        else:
            d = B("op_margin") + off["om"]
        om = set_("op_margin", y, d)
        # behind the defaults: interest & other, tax, dilution, SBC, D&A
        if s == "base":
            grow = (1 + g) if c["other_scales"] else 1.0
            set_("other_musd", y, c["other0"] if y == 0 else
                 c["other_run"] * grow if y == 1 else used["other_musd"][y - 1] * grow)
            set_("tax_rate", y, c["tax0"] if y == 0 else max(R.PROJ_TAX_FLOOR, used["tax_rate"][y - 1]))
            set_("da_pct", y, c["da0"] if y == 0 else used["da_pct"][y - 1])
            set_("sbc_pct", y, c["sbc0"] if y == 0 else max(0.0, used["sbc_pct"][y - 1] + R.PROJ_SBC_STEP))
        else:
            for k in ("other_musd", "tax_rate", "da_pct", "sbc_pct"):
                set_(k, y, B(k))
        if y >= 1:
            if s == "base":
                set_("share_growth", y, c["sg1"] if y == 1 else used["share_growth"][y - 1] * SF)
            else:
                set_("share_growth", y, B("share_growth") + off["sg"])
        oi = rev * om
        pretax = oi + used["other_musd"][y]
        tax = max(0.0, pretax) * used["tax_rate"][y]
        # 3. net margin: default = what the operating margin leaves after interest and tax
        derived_nm = (pretax - tax) / rev
        nm = set_("net_margin", y, derived_nm if s == "base" else derived_nm + (B("net_margin") - BD("net_margin")))
        ni = rev * nm
        # 4. EPS growth: default = net income over the projected share count
        shares_path = S["shares_now"] if y == 0 else o["shares"][y - 1] * (1 + used["share_growth"][y])
        eps_derived = ni / shares_path if shares_path else None
        can_grow = prev_eps is not None and prev_eps > 0
        d = (eps_derived / prev_eps - 1) if can_grow and eps_derived is not None else None
        if s != "base" and d is not None and B("eps_growth") is not None and BD("eps_growth") is not None:
            d += B("eps_growth") - BD("eps_growth")
        eg = set_("eps_growth", y, d)
        eps = prev_eps * (1 + eg) if can_grow and eg is not None else eps_derived
        shares = ni / eps if eps is not None and eps > 0 and ni > 0 else shares_path
        # 5. free cash flow
        if c["conv"] is not None:
            # FCF follows net income at the conversion of the last 12 months
            d = nm * c["conv"]
            if s != "base":
                d += B("fcf_margin") - BD("fcf_margin")
        elif s == "base":
            # no positive base: FCF margin moves with the operating margin, after tax
            d = (c["fcf0"] if y == 0 else
                 used["fcf_margin"][y - 1] + (om - used["op_margin"][y - 1]) * (1 - used["tax_rate"][y]))
        else:
            d = B("fcf_margin") + (om - B("op_margin")) * (1 - used["tax_rate"][y])
        fm = set_("fcf_margin", y, d)
        o["revenue"][y], o["op_income"][y], o["pretax"][y], o["tax"][y], o["net_income"][y] = rev, oi, pretax, tax, ni
        o["shares"][y], o["eps"][y] = shares, eps
        o["adj_eps"][y] = ((ni + (used["sbc_pct"][y] * rev + S["amort_musd"]) * (1 - used["tax_rate"][y])) / shares
                           if shares else None)
        o["eps_vs_consensus"][y] = (eps / cons_eps[y] - 1) if cons_eps[y] and eps is not None else None
        o["ebitda"][y] = oi + used["da_pct"][y] * rev
        o["fcf"][y] = rev * fm
        o["fcf_after_sbc"][y] = rev * (fm - used["sbc_pct"][y])
        yrs = (fy_ends[y] - S["price_date"]).days / 365.25
        o["years"][y] = yrs
        o["ahead"][y] = clamp(yrs, 0.0, 1.0)                       # part of the fiscal year still ahead
        o["df"][y] = 1 / (1 + S["wacc"]) ** max(yrs, 0.0)
        prev_rev, prev_eps = rev, eps

    price, r = S["price"], S["discount_rate"]
    for T in TARGETS:
        f = T + 1
        b = basis_for(S["method"], o["eps"][f], o["ebitda"][f], o["net_income"][f] / o["revenue"][f])
        o["basis"][T] = b
        o["suggested"][T] = suggested_multiple(b, growth_after(used["rev_growth"], f), S)
        mult = set_("multiple", T, o["suggested"][T])
        if b == "P/E":
            tgt = o["eps"][f] * mult
        elif b == "P/S":
            tgt = o["revenue"][f] * mult / o["shares"][f]
        else:
            tgt = (o["ebitda"][f] * mult + S["net_cash_musd"]) / o["shares"][f]
        o["target"][T] = tgt
        o["ret"][T] = _ret(tgt, price, o["years"][T])
        o["pv"][T] = tgt / (1 + r) ** max(o["years"][T], 0)
    return {"used": used, "default": dflt, "user": U, "out": o}


def _dcf(flows, o, S):
    """Five years of free cash flow discounted at the WACC, plus what the business is worth at the end
    of year 5 (an exit multiple on that year's FCF, or perpetual growth), plus net cash, per share today."""
    wacc, gt, m = S["wacc"], S["terminal_growth"], S["exit_multiple"]
    growth = S["terminal_method"] == "growth"
    none = {"value": None, "pv_flows": None, "pv_terminal": None, "ev": None, "terminal_share": None}
    if wacc is None or not S["shares_now"]:
        return none
    if growth and (gt is None or wacc - gt < 0.005):
        return none
    if not growth and m is None:
        return none
    pv = sum(f * a * d for f, a, d in zip(flows, o["ahead"], o["df"]))
    tv = flows[-1] * (1 + gt) / (wacc - gt) if growth else flows[-1] * m
    pv_tv = tv * o["df"][-1]
    ev = pv + pv_tv
    return {"value": (ev + S["net_cash_musd"]) / S["shares_now"], "pv_flows": pv, "pv_terminal": pv_tv, "ev": ev,
            "terminal_share": pv_tv / ev if ev else None}


def reconcile(res):
    """Why the two valuations agree or differ, in plain numbers (base case)."""
    S, b = res["settings"], res["scen"]["base"]
    o, w, gt, m = b["out"], S["wacc"], S["terminal_growth"], S["exit_multiple"]
    out = {"implied_growth": None, "growth_multiple": None, "conversion": None, "pe": None, "lines": []}
    if m is not None and w is not None:
        out["implied_growth"] = (m * w - 1) / (m + 1)          # the perpetual growth an exit multiple pays for
    if w is not None and gt is not None and w - gt >= 0.005:
        out["growth_multiple"] = (1 + gt) / (w - gt)           # the exit multiple perpetual growth is worth
    ni, f = o["net_income"][-1], o["fcf"][-1]
    out["conversion"] = f / ni if ni and ni > 0 else None
    lastT = TARGETS[-1]
    out["pe"] = b["used"]["multiple"][lastT] if o["basis"][lastT] == "P/E" else None
    label = res["labels"][-1]
    L = out["lines"]
    if S["terminal_method"] == "growth":
        if out["growth_multiple"] is not None:
            L.append(f"Perpetual growth of {gt * 100:.1f}% at a WACC of {w * 100:.2f}% values the business at "
                     f"{out['growth_multiple']:.1f}x its {label} free cash flow.")
    elif out["implied_growth"] is not None:
        L.append(f"An exit multiple of {m:.1f}x free cash flow at a WACC of {w * 100:.2f}% assumes cash flows "
                 f"growing {out['implied_growth'] * 100:.1f}% a year for ever after {label}"
                 + (f" (perpetual growth of {gt * 100:.1f}% would be worth {out['growth_multiple']:.1f}x)."
                    if out["growth_multiple"] is not None else "."))
    if out["conversion"] is not None:
        L.append(f"In {label}, free cash flow is {out['conversion'] * 100:.0f}% of net income: the multiple "
                 f"values the profit, the FCF method values only the cash.")
    if out["pe"] is not None and m is not None and S["terminal_method"] != "growth":
        L.append(f"Multiples used: {out['pe']:.1f}x earnings for the price target, {m:.1f}x free cash flow at the "
                 f"exit; discount rates {S['discount_rate'] * 100:.1f}% and {w * 100:.2f}%.")
    return out


def _ret(target, price, yrs):
    if not price or target is None or target <= 0 or yrs <= 0:
        return None
    return (target / price) ** (1 / yrs) - 1 if yrs > 0.25 else target / price - 1


def _weigh(res, S):
    w = {s: S["w_" + s] or 0 for s in SCENARIOS}
    tot = sum(w.values()) or 1
    w = {s: v / tot for s, v in w.items()}
    res["weights"] = w
    W = {"target": [None] * YEARS, "pv": [None] * YEARS, "ret": [None] * YEARS}
    for T in TARGETS:
        W["target"][T] = sum(w[s] * res["scen"][s]["out"]["target"][T] for s in SCENARIOS)
        W["pv"][T] = sum(w[s] * res["scen"][s]["out"]["pv"][T] for s in SCENARIOS)
        W["ret"][T] = _ret(W["target"][T], S["price"], res["scen"]["base"]["out"]["years"][T])
    res["weighted"] = W
    last = TARGETS[-1]
    mos = 1 - (S["margin_of_safety"] or 0)
    price = S["price"]

    def weighted(key):
        vals = [res["scen"][s][key]["value"] for s in SCENARIOS]
        return None if any(v is None for v in vals) else sum(w[s] * v for s, v in zip(SCENARIOS, vals))
    res["fair_value_raw"] = W["pv"][last]                     # multiples, before the margin of safety
    res["fair_value"] = W["pv"][last] * mos
    res["dcf_value_raw"] = weighted("dcf")
    res["dcf_value"] = None if res["dcf_value_raw"] is None else res["dcf_value_raw"] * mos
    res["dcf_sbc_value_raw"] = weighted("dcf_sbc")
    res["dcf_sbc_value"] = None if res["dcf_sbc_value_raw"] is None else res["dcf_sbc_value_raw"] * mos
    res["upside"] = (res["fair_value"] / price - 1) if price else None
    res["dcf_upside"] = (res["dcf_value"] / price - 1) if price and res["dcf_value"] is not None else None
    res["expected_return"] = W["ret"][last]
    notes = []
    for s in SCENARIOS:
        o = res["scen"][s]["out"]
        ps_years = [res["labels"][T + 1] for T in TARGETS if o["basis"][T] == "P/S"]
        if ps_years and S["method"] != "ps":
            notes.append(f"{SCEN_LABEL[s]}: not (yet meaningfully) GAAP-profitable in {', '.join(ps_years)} — "
                         f"net margin below {R.PROJ_PE_MIN_NET_MARGIN * 100:.0f}%, so valued on sales (P/S).")
    if S["method"] == "ev_ebitda":
        notes.append("EV/EBITDA: net cash (debt) held at today's level; debt taken on later is not included.")
    if res["dcf_value_raw"] is not None and res["dcf_value_raw"] <= 0:
        notes.append("FCF valuation is negative: free cash flow stays below zero in the projected years. "
                     "Enter the FCF margin you expect, or rely on the multiple.")
    if not price:
        notes.append("Enter today's share price to see returns and upside.")
    res["warnings"] += notes
