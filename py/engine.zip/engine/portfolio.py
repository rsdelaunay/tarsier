"""Portfolio: what you hold, how much, and how it splits by company, sector and style.

You enter tickers and the amount invested in each (no share counts). Sector and style
(Growth / Value / Dividend) are worked out from the Peer Groups workbook and SEC data;
you can overwrite either. Everything lives in portfolio.xlsx next to Tarsier.exe.
"""
import json
import os
from datetime import date

from openpyxl import Workbook, load_workbook
from openpyxl.chart import PieChart, Reference
from openpyxl.chart.label import DataLabelList
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

from . import edgar, metrics, paths, peers, rules

SECTORS = ["Information Technology", "Communication Services", "Consumer Discretionary", "Consumer Staples",
           "Health Care", "Financials", "Industrials", "Energy", "Materials", "Utilities", "Real Estate",
           "Diversified (fund)", "Cash"]
STYLES = ["Growth", "Value", "Dividend", "Blend (index fund)", "Cash"]
CASH = "CASH"          # type CASH as the ticker for money not invested
CONVICTIONS = ["High conviction", "Conviction", "Gamble"]     # caps in rules.CONVICTION_CAPS
UNKNOWN = "Not classified"
CURRENCIES = ["€", "$", "£", "CHF"]
FACTS = os.path.join(paths.CACHE, "portfolio_facts.json")
MAX_AGE_DAYS = 7

# Funds have no SEC financial statements: the common ones are known here, the rest you classify by hand.
_BROAD = "Diversified (fund)", "Blend (index fund)"
FUNDS = {
    **{t: _BROAD for t in ("VOO", "SPY", "IVV", "SPLG", "VTI", "ITOT", "VT", "VXUS", "VEA", "VWO", "IWM",
                           "DIA", "RSP", "VWCE", "VWRL", "VWRA", "IWDA", "SWDA", "EUNL", "CSPX", "SXR8",
                           "VUSA", "VUAA", "SPYL", "SSAC", "EIMI", "IMAE", "XDWD", "SPPW", "ACWI", "URTH")},
    **{t: ("Diversified (fund)", "Growth") for t in ("QQQ", "QQQM", "VUG", "SCHG", "IWF", "MGK", "SPYG",
                                                     "EQQQ", "CNDX", "SXRV", "EQQQ")},
    **{t: ("Diversified (fund)", "Value") for t in ("VTV", "SCHV", "IWD", "SPYV", "VOOV", "IUSV", "IWVL")},
    **{t: ("Diversified (fund)", "Dividend") for t in ("SCHD", "VYM", "DGRO", "JEPI", "JEPQ", "HDV", "DVY",
                                                       "NOBL", "SDY", "VIG", "VHYL", "TDIV", "FUSD", "SPYD")},
    **{t: ("Information Technology", "Growth") for t in ("XLK", "VGT", "SMH", "SOXX", "SOXQ", "IGV", "SEMI")},
    **{t: ("Health Care", "Value") for t in ("XLV", "VHT")},
    **{t: ("Financials", "Value") for t in ("XLF", "VFH")},
    **{t: ("Energy", "Dividend") for t in ("XLE", "VDE")},
    **{t: ("Utilities", "Dividend") for t in ("XLU", "VPU")},
    **{t: ("Real Estate", "Dividend") for t in ("VNQ", "XLRE")},
    CASH: ("Cash", "Cash"),
}


# ---------- sector ------------------------------------------------------------------------------
def _sic_sector(sic):
    """US SIC code → nearest GICS sector. Rough by nature: the Peer Groups workbook wins where it lists the ticker."""
    try:
        s = int(sic)
    except (TypeError, ValueError):
        return None
    table = [
        (100, 999, "Consumer Staples"), (1000, 1099, "Materials"), (1200, 1399, "Energy"),
        (1400, 1499, "Materials"), (1520, 1531, "Consumer Discretionary"), (1500, 1799, "Industrials"),
        (2000, 2199, "Consumer Staples"), (2200, 2399, "Consumer Discretionary"), (2400, 2499, "Materials"),
        (2500, 2599, "Consumer Discretionary"), (2600, 2699, "Materials"), (2700, 2799, "Communication Services"),
        (2830, 2836, "Health Care"), (2840, 2844, "Consumer Staples"), (2800, 2899, "Materials"),
        (2900, 2999, "Energy"), (3000, 3099, "Materials"), (3100, 3199, "Consumer Discretionary"),
        (3200, 3399, "Materials"), (3400, 3499, "Industrials"), (3570, 3579, "Information Technology"),
        (3500, 3599, "Industrials"), (3630, 3639, "Consumer Discretionary"), (3651, 3652, "Consumer Discretionary"),
        (3660, 3679, "Information Technology"), (3600, 3699, "Industrials"),
        (3710, 3716, "Consumer Discretionary"), (3750, 3751, "Consumer Discretionary"), (3700, 3799, "Industrials"),
        (3812, 3812, "Industrials"), (3820, 3829, "Information Technology"), (3840, 3851, "Health Care"),
        (3860, 3869, "Information Technology"), (3870, 3999, "Consumer Discretionary"),
        (4950, 4959, "Industrials"), (4000, 4799, "Industrials"), (4800, 4899, "Communication Services"),
        (4900, 4999, "Utilities"), (5120, 5122, "Health Care"), (5140, 5149, "Consumer Staples"),
        (5170, 5172, "Energy"), (5000, 5199, "Industrials"), (5400, 5499, "Consumer Staples"),
        (5912, 5912, "Consumer Staples"), (5200, 5999, "Consumer Discretionary"), (6500, 6553, "Real Estate"),
        (6798, 6798, "Real Estate"), (6000, 6799, "Financials"), (7000, 7099, "Consumer Discretionary"),
        (7200, 7299, "Consumer Discretionary"), (7311, 7319, "Communication Services"),
        (7370, 7379, "Information Technology"), (7300, 7399, "Industrials"), (7500, 7599, "Consumer Discretionary"),
        (7990, 7999, "Consumer Discretionary"), (7800, 7989, "Communication Services"),
        (8000, 8099, "Health Care"), (8200, 8299, "Consumer Discretionary"), (8700, 8799, "Industrials"),
    ]
    for lo, hi, name in table:
        if lo <= s <= hi:
            return name
    return None


_WB_SECTORS = None


def _workbook_sectors():
    """{ticker: (sector, industry)} from the Industries sheet of the Peer Groups workbook."""
    global _WB_SECTORS
    if _WB_SECTORS is not None:
        return _WB_SECTORS
    out = {}
    path = peers._workbook()
    if path:
        wb = load_workbook(path, read_only=True, data_only=True)
        if "Industries" in wb.sheetnames:
            head = None
            for row in wb["Industries"].iter_rows(values_only=True):
                cells = [str(c).strip() if c is not None else "" for c in row]
                if head is None:
                    if "Peers" in cells and "Sector" in cells:
                        head = {n: i for i, n in enumerate(cells) if n}
                    continue
                if not cells or not cells[0]:
                    continue
                sector = cells[head["Sector"]]
                members = peers._tickers(cells[head["Peers"]])
                if "Also followed" in head:
                    members += peers._tickers(cells[head["Also followed"]])
                for t in members:
                    out.setdefault(t.rstrip("*"), (sector, cells[0]))
        wb.close()
    _WB_SECTORS = out
    return out


# ---------- SEC facts for one ticker (cached a week) -------------------------------------------
def _cache():
    try:
        with open(FACTS, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _save_cache(data):
    os.makedirs(paths.CACHE, exist_ok=True)
    with open(FACTS, "w", encoding="utf-8") as f:
        json.dump(data, f)


def _fresh(entry):
    try:
        return (date.today() - date.fromisoformat(entry["asof"])).days <= MAX_AGE_DAYS
    except (KeyError, TypeError, ValueError):
        return False


def _facts_from(facts, subs):
    co = metrics.Company(facts)
    st = peers.stats_from(co) or {}
    end = st.get("period_end")
    snap = co.snapshot(end) if end else {}
    return {
        "name": (subs or {}).get("name") or facts.get("entityName"),
        "sic": (subs or {}).get("sic"), "industry": (subs or {}).get("sicDescription"),
        "period_end": end, "rev_growth": st.get("rev_growth"),
        "net_income": co.ttm("net_income", end) if end else None,
        "fcf": co.ttm("fcf", end) if end else None,
        "dividends": co.cf_ttm("dividends", end) if end else None,
        "shares": (snap or {}).get("shares_diluted"),
    }


def facts(ticker, offline=False):
    """What the classification needs about one company, or None (fund, foreign filer, not found)."""
    t = ticker.upper()
    if t in FUNDS:          # funds and cash have no SEC statements: never look them up
        return None
    cache = _cache()
    entry = cache.get(t)
    if entry and (_fresh(entry) or offline):
        return entry["facts"]
    try:
        raw, subs, _status = edgar.update(t, offline)
        f = _facts_from(raw, subs)
    except (edgar.SecError, RuntimeError, KeyError, ValueError, TypeError):
        return entry["facts"] if entry else None
    cache[t] = {"asof": date.today().isoformat(), "facts": f}
    _save_cache(cache)
    return f


def saved_price(ticker):
    """The share price you typed on page 2, if the company has a model file."""
    path = os.path.join(paths.COMPANIES, ticker.upper(), f"{ticker.upper()}_model.xlsx")
    if not os.path.exists(path):
        return None
    try:
        from .model_xlsx import read_user
        p = read_user(path).get("settings", {}).get("price")
        return float(p) if p else None
    except Exception:
        return None


# ---------- classification ----------------------------------------------------------------------
def _pct(x):
    return f"{x * 100:.1f}%"


def classify(ticker, f, price=None):
    """(sector, style, why). Uses the Peer Groups workbook, SEC facts and the page 2 price when there is one."""
    t = ticker.upper()
    if t in FUNDS:
        sector, style = FUNDS[t]
        return sector, style, ("cash: money not invested" if t == CASH else "fund: known index or sector ETF")
    sector = _workbook_sectors().get(t, (None, None))[0] or _sic_sector((f or {}).get("sic"))
    if not f:
        return sector or UNKNOWN, UNKNOWN, "no SEC data (fund or foreign filer?): choose sector and style yourself"
    g, div = f.get("rev_growth"), f.get("dividends") or 0.0
    earn = max(f.get("net_income") or 0.0, f.get("fcf") or 0.0)
    yld = div / (price * f["shares"]) if price and f.get("shares") and div > 0 else None
    payout = div / earn if earn > 0 and div > 0 else None
    gtxt = f"revenue {g * 100:+.1f}%" if g is not None else "revenue growth n/a"
    if yld is not None and yld >= rules.PORT_DIV_YIELD_MIN:
        return sector or UNKNOWN, "Dividend", f"dividend yield {_pct(yld)} (≥ {_pct(rules.PORT_DIV_YIELD_MIN)}), {gtxt}"
    if g is not None and g >= rules.PORT_GROWTH_MIN:
        extra = f", yield {_pct(yld)}" if yld else (f", pays {_pct(payout)} of earnings" if payout else "")
        return sector or UNKNOWN, "Growth", f"{gtxt} (≥ {_pct(rules.PORT_GROWTH_MIN)}){extra}"
    if payout is not None and payout >= rules.PORT_DIV_PAYOUT_MIN:
        return sector or UNKNOWN, "Dividend", f"pays {_pct(payout)} of earnings as dividends, {gtxt}"
    if g is None:
        return sector or UNKNOWN, UNKNOWN, "not enough quarters to measure growth: choose the style yourself"
    tail = f", pays {_pct(payout)} of earnings" if payout else ", no dividend"
    return sector or UNKNOWN, "Value", f"{gtxt} (< {_pct(rules.PORT_GROWTH_MIN)}){tail}"


# ---------- the holdings file -------------------------------------------------------------------
HEAD = ["Ticker", "Amount invested", "Weight", "Sector (auto)", "Style (auto)", "Sector (yours)",
        "Style (yours)", "Sector used", "Style used", "Why this style", "Conviction (yours)"]
FIRST = 5          # first holding row in the Holdings sheet


def load(path=None):
    """{'currency': '€', 'rows': [{ticker, amount, sector, style, sector_user, style_user, why}]}"""
    path = path or paths.PORTFOLIO
    out = {"currency": "€", "rows": []}
    if not os.path.exists(path):
        return out
    ws = load_workbook(path, data_only=True)["Holdings"]
    cur = ws["C2"].value
    if cur:
        out["currency"] = str(cur)
    for r in range(FIRST, ws.max_row + 1):
        t = ws.cell(r, 1).value
        if not t or str(t).strip().upper() == "TOTAL":
            continue
        amt = ws.cell(r, 2).value
        out["rows"].append({
            "ticker": str(t).strip().upper(),
            "amount": float(amt) if isinstance(amt, (int, float)) else None,
            "sector": ws.cell(r, 4).value or None, "style": ws.cell(r, 5).value or None,
            "sector_user": ws.cell(r, 6).value or None, "style_user": ws.cell(r, 7).value or None,
            "why": ws.cell(r, 10).value or "",
            "conviction": _conv(ws.cell(r, 11).value),
        })
    return out


def _conv(v):
    v = str(v or "").strip()
    return next((c for c in CONVICTIONS if c.lower() == v.lower()), None)


def used(row, key):
    return row.get(f"{key}_user") or row.get(key) or UNKNOWN


def summary(rows):
    """Weights by ticker, sector and style: {'total', 'ticker': [(name, amount, weight)], 'sector', 'style'}"""
    live = [r for r in rows if r.get("ticker") and (r.get("amount") or 0) > 0]
    total = sum(r["amount"] for r in live)
    out = {"total": total}
    for key in ("ticker", "sector", "style"):
        agg = {}
        for r in live:
            name = r["ticker"] if key == "ticker" else used(r, key)
            agg[name] = agg.get(name, 0.0) + r["amount"]
        out[key] = sorted(((n, a, a / total) for n, a in agg.items()), key=lambda x: -x[1]) if total else []
    return out


def fold(items, max_slices=None):
    """Keep the largest slices; the rest become one 'Other' slice."""
    max_slices = max_slices or rules.PORT_MAX_SLICES
    if len([1 for n, _a, _w in items if n != UNKNOWN]) < max_slices:      # 7 colours + grey
        return list(items), []
    keep, rest = items[:max_slices - 1], items[max_slices - 1:]
    return keep + [("Other", sum(a for _n, a, _w in rest), sum(w for _n, _a, w in rest))], [n for n, _a, _w in rest]


def save(data, path=None):
    """Write portfolio.xlsx: Holdings (your inputs, live formulas) and Summary (tables and pie charts)."""
    path = path or paths.PORTFOLIO
    navy = "1B2A41"
    yellow = PatternFill("solid", fgColor="FFF3CF")
    head_fill = PatternFill("solid", fgColor=navy)
    thin = Side(style="thin", color="D9DEE5")
    box = Border(top=thin, bottom=thin, left=thin, right=thin)
    f_head, f_body, f_blue = (Font(name="Arial", bold=True, color="FFFFFF", size=10), Font(name="Arial", size=10),
                              Font(name="Arial", size=10, color="0000FF"))
    cur = data.get("currency") or "€"
    money = f'"{cur}"#,##0;-"{cur}"#,##0;-' if cur in ("€", "$", "£") else f'#,##0" {cur}";-#,##0" {cur}";-'
    rows = [r for r in data["rows"] if r.get("ticker")]

    wb = Workbook()
    ws = wb.active
    ws.title = "Holdings"
    ws["A1"] = "Tarsier Research · Portfolio"
    ws["A1"].font = Font(name="Georgia", bold=True, size=14, color=navy)
    ws["A2"], ws["C2"] = "Currency", cur
    ws["A2"].font, ws["C2"].font, ws["C2"].fill = f_body, f_blue, yellow
    ws["A3"] = ("Yellow cells are yours: ticker, amount, Sector/Style (yours) to overwrite the automatic "
                "classification, and Conviction (High conviction ≤30%, Conviction ≤10%, Gamble ≤3%). "
                "Edit here or in the Tarsier window (Portfolio).")
    ws["A3"].font = Font(name="Arial", size=9, italic=True, color="6B7785")
    for c, h in enumerate(HEAD, 1):
        cell = ws.cell(FIRST - 1, c, h)
        cell.font, cell.fill, cell.border = f_head, head_fill, box
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    last = FIRST + max(len(rows), 1) - 1 + 10           # room for ten more holdings typed in Excel
    for i in range(FIRST, last + 1):
        r = rows[i - FIRST] if i - FIRST < len(rows) else {}
        vals = [r.get("ticker"), r.get("amount"), f'=IF(B{i}="","",IFERROR(B{i}/$B${last + 1},""))',
                r.get("sector"), r.get("style"), r.get("sector_user"), r.get("style_user"),
                f'=IF(A{i}="","",IF(F{i}<>"",F{i},IF(D{i}<>"",D{i},"{UNKNOWN}")))',
                f'=IF(A{i}="","",IF(G{i}<>"",G{i},IF(E{i}<>"",E{i},"{UNKNOWN}")))', r.get("why"), r.get("conviction")]
        for c, v in enumerate(vals, 1):
            cell = ws.cell(i, c, v)
            cell.border, cell.font = box, f_body
            if c in (1, 2, 6, 7, 11):
                cell.fill, cell.font = yellow, f_blue
        ws.cell(i, 2).number_format = money
        ws.cell(i, 3).number_format = "0.0%"
    tot = last + 1
    ws.cell(tot, 1, "TOTAL").font = Font(name="Arial", bold=True, size=10)
    ws.cell(tot, 2, f"=SUM(B{FIRST}:B{last})").number_format = money
    ws.cell(tot, 2).font = Font(name="Arial", bold=True, size=10)
    ws.cell(tot, 3, f"=IF(B{tot}>0,SUM(C{FIRST}:C{last}),\"\")").number_format = "0.0%"
    dv_s = DataValidation(type="list", formula1='"' + ",".join(SECTORS) + '"', allow_blank=True)
    dv_y = DataValidation(type="list", formula1='"' + ",".join(STYLES) + '"', allow_blank=True)
    dv_c = DataValidation(type="list", formula1='"' + ",".join(CURRENCIES) + '"', allow_blank=False)
    dv_k = DataValidation(type="list", formula1='"' + ",".join(CONVICTIONS) + '"', allow_blank=True)
    for dv in (dv_s, dv_y, dv_c, dv_k):
        ws.add_data_validation(dv)
    dv_s.add(f"F{FIRST}:F{last}")
    dv_y.add(f"G{FIRST}:G{last}")
    dv_c.add("C2")
    dv_k.add(f"K{FIRST}:K{last}")
    for c, w in zip(range(1, 12), (10, 16, 9, 24, 14, 24, 16, 24, 16, 60, 18)):
        ws.column_dimensions[get_column_letter(c)].width = w
    ws.row_dimensions[FIRST - 1].height = 30
    ws.freeze_panes = f"B{FIRST}"

    # Summary: three tables with SUMIF formulas, each with a pie chart beside it
    sm = wb.create_sheet("Summary")
    sm["A1"] = "Portfolio concentration"
    sm["A1"].font = Font(name="Georgia", bold=True, size=14, color=navy)
    sm["A2"] = "Live formulas on the Holdings sheet. Categories are listed as of the last save from Tarsier."
    sm["A2"].font = Font(name="Arial", size=9, italic=True, color="6B7785")
    s = summary(rows)
    rng = f"Holdings!$B${FIRST}:$B${last}"
    cols = {"ticker": f"Holdings!$A${FIRST}:$A${last}", "sector": f"Holdings!$H${FIRST}:$H${last}",
            "style": f"Holdings!$I${FIRST}:$I${last}"}
    top = 4
    for key, title in (("ticker", "By company"), ("sector", "By sector"), ("style", "By style")):
        names = [n for n, _a, _w in s[key]] or ["—"]
        for c, h in enumerate((title, "Amount", "Weight"), 1):
            cell = sm.cell(top, c, h)
            cell.font, cell.fill, cell.border = f_head, head_fill, box
        for j, n in enumerate(names, top + 1):
            sm.cell(j, 1, n).font = f_body
            sm.cell(j, 2, f'=SUMIF({cols[key]},A{j},{rng})').number_format = money
            sm.cell(j, 3, f"=IFERROR(B{j}/SUM($B${top + 1}:$B${top + len(names)}),0)").number_format = "0.0%"
            for c in (1, 2, 3):
                sm.cell(j, c).border = box
                sm.cell(j, c).font = f_body
        pie = PieChart()
        pie.title = title
        pie.add_data(Reference(sm, min_col=2, min_row=top, max_row=top + len(names)), titles_from_data=True)
        pie.set_categories(Reference(sm, min_col=1, min_row=top + 1, max_row=top + len(names)))
        pie.dataLabels = DataLabelList()
        pie.dataLabels.showPercent = True
        pie.height, pie.width = 7.5, 12
        pie.roundedCorners = False
        pie.legend.overlay = False
        sm.add_chart(pie, f"E{top}")
        top += max(len(names) + 3, 17)
    for c, w in zip("ABC", (26, 16, 10)):
        sm.column_dimensions[c].width = w
    backup(path)
    tmp = path + ".tmp"
    try:
        wb.save(tmp)                 # write a copy first, then swap: a crash never leaves a half-written file
        os.replace(tmp, path)
    except PermissionError:
        try:
            os.remove(tmp)
        except OSError:
            pass
        from .excel import FileOpenError
        raise FileOpenError("portfolio.xlsx is open in Excel: close it and save again.") from None
    return path


BACKUPS = os.path.join(paths.BASE, "_backups")
KEEP_BACKUPS = 30


def backup(path=None, now=False):
    """Once a day, before the first change, keep a copy of portfolio.xlsx in _backups (the last 30 copies).
    now=True: an extra copy right away (Settings → Back up now), stamped with the time."""
    path = path or paths.PORTFOLIO
    if not os.path.exists(path):
        return None
    import shutil
    from datetime import datetime
    os.makedirs(BACKUPS, exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M") if now else date.today().isoformat()
    dest = os.path.join(BACKUPS, f"portfolio_{stamp}.xlsx")
    if now or not os.path.exists(dest):
        try:
            shutil.copy2(path, dest)
        except OSError:
            return None
    old = sorted(f for f in os.listdir(BACKUPS) if f.startswith("portfolio_") and f.endswith(".xlsx"))
    for f in old[:-KEEP_BACKUPS]:
        try:
            os.remove(os.path.join(BACKUPS, f))
        except OSError:
            pass
    return dest
