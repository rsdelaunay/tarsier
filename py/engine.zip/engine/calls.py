"""Earnings calls, read with fixed rules (no AI, no cost).

Transcripts come from Alpha Vantage (free key, 25 requests a day): one entry per speaker turn, with the speaker's
name and title. Tarsier keeps them in companies/<TICKER>/calls/<YYYYQn>.json and reads them with the
Loughran-McDonald finance word lists (tone, uncertainty, hedging), simple rules for guidance and evasive answers,
and a comparison with the previous call. The transcript never leaves the PC (it is licensed text); the phone only
ever gets the reading.
"""
import json
import os
import re
import time
import urllib.parse
import urllib.request
from collections import Counter

from .lm_words import WORDS

AV_URL = "https://www.alphavantage.co/query"
GUIDE_URL = "https://www.alphavantage.co/support/#api-key"

# ---------- rules (all in one place, like rules.py) ----------------------------------------------------------
MANAGEMENT = re.compile(r"chief|\bceo\b|\bcfo\b|\bcoo\b|\bcto\b|president|officer|investor relations|\bir\b|"
                        r"head of|vice president|\bvp\b|\bevp\b|\bsvp\b|director|founder|chair|treasurer|"
                        r"controller|general manager|executive|managing director|\bgm\b", re.I)
FORWARD = re.compile(r"\b(expect\w*|anticipat\w*|guid\w*|outlook|forecast\w*|we (?:now )?see|going forward|"
                     r"next (?:quarter|year)|full[- ]year|fiscal (?:year )?20\d\d|for the (?:year|quarter)|"
                     r"target\w*|project(?:ed|ing|ion)s?|on track|range of|between)\b", re.I)
NUMBER = re.compile(r"(?:\$\s?\d[\d,]*(?:\.\d+)?\s?(?:billion|million|thousand|[bmk]\b)?|"
                    r"\b\d[\d,]*(?:\.\d+)?\s?(?:%|percent|percentage points?|basis points|bps|billion|million|x\b)|"
                    r"\b(?:mid|high|low)[- ](?:single|double|teens|twenties|thirties)[- ]?(?:digits?|percent)?)", re.I)
RAISED = re.compile(r"\b(rais\w*|increas\w*|lift\w*|upgrad\w*|higher than (?:our )?(?:prior|previous)|"
                    r"above (?:our )?(?:prior|previous|the high end))\b", re.I)
LOWERED = re.compile(r"\b(lower(?:ed|ing)? (?:our|the) (?:guid\w*|outlook|forecast|range)|reduc\w* (?:our|the) "
                     r"(?:guid\w*|outlook|forecast|range)|cut\w* (?:our|the)|below (?:our )?(?:prior|previous)|"
                     r"withdraw\w*)\b", re.I)
KEPT = re.compile(r"\b(reaffirm\w*|reiterat\w*|maintain\w* (?:our|the)|unchanged|on track)\b", re.I)
GUIDE_WORD = re.compile(r"\b(guid\w*|outlook|forecast\w*|range|expect\w*)\b", re.I)
DODGE = re.compile(r"(we (?:don't|do not|won't|will not) (?:break|disclose|provide|comment|guide|give|share|"
                   r"get into|quantify|split)|not (?:going|in a position) to (?:comment|give|provide|share|disclose|"
                   r"guide|quantify)|too early to (?:say|tell|comment|quantify)|(?:don't|do not) want to get ahead|"
                   r"(?:we'll|we will) (?:share|talk about|update you|provide) (?:more|that) (?:later|at|when|in)|"
                   r"(?:can't|cannot) (?:comment|get into|quantify|give)|we're not (?:providing|giving|guiding))",
                   re.I)
VAGUE_MIN_WORDS = 120          # a long answer ...
VAGUE_HEDGE = 2.0              # ... with this many hedging words per 100 words and no number is vague
TOPICS = {
    "AI": ["ai", "artificial intelligence", "genai", "generative", "agent", "agents", "agentic", "llm", "inference",
           "gpu", "gpus", "accelerator", "accelerators", "model", "models"],
    "Demand": ["demand", "pipeline", "bookings", "backlog", "orders", "rpo", "visibility"],
    "Pricing": ["pricing", "price", "prices", "asp", "asps", "discount", "discounting", "monetization"],
    "Margins": ["margin", "margins", "profitability", "operating leverage", "mix"],
    "Costs": ["cost", "costs", "opex", "headcount", "efficiency", "restructuring", "savings"],
    "Competition": ["competition", "competitor", "competitors", "competitive", "share gains", "market share"],
    "Macro": ["macro", "economy", "economic", "recession", "consumer", "interest rate", "interest rates",
              "inflation", "uncertainty", "fx", "currency"],
    "Tariffs & trade": ["tariff", "tariffs", "export", "exports", "china", "trade", "sanctions"],
    "Supply": ["supply", "capacity", "constraint", "constraints", "constrained", "shortage", "inventory",
               "lead times", "data center", "data centers", "power"],
    "Customers": ["customer", "customers", "churn", "retention", "renewal", "renewals", "net retention",
                  "expansion", "seats", "users"],
    "Cash & capital": ["free cash flow", "cash flow", "buyback", "buybacks", "repurchase", "repurchases",
                       "dividend", "capex", "capital expenditure", "capital expenditures", "balance sheet", "debt"],
    "M&A": ["acquisition", "acquisitions", "acquire", "acquired", "merger", "integration", "deal"],
    "Regulation": ["regulation", "regulatory", "antitrust", "doj", "ftc", "compliance", "lawsuit", "litigation"],
}
STOP = set("""a about above after again against all also am an and any are as at be because been before being below
between both but by can could did do does doing down during each few for from further had has have having he her
here hers him his how i if in into is it its itself just let me more most my no nor not now of off on once only or
other our ours out over own same she should so some such than that the their them then there these they this those
through to too under until up very was we were what when where which while who whom why will with would you your
yeah yes okay ok thank thanks thanks good morning afternoon evening great question questions really think know
going get got lot little bit kind sort mean just like well also one two three first second next last year years
quarter quarters call today us we're we've we'll i'm it's that's there's don't you're they're see said say much
many way things thing time maybe still back new make made right sure look looking want able need around across
overall continue continued continues based terms term particularly obviously certainly actually""".split())


# ---------- fetching ---------------------------------------------------------------------------------------
def api_key():
    from . import config                 # imported here: the phone's engine has no config.json
    return ((config.read().get("alphavantage") or {}).get("key") or "").strip()


def save_key(k):
    from . import config
    config.update(alphavantage={"key": (k or "").strip()})


def folder(ticker):
    from . import paths
    d = os.path.join(paths.company_dir(ticker), "calls")
    os.makedirs(d, exist_ok=True)
    return d


def _path(ticker, quarter):
    return os.path.join(folder(ticker), f"{quarter}.json")


def stored(ticker):
    """Quarters already on disk, newest first (YYYYQn)."""
    try:
        names = os.listdir(folder(ticker))
    except OSError:
        return []
    qs = [n[:-5] for n in names if re.fullmatch(r"\d{4}Q[1-4]\.json", n)]
    out = []
    for q in qs:
        c = load(ticker, q)
        if c and c.get("turns"):
            out.append(q)
    return sorted(out, reverse=True)


def load(ticker, quarter):
    try:
        with open(_path(ticker, quarter), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def quarter_of(label, end=None):
    """Tarsier's 'FY2026 Q3' -> '2026Q3' (Alpha Vantage uses fiscal quarters); else the calendar quarter of end."""
    m = re.search(r"FY(\d{4})\s*Q([1-4])", label or "")
    if m:
        return f"{m.group(1)}Q{m.group(2)}"
    if end:
        y, mo = int(str(end)[:4]), int(str(end)[5:7])
        return f"{y}Q{(mo - 1) // 3 + 1}"
    return None


def previous(q):
    y, n = int(q[:4]), int(q[5])
    return f"{y - 1}Q4" if n == 1 else f"{y}Q{n - 1}"


class Limit(Exception):
    """Alpha Vantage said no: no key, the daily limit, or a premium-only answer."""


OUT_OF_REQUESTS = ("no free requests left today: the free key allows 25 a day. Calls already saved still open; "
                   "try again tomorrow")
_last_ask = [0.0]
GAP = 1.5          # Alpha Vantage's free key: at most one request a second, or it answers "Thank you for using…"


def _per_day(msg):
    m = msg.lower()
    return "per day" in m or "daily" in m or "premium" in m and "second" not in m


def _get_av(ticker, quarter, key, tries=3, ask=None):
    """One answer from Alpha Vantage. Too quick a second request gets a polite note instead of the data:
    wait and ask again (up to 3 times). The daily limit and premium-only answers are real refusals."""
    for i in range(tries):
        wait = _last_ask[0] + GAP * (i + 1) - time.time()
        if wait > 0:
            time.sleep(wait)
        _last_ask[0] = time.time()
        try:
            return (ask or _ask_av)(ticker, quarter, key)
        except Limit as e:
            if _per_day(str(e)):
                raise Limit(OUT_OF_REQUESTS) from None
            if i == tries - 1:
                raise


def _ask_av(ticker, quarter, key):
    url = AV_URL + "?" + urllib.parse.urlencode({"function": "EARNINGS_CALL_TRANSCRIPT", "symbol": ticker,
                                                  "quarter": quarter, "apikey": key})
    req = urllib.request.Request(url, headers={"User-Agent": "Tarsier Research", "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        data = json.loads(r.read().decode("utf-8"))
    for k in ("Information", "Note", "Error Message"):
        if isinstance(data, dict) and data.get(k):
            raise Limit(str(data[k])[:240])
    return data


def parse_av(data):
    """Alpha Vantage's answer -> turns [{speaker, title, text, av_sentiment}]."""
    rows = (data or {}).get("transcript") or []
    turns = []
    for r in rows:
        text = (r.get("content") or "").strip()
        if not text:
            continue
        try:
            s = float(r.get("sentiment")) if r.get("sentiment") not in (None, "") else None
        except (TypeError, ValueError):
            s = None
        turns.append({"speaker": (r.get("speaker") or "").strip(), "title": (r.get("title") or "").strip(),
                      "text": text, "av_sentiment": s})
    return turns


def fetch(ticker, quarter, force=False, say=None):
    """The call for one quarter, from disk or Alpha Vantage. Returns the stored dict or None (no transcript)."""
    have = load(ticker, quarter)
    if have and not force and (have.get("turns") or time.time() - have.get("fetched", 0) < 7 * 86400):
        return have if have.get("turns") else None              # a miss is remembered for a week
    key = api_key()
    if not key:
        raise Limit("no Alpha Vantage key: add the free key in Settings → Earnings calls")
    if say:
        say(f"Asking Alpha Vantage for {ticker} {quarter}…")
    turns = parse_av(_get_av(ticker, quarter, key))
    rec = {"ticker": ticker, "quarter": quarter, "source": "Alpha Vantage", "fetched": time.time(), "turns": turns}
    with open(_path(ticker, quarter), "w", encoding="utf-8") as f:
        json.dump(rec, f, ensure_ascii=False)
    return rec if turns else None


def fetch_latest(ticker, label, end, say=None):
    """The latest call and the one before it (for the comparison). At most 4 requests."""
    tried, got = [], []
    q = quarter_of(label, end)
    cal = quarter_of(None, end)
    order = [q] + ([cal] if cal and cal != q else []) + [previous(q)]
    for cand in order:
        if cand in tried or not cand:
            continue
        tried.append(cand)
        c = fetch(ticker, cand, say=say)
        if c:
            got.append(c)
            break
    if got:
        p = previous(got[0]["quarter"])
        try:
            prev = fetch(ticker, p, say=say)
        except Limit:
            prev = None
        if prev:
            got.append(prev)
    return got


# ---------- when the call was held -----------------------------------------------------------------------
_MONTHS = "January February March April May June July August September October November December".split()
_DATE = re.compile(r"\b(" + "|".join(_MONTHS) + r")\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(20\d\d)\b")


def call_date(call, quarter_end=None, subs=None):
    """(YYYY-MM-DD, how it is known) for the day of the call, or (None, None):
    - said in the call's first minutes ("…today, November 5, 2026"), when it falls after the quarter;
    - else the earnings release at the SEC (8-K item 2.02) filed after the quarter: the call is that day or the next."""
    end = str(quarter_end or "")[:10]
    for t in (call.get("turns") or [])[:6]:
        for m in _DATE.finditer(t.get("text") or ""):
            d = f"{m.group(3)}-{_MONTHS.index(m.group(1)) + 1:02d}-{int(m.group(2)):02d}"
            if end and end < d <= _plus(end, 120):
                return d, "said in the call"
    if end and subs:
        r = ((subs.get("filings") or {}).get("recent")) or {}
        found = [d for f, it, d in zip(r.get("form", []), r.get("items", []), r.get("filingDate", []))
                 if f in ("8-K", "8-K/A") and "2.02" in (it or "") and end < d <= _plus(end, 120)]
        if found:
            return min(found), "results release (SEC 8-K)"
    return None, None


def _plus(iso, days):
    import datetime as _dt
    return (_dt.date.fromisoformat(iso) + _dt.timedelta(days=days)).isoformat()


# ---------- reading ------------------------------------------------------------------------------------
def _words(text):
    return re.findall(r"[a-z]+(?:'[a-z]+)?", text.lower())


def _sentences(text):
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+(?=[A-Z\"'(])", text) if s.strip()]


def role(turn):
    sp, ti = turn["speaker"].lower(), turn["title"].lower()
    if sp == "operator" or "operator" in ti:
        return "operator"
    if MANAGEMENT.search(ti):
        return "management"
    return "analyst"


def _tone(words):
    n = max(len(words), 1)
    c = {k: sum(1 for w in words if w in WORDS[k]) for k in ("positive", "negative", "uncertainty", "weak_modal",
                                                               "strong_modal", "litigious")}
    pos, neg = c["positive"], c["negative"]
    return {"words": len(words), "positive": pos, "negative": neg,
            "net": (pos - neg) / (pos + neg) if pos + neg else 0.0,          # -1 … +1
            "pos_k": pos / n * 1000, "neg_k": neg / n * 1000,
            "uncertainty_k": c["uncertainty"] / n * 1000, "hedge_k": (c["weak_modal"] + c["uncertainty"]) / n * 1000,
            "strong_k": c["strong_modal"] / n * 1000, "litigious_k": c["litigious"] / n * 1000}


def _topics(text_low, nwords):
    out = {}
    for t, terms in TOPICS.items():
        hits = sum(len(re.findall(r"\b" + re.escape(x) + r"\b", text_low)) for x in terms)
        out[t] = {"hits": hits, "per_k": hits / max(nwords, 1) * 1000}
    return out


def _bigrams(words):
    ws = [w for w in words if w not in STOP and len(w) > 2 and not w.isdigit()]
    return Counter(f"{a} {b}" for a, b in zip(ws, ws[1:]))


def _direction(s):
    if LOWERED.search(s):
        return "lowered"
    if RAISED.search(s) and GUIDE_WORD.search(s):
        return "raised"
    if KEPT.search(s):
        return "reaffirmed"
    return "outlook"


def analyze(call, prev=None):
    """The reading of one call (and the comparison with the call before it, when there is one)."""
    turns = [dict(t, role=role(t)) for t in call["turns"]]
    qa_from = next((i for i, t in enumerate(turns) if t["role"] == "analyst"), len(turns))
    for i, t in enumerate(turns):
        t["section"] = "qa" if i >= qa_from else "prepared"
    mgmt = [t for t in turns if t["role"] == "management"]
    all_text = " ".join(t["text"] for t in turns if t["role"] != "operator")
    words = _words(all_text)
    prep_words = _words(" ".join(t["text"] for t in mgmt if t["section"] == "prepared"))
    qa_words = _words(" ".join(t["text"] for t in mgmt if t["section"] == "qa"))

    # guidance: forward-looking management sentences with a number
    guidance, kpis, seen = [], [], set()
    for t in mgmt:
        for s in _sentences(t["text"]):
            if len(s) < 30 or s in seen:
                continue
            seen.add(s)
            has_num = bool(NUMBER.search(s))
            if has_num and FORWARD.search(s):
                guidance.append({"text": s, "speaker": t["speaker"], "direction": _direction(s),
                                 "section": t["section"]})
            elif has_num and len(kpis) < 40:
                kpis.append({"text": s, "speaker": t["speaker"]})

    # Q&A: each analyst question and the management answer that follows
    qa, i = [], qa_from
    while i < len(turns):
        t = turns[i]
        if t["role"] != "analyst":
            i += 1
            continue
        j, ans = i + 1, []
        while j < len(turns) and turns[j]["role"] == "management":
            ans.append(turns[j])
            j += 1
        a_text = " ".join(x["text"] for x in ans)
        a_words = _words(a_text)
        hedge = sum(1 for w in a_words if w in WORDS["weak_modal"] or w in WORDS["uncertainty"])
        nums = len(NUMBER.findall(a_text))
        dodge = DODGE.search(a_text)
        q_low = t["text"].lower()
        topics = [k for k, terms in TOPICS.items() if any(re.search(r"\b" + re.escape(x) + r"\b", q_low)
                                                           for x in terms)]
        hedge_100 = hedge / max(len(a_words), 1) * 100
        vague = bool(dodge) or (nums == 0 and len(a_words) >= VAGUE_MIN_WORDS and hedge_100 >= VAGUE_HEDGE)
        qa.append({"analyst": t["speaker"], "firm": t["title"], "question": t["text"], "topics": topics,
                   "answer_by": sorted({x["speaker"] for x in ans}), "answer_words": len(a_words),
                   "numbers": nums, "hedge_100": hedge_100, "dodge": dodge.group(0) if dodge else None,
                   "vague": vague, "turn": i, "answer_turns": list(range(i + 1, j))})
        i = j

    tone = _tone(words)
    res = {"ticker": call["ticker"], "quarter": call["quarter"], "turns": turns, "tone": tone,
           "tone_prepared": _tone(prep_words), "tone_qa": _tone(qa_words),
           "topics": _topics(all_text.lower(), len(words)), "guidance": guidance, "kpis": kpis[:12], "qa": qa,
           "speakers": _speakers(turns), "bigrams": _bigrams(words),
           "share_qa": len(qa_words) / max(len(prep_words) + len(qa_words), 1)}
    res["vs"] = _compare(res, analyze(prev) if prev else None)
    res["points"] = _points(res)
    return res


def _speakers(turns):
    d = {}
    for t in turns:
        if t["role"] == "operator":
            continue
        s = d.setdefault(t["speaker"], {"name": t["speaker"], "title": t["title"], "role": t["role"], "words": 0,
                                        "turns": 0})
        s["words"] += len(_words(t["text"]))
        s["turns"] += 1
    return sorted(d.values(), key=lambda s: (s["role"] != "management", -s["words"]))


def _compare(now, before):
    if not before:
        return None
    t0, t1 = before["tone"], now["tone"]
    topics = []
    for k in TOPICS:
        a, b = before["topics"][k]["per_k"], now["topics"][k]["per_k"]
        if max(a, b) >= 0.8:
            topics.append({"topic": k, "now": b, "before": a, "change": b - a})
    topics.sort(key=lambda x: -abs(x["change"]))
    bg0, bg1 = before["bigrams"], now["bigrams"]
    n0, n1 = max(before["tone"]["words"], 1), max(now["tone"]["words"], 1)
    new = sorted(((p, c) for p, c in bg1.items() if c >= 3 and c / n1 > 2.5 * (bg0.get(p, 0) + 0.5) / n0),
                 key=lambda x: -x[1])[:8]
    gone = sorted(((p, c) for p, c in bg0.items() if c >= 3 and bg1.get(p, 0) == 0), key=lambda x: -x[1])[:6]
    return {"quarter": before["quarter"], "net": t1["net"] - t0["net"],
            "uncertainty_k": t1["uncertainty_k"] - t0["uncertainty_k"], "hedge_k": t1["hedge_k"] - t0["hedge_k"],
            "before": {"net": t0["net"], "uncertainty_k": t0["uncertainty_k"], "hedge_k": t0["hedge_k"]},
            "topics": topics, "new_phrases": new, "gone_phrases": gone,
            "guidance_before": len(before["guidance"]), "qa_before": len(before["qa"])}


def _ql(q):
    return f"FY{q[:4]} Q{q[5]}"


def tone_word(net):
    return ("very positive" if net >= 0.6 else "positive" if net >= 0.3 else "balanced" if net >= -0.1
            else "negative" if net >= -0.4 else "very negative")


def _points(r):
    pts = []
    t, v = r["tone"], r["vs"]
    pts.append(f"Tone {tone_word(t['net'])} ({t['net']:+.2f} on −1…+1)"
               + (f", {'up' if v['net'] > 0.03 else 'down' if v['net'] < -0.03 else 'about the same'} vs "
                  f"{_ql(v['quarter'])} ({v['before']['net']:+.2f})" if v else ""))
    if v and abs(v["uncertainty_k"]) >= 1:
        pts.append(f"Uncertainty words {'up' if v['uncertainty_k'] > 0 else 'down'}: "
                   f"{t['uncertainty_k']:.1f} per 1,000 words (was {v['before']['uncertainty_k']:.1f})")
    d = Counter(g["direction"] for g in r["guidance"])
    if r["guidance"]:
        bits = [f"{d[k]} {k}" for k in ("raised", "lowered", "reaffirmed") if d[k]]
        pts.append(f"{len(r['guidance'])} forward-looking statements with numbers" + (f" ({', '.join(bits)})"
                                                                                      if bits else ""))
    else:
        pts.append("No forward-looking statement with a number: no quantified guidance in the call")
    asked = Counter(k for q in r["qa"] for k in q["topics"])
    if asked:
        pts.append("Analysts asked most about " + ", ".join(f"{k} ({n})" for k, n in asked.most_common(3)))
    vague = [q for q in r["qa"] if q["vague"]]
    if r["qa"]:
        pts.append(f"{len(r['qa'])} questions; {len(vague)} answered vaguely" + (
            " (" + ", ".join(sorted({q['analyst'] for q in vague})[:3]) + ")" if vague else ""))
    if r["tone_qa"]["words"] and r["tone_prepared"]["words"]:
        gap = r["tone_qa"]["net"] - r["tone_prepared"]["net"]
        if gap <= -0.2:
            pts.append(f"Less upbeat when answering than in the script ({r['tone_qa']['net']:+.2f} vs "
                       f"{r['tone_prepared']['net']:+.2f})")
    return pts


def marks(text):
    """Where to highlight a passage: [(start, end, kind)] for numbers, guidance, hedging and dodges."""
    out = []
    for m in NUMBER.finditer(text):
        out.append((m.start(), m.end(), "number"))
    for m in DODGE.finditer(text):
        out.append((m.start(), m.end(), "dodge"))
    for m in re.finditer(r"[A-Za-z]+(?:'[a-z]+)?", text):
        w = m.group(0).lower()
        if w in WORDS["weak_modal"] or w in WORDS["uncertainty"]:
            out.append((m.start(), m.end(), "hedge"))
    pos = 0
    for s in _sentences(text):
        k = text.find(s, pos)
        if k < 0:
            continue
        pos = k + len(s)
        if NUMBER.search(s) and FORWARD.search(s):
            out.append((k, k + len(s), "guidance"))
    return out
