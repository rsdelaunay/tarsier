"""ZETA_report.xlsx: the report card as it will look on the website, the 8-quarter
trend, and the raw tables (for Power Query). Written by the engine on every run."""
from openpyxl import Workbook
from openpyxl.chart import LineChart, Reference
from openpyxl.formatting.rule import CellIsRule, ColorScaleRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from . import excel

FONT = "Arial"
NAVY, GOLD, INK, MUTED, LINE = "1B2A41", "C9962E", "1F2933", "6B7785", "D9DEE5"
GOOD_BG, GOOD_FG = "E3F2E6", "1E7B34"
BAD_BG, BAD_FG = "FBE4E2", "B3261E"
NEUTRAL_BG = "F1F3F6"
GRADE_COLORS = {"A": ("1E7B34", "FFFFFF"), "B": ("7FB77E", "FFFFFF"), "C": ("E9B54B", INK),
                "D": ("E07B39", "FFFFFF"), "F": ("B3261E", "FFFFFF")}
THIN = Side(style="thin", color=LINE)
M = 1e6


def f(size=10, bold=False, color=INK, italic=False):
    return Font(name=FONT, size=size, bold=bold, color=color, italic=italic)


def fill(c):
    return PatternFill("solid", fgColor=c)


def pct(x):
    return None if x is None else x / 100


def money(x):
    return None if x is None else x / M


def _set(ws, ref, value, font=None, fmt=None, bg=None, align=None, border=False):
    c = ws[ref]
    c.value = value
    c.font = font or f()
    if fmt:
        c.number_format = fmt
    if bg:
        c.fill = fill(bg)
    if align:
        c.alignment = align
    if border:
        c.border = Border(bottom=THIN)
    return c


def _section(ws, row, title, ncols=7):
    _set(ws, f"A{row}", title, f(11, True, NAVY))
    for col in range(1, ncols + 1):
        ws.cell(row=row, column=col).border = Border(bottom=Side(style="medium", color=GOLD))
    return row + 1


def _header_row(ws, row, labels):
    for i, lab in enumerate(labels, 1):
        c = ws.cell(row=row, column=i, value=lab)
        c.font, c.fill = f(9, True, "FFFFFF"), fill(NAVY)
        c.alignment = Alignment(horizontal="left" if i in (1, 6) else "center", vertical="center", wrap_text=True)
    ws.row_dimensions[row].height = 28
    return row + 1


def _verdict(ws, row, col, good):
    if good is None:
        c = ws.cell(row=row, column=col, value="■ neutral")
        c.font, c.fill = f(9, False, MUTED), fill(NEUTRAL_BG)
    else:
        c = ws.cell(row=row, column=col, value="▲ good" if good else "▼ bad")
        c.font = f(9, True, GOOD_FG if good else BAD_FG)
        c.fill = fill(GOOD_BG if good else BAD_BG)
    c.alignment = Alignment(horizontal="center")


def _grade_fill(grade):
    return GRADE_COLORS.get((grade or "F")[0], GRADE_COLORS["F"])


def _parts(g):
    return {p["id"]: p for b in g["blocks"].values() for p in b["parts"]}


def _moved(p):
    """◯+ / ◯− when this input pushed the grade (same rule as the circles)."""
    if not p or p.get("points") is None:
        return None
    if p["points"] >= 90:
        return "◯ +"
    if p["points"] <= 40:
        return "◯ −"
    return None


def _good_pp(pp, tol=0.25, lower_is_better=False):
    if pp is None or abs(pp) < tol:
        return None
    return (pp < 0) if lower_is_better else (pp > 0)


def headline_rows(m, g):
    """(metric, last year, this quarter, change, change_fmt, value_fmt, good, comment, moved)"""
    r, e, c, mg, s, b, d = (m["revenue"], m["eps"], m["cash"], m["margins"], m["sbc"],
                            m["balance"], m["dilution"])
    cur, prior = m["cur"], m["prior"]
    P = _parts(g)
    rows = []

    note = []
    if r["organic_yoy_pct"] is not None:
        note.append(f"organic {r['organic_yoy_pct']:+.1f}%")
    if r["yoy_pct_prev_quarter"] is not None:
        note.append(f"last quarter {r['yoy_pct_prev_quarter']:+.1f}%"
                    + (" · accelerating" if (r["accel_pp"] or 0) >= 3 else
                       " · decelerating" if (r["accel_pp"] or 0) <= -3 else ""))
    rows.append(("Revenue ($M)", money(r["prior"]), money(r["cur"]), pct(r["yoy_pct"]), "+0.0%;-0.0%",
                 "#,##0.0", None if r["yoy_pct"] is None else r["yoy_pct"] > 0, " · ".join(note),
                 _moved(P.get("revenue_growth"))))

    gv = P.get("rev_vs_guidance", {})
    rows.append(("Revenue vs guidance midpoint", None, pct(gv.get("value")), None, None, "+0.0%;-0.0%",
                 None if gv.get("value") is None else gv["value"] >= 0,
                 " · ".join(x for x in [gv.get("note"), P.get("beat_vs_habit", {}).get("note")] if x)
                 or "enter guidance in the inputs file", _moved(gv)))
    cv = P.get("rev_vs_consensus", {})
    rows.append(("Revenue vs consensus", None, pct(cv.get("value")), None, None, "+0.0%;-0.0%",
                 None if cv.get("value") is None else cv["value"] >= 0,
                 cv.get("note") or "enter consensus in the inputs file", _moved(cv)))
    gp = P.get("guidance", {})
    rows.append(("Full-year guidance", None, gp.get("value") or "n/a", None, None, "@",
                 {"raised": True, "lowered": False}.get(gp.get("value")), gp.get("note") or "", _moved(gp)))

    cy = m["cost_of_revenue_yoy_pct"]
    faster = None if cy is None or r["yoy_pct"] is None else cy > r["yoy_pct"]
    rows.append(("Cost of revenue ($M)", money(prior["cost_of_revenue"]), money(cur["cost_of_revenue"]),
                 pct(cy), "+0.0%;-0.0%", "#,##0.0", None if faster is None else not faster,
                 "" if faster is None else
                 f"{'faster' if faster else 'slower'} than revenue ({cy - r['yoy_pct']:+.1f}pp)", None))
    for key, label, pid in (("gross", "Gross margin", "gross"), ("operating", "Operating margin", "operating"),
                            ("net", "Net margin", "net")):
        v = mg[key]
        rows.append((label, pct(v["prior"]), pct(v["cur"]), None if v["pp"] is None else v["pp"],
                     '+0.0"pp";-0.0"pp"', "0.0%", _good_pp(v["pp"]), "", _moved(P.get(pid))))

    good_eps = None if e["classification"] is None else e["classification"] in (
        "turned profitable", "profit grew", "loss narrowed")
    eps_change = pct(e["yoy_pct"]) if e["gaap_prior"] is not None and e["gaap_prior"] > 0 else None
    rows.append(("GAAP EPS ($)", e["gaap_prior"], e["gaap_cur"], eps_change, "+0.0%;-0.0%", "0.00", good_eps,
                 (e["classification"] or "") + (" · estimated (Q4)" if e["approx"] else ""), None))
    if e["nongaap_cur"] is not None:
        ng_chg = None
        if e["nongaap_prior"]:
            ng_chg = (e["nongaap_cur"] - e["nongaap_prior"]) / abs(e["nongaap_prior"])
        gap = f"gap to GAAP ${e['gap']:.2f}" if e["gap"] is not None else ""
        if e["sbc_per_share"] is not None and gap:
            gap += f", of which SBC ≈ ${e['sbc_per_share']:.2f}"
        rows.append(("Non-GAAP EPS ($)", e["nongaap_prior"], e["nongaap_cur"], ng_chg, "+0.0%;-0.0%", "0.00",
                     None if ng_chg is None else ng_chg > 0, gap, None))

    rows.append(("FCF margin", pct(c["fcf_margin_prior"]), pct(c["fcf_margin_cur"]), c["fcf_margin_pp"],
                 '+0.0"pp";-0.0"pp"', "0.0%", _good_pp(c["fcf_margin_pp"]),
                 (f"FCF ${c['fcf_cur'] / M:,.1f}M" if c["fcf_cur"] is not None else "")
                 + (f" · last 12 months {c['fcf_margin_ttm']:.1f}% (the level that is scored)"
                    if c["fcf_margin_ttm"] is not None else ""), _moved(P.get("fcf_margin"))))
    pa = None
    if prior.get("fcf") is not None and prior.get("sbc") is not None and prior["revenue"]:
        pa = (prior["fcf"] - prior["sbc"]) / prior["revenue"] * 100
    after_pp = None if pa is None or c["fcf_after_sbc_margin"] is None else c["fcf_after_sbc_margin"] - pa
    rows.append(("FCF after SBC margin", pct(pa), pct(c["fcf_after_sbc_margin"]), after_pp,
                 '+0.0"pp";-0.0"pp"', "0.0%", _good_pp(after_pp), "the cash left once paying staff in stock"
                 + (f" · last 12 months {c['fcf_after_sbc_margin_ttm']:.1f}%"
                    if c["fcf_after_sbc_margin_ttm"] is not None else ""),
                 _moved(P.get("fcf_after_sbc"))))
    rows.append(("SBC % of revenue", pct(s["pct_rev_prior"]), pct(s["pct_rev_cur"]), s["pp_yoy"],
                 '+0.0"pp";-0.0"pp"', "0.0%", _good_pp(s["pp_yoy"], 0.5, lower_is_better=True),
                 "rising is negative (house rule)", _moved(P.get("sbc_trend"))))
    dp = P.get("dilution", {})
    rows.append(("Basic shares (M)", money(d["basic_shares_prior"]), money(d["basic_shares_cur"]),
                 pct(d["yoy_pct"]), "+0.0%;-0.0%", "#,##0.0",
                 None if dp.get("points") is None else dp["points"] >= 60,
                 "dilution · " + (dp.get("note") or ""), _moved(dp)))
    if P.get("rule_of_40", {}).get("applies") and m["rule_of_40"] is not None:
        rows.append(("Rule of 40", None, m["rule_of_40"], None, None, "0", m["rule_of_40"] >= 40,
                     f"scored revenue growth + FCF margin, {c['level_basis']} (software only)", _moved(P.get("rule_of_40"))))
    return rows


def debt_rows(m, g):
    """Same shape as headline_rows: debt, its cost, when it falls due, and the assets behind it."""
    d, a, P = m["debt"], m["assets"], _parts(g)
    rev_yoy = m["revenue"]["yoy_pct"]
    PP, PCT = '+0.0"pp";-0.0"pp"', "+0.0%;-0.0%"
    rows = []
    if d["total"]:
        note = []
        if d["pct_revenue_ttm"] is not None:
            note.append(f"{d['pct_revenue_ttm']:.0f}% of a year's revenue")
        if d["yoy_pct"] is not None and rev_yoy is not None:
            note.append(f"debt {d['yoy_pct']:+.0f}% vs revenue {rev_yoy:+.0f}%")
        if d["finance_leases"]:
            note.append(f"incl. finance leases ${d['finance_leases'] / M:,.1f}M")
        pace = d["revenue_minus_debt_growth_pp"]
        rows.append(("Total debt ($M)", money(d["total_prior_year"]), money(d["total"]), pct(d["yoy_pct"]), PCT,
                     "#,##0.0", None if pace is None or not d["material"] else pace >= 0, " · ".join(note),
                     _moved(P.get("debt_pace"))))
    nd = d["net_debt_to_ebitda"]
    rows.append(("Net cash (debt) ($M)", money(d["net_cash_prior_year"]), money(d["net_cash"]), None, None,
                 "#,##0.0;(#,##0.0)", None if d["net_cash"] is None else d["net_cash"] >= 0,
                 (f"cash ${d['liquid'] / M:,.1f}M" if d["liquid"] is not None else "")
                 + (f" − debt ${d['total'] / M:,.1f}M" if d["total"] else " · no debt")
                 + (f" · net debt {nd:.1f}x EBITDA (12 months)" if nd is not None else ""),
                 _moved(P.get("net_debt"))))
    if d["total"]:
        both = d["interest_q"] and d["interest_prior"] and d["interest_q"] > 0 and d["interest_prior"] > 0
        rows.append(("Interest expense ($M)", money(d["interest_prior"]), money(d["interest_q"]),
                     (d["interest_q"] - d["interest_prior"]) / d["interest_prior"] if both else None, PCT,
                     "#,##0.0;(#,##0.0)", None, "as reported: some companies show it net of interest income", None))
        r_c, r_p = d["avg_rate_pct"], d["avg_rate_prior_pct"]
        note = "interest × 4 ÷ average debt"
        if d["disclosed_rate_pct"] is not None:
            note += f" · rate disclosed in the filing {d['disclosed_rate_pct']:.2f}%"
        if r_c is not None and r_c < 2:
            note += " · looks too low: see step 6"
        rows.append(("Average interest rate (a year)", pct(r_p), pct(r_c),
                     None if r_c is None or r_p is None else r_c - r_p, PP, "0.00%", None, note, None))
        ir, ir_p = d["interest_pct_revenue"], d["interest_pct_revenue_prior"]
        ipp = None if ir is None or ir_p is None else ir - ir_p
        rows.append(("Interest % of revenue", pct(ir_p), pct(ir), ipp, PP, "0.00%",
                     _good_pp(ipp, 0.25, lower_is_better=True), "what the debt costs against what the business sells",
                     None))
        cv = d["interest_cover"]
        rows.append(("Interest cover (EBITDA ÷ interest)", None, cv, None, None, '0.0"x"',
                     None if cv is None else (True if cv >= 6 else False if cv < 2.5 else None),
                     d["interest_cover_basis"] or "", _moved(P.get("interest_cover"))))
        nc = d["near_term_cover"]
        note = []
        if nc is not None:
            note.append(f"covered {nc:.1f}x by cash")
        if d["avg_maturity_years"] is not None:
            note.append(f"average maturity ≈ {d['avg_maturity_years']:.1f} years")
        rows.append((f"Debt due within ~{d['near_term_months']} months ($M)", None, money(d["near_term"]), None, None,
                     "#,##0.0", None if nc is None else (True if nc >= 1.5 else False if nc < 1 else None),
                     " · ".join(note) or "maturity schedule not found in the filing", _moved(P.get("maturity"))))
    o = m["margins"]["operating"]["cur"]
    rows.append(("EBITDA margin", pct(a["ebitda_margin_prior"]), pct(a["ebitda_margin"]), a["ebitda_margin_pp"], PP,
                 "0.0%", _good_pp(a["ebitda_margin_pp"]),
                 "" if a["depreciation_drag_pp"] is None or o is None else
                 f"operating margin is {o:.1f}%: depreciation and amortisation take {a['depreciation_drag_pp']:.1f}pp",
                 _moved(P.get("ebitda"))))
    dpp = None if a["da_pct_revenue"] is None or a["da_pct_revenue_prior"] is None \
        else a["da_pct_revenue"] - a["da_pct_revenue_prior"]
    rows.append(("D&A % of revenue", pct(a["da_pct_revenue_prior"]), pct(a["da_pct_revenue"]),
                 dpp, PP, "0.0%", _good_pp(dpp, 0.25, lower_is_better=True),
                 "" if a["da_yoy_pct"] is None or rev_yoy is None else
                 f"D&A {a['da_yoy_pct']:+.0f}% vs revenue {rev_yoy:+.0f}%", None))
    if a["capex_pct_revenue"] is not None:
        ratio = a["capex_to_depreciation"]
        rows.append(("Capex % of revenue", None, pct(a["capex_pct_revenue"]), None, None, "0.0%", None,
                     "" if ratio is None else f"capex is {ratio:.1f}x depreciation: the asset base is "
                     f"{'growing' if ratio > 1.1 else 'shrinking' if ratio < 0.9 else 'stable'}", None))
    if a["ppe_net"]:
        note = [f"{a['intensity_pct']:.0f}% of a year's revenue"] if a["intensity_pct"] is not None else []
        if a["asset_heavy"] and a["remaining_life_years"] is not None:
            note.append(f"≈ {a['remaining_life_years']:.1f} years of life left at the current depreciation rate")
        rows.append(("Property & equipment, net ($M)", money(a["ppe_net_prior"]), money(a["ppe_net"]),
                     pct(a["ppe_yoy_pct"]), PCT, "#,##0.0", None, " · ".join(note), None))
    return rows


def fcf_rows(m, g):
    """Free cash flow over the last twelve months and where it went."""
    f, P = m["fcf"], _parts(g)
    PP, PCT = '+0.0"pp";-0.0"pp"', "+0.0%;-0.0%"
    gr = f["growth_pct"]
    note = ""
    if f["cfo_ttm"] is not None and f["capex_ttm"] is not None:
        note = f"cash from operations ${f['cfo_ttm'] / M:,.1f}M − capex ${f['capex_ttm'] / M:,.1f}M"
    rows = [("Free cash flow, 12 months ($M)", money(f["ttm_prior"]), money(f["ttm"]), pct(gr), PCT,
             "#,##0.0;(#,##0.0)", None if gr is None else gr > 0, note, _moved(P.get("fcf_margin"))),
            ("FCF margin, 12 months", pct(f["margin_ttm_prior"]), pct(f["margin_ttm"]), f["margin_pp"], PP, "0.0%",
             _good_pp(f["margin_pp"]), "the level the Cash block scores", None)]
    a, a_p = f["after_sbc_ttm"], f["after_sbc_ttm_prior"]
    rows.append(("FCF after SBC, 12 months ($M)", money(a_p), money(a),
                 (a - a_p) / a_p if a is not None and a_p and a_p > 0 else None, PCT, "#,##0.0;(#,##0.0)",
                 None if a is None else a > 0,
                 "" if f["sbc_ttm"] is None else f"stock-based pay ${f['sbc_ttm'] / M:,.1f}M in 12 months", None))
    for key, label in (("buybacks", "Buybacks, 12 months ($M)"), ("dividends", "Dividends, 12 months ($M)"),
                       ("acquisitions", "Acquisitions, 12 months ($M)"),
                       ("tax_withheld", "Taxes paid on employee stock, 12 months ($M)"),
                       ("net_borrowing", "Net borrowing (repayment), 12 months ($M)")):
        v = f["uses"].get(key)
        if v:
            share_ = f" · {v / f['ttm'] * 100:.0f}% of free cash flow" if f["ttm"] and f["ttm"] > 0 and v > 0 else ""
            rows.append((label, None, money(v), None, None, "#,##0.0;(#,##0.0)", None, share_.strip(" ·"), None))
    return rows


def _metric_table(ws, row, rows):
    for metric, prev, now, chg, chg_fmt, fmt, good, comment, moved in rows:
        _set(ws, f"A{row}", metric, f(10, True), border=True)
        _set(ws, f"B{row}", prev if prev is not None else "—", f(10, color=MUTED), fmt if prev is not None else None,
             align=Alignment(horizontal="right"), border=True)
        _set(ws, f"C{row}", now if now is not None else "n/a", f(10, True), fmt if now is not None else None,
             align=Alignment(horizontal="right"), border=True)
        _set(ws, f"D{row}", chg if chg is not None else "", f(10, True, MUTED if good is None else
                                                              (GOOD_FG if good else BAD_FG)),
             chg_fmt, align=Alignment(horizontal="right"), border=True)
        _verdict(ws, row, 5, good)
        _set(ws, f"F{row}", comment, f(9, color=MUTED), align=Alignment(wrap_text=True, vertical="center"),
             border=True)
        _set(ws, f"G{row}", moved, f(10, True, GOOD_FG if moved == "◯ +" else BAD_FG),
             align=Alignment(horizontal="center"), border=True)
        if len(comment or "") > 62:
            ws.row_dimensions[row].height = 27
        row += 1
    return row


def report_card(ws, ticker, name, m, g):
    ws.sheet_view.showGridLines = False
    for col, w in zip("ABCDEFGH", (30, 15, 15, 12, 17, 50, 10, 2)):
        ws.column_dimensions[col].width = w
    p = m["period"]
    _set(ws, "A1", "TARSIER RESEARCH  ·  SEE PAST THE HEADLINES", f(9, True, GOLD))
    _set(ws, "A2", f"{ticker}  ·  {name}", f(18, True, NAVY))
    _set(ws, "A3", f"{p['label']}  ·  quarter ended {p['end']}", f(11, True, INK))
    _set(ws, "A4", f"Graded against: {g['industry_group']}  ·  {g['company_type']} company  ·  "
                   f"source {p['form']} filed {p['filed']}  ·  method {g['method_version']}", f(9, color=MUTED))
    bg, fg = _grade_fill(g["grade"])
    ws.merge_cells("F2:F3")
    _set(ws, "F2", f"Quarter grade  {g['grade'] or 'n/a'}", f(20, True, fg), bg=bg,
         align=Alignment(horizontal="center", vertical="center"))
    _set(ws, "F4", ("n/a" if g["score"] is None else f"{g['score']:.1f} / 100")
         + ("  ·  PROVISIONAL: Execution inputs missing" if g["provisional"] else ""), f(10, True, fg), bg=bg,
         align=Alignment(horizontal="center"))
    ws.row_dimensions[2].height = 26

    row = _section(ws, 6, "PAST THE HEADLINES  ·  same quarter last year → this quarter")
    row = _header_row(ws, row, ["Metric", "Same quarter last year", "This quarter", "Change", "Verdict",
                                "Comment", "Moved the grade"])
    row = _metric_table(ws, row, headline_rows(m, g))

    d, a = m["debt"], m["assets"]
    row = _section(ws, row + 1, "DEBT AND ASSETS  ·  how much, how expensive, when it falls due, what stands behind it")
    ws.merge_cells(f"A{row}:G{row}")
    _set(ws, f"A{row}", a["profile"], f(9, True, NAVY), align=Alignment(wrap_text=True, vertical="center"))
    ws.row_dimensions[row].height = 27
    row = _header_row(ws, row + 1, ["Metric", "Same quarter last year", "This quarter", "Change", "Verdict",
                                    "Comment", "Moved the grade"])
    row = _metric_table(ws, row, debt_rows(m, g))
    extra = []
    if d["schedule"]:
        extra.append("Repayment ladder:  " + "  ·  ".join(f"{lab} ${amt / M:,.1f}M" for lab, amt in d["schedule"]))
    flows = [x for x in ((f"borrowed ${d['issued_ytd'] / M:,.1f}M" if d["issued_ytd"] else None),
                         (f"repaid ${d['repaid_ytd'] / M:,.1f}M" if d["repaid_ytd"] else None),
                         (f"interest paid in cash ${d['interest_paid_ytd'] / M:,.1f}M"
                          if d["interest_paid_ytd"] else None)) if x]
    if flows:
        extra.append("Year to date:  " + "  ·  ".join(flows))
    for line in extra:
        ws.merge_cells(f"A{row}:G{row}")
        _set(ws, f"A{row}", line, f(9, color=MUTED))
        row += 1

    row = _section(ws, row + 1, "FREE CASH FLOW  ·  how much, is it growing, and where does it go")
    ws.merge_cells(f"A{row}:G{row}")
    _set(ws, f"A{row}", m["fcf"]["verdict"], f(9, True, NAVY), align=Alignment(wrap_text=True, vertical="center"))
    ws.row_dimensions[row].height = 27
    row = _header_row(ws, row + 1, ["Metric", "Same 12 months a year ago", "Last 12 months", "Change", "Verdict",
                                    "Comment", "Moved the grade"])
    row = _metric_table(ws, row, fcf_rows(m, g))

    row = _section(ws, row + 1, "SCORECARD")
    row = _header_row(ws, row, ["Block", "Score", "Weight", "Contribution", "", "What it scores", ""])
    first = row
    used = sum(g["weights"][k] for k, b in g["blocks"].items() if b["score"] is not None)
    what = {"growth": "Revenue growth (organic when broken out), acceleration",
            "profitability": "Gross, operating, net margin change; GAAP EPS; operating leverage; rule of 40",
            "cash": "FCF margin and change, FCF after SBC, SBC trend",
            "balance": "Net cash or debt, interest cover, debt due soon, debt vs revenue pace, dilution", "execution": "Beats vs guidance and consensus, guidance change"}
    for k, b in g["blocks"].items():
        _set(ws, f"A{row}", k.capitalize(), f(10, True), border=True)
        _set(ws, f"B{row}", None if b["score"] is None else round(b["score"]), f(10, True), "0",
             align=Alignment(horizontal="right"), border=True)
        _set(ws, f"C{row}", g["weights"][k] / 100, f(10), "0%", align=Alignment(horizontal="right"), border=True)
        _set(ws, f"D{row}", None if b["score"] is None else b["score"] * g["weights"][k] / used, f(10), "0.0",
             align=Alignment(horizontal="right"), border=True)
        _set(ws, f"F{row}", what[k] + (f"  ·  {b['inputs_used']} of {b['inputs_total']} inputs"
                                       if b["inputs_used"] < b["inputs_total"] else ""), f(9, color=MUTED),
             border=True)
        row += 1
    ws.conditional_formatting.add(f"B{first}:B{row - 1}", ColorScaleRule(
        start_type="num", start_value=40, start_color="F4B6B0", mid_type="num", mid_value=70,
        mid_color="FBE7B5", end_type="num", end_value=95, end_color="A8D5B0"))
    for rule in g["house_rules_applied"]:
        _set(ws, f"A{row}", "House rule: " + rule, f(9, True, GOLD))
        row += 1

    row = _section(ws, row + 1, "THE ANNOTATED STATEMENT  ·  $M")
    row = _header_row(ws, row, ["Line", "Same quarter last year", "This quarter", "YoY",
                                "% of revenue", "Change in % of revenue", "Good / bad"])
    circled = set(g["circled"])
    for ln in m["statement"]:
        is_total = ln["kind"] in ("revenue", "profit")
        name = ("◯ " if ln["key"] in circled else "") + ln["name"]
        _set(ws, f"A{row}", name, f(10, is_total), border=True)
        for col, v in (("B", ln["prior"]), ("C", ln["cur"])):
            _set(ws, f"{col}{row}", money(v), f(10, is_total), "#,##0.0;(#,##0.0)",
                 align=Alignment(horizontal="right"), border=True)
        if ln["sign_flip"]:
            _set(ws, f"D{row}", "sign flip", f(9, color=MUTED), align=Alignment(horizontal="right"), border=True)
        elif ln["prior"] is not None and ln["prior"] < 0:
            _set(ws, f"D{row}", money(ln["cur"] - ln["prior"]) if ln["cur"] is not None else None,
                 f(9, color=MUTED), '+$#,##0.0"M";-$#,##0.0"M"', align=Alignment(horizontal="right"), border=True)
        else:
            _set(ws, f"D{row}", pct(ln["yoy_pct"]), f(10), "+0.0%;-0.0%", align=Alignment(horizontal="right"),
                 border=True)
        share = "100%" if ln["kind"] == "revenue" else (
            f"{ln['pct_rev_prior']:.1f}% → {ln['pct_rev_cur']:.1f}%"
            if ln["pct_rev_prior"] is not None and ln["pct_rev_cur"] is not None else "")
        _set(ws, f"E{row}", share, f(9, color=MUTED), align=Alignment(horizontal="right"), border=True)
        pp = ln["pp"] if ln["kind"] != "revenue" else None
        _set(ws, f"F{row}", "" if pp is None else f"{'▲' if pp > 0 else '▼'} {pp:+.1f}pp",
             f(10, True, MUTED if ln["good"] is None else (GOOD_FG if ln["good"] else BAD_FG)), border=True)
        if ln["kind"] != "revenue":
            _verdict(ws, row, 7, ln["good"])
        row += 1
    _set(ws, f"A{row}", "Colour = good or bad for the business, not up or down. ◯ = moved the grade.",
         f(8, italic=True, color=MUTED))

    row = _section(ws, row + 2, "NUMBERS THAT NEED AN EXPLANATION  ·  step 6")
    for q in m["questions"] or ["none"]:
        ws.merge_cells(f"A{row}:G{row}")
        _set(ws, f"A{row}", "☐  " + q, f(9), align=Alignment(wrap_text=True, vertical="top"))
        ws.row_dimensions[row].height = 26
        row += 1
    if g["warnings"]:
        row = _section(ws, row + 1, "DATA GAPS")
        for w in g["warnings"]:
            _set(ws, f"A{row}", w, f(9, color=BAD_FG))
            row += 1
    ws.merge_cells(f"A{row + 1}:G{row + 1}")
    _set(ws, f"A{row + 1}", "Educational analysis of published results, not a recommendation. "
                            "Thesis grade: assigned by the author after the call.", f(8, italic=True, color=MUTED))
    ws.freeze_panes = "A6"
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.fitToHeight = 0


TREND = [  # label, getter, number format, colour rule: "up" good, "down" good, None
    ("Quarter grade", lambda m, g: (g["grade"] or "") + ("*" if g["provisional"] else ""), "@", None),
    ("Score", lambda m, g: g["score"], "0.0", "up"),
    ("Revenue ($M)", lambda m, g: money(m["revenue"]["cur"]), "#,##0.0", None),
    ("Revenue YoY", lambda m, g: pct(m["revenue"]["yoy_pct"]), "0.0%", "up"),
    ("Organic revenue YoY", lambda m, g: pct(m["revenue"]["organic_yoy_pct"]), "0.0%", "up"),
    ("Cost of revenue YoY", lambda m, g: pct(m["cost_of_revenue_yoy_pct"]), "0.0%", None),
    ("Revenue minus cost growth (pp)", lambda m, g: None if m["cost_of_revenue_yoy_pct"] is None or
     m["revenue"]["yoy_pct"] is None else m["revenue"]["yoy_pct"] - m["cost_of_revenue_yoy_pct"],
     '+0.0;-0.0', "up"),
    ("Beat vs guidance midpoint", lambda m, g: pct(_parts(g).get("rev_vs_guidance", {}).get("value")),
     "+0.0%;-0.0%", "up"),
    ("Full-year guidance", lambda m, g: _parts(g).get("guidance", {}).get("value"), "@", None),
    ("Gross margin", lambda m, g: pct(m["margins"]["gross"]["cur"]), "0.0%", "up"),
    ("Operating margin", lambda m, g: pct(m["margins"]["operating"]["cur"]), "0.0%", "up"),
    ("Net margin", lambda m, g: pct(m["margins"]["net"]["cur"]), "0.0%", "up"),
    ("GAAP EPS ($)", lambda m, g: m["eps"]["gaap_cur"], "0.00", "up"),
    ("EPS vs last year", lambda m, g: m["eps"]["classification"], "@", None),
    ("FCF margin", lambda m, g: pct(m["cash"]["fcf_margin_cur"]), "0.0%", "up"),
    ("FCF margin, last 12 months", lambda m, g: pct(m["cash"]["fcf_margin_ttm"]), "0.0%", "up"),
    ("FCF after SBC margin", lambda m, g: pct(m["cash"]["fcf_after_sbc_margin"]), "0.0%", "up"),
    ("SBC % of revenue", lambda m, g: pct(m["sbc"]["pct_rev_cur"]), "0.0%", "down"),
    ("Basic shares YoY (dilution)", lambda m, g: pct(m["dilution"]["yoy_pct"]), "0.0%", "down"),
    ("Net cash (debt) ($M)", lambda m, g: money(m["balance"]["net_cash"]), "#,##0.0;(#,##0.0)", "up"),
    ("Total debt ($M)", lambda m, g: money(m["debt"]["total"]), "#,##0.0", None),
    ("Debt YoY", lambda m, g: pct(m["debt"]["yoy_pct"]), "0.0%", None),
    ("Net debt / EBITDA (x)", lambda m, g: m["debt"]["net_debt_to_ebitda"], "0.0", "down"),
    ("Average interest rate", lambda m, g: pct(m["debt"]["avg_rate_pct"]), "0.00%", None),
    ("Interest % of revenue", lambda m, g: pct(m["debt"]["interest_pct_revenue"]), "0.00%", "down"),
    ("Interest cover (x)", lambda m, g: m["debt"]["interest_cover"], "0.0", "up"),
    ("EBITDA margin", lambda m, g: pct(m["assets"]["ebitda_margin"]), "0.0%", "up"),
    ("D&A % of revenue", lambda m, g: pct(m["assets"]["da_pct_revenue"]), "0.0%", "down"),
    ("Capex % of revenue", lambda m, g: pct(m["assets"]["capex_pct_revenue"]), "0.0%", None),
]


def trend_sheet(ws, ticker, quarters):
    ws.sheet_view.showGridLines = False
    n = len(quarters)
    _set(ws, "A1", f"{ticker}  ·  the last {n} quarters, oldest → newest", f(14, True, NAVY))
    _set(ws, "A2", "Each column is one quarter compared with the same quarter a year earlier. "
                   "Colours run within each row: green = better for the business. "
                   "* = provisional grade (fewer than 3 of the 5 Execution inputs entered).", f(9, color=MUTED))
    ws.column_dimensions["A"].width = 32
    hdr = 4
    _set(ws, f"A{hdr}", "Metric", f(9, True, "FFFFFF"), bg=NAVY)
    for j, (m, g) in enumerate(quarters, 2):
        col = get_column_letter(j)
        ws.column_dimensions[col].width = 13
        _set(ws, f"{col}{hdr}", m["period"]["label"], f(9, True, "FFFFFF"), bg=NAVY,
             align=Alignment(horizontal="center"))
    for i, (label, get, fmt, rule) in enumerate(TREND, hdr + 1):
        _set(ws, f"A{i}", label, f(10, True), border=True)
        for j, (m, g) in enumerate(quarters, 2):
            v = get(m, g)
            c = _set(ws, f"{get_column_letter(j)}{i}", v if v is not None else "", f(10),
                     fmt if v is not None else None, align=Alignment(horizontal="center"), border=True)
            if label == "Quarter grade" and v:
                c.value = v
                bg, fg = _grade_fill(v)
                c.fill, c.font = fill(bg), f(11, True, fg)
        rng = f"B{i}:{get_column_letter(n + 1)}{i}"
        if rule == "up":
            ws.conditional_formatting.add(rng, ColorScaleRule(start_type="min", start_color="F4B6B0",
                                                              mid_type="percentile", mid_value=50,
                                                              mid_color="FFFFFF", end_type="max",
                                                              end_color="A8D5B0"))
        elif rule == "down":
            ws.conditional_formatting.add(rng, ColorScaleRule(start_type="min", start_color="A8D5B0",
                                                              mid_type="percentile", mid_value=50,
                                                              mid_color="FFFFFF", end_type="max",
                                                              end_color="F4B6B0"))
        if label == "Revenue minus cost growth (pp)":
            ws.conditional_formatting.add(rng, CellIsRule(operator="lessThan", formula=["0"],
                                                          font=Font(name=FONT, bold=True, color=BAD_FG)))
    ws.freeze_panes = "B5"

    rows = {label: i for i, (label, *_rest) in enumerate(TREND, hdr + 1)}
    last_col = n + 1

    def chart(title, labels, anchor, fmt="0%"):
        ch = LineChart()
        ch.title, ch.height, ch.width = title, 7.5, 16
        ch.roundedCorners = False
        for lab in labels:
            r = rows[lab]
            ch.add_data(Reference(ws, min_col=1, max_col=last_col, min_row=r, max_row=r),
                        titles_from_data=True, from_rows=True)
        for series in ch.series:
            series.smooth = False
        ch.set_categories(Reference(ws, min_col=2, max_col=last_col, min_row=hdr, max_row=hdr))
        ch.y_axis.number_format = fmt
        ch.y_axis.majorGridlines = None
        ch.x_axis.delete = False
        ch.y_axis.delete = False
        ch.legend.position = "b"
        ch.legend.overlay = False
        ch.title.overlay = False
        ws.add_chart(ch, anchor)

    base = hdr + len(TREND) + 3
    chart("Revenue growth vs cost of revenue growth", ["Revenue YoY", "Cost of revenue YoY"], f"A{base}")
    chart("Margins: gross, operating, net", ["Gross margin", "Operating margin", "Net margin"],
          f"F{base}")
    chart("Cash and dilution", ["FCF margin", "SBC % of revenue", "Basic shares YoY (dilution)"],
          f"A{base + 16}")
    chart("What the assets and the debt cost: % of revenue",
          ["D&A % of revenue", "Interest % of revenue", "Capex % of revenue"], f"F{base + 16}")


def write(path, ticker, name, quarters, data_tables):
    """quarters: [(metrics, grade)] oldest -> newest. data_tables: [(title, rows)]."""
    wb = Workbook()
    rc = wb.active
    rc.title = "Report card"
    report_card(rc, ticker, name, *quarters[-1])
    trend_sheet(wb.create_sheet("Trend"), ticker, quarters)
    for title, rows in data_tables:
        ws = wb.create_sheet(title)
        cols = list(rows[0].keys()) if rows else ["period_end"]
        excel._header(ws, cols, {"question": 110, "line": 32, "item": 40, "note": 40,
                                 "house_rules": 40, "data_gaps": 60})
        for r in rows:
            ws.append([r.get(c) for c in cols])
        excel._table(ws, f"{ticker}_{title}".replace("-", "_").replace(".", "_"), len(cols), len(rows))
        ws.sheet_properties.tabColor = "BFC5CE"
    excel._save(wb, path)
